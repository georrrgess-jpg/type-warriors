/* ===== RUNESTONE TOWER DEFENSE 9.0: the Wonderland Championship, its prize and the Tower Skins screen (95j, after 95i) =====
   A season leaderboard of the best wave reached in the endless Wonderland (map 4 only), built exactly like the Wildcard Ranked
   board (89w): the same seasons (rkSeason, six weeks), the same player key and name (#abcd), the same public Nostr relays
   (WCRELAYS), signatures, lazy verification, paging, offline copy and "Show me" switch. Each player's game posts one replaceable
   event per season (kind 30078, tags d/t = "twrp-lb-s<season>"): {v:1,s,n,w (best wave held),d (that run's game time, s),
   k (its kills),r (runs this season),t (when it was reached)}. Hidden players post {hide:1}.
   Checks (rpLbCheck, by every reader): the season tag and time window; whole numbers in range; at least RPLBWT game seconds per
   wave; enough kills for the waves; the run fits in the season even at 3x speed; not more runs than time allows; names cleaned
   (rkLbName). Ranking: most waves, then who reached it first.
   Prize: an hour after a season ends, the game reads that season's board once (rpLbPrize). If this player is first, it pays
   RPLB_PRIZE coins once and unlocks the Azure Dragon skin ('dragon:azure': blue steel, gold trim, blue fire), and shows the
   champion's ceremony. The season's champion is remembered (L.champ) and shown on the hub. The prize is advertised on the home
   screen (a championship card), the hub (a championship panel and top buttons), the board, the Wonderland side panel and result,
   the Tower Skins screen and the help text. No Updates-tab notice.
   Save: P.rp.lb via rpLbSt(): s (season), best/bt/bd/bk (this season's best run), runs, hide, last/pend/sent/at (sending), c (the
   board saved for offline), hist {season: best run}, chk {season: prize checked}, won {season: 1}, champ {season: {n,pk,w,me}},
   cel (a ceremony waiting). */
const RPLB={t:0,s:0,state:'idle',list:[],all:0,me:null,hidden:0,relays:0,reached:0,p:null,loading:null,pushT:0,pushQ:0,refT:0,busy:0};
/* 9.9f: the Wonderland Championship has its own calendar: season 1 (from WCRSEA.start, 12 Oct 2026) ends 11 Nov 2026 21:00 UTC (set by
   the owner: 14 days from 28 Oct 2026), then six-week seasons as before. Wildcard Ranked keeps rkSeason/rkSeasonEnd. */
const RPS1END=Date.UTC(2026,10,11,21,0),rpSeason=()=>{const n=Date.now();return n<RPS1END?1:2+Math.floor((n-RPS1END)/WCRSEA.len)},
 rpSeasonEnd=s=>s<=1?RPS1END:RPS1END+(s-1)*WCRSEA.len,rpSeaStart=s=>Math.floor((s<=1?WCRSEA.start:rpSeasonEnd(s-1))/1000);
const RPLBK=30078,RPLBWT=8,RPLB_PRIZE=50000,rpLbTag=s=>'twrp-lb-s'+s;
/* this player's key, without making one: reading the board must not give a fresh profile a key (only sending does) */
const rpMyPk=()=>{try{return P.rk&&/^[0-9a-f]{64}$/.test(P.rk.nsk||'')?rkLbKey().pk:''}catch(e){return''}};
function rpLbSt(){const r=RPP();let L=r.lb;if(!L||typeof L!=='object'||Array.isArray(L))L=r.lb={};
 const D={s:0,best:0,bt:0,bd:0,bk:0,runs:0,hide:0,last:'',pend:0,sent:0,at:0,c:null,hist:{},chk:{},won:{},champ:{},cel:0};
 for(const k in D)if(L[k]===undefined||(D[k]!==null&&(typeof L[k]!==typeof D[k]||Array.isArray(L[k]))))L[k]=D[k];
 const s=rpSeason();if(L.s!==s){if(L.s&&L.best>0&&!L.hist[L.s])L.hist[L.s]={w:L.best,t:L.bt,d:L.bd,k:L.bk,r:L.runs,hide:L.hide};Object.assign(L,{s,best:0,bt:0,bd:0,bk:0,runs:0,last:'',pend:0,sent:0,c:null})}
 return L}
const rpSeaLeft=()=>{const ms=rpSeasonEnd(rpSeason())-Date.now(),d=Math.floor(ms/864e5),h=Math.floor(ms/36e5);return d>=2?`${d} days left`:h>=1?`${h} h left`:'ends within the hour'};
/* ---------- what this player posts ---------- */
function rpLbMine(){const L=rpLbSt();return{v:1,s:L.s,n:rkLbName(P.name||'Player'),w:L.best,d:L.bd,k:L.bk,r:Math.max(1,L.runs),t:L.bt}}
const rpLbContent=()=>{const L=rpLbSt();return JSON.stringify(L.hide?{v:1,s:L.s,hide:1}:rpLbMine())};
const rpLbDirty=()=>{try{const L=rpLbSt();if(!L.hide&&L.best<1)return false;return !!L.pend||L.last!==rpLbContent()}catch(e){return false}};
async function rpLbPush(force){const L=rpLbSt(),rel=rkLbRelays();if(!rel.length)return 0;if(!L.hide&&L.best<1)return 0;
 if(RPLB.p){RPLB.again=1;return RPLB.p}const now=Date.now();
 if(now-RPLB.pushT<15000&&!force){clearTimeout(RPLB.pushQ);RPLB.pushQ=setTimeout(()=>rpLbPush(),15000-(now-RPLB.pushT));return 0}RPLB.pushT=now;clearTimeout(RPLB.pushQ);
 RPLB.p=(async()=>{let n=0;try{const K=rkLbKey(),txt=rpLbContent(),tg=rpLbTag(L.s);
  const at=Math.max(Math.floor(Date.now()/1000),(rpLbSt().at|0)+1);rpLbSt().at=at;
  const ev=await rkEvSign(K,RPLBK,[['d',tg],['t',tg],['t','twrp-lb']],txt,at);const oks=await Promise.all(rel.map(u=>rkRelaySend(u,ev,6000)));n=oks.filter(Boolean).length;
  const S2=rpLbSt();if(n){S2.sent=Date.now();S2.last=txt;S2.pend=0;RPLB.t=0;try{const k=rkSt();if(!k.lbSent)k.lbSent=Date.now()}catch(e){}}else S2.pend=1;save()}catch(e){try{rpLbSt().pend=1;save()}catch(x){}}
  finally{RPLB.p=null;if(RPLB.again){RPLB.again=0;if(rpLbDirty())setTimeout(()=>rpLbPush(true),50)}}rpLbPaint();return n})();return RPLB.p}
try{addEventListener('online',()=>{if(rpLbDirty())rpLbPush(true);rpLbPrize()})}catch(e){}
/* ---------- the checks ---------- */
function rpLbCheck(ev,season,now){try{now=now||Math.floor(Date.now()/1000);const S0=rpSeaStart(season),tg=rpLbTag(season);
 if(ev.kind!==RPLBK||!Array.isArray(ev.tags)||!ev.tags.some(t=>Array.isArray(t)&&t[0]==='d'&&t[1]===tg)||typeof ev.content!=='string'||ev.content.length>2000)return null;
 if(!rkInt(ev.created_at,S0-60,Math.min(now+600,rpSeaStart(season+1)+3600)))return null;
 const c=JSON.parse(ev.content);if(!c||typeof c!=='object'||Array.isArray(c)||c.v!==1||c.s!==season)return null;if(c.hide===1)return{hide:1,gone:c.gone===1};
 const{w,d,k,r,t}=c;if(!rkInt(w,1,5000)||!rkInt(d,w*RPLBWT,1e7)||!rkInt(k,Math.max(0,w*5-25),1e8)||!rkInt(r,1,1e6)||!rkInt(t,S0-60,ev.created_at+5))return null;
 if(t-Math.ceil(d/3)<S0-120)return null;/* even at 3x speed the run had to be played inside the season */
 if(r>(ev.created_at-S0)/3+5)return null;/* not more runs than time allows */
 return{pk:ev.pubkey,id:ev.id,t:ev.created_at,n:rkLbName(c.n),w,d,k,r,at:t,sc:w}}catch(e){return null}}
function rpLbSort(a,b){return b.w-a.w||a.at-b.at||a.d-b.d||(a.pk<b.pk?-1:a.pk>b.pk?1:0)}
async function rpLbHead(g,season,nowS){while(g.length){const ev=g[0],e=rpLbCheck(ev,season,nowS);if(e&&!e.hide){e.ev=ev;return e}
  if(g.length>1&&!(await rkEvOk(ev))){g.shift();continue}return e}return null}
/* read a season's board from every relay: the newest valid entry per player, verified, ranked (this player's own key left out) */
async function rpLbFetch(season){const rel=rkLbRelays();if(!rel.length)return{ok:0,relays:0,reached:0};const tg=rpLbTag(season);
 const res=await Promise.all(rel.map(u=>rkRelayQueryAll(u,{kinds:[RPLBK],'#t':[tg],limit:1000},6500))),reached=res.filter(x=>x.ok).length;if(!reached)return{ok:0,relays:rel.length,reached};
 const groups=new Map();for(const x of res)for(const ev of x.evs){if(!rkEvShape(ev))continue;let g=groups.get(ev.pubkey);if(!g)groups.set(ev.pubkey,g=[]);if(!g.some(o=>o.id===ev.id&&o.sig===ev.sig))g.push(ev)}
 const mine=rpMyPk(),nowS=Math.floor(Date.now()/1000),cand=[];let hidden=0;if(mine)groups.delete(mine);
 for(const g of groups.values()){g.sort((a,b)=>b.created_at-a.created_at||(a.id<b.id?-1:1));if(g.length>6)g.length=6;const e=await rpLbHead(g,season,nowS);if(!e)continue;if(e.hide){if(!e.gone)hidden++;continue}cand.push(e)}
 cand.sort(rpLbSort);const list=[];let i=0,k=0;
 while(i<cand.length&&list.length<100){const e=cand[i++];if(await rkEvOk(e.ev)){list.push(e);if(++k%10===0)await new Promise(r=>setTimeout(r,0));continue}
  const g=groups.get(e.pk);g.shift();const n=await rpLbHead(g,season,nowS);if(!n)continue;if(n.hide){if(!n.gone)hidden++;continue}
  let j=i;while(j<cand.length&&rpLbSort(cand[j],n)<0)j++;cand.splice(j,0,n)}
 return{ok:1,relays:rel.length,reached,list,rest:cand.slice(i),hidden}}
async function rpLbLoad(force){const L=rpLbSt(),now=Date.now();if(!force&&RPLB.state==='ok'&&now-RPLB.t<120000&&RPLB.s===L.s)return RPLB;if(RPLB.loading)return RPLB.loading;
 if(!rkLbRelays().length){RPLB.state='offline';RPLB.relays=0;RPLB.reached=0;rpLbPaint();return RPLB}RPLB.state=RPLB.state==='ok'&&RPLB.s===L.s?'ok':'loading';RPLB.busy=1;rpLbPaint();
 RPLB.loading=(async()=>{try{const season=L.s,f=await rpLbFetch(season);RPLB.relays=f.relays;RPLB.reached=f.reached;if(!f.ok){RPLB.state='offline';return RPLB}
  const list=f.list,rest=f.rest;let me=null,place=0;const L2=rpLbSt();
  if(!L2.hide&&L2.best>0){const c=rpLbMine();me={pk:rpMyPk()||'me',me:1,t:Math.floor((L2.sent||now)/1000),n:c.n,w:c.w,d:c.d,k:c.k,r:c.r,at:c.t,sc:c.w};
   place=list.filter(e=>rpLbSort(e,me)<0).length+rest.filter(e=>rpLbSort(e,me)<0).length+1;const at=list.findIndex(e=>rpLbSort(e,me)>0);
   if(at>=0){list.splice(at,0,me);if(list.length>100)list.length=100}else list.push(me);me.place=place}
  Object.assign(RPLB,{state:'ok',list,all:list.filter(e=>!e.me).length+rest.length+(me?1:0),me,hidden:f.hidden,t:Date.now(),s:season});
  try{L2.c={t:RPLB.t,s:season,list:list.map(e=>({pk:e.pk.slice(0,8),n:e.n,w:e.w,d:e.d,r:e.r,me:e.me?1:0})),all:RPLB.all,place};save()}catch(e){}
  if(rpLbDirty())rpLbPush(true);return RPLB}
 catch(e){RPLB.state='offline';return RPLB}finally{RPLB.loading=null;RPLB.busy=0;rpLbPaint()}})();return RPLB.loading}
/* ---------- the season's prize ---------- */
async function rpLbPrize(){if(RPLB.pz)return;const L=rpLbSt(),now=Date.now();const ss=Object.keys(L.hist).map(Number).filter(s=>s<L.s&&!L.chk[s]&&now>rpSeasonEnd(s)+36e5);if(!ss.length)return;RPLB.pz=1;
 try{for(const s of ss){const h=L.hist[s],f=await rpLbFetch(s);if(!f.ok)continue;const top=f.list[0]||null,me={pk:rpMyPk(),w:h.w,at:h.t,d:h.d};
   const win=!h.hide&&h.w>0&&(!top||rpLbSort(me,top)<0);
   L.champ[s]=win?{n:rkLbName(P.name||'Player'),pk:(me.pk||'').slice(0,4),w:h.w,me:1}:top?{n:top.n,pk:top.pk.slice(0,4),w:top.w}:null;L.chk[s]=1;
   if(win&&!L.won[s]){L.won[s]=1;RPP().own['dragon:azure']=1;P.gold=Math.min(1e12,(P.gold||0)+RPLB_PRIZE);try{stat('gold',RPLB_PRIZE,'add')}catch(e){}L.cel=s}save()}}
 catch(e){}finally{RPLB.pz=0}if(L.cel)rpChampCeremony()}
setTimeout(()=>{try{rpLbSt();rpLbPrize();if(rpLbDirty())rpLbPush(true)}catch(e){}},4500);
/* a reset or replaced save: its Wonderland entry leaves the board too (the Wildcard retire list, 89w, holds the old keys) */
async function rpLbRetireRun(){if(RPLB.ret||RKLB.ret)return;const rel=rkLbRelays();let L=rkLbRetireList();if(!rel.length||!L.some(x=>!x.rpd))return;RPLB.ret=1;
 try{for(const x of L){if(x.rpd)continue;const d=BigInt('0x'+x.nsk),pk=wcHx(wcN2b(wcMul(d)[0])),s=rpSeason(),tg=rpLbTag(s);
  /* only a key that has a visible Wonderland entry this season needs a "gone" entry */
  const got=await Promise.all(rel.map(u=>rkRelayQuery(u,{kinds:[RPLBK],authors:[pk],'#t':[tg],limit:4},5000)));if(!got.some(g=>g.ok))continue;
  const on=got.some(g=>g.evs.some(ev=>{try{const c=JSON.parse(ev.content);return ev.pubkey===pk&&c&&!c.hide}catch(e){return false}}));if(!on){x.rpd=1;continue}
  const ev=await rkEvSign({d,pk},RPLBK,[['d',tg],['t',tg],['t','twrp-lb']],JSON.stringify({v:1,s,hide:1,gone:1}));if((await Promise.all(rel.map(u=>rkRelaySend(u,ev,6000)))).some(Boolean))x.rpd=1}
  const cur=rkLbRetireList();for(const y of cur){const m=L.find(x=>x.nsk===y.nsk);if(m&&m.rpd)y.rpd=1}rkLbLs('twlbRetire',cur)}catch(e){}finally{RPLB.ret=0}}
setTimeout(()=>{try{rpLbRetireRun()}catch(e){}},6000);
/* a Wonderland run counts when it ends (before the result screen is drawn) */
{const f0=rpFinishEndless;rpFinishEndless=function(){const R=RPX;try{if(R&&!R.over){const held=R.heldAt!=null?R.heldAt:Math.max(0,R.wave-(R.wst==='build'?0:1));if(held>0){const L=rpLbSt();L.runs++;
  if(held>L.best){L.best=held;L.bt=Math.floor(Date.now()/1000);L.bd=Math.max(Math.round(R.time),held*RPLBWT);L.bk=Math.max(R.kills,held*5);R.lbNew=1}R.lbBest=L.best;setTimeout(()=>rpLbPush(true).then(()=>rpLbLoad(true)),300)}}}catch(e){}return f0.apply(this,arguments)}}

/* ---------- painting (only what changed) ---------- */
const rpLbView=()=>{const L=rpLbSt();if(RPLB.state==='ok'&&RPLB.s===L.s)return{live:1,list:RPLB.list,all:RPLB.all,place:RPLB.me?RPLB.me.place:0,t:RPLB.t};const c=L.c;if(c&&c.s===L.s&&Array.isArray(c.list))return{live:0,list:c.list,all:c.all|0,place:c.place|0,t:c.t};return null};
const rpFmtD=s=>{s=Math.max(0,s|0);const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return h?`${h} h ${m} min`:`${m} min`};
function rpLbRow(e,place){const pl=place<=3?` p${place}`:'';return `<div class="rplbr${e.me?' me':''}" style="--d:${Math.min(place,14)}"><span class="rkbpl${pl}">${place}</span><span class="rplbn"><b>${esc(e.me?rkLbName(P.name||'Player'):e.n)}</b><small>${e.me?'you':'#'+esc(String(e.pk).slice(0,4))}</small></span><span class="rplbw"><b>${cmn(e.w)}</b><small>waves</small></span><span class="rplbt">${rpFmtD(e.d)}</span><span class="rplbu">${cmn(e.r)} run${e.r===1?'':'s'}</span></div>`}
function rpLbStatus(){const v=rpLbView(),L=rpLbSt();if(RPLB.busy&&!v)return'Loading the leaderboard…';
 if(RPLB.state==='ok'&&v&&v.live)return`Updated ${rkAgo(v.t)} · ${RPLB.reached} of ${RPLB.relays} relays answered${RPLB.hidden?` · ${RPLB.hidden} hidden by their players`:''}`;
 if(RPLB.busy)return'Updating…';if(v)return`Offline · showing the board saved ${rkAgo(v.t)}`;return L.pend?'Offline · your best wave will be sent when you are back online':'Could not reach the leaderboard.'}
function rpLbPlaceTxt(){const v=rpLbView(),L=rpLbSt();if(L.hide)return'Hidden from the board';if(L.best<1)return'Not on the board yet';return v&&v.place?`#${v.place} of ${cmn(v.all)}`:RPLB.busy?'Finding your place…':'Place shows once the board loads'}
function rpLbPaint(){try{const v=rpLbView(),L=rpLbSt();
 const set=(id,h)=>{const el=document.getElementById(id);if(el&&el.dataset.k!==h){el.dataset.k=h;el.innerHTML=h}return el};
 const lead=v&&v.list.length?v.list[0]:null,leadTxt=lead?`${lead.me?'You lead':`Leader: ${esc(lead.me?rkLbName(P.name||'Player'):lead.n)}`} · wave ${cmn(lead.w)}`:RPLB.busy?'Loading the leaders…':'No one on the board yet: be the first!';
 set('rpchlead',leadTxt);set('rpchme',L.best?`<b>${rpLbPlaceTxt()}</b> · your best ${cmn(L.best)} waves`:'Play the Wonderland to get on the board');
 set('rphchl',L.best?`${rpLbPlaceTxt()} · best ${cmn(L.best)}`:leadTxt);
 set('rplbres',L.best?`<b>${rpLbPlaceTxt()}</b> on the season board · season best ${cmn(L.best)} waves`:'');
 const bd=document.getElementById('rplb');if(!bd)return;const box=bd.querySelector('#rplbrows'),st=bd.querySelector('#rplbst'),pl=bd.querySelector('#rplbplace'),of=bd.querySelector('#rplbof'),rf=bd.querySelector('#rplbref');
 if(rf)rf.classList.toggle('spin',!!RPLB.busy);if(st)st.textContent=rpLbStatus();
 if(pl){pl.textContent=L.hide?'Hidden':v&&v.place?'#'+v.place:'—';of.textContent=L.hide?'You are not shown on the leaderboard.':L.best<1?'Hold a wave in the Wonderland to get on the board.':v&&v.place?`of ${cmn(v.all)} player${v.all===1?'':'s'} · best ${cmn(L.best)} waves`:RPLB.busy?'Finding your place…':'Your place shows once the board loads.'}
 if(box){let h;if(v&&v.list.length){let out='',shown=false;for(let i=0;i<v.list.length;i++){const e=v.list[i];out+=rpLbRow(e,e.me&&v.place?v.place:i+1);if(e.me)shown=true}h=out}
  else if(v)h=`<div class="rkbmt"><b>No one is on the board yet</b><p>Season ${L.s} is waiting for its first defenders. Hold a wave in the Wonderland to take first place.</p></div>`;
  else if(RPLB.busy)h=`<div class="rkbmt"><b>Loading the leaderboard…</b><p>Asking the relays for this season's defenders.</p></div>`;
  else h=`<div class="rkbmt"><b>Couldn't reach the leaderboard</b><p>The leaderboard lives on public relays and needs an internet connection. Your best wave is safe on this device and is sent when you are back online.</p><button class="rpbk" id="rplbretry">Try again</button></div>`;
  if(box.dataset.k!==h){box.dataset.k=h;box.innerHTML=h;const me=box.querySelector('.rplbr.me');if(me&&!box.dataset.sc){box.dataset.sc=1;box.scrollTop=Math.max(0,me.offsetTop-box.offsetTop-box.clientHeight/2+30)}
   const rt=box.querySelector('#rplbretry');if(rt)rt.onclick=()=>{rpSfx('key',2);rpLbLoad(true)}}}}catch(e){}}

/* ---------- the animated prize: the Azure Dragon breathing blue fire ---------- */
function rpPrizeLive(cv,o){o=o||{};const g=cv.getContext('2d'),W2=cv.width,H2=cv.height,tier=o.tier||5,sc=o.sc||1.6;
 const fn=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W2,H2);if(!o.clear){const q=g.createRadialGradient(W2*.42,H2*.55,10,W2*.42,H2*.55,W2*.7);q.addColorStop(0,'#1e3a8a');q.addColorStop(.55,'#121a50');q.addColorStop(1,'#0a0828');g.fillStyle=q;g.fillRect(0,0,W2,H2)}
  const cyc=(t%4.2)/4.2,ch=cyc<.5?0:Math.min(1,Math.sin((cyc-.5)/.5*Math.PI)*1.6),aim=.45+Math.sin(t*1.3)*.12,x=W2*(o.x||.34),y=H2*(o.y||.86);
  g.save();g.translate(x,y);g.scale(sc,sc);const op={aim,face:1,charge:ch,ph:.3};rpTowerDraw(g,'dragon',tier,'azure',t,op);const m=rpDragonMouth(tier,Object.assign({t},op));g.restore();
  if(ch>.02){const mx=x+m.x*sc,my=y+m.y*sc,r=W2*.55;rpDragonBreath(g,mx,my,mx+Math.cos(aim)*r,my+Math.sin(aim)*r*.8,t,ch,tier,'azure',RPFX.lite)}};
 fn(1.2);if(!rpRM())LIVE.push({cv,fn,slow:2,ph:o.ph||0,vis:true});return fn}

/* ---------- the board screen ---------- */
function rpBoard(back){const L=rpLbSt(),K=(()=>{try{return rkLbKey()}catch(e){return{pk:''}}})(),pc=L.champ[L.s-1];back=back||(()=>rampartsMenu(title));
 show(`<div class="rpx rplb" id="rplb"><canvas class="rplbbg" id="rplbbg" width="1600" height="900"></canvas>
  <div class="rphtop"><button class="rpbk" id="rplbback" aria-label="Back (Esc)">‹ Back</button></div>
  <div class="rplbh"><p class="rpkick">SEASON ${L.s} · ${rpSeaLeft().toUpperCase()}</p><h1 class="rptitle">Wonderland Championship</h1></div>
  <section class="rplbp rplbme"><div class="rplbpz"><canvas id="rplbpc" width="460" height="250"></canvas><span class="rplbtag">CHAMPION'S PRIZE</span></div>
   <h3>Azure Dragon <i>+</i> <b>${cmn(RPLB_PRIZE)}</b> coins</h3><p class="rplbpx">The player who holds the most waves in the endless Wonderland this season wins a dragon skin of blue steel that breathes blue fire, and ${cmn(RPLB_PRIZE)} coins. Ties go to whoever reached it first.</p>
   <div class="rplbyou"><div><small>YOUR PLACE</small><div class="rplbbig" id="rplbplace">—</div></div><p class="rkbof" id="rplbof"></p></div>
   <div class="rkbname">On the board as <b>${esc(rkLbName(P.name||'Player'))}</b> <span>#${esc(K.pk.slice(0,4))}</span></div>
   <div class="rkbtog"><span>Show me on the leaderboard</span><div class="seg"><button class="sm${L.hide?'':' on'}" data-h="0">On</button><button class="sm${L.hide?' on':''}" data-h="1">Off</button></div></div>
   ${pc?`<p class="rplbpc">Season ${L.s-1} champion: <b>${esc(pc.n)}</b> #${esc(pc.pk)} · wave ${cmn(pc.w)}${pc.me?' · that was you!':''}</p>`:''}</section>
  <section class="rplbp rplbl"><div class="rkbtop"><h4>Season ${L.s} · top 100</h4><span class="rkbst" id="rplbst"></span><button class="rpbk rplbref" id="rplbref" aria-label="Refresh"><svg viewBox="0 0 24 24"><path d="M12 4a8 8 0 0 1 7.4 5H17v2h6V5h-2v2.3A10 10 0 1 0 22 12h-2a8 8 0 1 1-8-8z" fill="currentColor"/></svg><span>Refresh</span></button></div>
   <div class="rplbhd"><span>#</span><span>Player</span><span>Best</span><span>Run time</span><span>Runs</span></div><div class="rplbrows" id="rplbrows"></div>
   <p class="rkbnote">Every score is signed by its player's game, and only waves held in the Wonderland count. Scores that could not have been played are hidden automatically.</p></section></div>`,'rpx rplbx');
 S.view='ramparts';S.back=back;$('rplbback').onclick=()=>back();
 {const bg=$('rplbbg'),g=bg.getContext('2d');try{g.drawImage(rpBake(RP_MAP('wonder')).c,0,0,1600,900)}catch(e){}g.fillStyle='rgba(8,5,28,.72)';g.fillRect(0,0,1600,900)}
 rpPrizeLive($('rplbpc'),{tier:5,sc:1.2,x:.28,y:.95});
 $('rplbref').onclick=()=>{if(RPLB.busy)return;if(Date.now()-RPLB.refT<4000){rpLbPaint();return}RPLB.refT=Date.now();rpSfx('key',2);rpLbLoad(true)};
 ov.querySelectorAll('.rkbtog [data-h]').forEach(b=>b.onclick=()=>{const h=+b.dataset.h,L2=rpLbSt();if(L2.hide===h)return;rpSfx('key',2);L2.hide=h;save();
  ov.querySelectorAll('.rkbtog [data-h]').forEach(x=>x.classList.toggle('on',x===b));RPLB.t=0;rpLbPaint();rpLbPush(true).then(()=>rpLbLoad(true))});
 rpLbPaint();rpLbLoad();rpLbPrize()}

/* ---------- the champion's ceremony ---------- */
function rpChampCeremony(){const L=rpLbSt(),s=L.cel;if(!s||document.getElementById('rpcel'))return;const host=ov;if(!host)return;
 const d=document.createElement('div');d.className='rpcel';d.id='rpcel';d.innerHTML=`<div class="rpcelc"><canvas id="rpcelcv" width="560" height="300"></canvas><small>SEASON ${s} · WONDERLAND CHAMPIONSHIP</small><h2>You are the champion!</h2>
  <p>You held the most waves in the Wonderland this season.</p><div class="rpcelp"><span><img alt="" src="${rpIconCanvas('dragon',3,'azure',96)}"><b>Azure Dragon</b><em>tower skin</em></span><span><i class="rpcelco">${RPI.coin}</i><b>+${cmn(RPLB_PRIZE)}</b><em>coins</em></span></div>
  <div class="rpcelb"><button id="rpcelq">Equip the Azure Dragon</button><button class="sm" id="rpcelx">Later</button></div></div>`;host.appendChild(d);
 rpPrizeLive($('rpcelcv'),{tier:5,sc:1.3,x:.32,y:.96});try{jingle('win')}catch(e){}
 const close=()=>{rpLbSt().cel=0;save();d.remove()};$('rpcelx').onclick=close;$('rpcelq').onclick=()=>{RPP().skin.dragon='azure';close();try{rpSkins(()=>rampartsMenu(title))}catch(e){}}}

/* ---------- the Tower Skins screen ---------- */
const RP_SKINLIST=()=>{const L=[];for(const t of RP_TWORDER){L.push({tw:t,k:'base',n:'Classic',how:'Always yours'});for(const s of RP_SKINS)if(s.tw===t)L.push({tw:t,k:s.k,n:s.n,how:`Earn ${s.need} stars`,star:s.need})
 if(t==='dragon')L.push({tw:t,k:'azure',n:'Azure Dragon',how:'Season champion\'s prize',champ:1})}return L};
const rpSkinOwn=s=>s.k==='base'||!!RPP().own[s.tw+':'+s.k];
let RPSKSEL=null;
function rpSkins(back){back=back||(()=>rampartsMenu(title));const r=RPP(),list=RP_SKINLIST();if(!RPSKSEL||!list.some(s=>s.tw===RPSKSEL.tw&&s.k===RPSKSEL.k))RPSKSEL=list.find(s=>s.tw==='dragon'&&s.k==='azure');const sel=RPSKSEL,own=rpSkinOwn(sel),on=rpSkinOf(sel.tw)===sel.k,locked=sel.tw==='dragon'&&!rpDragonOpen();
 const tile=s=>{const o=rpSkinOwn(s),eq=rpSkinOf(s.tw)===s.k,sl=s===sel;return `<button class="rpskt${o?'':' lock'}${eq?' eq':''}${sl?' sel':''}${s.champ?' champ':''}" data-tw="${s.tw}" data-k="${s.k}"><img alt="" src="${rpIconCanvas(s.tw,3,s.k,88)}"><b>${esc(s.n)}</b><small>${eq?'Equipped':o?'Owned':s.champ?'Champion only':esc(s.how)}</small>${o?'':`<i class="rpsklk">${RPI.lock}</i>`}</button>`};
 const rows=RP_TWORDER.map(t=>`<div class="rpskr"><span class="rpskn" style="--c:${RPTW[t].col}">${esc(RPTW[t].n)}${t==='dragon'&&!rpDragonOpen()?'<em>locked tower</em>':''}</span><div>${list.filter(s=>s.tw===t).map(tile).join('')}</div></div>`).join('');
 const btn=own?(on&&sel.k!=='base'?`<button class="sm" id="rpskeq">Unequip</button>`:on?`<button class="sm" disabled>Equipped</button>`:`<button id="rpskeq">Equip ${esc(sel.n)}</button>`):sel.champ?`<button id="rpskeq" class="rpskch">See the championship ›</button>`:`<button class="sm" disabled>${esc(sel.how)}</button>`;
 show(`<div class="rpx rpskx" id="rpsk"><canvas class="rplbbg" id="rpskbg" width="1600" height="900"></canvas>
  <div class="rphtop"><button class="rpbk" id="rpskback" aria-label="Back (Esc)">‹ Back</button></div>
  <div class="rplbh"><p class="rpkick">RUNESTONE TOWER DEFENSE</p><h1 class="rptitle">Tower Skins</h1></div>
  <section class="rplbp rpskp"><div class="rpskpv${sel.champ?' champ':''}"><canvas id="rpskcv" width="520" height="430"></canvas>${sel.champ?'<span class="rplbtag">CHAMPION\'S PRIZE</span>':''}</div>
   <h3>${esc(sel.n)}</h3><p class="rpsksub">${esc(RPTW[sel.tw].n)} · ${own?(on?'equipped':'owned'):'locked'}</p>
   <p class="rpskd">${sel.champ?`Blue steel, gold trim and blue fire. Only the season's champion wins it: hold the most waves in the Wonderland this season (${rpSeaLeft()}). The champion also gets ${cmn(RPLB_PRIZE)} coins.`:sel.k==='base'?'The classic look.':own?'Yours to equip.':`${esc(sel.how)} across the maps to unlock it.`}${locked?' Win Ember Crown to unlock the Dragon Roost itself.':''}</p>
   <div class="rpskbt">${btn}</div></section>
  <section class="rplbp rpskl">${rows}</section></div>`,'rpx rpskxx');
 S.view='ramparts';S.back=back;$('rpskback').onclick=()=>back();
 {const bg=$('rpskbg'),g=bg.getContext('2d');try{g.drawImage(rpWorldArt(rpWonderOpen()),0,0,1600,900)}catch(e){try{g.drawImage(rpBake(RP_MAP('moss')).c,0,0,1600,900)}catch(x){}}g.fillStyle='rgba(8,5,28,.74)';g.fillRect(0,0,1600,900)}
 {const cv=$('rpskcv');if(sel.tw==='dragon')rpPrizeLive(cv,{tier:3,sc:2,x:.4,y:.92,clear:1});else{const g=cv.getContext('2d');const fn=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,520,430);g.translate(260,370);g.scale(2.4,2.4);rpTowerDraw(g,sel.tw,3,sel.k,t,{aim:Math.sin(t*.7)*.8-.4,ph:.4,fire:(t%2.4)<.3?1-(t%2.4)/.3:0,charge:.6+.4*Math.sin(t*2)})};fn(1);if(!rpRM())LIVE.push({cv,fn,slow:2,vis:true})}}
 ov.querySelectorAll('.rpskt').forEach(b=>b.onclick=()=>{const s=list.find(x=>x.tw===b.dataset.tw&&x.k===b.dataset.k);if(!s)return;RPSKSEL=s;rpSfx('key',2);
  if(rpSkinOwn(s)&&rpSkinOf(s.tw)!==s.k){RPP().skin[s.tw]=s.k;save();rpSfx('up')}rpSkins(back)});
 const eq=$('rpskeq');if(eq)eq.onclick=()=>{if(sel.champ&&!own){rpBoard(()=>rpSkins(back));return}const r2=RPP();r2.skin[sel.tw]=on?'base':sel.k;save();rpSfx('up');rpSkins(back)}}

/* ---------- the hub: top buttons, a championship panel in the armory bar, the Wonderland panel ---------- */
const RPTRO='<svg viewBox="0 0 24 24"><path d="M7 3h10v3h3v2a5 5 0 0 1-5 5h-.4A4.5 4.5 0 0 1 13 14.6V17h3v4H8v-4h3v-2.4A4.5 4.5 0 0 1 9.4 13H9a5 5 0 0 1-5-5V6h3z" fill="#ffd45a" stroke="#12081f" stroke-width="1.5" stroke-linejoin="round"/><path d="M4 8h3v3a3 3 0 0 1-3-3zM20 8h-3v3a3 3 0 0 0 3-3z" fill="#c88a10"/></svg>';
const RPBRUSH='<svg viewBox="0 0 24 24"><path d="M14.5 3.5l6 6-8.5 8.5-6-6z" fill="#9fe8ff" stroke="#12081f" stroke-width="1.5" stroke-linejoin="round"/><path d="M6 12l6 6-2 2c-1.6 1.6-4.4 1.6-6 0s-1.6-3.4 0-5z" fill="#ff8ad8" stroke="#12081f" stroke-width="1.5" stroke-linejoin="round"/></svg>';
{const m0=rampartsMenu;rampartsMenu=function(back){const out=m0.apply(this,arguments);try{const hb=back||title,L=rpLbSt(),pc=L.champ[L.s-1];
 const top=ov.querySelector('.rphtop');if(top){top.insertAdjacentHTML('beforeend',`<button class="rpbk rpbkg" id="rphlb"><i class="rpbki">${RPTRO}</i>Leaderboard</button><button class="rpbk" id="rphsk"><i class="rpbki">${RPBRUSH}</i>Tower Skins</button>`);
  $('rphlb').onclick=()=>{rpSfx('key',2);rpBoard(()=>rampartsMenu(hb))};$('rphsk').onclick=()=>{rpSfx('key',2);rpSkins(()=>rampartsMenu(hb))}}
 const arm=ov.querySelector('.rparm'),vr=$('rpvr');if(arm&&vr){const h=arm.querySelector('.rparmh');if(h){vr.textContent='View rewards ›';h.appendChild(vr)}
  arm.insertAdjacentHTML('beforeend',`<button class="rpchb" id="rpchb"><canvas id="rpchcv" width="150" height="120"></canvas><span class="rpcht"><small>SEASON ${L.s} CHAMPIONSHIP · ${rpSeaLeft().toUpperCase()}</small><b>Win the Azure Dragon</b><em>+ ${cmn(RPLB_PRIZE)} coins for the Wonderland's #1</em><i id="rpchme"></i></span><span class="rpchgo">›</span></button>`);
  $('rpchb').onclick=()=>{rpSfx('key',2);rpBoard(()=>rampartsMenu(hb))};rpPrizeLive($('rpchcv'),{tier:3,sc:.82,x:.36,y:.97,clear:1})}
 const side=ov.querySelector('.rpsidew');if(side){const asc=side.querySelector('.rpasc');const d=document.createElement('div');d.className='rpwch';d.innerHTML=`<span class="rpwchi">${RPTRO}</span><span><b>Season ${L.s} championship</b><em id="rpchlead"></em></span><button class="rpwchb" id="rpwchb">Board ›</button>`;if(asc)asc.before(d);else side.appendChild(d);$('rpwchb').onclick=()=>{rpSfx('key',2);rpBoard(()=>rampartsMenu(hb))}}
 if(pc){const hl=ov.querySelector('.rphl');if(hl)hl.insertAdjacentHTML('beforeend',`<p class="rpchamp">${RPTRO}<span>Season ${L.s-1} champion: <b>${esc(pc.n)}</b> · wave ${cmn(pc.w)}</span></p>`)}
 rpLbPaint();rpLbLoad();rpLbPrize();if(L.cel)setTimeout(rpChampCeremony,500)}catch(e){console.error(e)}return out}}
/* the Wonderland result: the season board line and the prize */
{const r0=rpResultEndless;rpResultEndless=function(R,r){const out=r0.apply(this,arguments);try{const box=ov.querySelector('.rpres'),row=box&&box.querySelector('.row');if(row){const d=document.createElement('div');d.className='rplbrs';
  d.innerHTML=`<span class="rpwchi">${RPTRO}</span><span><small>WONDERLAND CHAMPIONSHIP · SEASON ${rpLbSt().s} · ${rpSeaLeft()}</small><em id="rplbres"></em><i>Top the board to win the Azure Dragon and ${cmn(RPLB_PRIZE)} coins.</i></span><button class="sm" id="rplbgo">Leaderboard ›</button>`;row.before(d);
  $('rplbgo').onclick=()=>{rpLeave();rpBoard(()=>rampartsMenu(title))};rpLbPaint()}}catch(e){console.error(e)}return out}}
/* the home screen: a championship card on the hero stage */
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{rpChampHome()}catch(e){console.error(e)}return r}}
function rpChampHome(){if(!HOME||ov.querySelector('#rphch'))return;const st=ov.querySelector('.dkstage')||ov.querySelector('#dkh');if(!st)return;const L=rpLbSt();
 const d=document.createElement('button');d.className='rphch';d.id='rphch';d.setAttribute('aria-label','Wonderland Championship: win the Azure Dragon and '+cmn(RPLB_PRIZE)+' coins');
 d.innerHTML=`<canvas id="rphchcv" width="250" height="150"></canvas><small>SEASON ${L.s} CHAMPIONSHIP</small><b>Win the Azure Dragon</b><span>+ ${cmn(RPLB_PRIZE)} coins · Wonderland's best wave</span><em id="rphchl"></em><i>${rpSeaLeft()} ›</i>`;
 (ov.querySelector('#dkh')||ov).appendChild(d);d.onclick=()=>{try{rpBoard(title)}catch(e){console.error(e)}};rpPrizeLive($('rphchcv'),{tier:5,sc:.6,x:.3,y:.96,ph:1});rpLbPaint();if(rpLbSt().best||RPLB.state!=='ok')rpLbLoad();if(L.cel)setTimeout(rpChampCeremony,700)}
/* the mode sheet, help and how-to texts */
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{const b=document.querySelector('#dmrp small');if(b&&!b.dataset.ch){b.dataset.ch=1;b.textContent+=` Season championship: win the Azure Dragon and ${cmn(RPLB_PRIZE)} coins.`}}catch(e){}return r}}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=` Wonderland Championship: every season (six weeks, like Wildcard Ranked) the player who holds the most waves in the Wonderland tops a public leaderboard and wins the Azure Dragon skin (blue steel, blue fire) and ${cmn(RPLB_PRIZE)} coins. Tower Skins (on the Tower Defense hub) lets you choose the look of each tower.`}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Dragon Roost.</b> Win Ember Crown to unlock it: a clockwork dragon that breathes sweeping fire over every monster it crosses, flyers too. Press C (or Wind up) to make it breathe at once.</p><p><b>Wonderland Championship.</b> Each season the player who holds the most waves in the Wonderland wins the Azure Dragon skin and ${cmn(RPLB_PRIZE)} coins. See the Leaderboard button.</p>`)}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
.rpbki{width:26px;height:26px;display:grid;place-items:center}.rpbki svg{width:24px;height:24px}
#ov .rphub .rpbk.rpbkg{border-color:#ffd45a;background:linear-gradient(180deg,#5a3a10f0,#2a1606f2)}
.rparmh #rpvr,#ov .rphub .rparmh #rpvr{all:unset;cursor:pointer;font:800 14px var(--ui);color:#9fe8ff;margin-top:2px}.rparmh #rpvr:hover{color:#ffffff}
.rparm .rptrk{margin:0 14px}
#ov .rpchb{position:relative;flex:none;width:520px;height:104px;margin:0 -10px 0 0;padding:0 16px 0 0;display:flex;align-items:center;gap:6px;border-radius:18px;border:2px solid #ffd45a;background:linear-gradient(100deg,#1a3a8a 0%,#16206a 40%,#2a1a10 100%);box-shadow:0 0 0 2px #12081f,0 6px 16px #0008;color:#fff8e8;text-align:left;cursor:pointer;overflow:hidden;transition:transform .18s var(--sp)}
#ov .rpchb:hover{transform:translateY(-3px)}
.rpchb canvas{width:125px;height:100px;flex:none;margin:0 2px 0 4px}
.rpcht{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}.rpcht small{font:800 11px var(--ui);letter-spacing:.12em;color:#9fe8ff}.rpcht em,.rpcht small{white-space:nowrap}.rpcht b{white-space:nowrap;font:400 30px/1.05 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f}
.rpcht em{font:700 13px var(--ui);font-style:normal;color:#e8e0ff}.rpcht i{font:600 12.5px var(--ui);font-style:normal;color:#c4badf;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rpcht i b{font:800 12.5px var(--ui);color:#fff8e8;text-shadow:none}
.rpchgo{flex:none;width:40px;height:40px;display:grid;place-items:center;font-size:26px!important;border-radius:50%;background:linear-gradient(180deg,#fff0a8,#ffd45a 50%,#e8a426);color:#3a1a04;font:800 15px var(--ui);box-shadow:0 0 0 2px #12081f}
.rpwch{display:flex;align-items:center;gap:10px;margin:12px 0 0;padding:8px 10px;border-radius:14px;border:2px solid #ffd45a;background:linear-gradient(90deg,#3a2a10,#16124a)}
.rpwchi{width:34px;height:34px;flex:none}.rpwchi svg{width:100%;height:100%}.rpwch>span:nth-child(2){flex:1;min-width:0;display:flex;flex-direction:column}.rpwch b{font:800 14px var(--ui);color:#ffd45a}.rpwch em{font:600 12.5px var(--ui);font-style:normal;color:#e8e0ff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#ov .rpwchb{flex:none;height:34px;margin:0;padding:0 12px;border-radius:10px;border:2px solid #ffd45a;background:#2a1a08;color:#ffd45a;font:800 13px var(--ui);box-shadow:none}
.rpchamp{display:flex;align-items:center;gap:8px;margin:10px 0 0;padding:6px 12px 6px 8px;width:max-content;border-radius:12px;background:#0c0826d8;border:2px solid #ffd45a;font:600 14px var(--ui);color:#e8e0ff}.rpchamp svg{width:24px;height:24px}.rpchamp b{color:#ffd45a}
.rplbx #ov,.rplb,.rpskx{position:absolute;inset:0}
.rplbbg{position:absolute;inset:0;width:1600px;height:900px}
.rplbh{position:absolute;left:44px;top:80px}#ov .rplbh .rptitle{margin:2px 0 0;font-size:64px;line-height:1}
#ov .rplb .rpbk,#ov .rpskx .rpbk{display:flex;align-items:center;gap:8px;height:48px;margin:0;padding:0 20px;border-radius:14px;border:2px solid #6a5ac8;background:linear-gradient(180deg,#2a2070f0,#160f46f2);color:#fff8e8;font:700 18px var(--ui);box-shadow:0 0 0 2px #12081f,0 6px 14px #0008}
#ov .rplb .rkbmt .rpbk{display:inline-flex;margin-top:10px}.rplbh .rpkick{margin:0 0 4px}
.rplbp{position:absolute;padding:18px 20px;border-radius:24px;background:linear-gradient(180deg,#1e1650f2,#0e0a2cf6);border:2px solid #5a4ca0;box-shadow:0 0 0 2px #12081f,0 18px 40px #000a;box-sizing:border-box;color:#fff8e8;text-align:left}
.rplbme{left:40px;top:176px;bottom:24px;width:500px;display:flex;flex-direction:column;border-color:#ffd45a}
.rplbpz{position:relative;margin:-6px -8px 6px;border-radius:18px;overflow:hidden;border:2px solid #3a5ac8;box-shadow:0 0 0 2px #12081f}.rplbpz canvas{display:block;width:100%;height:auto}
.rplbtag{position:absolute;left:12px;top:10px;padding:4px 10px;border-radius:999px;background:#ffd45a;color:#3a1a04;font:800 12px var(--ui);letter-spacing:.12em;box-shadow:0 0 0 2px #12081f}
.rplbme h3{margin:4px 0 2px;font:400 36px/1.05 'Pirata One',Georgia,serif;color:#9fe8ff}.rplbme h3 i{font-style:normal;color:#e8e0ff}.rplbme h3 b{font-weight:400;color:#ffd45a}
.rplbpx{margin:0 0 10px;font:600 14px/1.45 var(--ui);color:#cfc6f5}
.rplbyou{display:flex;align-items:center;gap:16px;padding:8px 14px;border-radius:16px;background:#0e0828;border:1.5px solid #2e2660}.rplbyou small{font:800 11px var(--ui);letter-spacing:.12em;color:#8a80c0}
.rplbbig{font:400 54px/1 'Pirata One',var(--ui);color:#ffd45a}.rplbyou .rkbof{margin:0;flex:1;text-align:left}
.rplbme .rkbname{margin-top:10px}.rplbme .rkbtog{margin-top:auto}
.rplbpc{margin:10px 0 0;font:600 14px var(--ui);color:#e8e0ff}.rplbpc b{color:#ffd45a}
.rplbl{left:564px;right:40px;top:176px;bottom:24px;display:flex;flex-direction:column}
#ov .rplbref{height:40px;padding:0 14px;font-size:15px}.rplbref svg{width:18px;height:18px}.rplbref.spin svg{animation:rkspin .9s linear infinite}
.rplbhd,.rplbr{display:grid;grid-template-columns:62px minmax(0,1fr) 150px 150px 110px;gap:10px;align-items:center}
.rplbhd{padding:0 26px 6px 10px;font:800 12px var(--ui);letter-spacing:.12em;text-transform:uppercase;color:#8a80c0}.rplbhd span:first-child{text-align:center}.rplbhd span:nth-child(n+3){text-align:right}
.rplbrows{flex:1;min-height:0;overflow-y:auto;padding-right:6px;overscroll-behavior:contain}
.rplbrows::-webkit-scrollbar{width:10px}.rplbrows::-webkit-scrollbar-thumb{background:#463a8a;border-radius:10px;border:2px solid #100a30}
.rplbr{height:54px;padding:0 16px 0 10px;margin-bottom:6px;border-radius:14px;background:#0e0828;border:1.5px solid #2e2660;box-sizing:border-box;animation:rkbin .4s var(--sp) both;animation-delay:calc(var(--d)*25ms)}
.rplbr.me{border:2px solid #ffd45a;background:linear-gradient(90deg,#3a2a12,#0e0828 70%)}
.rplbn{display:flex;align-items:baseline;gap:8px;min-width:0}.rplbn b{font:800 17px var(--ui);color:#fff8e8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rplbn small{font:700 13px var(--ui);color:#8a80c0;flex:none}.rplbr.me .rplbn small{color:#ffd45a}
.rplbw,.rplbt,.rplbu{text-align:right;white-space:nowrap}.rplbw b{font:900 20px var(--ui);color:#9fe8ff}.rplbw small{font:700 12px var(--ui);color:#a8a0d0;margin-left:5px}.rplbt,.rplbu{font:700 14px var(--ui);color:#cfc6f5}
.rplbl .rkbnote{margin:8px 0 0}
.rplbrs{display:flex;align-items:center;gap:14px;max-width:760px;margin:10px auto 4px;padding:10px 14px;border-radius:16px;border:2px solid #ffd45a;background:linear-gradient(90deg,#1a2a6a,#1a1240 60%,#2a1a08);text-align:left}
.rplbrs>span:nth-child(2){flex:1;display:flex;flex-direction:column}.rplbrs small{font:800 11px var(--ui);letter-spacing:.1em;color:#9fe8ff}.rplbrs em{font:600 15px var(--ui);font-style:normal;color:#fff8e8}.rplbrs em b{color:#ffd45a}.rplbrs i{font:600 13px var(--ui);font-style:normal;color:#c4badf}
#ov .rplbrs button{margin:0;flex:none}
.rphch{position:absolute;right:30px;top:132px;width:270px;padding:10px 10px 12px;border-radius:22px;border:2px solid #ffd45a;background:linear-gradient(180deg,#1a2a78f0,#120c40f4 60%,#1c1030f6);box-shadow:0 0 0 3px #12081f,0 14px 30px #000a;color:#fff8e8;text-align:left;cursor:pointer;z-index:3;transition:transform .2s var(--sp);animation:rphch .7s var(--sp) both .3s}
.rphch:hover{transform:translateY(-4px) rotate(-.6deg)}@keyframes rphch{from{opacity:0;transform:translateY(-16px) scale(.94)}}
.rphch canvas{display:block;width:250px;height:150px;border-radius:14px;border:2px solid #3a5ac8;box-shadow:0 0 0 2px #12081f}
.rphch small{display:block;margin:8px 4px 0;font:800 11px var(--ui);letter-spacing:.14em;color:#9fe8ff}.rphch b{display:block;margin:0 4px;font:400 30px/1.05 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f}
.rphch span{display:block;margin:2px 4px 0;font:700 13px var(--ui);color:#e8e0ff}.rphch em{display:block;margin:4px 4px 0;font:600 12.5px var(--ui);font-style:normal;color:#c4badf;min-height:16px}.rphch i{display:block;margin:6px 4px 0;font:800 13px var(--ui);font-style:normal;color:#ffd45a}
.rpcel{position:absolute;inset:0;z-index:50;display:grid;place-items:center;background:#06041ae0;animation:rpfade .4s both}@keyframes rpfade{from{opacity:0}}
.rpcelc{width:640px;padding:22px 30px 24px;border-radius:28px;border:3px solid #ffd45a;background:linear-gradient(180deg,#1a2a78fa,#100a30fc);box-shadow:0 0 0 3px #12081f,0 30px 80px #000c;text-align:center;color:#fff8e8;animation:rpTut .5s var(--sp)}
.rpcelc canvas{width:560px;height:300px;border-radius:18px;border:2px solid #3a5ac8}.rpcelc small{display:block;margin-top:10px;font:800 12px var(--ui);letter-spacing:.16em;color:#9fe8ff}
.rpcelc h2{margin:2px 0 4px;font:400 56px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f}.rpcelc p{margin:0 0 10px;font:600 16px var(--ui);color:#e8e0ff}
.rpcelp{display:flex;justify-content:center;gap:16px}.rpcelp span{display:flex;flex-direction:column;align-items:center;min-width:160px;padding:8px 12px;border-radius:16px;background:#0c0826;border:2px solid #3a5ac8}.rpcelp img{width:80px;height:80px;margin-top:-10px}
.rpcelco{width:60px;height:60px;display:block;margin:4px 0}.rpcelco svg{width:100%;height:100%}.rpcelp b{font:800 22px var(--ui);color:#ffd45a}.rpcelp em{font:600 13px var(--ui);font-style:normal;color:#c4badf}
.rpcelb{display:flex;justify-content:center;gap:12px;margin-top:14px}#ov .rpcelb button{margin:0}
.rpskp{left:40px;top:176px;bottom:24px;width:560px;display:flex;flex-direction:column}
.rpskpv{position:relative;margin:-6px -8px 6px;height:380px;border-radius:18px;overflow:hidden;border:2px solid #3a3070;background:radial-gradient(circle at 50% 70%,#2e2470,#0c0826 75%)}.rpskpv.champ{border-color:#3a5ac8;background:radial-gradient(circle at 45% 70%,#1e3a8a,#0a0828 75%)}
.rpskpv canvas{position:absolute;left:12px;top:-50px;width:520px;height:430px}
.rpskp h3{margin:6px 0 0;font:400 42px/1 'Pirata One',Georgia,serif;color:#ffd45a}.rpsksub{margin:2px 0 6px;font:700 14px var(--ui);color:#9fe8ff}.rpskd{margin:0;font:600 14.5px/1.5 var(--ui);color:#cfc6f5}
.rpskbt{margin-top:auto;display:flex;gap:10px}#ov .rpskbt button{margin:0}#ov .rpskbt .rpskch{background:linear-gradient(180deg,#bfe6ff,#5aa8ff 50%,#2a6ad0);color:#0a1a40}
.rpskl{left:624px;right:40px;top:176px;bottom:24px;overflow-y:auto;display:grid;grid-template-columns:1fr 1fr;align-content:start;gap:12px 18px;padding:16px 18px}
.rpskr{display:flex;flex-direction:column;gap:8px;padding:10px;border-radius:18px;background:#0c082480;border:1.5px solid #2e2660}.rpskr>div{display:flex;gap:10px;flex-wrap:wrap}
.rpskn{font:800 16px var(--ui);color:#fff8e8;border-left:4px solid var(--c);padding-left:10px}.rpskn em{display:block;font:600 12px var(--ui);font-style:normal;color:#ff9a7a}
#ov .rpskt{position:relative;width:126px;height:136px;margin:0;padding:4px 6px 8px;display:flex;flex-direction:column;align-items:center;gap:0;border-radius:16px;border:2px solid #3a3070;background:#0c0824;color:#fff8e8;box-shadow:none;cursor:pointer;transition:transform .15s var(--sp)}
#ov .rpskt:hover{transform:translateY(-3px)}.rpskt img{width:84px;height:84px}.rpskt b{font:800 12.5px var(--ui);text-align:center;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}.rpskt small{font:700 11.5px var(--ui);color:#c4badf;text-align:center}
#ov .rpskt.sel{border-color:#9fe8ff;box-shadow:0 0 0 2px #12081f,0 0 0 4px #9fe8ff66}#ov .rpskt.eq small{color:#ffd45a}#ov .rpskt.eq{border-color:#ffd45a}
.rpskt.lock img{opacity:.38}.rpsklk{position:absolute;left:50%;top:34px;width:28px;height:28px;margin-left:-14px}.rpsklk svg{width:100%;height:100%}
#ov .rpskt.champ{background:linear-gradient(180deg,#1a2a6a,#0c0824);border-color:#5aa8ff}#ov .rpskt.champ small{color:#9fe8ff}`;document.head.appendChild(st)}
{const st=document.createElement('style');st.textContent='.rpasc>div{gap:5px}.rpasc .rpai{width:52px;height:52px;border-radius:10px}.rpasc .rpai img{width:48px;height:48px}';document.head.appendChild(st)}
