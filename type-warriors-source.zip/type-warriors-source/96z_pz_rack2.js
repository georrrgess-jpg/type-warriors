/* ===== 9.5 THE CROOKED CUE: the Cue Rack, redone (96z) =====
   Cues stand upright on a wooden wall rack, split into the shop and the ones won at the tables, each with a hanging
   tag (in hand, owned, price, wins so far, or ? for a regular you have not met). Felts and ball sets are big swatch
   cards. The detail panel shows a large preview, where it comes from, the price as a sum (price, you have, after) and
   a hold-to-buy button (700 ms; letting go cancels), or Equip, or the way to earn it with a "Challenge" shortcut.
   A loadout strip shows what is in your hand. Keys: Q/E tabs, left/right pick, Enter equip (hold to buy), 1-3 tabs. */
const PZ_RKTABS=[['cues','Cues'],['felts','Felts'],['balls','Ball sets']];
function pzRkList(tab){return tab==='cues'?PZ_CUES:tab==='felts'?PZ_FELT:PZ_BALLS}
function pzRkOwn(tab){const Z=PZS();return tab==='cues'?Z.cues:tab==='felts'?Z.felts:Z.ballsets}
function pzRkEq(tab){const Z=PZS();return tab==='cues'?Z.cue:tab==='felts'?Z.felt:Z.balls}
function pzRkWho(x){return x.beat?x.beat:x.beatShade?'shade':null}
function pzRkTag(tab,x){const own=pzRkOwn(tab),eq=pzRkEq(tab),Z=PZS();if(eq===x.id)return ['inhand','IN HAND'];if(own[x.id])return ['own','✓ OWNED'];if(x.price)return [P.gold>=x.price?'buy':'poor',cmn(x.price)];
 const who=pzRkWho(x);if(!who)return ['lock','?'];const met=who==='shade'?(Z.shade.seen||0)>0:pzOpen(who);if(!met)return ['lock','?'];const need=tab==='cues'?3:x.beatShade||1,n=who==='shade'?(Z.shade.beat||0):(Z.beat[who]||0);return ['prog',`${Math.min(n,need)} / ${need}`]}
const PZ_UPRIGHT={};
function pzCueUpright(id){if(PZ_UPRIGHT[id])return PZ_UPRIGHT[id];const c=pzCv(60,480),g=c.getContext('2d'),s=pzCueSprite(id),k=456/(PZ_CUE.L+22),it=PZ_CUES.find(x=>x.id===id);
 if(it&&it.glow)pzGlow(g,30,150,60,pzRgba(it.glow),.35);g.translate(30,12);g.rotate(-Math.PI/2);g.scale(k,k*1.55);g.drawImage(s.c,-(s.L+10),-15,s.W/2,s.H/2);return PZ_UPRIGHT[id]=c}
function pzCueRack(){const Z=PZS(),tab=PZ.rackTab||'cues';PZ.rackTab=tab;PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;try{pzMusicOn()}catch(e){}
 const items=pzRkList(tab),own=pzRkOwn(tab),eq=pzRkEq(tab);PZ.rackSel=PZ.rackSel&&items.find(x=>x.id===PZ.rackSel)?PZ.rackSel:eq;
 const cnt=t=>{const l=pzRkList(t),o=pzRkOwn(t);return `${l.filter(x=>o[x.id]).length}/${l.length}`};
 const oc=pzOwnCount(),np=pzNextPrize();
 show(`<div class="pzk pzrk9" id="pzk"><canvas id="pzkbg" width="1600" height="900"></canvas><button class="pzback" id="pzbk">‹&nbsp; The bar <kbd>Esc</kbd></button><div class="pzgold"><i></i><b id="pzkgold">${cmn(P.gold)}</b></div>
  <div class="pztitle sm">The Cue Rack</div>
  <div class="pzktabs pzktabs9"><i class="pzktp"></i>${PZ_RKTABS.map(([k,l],i)=>`<button class="${tab===k?'on':''}" data-t="${k}" style="--i:${i}">${l} <em>${cnt(k)}</em></button>`).join('')}<kbd class="q">Q</kbd><kbd class="e">E</kbd></div>
  <div class="pzkwall ${tab}" id="pzkwall"></div><div class="pzkdet" id="pzkdet"></div>
  <div class="pzkload"><div class="pzh3k">In your hand</div>${PZ_RKTABS.map(([k,l],i)=>{const it=pzRkList(k).find(x=>x.id===pzRkEq(k))||pzRkList(k)[0];return `<button class="pzkls" data-t="${k}"><small>${l.replace(/s$/,'').toUpperCase()}</small><b>${it.n}</b><canvas width="180" height="34" data-lt="${k}" data-li="${it.id}"></canvas><kbd>${i+1}</kbd></button>`}).join('')}
   <div class="pzkcol"><div><b>Collection</b><span>${oc.n} / ${oc.t}</span></div><em><i style="transform:scaleX(${oc.n/oc.t})"></i></em><p>${np?`Next unlock: <b>${np.it.n}${np.t==='felt'?' felt':''}</b> · ${np.need>1?`beat ${pzShort(np.id)} ${np.need} more times`:`beat ${pzShort(np.id)} once`}`:'Everything won. A true collector.'}</p><p class="pzklook">Cosmetic only: they change the look, not the shots.</p></div></div></div>`,'casbg pzx');
 $('pzkbg').getContext('2d').drawImage(pzHubBake(),0,0);$('pzbk').onclick=()=>pzGo(pzHub);S.back=()=>pzGo(pzHub);
 ov.querySelectorAll('.pzktabs9 button').forEach(b=>b.onclick=()=>pzRkTab(b.dataset.t));
 ov.querySelectorAll('.pzkls').forEach(b=>{b.onclick=()=>pzRkTab(b.dataset.t);const cv=b.querySelector('canvas');try{pzRkThumb(cv.getContext('2d'),cv.dataset.lt,pzRkList(cv.dataset.lt).find(x=>x.id===cv.dataset.li),180,34)}catch(e){}});
 pzRkWall(true);pzRkDetail();pzRkPuck();pzFitTM()}
function pzRkPuck(){const on=ov.querySelector('.pzktabs9 button.on'),p=ov.querySelector('.pzktp');if(on&&p){p.style.width=on.offsetWidth+'px';p.style.transform=`translateX(${on.offsetLeft}px)`}}
function pzRkTab(t){if(t===PZ.rackTab)return;PZ.rackTab=t;PZ.rackSel=null;pzFx('tick');ov.querySelectorAll('.pzktabs9 button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));pzRkPuck();PZ.rackSel=pzRkEq(t);const w=$('pzkwall');if(w)w.className='pzkwall '+t;pzRkWall(true);pzRkDetail()}
function pzRkWall(anim){const tab=PZ.rackTab,w=$('pzkwall');if(!w)return;const items=pzRkList(tab),sel=PZ.rackSel;
 const tagH=x=>{const [k,t]=pzRkTag(tab,x),who=pzRkWho(x);return `<span class="pzktag ${k}">${k==='prog'&&who?`<canvas width="44" height="44" data-p="${who}"></canvas>`:''}${t}</span>`};
 if(tab==='cues'){const shop=items.filter(x=>x.price!=null&&!x.beat&&!x.beatShade),won=items.filter(x=>x.beat||x.beatShade);const o=pzRkOwn(tab);
  const col=(x,i)=>`<button class="pzki pzkc ${x.id===sel?'sel':''} ${o[x.id]?'':'lock'} ${pzRkEq(tab)===x.id?'eq':''} ${!o[x.id]&&!x.price?'dark':''}" data-i="${x.id}" style="--i:${i}" aria-label="${x.n}"><canvas width="60" height="480" data-cu="${x.id}"></canvas>${!PZS().seen[x.id]&&o[x.id]&&x.price!==0&&x.how!=='Free'?'<s class="pzknew">NEW</s>':''}${tagH(x)}</button>`;
  w.innerHTML=`<div class="pzkrail t"></div><div class="pzkrail b"></div><div class="pzkhead s">THE SHOP · ${shop.filter(x=>o[x.id]).length} / ${shop.length}</div><div class="pzkhead w">WON AT THE TABLES · ${won.filter(x=>o[x.id]).length} / ${won.length}</div><div class="pzkcols">${shop.map(col).join('')}<i class="pzkgap"></i>${won.map((x,i)=>col(x,i+shop.length)).join('')}</div>`;
  {const fs=w.querySelector('.pzkc'),fw=w.querySelector('.pzkgap+.pzkc'),hs=w.querySelector('.pzkhead.s'),hw=w.querySelector('.pzkhead.w');if(fs&&hs)hs.style.left=(fs.offsetLeft+28)+'px';if(fw&&hw)hw.style.left=(fw.offsetLeft+28)+'px'}
 w.querySelectorAll('canvas[data-cu]').forEach(cv=>{const g=cv.getContext('2d'),id=cv.dataset.cu;g.drawImage(pzCueUpright(id),0,0);if(cv.closest('.dark')){g.globalCompositeOperation='source-atop';g.fillStyle='rgba(12,8,24,.86)';g.fillRect(0,0,60,480);g.globalCompositeOperation='source-over'}})}
 else{const o=pzRkOwn(tab);w.innerHTML=`<div class="pzkcards">${items.map((x,i)=>`<button class="pzki pzksw ${x.id===sel?'sel':''} ${o[x.id]?'':'lock'} ${pzRkEq(tab)===x.id?'eq':''}" data-i="${x.id}" style="--i:${i}"><canvas width="300" height="${tab==='felts'?150:60}" data-sw="${x.id}"></canvas><b>${x.n}</b>${!PZS().seen[x.id]&&o[x.id]&&x.price!==0&&x.how!=='Free'?'<s class="pzknew">NEW</s>':''}${tagH(x)}</button>`).join('')}</div>`;
  w.querySelectorAll('canvas[data-sw]').forEach(cv=>{const it=items.find(x=>x.id===cv.dataset.sw);try{pzRkThumb(cv.getContext('2d'),tab,it,300,tab==='felts'?150:60)}catch(e){}})}
 w.querySelectorAll('canvas[data-p]').forEach(cv=>pzCastPortrait(cv.getContext('2d'),'mon',cv.dataset.p,44,1,Object.assign(pzCastEx(),PZ_EXP.neutral)));
 w.querySelectorAll('.pzki').forEach(b=>{b.onclick=()=>{if(PZ.rackSel===b.dataset.i)return;PZ.rackSel=b.dataset.i;pzFx('tick');w.querySelectorAll('.pzki').forEach(x=>x.classList.toggle('sel',x===b));pzRkDetail()}});
 if(anim){w.classList.remove('in');void w.offsetWidth;w.classList.add('in')}}
function pzRkDetail(){const tab=PZ.rackTab,d=$('pzkdet');if(!d)return;const Z=PZS(),items=pzRkList(tab),it=items.find(x=>x.id===PZ.rackSel)||items[0],own=pzRkOwn(tab),have=!!own[it.id],eq=pzRkEq(tab)===it.id,who=pzRkWho(it);
 const from=it.price===0?'The house gives you this one.':it.price?'From the shop.':who?`Won at the tables: ${it.how.toLowerCase().replace(/^beat/,'beat')}.`:it.how;
 let act='';
 if(have)act=`<button class="pzmb gold pzkbig" id="pzkeq" ${eq?'disabled':''}>${eq?'In your hand':'Equip'} ${eq?'':'<kbd>Enter</kbd>'}</button>`;
 else if(it.price){const ok=P.gold>=it.price;act=`<div class="pzksum"><div><small>PRICE</small><b>${cmn(it.price)}</b></div><i>→</i><div><small>YOU HAVE</small><b>${cmn(P.gold)}</b></div><i>→</i><div class="${ok?'ok':'no'}"><small>AFTER</small><b>${ok?cmn(P.gold-it.price):'not enough'}</b></div></div>
  <button class="pzmb gold pzkbig pzkhold" id="pzkbuy" ${ok?'':'disabled'}><i class="pzkfill"></i><span>${ok?`Hold to buy · ${cmn(it.price)}`:'Not enough gold'}</span>${ok?'<kbd>hold Enter</kbd>':''}</button>`}
 else if(who){const met=who==='shade'?(Z.shade.seen||0)>0:pzOpen(who),need=tab==='cues'?3:(it.beatShade||1),n=who==='shade'?(Z.shade.beat||0):(Z.beat[who]||0);
  act=`<div class="pzkprog"><div><b>${met?`${Math.min(n,need)} / ${need} wins against ${PZ_REG[who].n}`:'A regular you have not met yet'}</b><em><i style="transform:scaleX(${met?Math.min(n,need)/need:0})"></i></em></div></div>${met&&who!=='shade'?`<button class="pzmb pzkbig" id="pzkch">Challenge ${pzShort(who)} ›</button>`:`<button class="pzmb pzkbig" disabled>Locked</button>`}`}
 d.innerHTML=`<div class="pzkpv"><canvas id="pzkpv" width="820" height="420"></canvas></div><div class="pzh3k">${it.n}</div><p class="pzkfrom">${from}</p>${act}`;
 d.classList.remove('in');void d.offsetWidth;d.classList.add('in');
 {const cv=$('pzkpv'),g=cv.getContext('2d');const f=()=>{if(!cv.isConnected)return;pzRackPreview(g,tab,it,performance.now()/1000)};f();LIVE.push({cv,fn:f,slow:1,ph:0})}
 const e=$('pzkeq');if(e)e.onclick=()=>{if(tab==='cues')Z.cue=it.id;else if(tab==='felts')Z.felt=it.id;else Z.balls=it.id;save();pzFx('place');pzRkWall(false);pzRkDetail();pzRkLoad()};
 const c=$('pzkch');if(c)c.onclick=()=>{PZ.sel=who;pzGo(pzHub)};
 const b=$('pzkbuy');if(b&&!b.disabled)pzRkHold(b,()=>{if(it.price&&P.gold>=it.price&&cTake(it.price)){own[it.id]=1;Z.seen=Z.seen||{};Z.seen[it.id]=1;if(tab==='cues')Z.cue=it.id;else if(tab==='felts')Z.felt=it.id;else Z.balls=it.id;save();pzFx('win');const gd=$('pzkgold');if(gd)gd.textContent=cmn(P.gold);pzRkBurst(b);pzRkWall(false);pzRkDetail();pzRkLoad();pzNote(`${it.n} is yours, and in your hand.`)}})}
function pzRkThumb(g,tab,it,w,h){if(tab!=='balls'){pzRackThumb(g,tab,it,w,h);return}g.clearRect(0,0,w,h);pzbSetup(PZ_BS.D||52,it.id);const n=[1,3,8,9,15],sz=h-4,gap=Math.min(sz+6,(w-sz)/(n.length-1));for(let i=0;i<n.length;i++){const M=pzbRot(pzbRot(pzbI(),0,1,0,.3+i*.2),1,0,0,-.2);pzbPaint(15,n[i],M);g.drawImage(PZ_BS.atlas,15*PZ_BS.D,0,PZ_BS.D,PZ_BS.D,w-sz-(n.length-1-i)*gap,2,sz,sz)}pzbSetup(PZ_BS.D,PZS().balls)}
function pzRkLoad(){ov.querySelectorAll('.pzkls').forEach(b=>{const k=b.dataset.t,it=pzRkList(k).find(x=>x.id===pzRkEq(k))||pzRkList(k)[0];b.querySelector('b').textContent=it.n;const cv=b.querySelector('canvas');try{pzRkThumb(cv.getContext('2d'),k,it,180,34)}catch(e){}})}
/* hold-to-buy: the fill grows for 700 ms; letting go early cancels */
function pzRkHold(b,done){const fill=b.querySelector('.pzkfill');let t0=0,raf=0;const stop=()=>{t0=0;cancelAnimationFrame(raf);fill.style.transform='scaleX(0)'};
 const step=()=>{if(!t0||!b.isConnected)return;const u=Math.min(1,(performance.now()-t0)/700);fill.style.transform=`scaleX(${u})`;if(u>=1){t0=0;done();return}raf=requestAnimationFrame(step)};
 const start=()=>{if(t0)return;t0=performance.now();pzFx('tick');raf=requestAnimationFrame(step)};b._hold={start,stop};
 b.addEventListener('pointerdown',e=>{e.preventDefault();start()});for(const ev of['pointerup','pointerleave','pointercancel'])b.addEventListener(ev,stop)}
function pzRkBurst(b){const host=$('pzk');if(!host||pzRM())return;const r=b.getBoundingClientRect(),hb=host.getBoundingClientRect(),s=hb.width/1600||1,x=(r.left+r.width/2-hb.left)/s,y=(r.top-hb.top)/s;
 for(let i=0;i<24;i++){const c=document.createElement('i');c.className='pzcoinfx';c.style.left=x+'px';c.style.top=y+'px';c.style.setProperty('--x',(Math.random()*500-250)+'px');c.style.setProperty('--y',(-(120+Math.random()*220))+'px');c.style.setProperty('--d',(Math.random()*.3)+'s');host.appendChild(c);setTimeout(()=>c.remove(),2000)}}
if(!window.__pzRkKeys){window.__pzRkKeys=1;const kd=e=>{try{if(!ov.querySelector('.pzrk9')||PZ.modal||pzCoachActive())return;const k=e.key;
 if(e.type==='keyup'){if(k==='Enter'){const b=$('pzkbuy');if(b&&b._hold)b._hold.stop()}return}
 if(k==='Enter'){const b=$('pzkbuy');if(b&&b._hold&&!b.disabled){e.preventDefault();if(!e.repeat)b._hold.start();return}const q=$('pzkeq');if(q&&!q.disabled&&!e.repeat){e.preventDefault();q.click()}return}
 if(e.repeat)return;const tabs=PZ_RKTABS.map(x=>x[0]),i=tabs.indexOf(PZ.rackTab);
 if(k==='q'||k==='Q'){e.preventDefault();pzRkTab(tabs[(i+2)%3]);return}if(k==='e'||k==='E'){e.preventDefault();pzRkTab(tabs[(i+1)%3]);return}
 if(/^[1-3]$/.test(k)){e.preventDefault();pzRkTab(tabs[+k-1]);return}
 if(k==='ArrowLeft'||k==='ArrowRight'){const bs=[...ov.querySelectorAll('#pzkwall .pzki')],j=bs.findIndex(b=>b.classList.contains('sel')),n=bs[Math.max(0,Math.min(bs.length-1,j+(k==='ArrowRight'?1:-1)))];if(n){e.preventDefault();n.click()}}}catch(err){}};
 addEventListener('keydown',kd);addEventListener('keyup',kd)}
{const st=document.createElement('style');st.textContent=`
.pzrk9 .pzback{display:flex;align-items:center;gap:10px}
.pzktabs9{position:absolute;left:50%;top:92px;transform:translateX(-50%);display:flex;gap:0;padding:5px;border-radius:18px;background:#100a30;border:3px solid #4a3e90;z-index:3}
.pzktabs9 button{position:relative;z-index:1;height:40px;padding:0 24px;border:0;border-radius:13px;background:transparent;box-shadow:none;color:#c4badf;font:800 16px Poppins,sans-serif;cursor:pointer}.pzktabs9 button.on{color:#2a1a04}.pzktabs9 button em{font-style:normal;font-size:12px;opacity:.75}
.pzktp{position:absolute;left:0;top:5px;height:40px;border-radius:13px;background:linear-gradient(180deg,#ffe27a,#f2b631);box-shadow:0 3px 0 #9a6a10;transition:transform .3s cubic-bezier(.3,1.4,.5,1);z-index:0}
.pzktabs9 kbd{position:absolute;top:13px;font:800 10px/18px Poppins,sans-serif;padding:0 5px;border-radius:6px;background:#12081f;border:1px solid #4a3e90;color:#9a90c8}.pzktabs9 kbd.q{left:-30px}.pzktabs9 kbd.e{right:-30px}
.pzkwall{position:absolute;left:24px;top:152px;width:900px;height:596px;box-sizing:border-box;border-radius:24px;background:linear-gradient(180deg,#8a4a1e,#5a2c10);border:4px solid #12081f;box-shadow:inset 0 0 40px #0008,0 12px 30px #000a;z-index:2;overflow:hidden}
.pzkwall::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(90deg,transparent 0 68px,#00000018 68px 70px);pointer-events:none}
.pzkwall.felts,.pzkwall.balls{background:linear-gradient(180deg,#241c60,#110a32);border-color:#4a3e90}.pzkwall.felts::before,.pzkwall.balls::before{display:none}
.pzkrail{position:absolute;left:18px;right:18px;height:20px;border-radius:10px;background:linear-gradient(180deg,#c87a3a,#7a3e18);border:3px solid #12081f}.pzkrail.t{top:52px}.pzkrail.b{top:470px}
.pzkhead{position:absolute;top:14px;padding:4px 12px;border-radius:9px;background:#12081f;color:#ffd45a;font:800 11px Poppins,sans-serif;letter-spacing:.12em}.pzkhead.s{left:80px}.pzkhead.w{left:470px}
.pzkcols{position:absolute;left:28px;right:28px;top:40px;bottom:16px;display:flex;justify-content:space-between;align-items:flex-start}
.pzkgap{width:10px;flex:none}
.pzkc{position:relative;width:60px;height:540px;padding:0;border:0;background:none;box-shadow:none;cursor:pointer;transition:transform .25s cubic-bezier(.3,1.5,.5,1)}
.pzkc canvas{position:absolute;left:0;top:0;width:60px;height:480px}
.pzkc:hover{transform:translateY(-8px)}.pzkc.sel{transform:translateY(-22px)}
.pzkc.sel::before{content:'';position:absolute;left:-4px;right:-4px;top:-4px;height:492px;border:3px solid #ffd45a;border-radius:14px;pointer-events:none}
.pzktag{position:absolute;left:50%;bottom:0;transform:translateX(-50%);min-width:54px;padding:4px 4px;border-radius:9px;border:2px solid #12081f;font:800 10px/1.1 Poppins,sans-serif;text-align:center;white-space:nowrap;display:flex;align-items:center;justify-content:center;gap:3px}
.pzktag canvas{width:18px;height:18px;border-radius:50%}
.pzrk9 .pzktag.inhand{background:#ffd45a;color:#2a1a04}.pzrk9 .pzktag.own{background:#8affb4;color:#06200f}.pzrk9 .pzktag.buy{background:#fff2c8;color:#2a1a04}.pzrk9 .pzktag.poor{background:#3a3456;color:#9a90c8}.pzrk9 .pzktag.prog{background:#3a2f8a;color:#efe8ff}.pzrk9 .pzktag.lock{background:#241e32;color:#8a86a0;min-width:30px}
.pzknew{position:absolute;left:50%;bottom:30px;transform:translateX(-50%);padding:2px 7px;border-radius:8px;background:#ff4a6a;color:#fff;font:800 10px Poppins,sans-serif;text-decoration:none;border:2px solid #12081f}
.pzkwall.in .pzkc{animation:pzkcIn .45s calc(var(--i)*.03s) cubic-bezier(.3,1.4,.5,1) both}
.pzkcards{position:absolute;inset:24px;display:grid;grid-template-columns:1fr 1fr;gap:16px;align-content:start}
.pzkwall.balls .pzkcards{grid-template-columns:1fr}
.pzksw{position:relative;padding:12px 12px 40px;border-radius:18px;background:#140c36;border:3px solid #3a3070;color:#efe8ff;cursor:pointer;text-align:left;box-shadow:none;transition:transform .22s cubic-bezier(.3,1.5,.5,1)}
.pzksw canvas{display:block;width:100%;height:auto;border-radius:12px}.pzksw b{display:block;margin-top:8px;font:400 24px/1.1 "Pirata One",serif}
.pzksw .pzktag{left:auto;right:12px;bottom:10px;transform:none}.pzksw.lock canvas{opacity:.45}
.pzksw:hover{transform:translateY(-4px)}.pzksw.sel{border-color:#ffd45a;transform:translateY(-4px)}
.pzkwall.in .pzksw{animation:pzrise .4s calc(var(--i)*.05s) cubic-bezier(.25,1.3,.45,1) both}
.pzkdet{position:absolute;left:944px;top:152px;width:632px;height:596px;box-sizing:border-box;padding:16px 20px;border-radius:24px;background:linear-gradient(180deg,#221a5a,#100a30);border:3px solid #c99a3a;box-shadow:inset 0 1px 0 #ffffff1f,0 12px 30px #000a;text-align:center;z-index:2}
.pzkdet.in>*{animation:pzrise .35s cubic-bezier(.25,1.3,.45,1) both}.pzkdet.in>*:nth-child(2){animation-delay:.04s}.pzkdet.in>*:nth-child(3){animation-delay:.08s}.pzkdet.in>*:nth-child(n+4){animation-delay:.12s}
.pzkpv{height:300px;border-radius:16px;overflow:hidden;background:#0c0824}.pzkpv canvas{width:586px;height:300px;display:block}
.pzrk9 .pzh3k{margin:12px 0 0;font:400 46px/1 "Pirata One",serif;color:#ffd45a}.pzkfrom{margin:4px 0 0;font:600 14px Poppins,sans-serif;color:#c4badf}
.pzksum{display:flex;align-items:center;justify-content:center;gap:14px;margin:12px 0 0;padding:10px;border-radius:14px;background:#0c0824;border:2px solid #2a2468}.pzksum>i{font-style:normal;color:#8a80c8;font-weight:800}
.pzksum small{display:block;font:800 10px Poppins,sans-serif;letter-spacing:.1em;color:#9a90c8}.pzksum b{font:400 28px/1 "Pirata One",serif;color:#efe8ff}.pzksum .ok b{color:#8affb4}.pzksum .no b{color:#ff9a9a;font-size:20px}
.pzkbig{position:relative;overflow:hidden;width:100%!important;height:60px;margin:12px 0 0!important;font-size:19px!important;display:flex;align-items:center;justify-content:center;gap:12px}
.pzkbig kbd{display:inline-block;padding:0 6px;border-radius:7px;background:#12081f33;border:1px solid #12081f55;font:800 11px/20px Poppins,sans-serif}
.pzkfill{position:absolute;inset:0;background:linear-gradient(90deg,#fff3b0,#ffd45a);transform-origin:0 50%;transform:scaleX(0);pointer-events:none}.pzkhold span,.pzkhold kbd{position:relative}
.pzkprog{margin-top:12px;padding:10px 14px;border-radius:14px;background:#0c0824;border:2px solid #2a2468;text-align:left}.pzkprog b{display:block;font:700 14px Poppins,sans-serif;color:#efe8ff}.pzkprog em{display:block;height:7px;margin-top:6px;border-radius:4px;background:#2a2468;overflow:hidden}.pzkprog em i{display:block;height:100%;background:#ffd45a;transform-origin:0 50%}
.pzkload{position:absolute;left:24px;top:766px;width:1552px;height:112px;box-sizing:border-box;padding:12px 18px;border-radius:24px;background:linear-gradient(180deg,#221a5a,#100a30);border:3px solid #4a3e90;display:flex;align-items:center;gap:14px;z-index:2;box-shadow:0 10px 26px #0009}
.pzkload .pzh3k{width:110px;font:400 30px/1 "Pirata One",serif;color:#ffd45a;margin:0;text-align:left}
.pzkls{position:relative;width:290px;height:84px;padding:8px 12px;border-radius:16px;background:#140c36;border:2px solid #3a3070;color:#efe8ff;text-align:left;cursor:pointer;box-shadow:none;transition:transform .2s cubic-bezier(.3,1.5,.5,1)}.pzkls:hover{transform:translateY(-3px);border-color:#ffd45a}
.pzkls small{display:block;font:800 10px Poppins,sans-serif;letter-spacing:.12em;color:#9a90c8}.pzkls b{display:block;font:800 15px Poppins,sans-serif}.pzkls canvas{position:absolute;right:12px;bottom:8px;width:150px;height:28px}.pzkls kbd{position:absolute;right:10px;top:8px;font:800 10px/18px Poppins,sans-serif;padding:0 5px;border-radius:6px;background:#12081f;border:1px solid #4a3e90;color:#9a90c8}
.pzkcol{flex:1;padding-left:10px}.pzkcol div{display:flex;justify-content:space-between;font:800 14px Poppins,sans-serif;color:#efe8ff}.pzkcol div span{color:#ffd45a}.pzkcol em{display:block;height:7px;margin:6px 0;border-radius:4px;background:#2a2468;overflow:hidden}.pzkcol em i{display:block;height:100%;background:linear-gradient(90deg,#8affb4,#ffd45a);transform-origin:0 50%}
.pzkcol p{margin:0;font:600 12.5px Poppins,sans-serif;color:#c4badf}.pzkcol p b{color:#c8a0ff}.pzkcol .pzklook{color:#8a80b8;font-size:11.5px;margin-top:2px}
.pzrk9 .pzkc{display:block;height:540px;padding:0;border-radius:0;background:none;border:0;box-shadow:none}.pzrk9 .pzkc canvas{width:60px;height:480px}
.pzrk9 .pzksw{display:block;height:auto}.pzrk9 .pzkwall.balls .pzksw canvas{width:470px;height:94px}.pzrk9 .pzkwall.balls .pzksw{padding-bottom:16px}.pzrk9 .pzkwall.balls .pzksw .pzktag{bottom:auto;top:16px}.pzrk9 .pzksw canvas{height:auto}.pzrk9 .pzksw b{display:block;font:400 24px/1.1 "Pirata One",serif}
.pzrk9 .pzktabs9 button,.pzrk9 .pzktabs9 button.on{background:transparent;border:0;box-shadow:none}
@keyframes pzkcIn{from{opacity:0;transform:translateY(-60px)}to{opacity:1}}
`;document.head.appendChild(st)}
