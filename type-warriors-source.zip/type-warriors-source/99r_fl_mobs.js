/* ===== UPDATE 10.4, HARVEST MOON RUSH: nine fall monsters and three bosses (99r, prefix flr) =====
   The limited-time Endless variant of the Harvest Festival (99r3 runs it, 99r2 draws its fields). Built like Monster Mash (84a):
   every monster faces left (toward the hero), y=0 is the ground, each has its own silhouette and a small idle story.
   Leaves are baked once into sprites so a swarm costs a few drawImage calls; everything else is plain paths (no shadowBlur / filter). */
const FLRO='#12081f';
const flrA=n=>Math.round(Math.max(0,Math.min(1,n))*255).toString(16).padStart(2,'0');
const flrCy=(t,p)=>((t%p)+p)%p;
const flrSm=x=>x<=0?0:x>=1?1:x*x*(3-2*x);
const flrFO=(g,f,w)=>{g.fillStyle=f;g.fill();if(w){g.strokeStyle=FLRO;g.lineWidth=w;g.stroke()}};
/* ---------- baked leaf sprites (maple and oak, four colours each) ---------- */
const FLR_LEAFC=['#d8401c','#f07a1a','#e8b02a','#a82418','#c8641e','#8a4a1a'];
const FLR_MAPLE=[0,-11,1.6,-6.4,4.6,-8.6,4,-4,8.6,-5.6,7,-2,10.2,.6,5.6,1.6,6.2,4.6,2,3,.8,5.6,-.8,5.6,-2,3,-6.2,4.6,-5.6,1.6,-10.2,.6,-7,-2,-8.6,-5.6,-4,-4,-4.6,-8.6,-1.6,-6.4];
function flrMaplePath(g,s){g.beginPath();g.moveTo(FLR_MAPLE[0]*s,FLR_MAPLE[1]*s);for(let i=2;i<FLR_MAPLE.length;i+=2)g.lineTo(FLR_MAPLE[i]*s,FLR_MAPLE[i+1]*s);g.closePath()}
function flrOakPath(g,s){g.beginPath();g.moveTo(0,-11*s);for(let i=0;i<=8;i++){const u=i/8,y=(-11+u*17)*s,w=(3+Math.sin(u*Math.PI)*4.2)*s*(i%2?1:.72);g.lineTo(w,y)}g.lineTo(.6*s,7*s);g.lineTo(-.6*s,7*s);for(let i=8;i>=0;i--){const u=i/8,y=(-11+u*17)*s,w=(3+Math.sin(u*Math.PI)*4.2)*s*(i%2?1:.72);g.lineTo(-w,y)}g.closePath()}
const FLRLS={};
/* kind 0..5 maple colours, 6..7 oak; returns {c, r}: a 2x canvas holding a leaf about 24 px long */
function flrLeaf(k){k=k|0;const key=k;if(FLRLS[key])return FLRLS[key];const c=document.createElement('canvas');c.width=c.height=56;const g=c.getContext('2d');g.scale(2,2);g.translate(14,14);g.lineJoin='round';
 const col=k<6?FLR_LEAFC[k]:(k===6?'#9a5a1e':'#7a6a22');
 if(k<6)flrMaplePath(g,1.12);else flrOakPath(g,1.1);g.fillStyle=col;g.fill();g.strokeStyle=FLRO;g.lineWidth=1.1;g.stroke();
 g.strokeStyle=shade(col,.35);g.lineWidth=.7;g.beginPath();g.moveTo(0,8);g.lineTo(0,-8);if(k<6){g.moveTo(0,1);g.lineTo(6,-3.6);g.moveTo(0,1);g.lineTo(-6,-3.6);g.moveTo(0,3);g.lineTo(4,4);g.moveTo(0,3);g.lineTo(-4,4)}else{for(const y of[-5,-1,3]){g.moveTo(0,y);g.lineTo(3.6,y-2);g.moveTo(0,y);g.lineTo(-3.6,y-2)}}g.stroke();
 g.strokeStyle='#4a2a10';g.lineWidth=1;g.beginPath();g.moveTo(0,5.6);g.lineTo(.4,10.5);g.stroke();
 return FLRLS[key]={c,r:14}}
/* draw one baked leaf: centre x,y, size s (1 = 24 px), rotation a, flutter f (-1..1 squashes it to fake a turn) */
function flrLeafAt(g,k,x,y,s,a,f){const L=flrLeaf(k);g.save();g.translate(x,y);g.rotate(a);g.scale(s*(f==null?1:Math.max(.18,Math.abs(f))),s);g.drawImage(L.c,-14,-14,28,28);g.restore()}
/* a small crow, facing left (shared by the Murder of Crows, the Scarecrow King's court and the Thieving Crows twist) */
function flrCrow(g,x,y,s,flap,caw,perch){g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';const w=flap==null?0:flap;
 /* tail */
 g.beginPath();g.moveTo(7,-1);g.lineTo(21,-6);g.lineTo(23,-1);g.lineTo(21,4);g.closePath();flrFO(g,'#1c1828',1.2);
 /* far wing */
 if(!perch){g.beginPath();g.moveTo(2,-3);g.quadraticCurveTo(6,-10-w*9,12+w*2,-17*w-4);g.lineTo(8,-2);g.closePath();flrFO(g,'#120f1c',1)}
 /* body and head */
 g.beginPath();g.ellipse(2,0,11.5,7,-.08,0,TAU);flrFO(g,'#221d33',1.4);
 g.strokeStyle='#6a5aa8aa';g.lineWidth=1.3;g.beginPath();g.ellipse(2,-1,8.5,4.4,-.08,Math.PI*1.08,Math.PI*1.86);g.stroke();
 g.beginPath();g.arc(-9,-3.4,5.2,0,TAU);flrFO(g,'#221d33',1.3);
 /* beak (caw opens the lower half) */
 const cw=Math.max(0,caw||0);g.beginPath();g.moveTo(-12.6,-5.2);g.lineTo(-21.5,-3.2-cw*1.2);g.lineTo(-12.8,-2.4);g.closePath();flrFO(g,'#4a4458',1);
 g.beginPath();g.moveTo(-12.8,-2);g.lineTo(-19.5,-1.4+cw*3.4);g.lineTo(-12.6,-.6);g.closePath();flrFO(g,'#3a3446',.9);
 ell(g,-10,-4.4,1.5,1.5,'#ffb830');ell(g,-10.4,-4.8,.5,.5,'#fff');
 /* near wing: folded when perched, flapping otherwise */
 if(perch){g.beginPath();g.moveTo(-3,-3);g.quadraticCurveTo(8,-6,16,1);g.quadraticCurveTo(6,3,-2,2);g.closePath();flrFO(g,'#16121f',1)}
 else{g.beginPath();g.moveTo(-3,-2);g.quadraticCurveTo(2,-8-w*10,-6+w*3,-20*w-2);g.lineTo(1,-19*w-1);g.lineTo(7+w,-16*w);g.lineTo(9,-1);g.closePath();flrFO(g,'#16121f',1.1)}
 /* feet */
 if(perch){g.strokeStyle='#5a5262';g.lineWidth=1.2;g.beginPath();g.moveTo(0,6);g.lineTo(-1,10);g.moveTo(4,6);g.lineTo(4,10);g.stroke()}
 g.restore()}
/* a turkey's tail as one fan: a sector from angle a0 to a1 (radians, 0 = right), banded chestnut, black and buff, cream tips */
function flrFan(g,R,a0,a1,n,warm){g.lineJoin='round';const sec=(r)=>{g.beginPath();g.moveTo(0,0);g.arc(0,0,r,a0,a1);g.closePath()};
 sec(R);g.fillStyle=rgr(g,0,0,R*.15,R,'#5a2a10','#9a5222');g.fill();g.strokeStyle=FLRO;g.lineWidth=Math.max(1.2,R*.03);g.stroke();
 g.strokeStyle='#1a0e08';g.lineWidth=R*.1;g.beginPath();g.arc(0,0,R*.8,a0+.02,a1-.02);g.stroke();
 g.strokeStyle='#d8a050';g.lineWidth=R*.035;g.beginPath();g.arc(0,0,R*.66,a0+.02,a1-.02);g.stroke();
 g.strokeStyle='#2a140888';g.lineWidth=Math.max(1,R*.018);g.beginPath();for(let i=1;i<n;i++){const a=a0+(a1-a0)*i/n;g.moveTo(Math.cos(a)*R*.22,Math.sin(a)*R*.22);g.lineTo(Math.cos(a)*R*.98,Math.sin(a)*R*.98)}g.stroke();
 for(let i=0;i<n;i++){const a=a0+(a1-a0)*(i+.5)/n,w=R*Math.min(.115,(a1-a0)/n*.5);g.beginPath();g.ellipse(Math.cos(a)*R*.93,Math.sin(a)*R*.93,w,w*1.25,a+Math.PI/2,0,TAU);g.fillStyle=warm?'#ffe6b0':'#f2e6c6';g.fill();g.strokeStyle=FLRO;g.lineWidth=Math.max(1,R*.02);g.stroke()}}
/* a folded turkey wing (local coords: shoulder at 0,0, tip toward +x) with barred primaries */
function flrWing(g,L,H){g.beginPath();g.moveTo(0,-H*.3);g.quadraticCurveTo(L*.55,-H*.75,L,H*.15);g.quadraticCurveTo(L*.7,H*.5,L*.45,H*.45);g.quadraticCurveTo(L*.2,H*.55,0,H*.35);g.closePath();g.fillStyle=vgr(g,-H*.6,H*.5,'#6a4626','#3a2412');g.fill();g.strokeStyle=FLRO;g.lineWidth=Math.max(1.2,H*.06);g.stroke();
 g.strokeStyle='#c89a5a88';g.lineWidth=Math.max(1,H*.05);for(let r=0;r<2;r++)for(let i=0;i<3;i++){g.beginPath();g.arc(L*(.12+i*.13+r*.06),-H*(.12-r*.22),H*.16,Math.PI*.1,Math.PI*.9);g.stroke()}
 g.save();g.beginPath();g.moveTo(L*.5,-H*.5);g.quadraticCurveTo(L*.8,-H*.4,L,H*.15);g.quadraticCurveTo(L*.7,H*.5,L*.45,H*.45);g.closePath();g.clip();g.strokeStyle='#efe6d4';g.lineWidth=Math.max(1.2,H*.07);g.setLineDash([H*.12,H*.12]);for(let i=0;i<3;i++){g.beginPath();g.moveTo(L*.48,-H*.2+i*H*.22);g.quadraticCurveTo(L*.78,-H*.18+i*H*.18,L*.98,H*.1+i*H*.08);g.stroke()}g.setLineDash([]);g.restore()}
const FLRD={};

/* 1. Straw Scarecrow: hops on its one pole, plaid shirt stuffed with straw, a button eye and an ember eye. A crow rides its arm. */
FLRD.flrscare=(g,t,o)=>{const lg=(o&&o.lg)||0,ph=flrCy(t*1.55,1),hop=Math.sin(ph*Math.PI),H=hop*11,land=Math.max(0,1-ph/.14)+Math.max(0,(ph-.9)/.1),sx=1+.05*land,sy=1-.07*land;
 g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-H);g.rotate(-lg*.2+Math.sin(ph*TAU)*.035);g.scale(sx,sy);
 /* the stake */
 g.beginPath();g.moveTo(-3.4,-100);g.lineTo(3.4,-100);g.lineTo(3,-6);g.lineTo(0,1);g.lineTo(-3,-6);g.closePath();flrFO(g,'#6a4626',1.6);g.fillStyle='#ffffff18';g.fillRect(-2.6,-98,1.6,90);
 /* straw skirt */
 for(let i=0;i<11;i++){const x=-14+i*2.8,l=12+((i*7)%5)*2,sw=Math.sin(t*3+i)*1.6;g.strokeStyle=i%3?'#e8c35a':'#c8962a';g.lineWidth=2.2;g.beginPath();g.moveTo(x,-40);g.quadraticCurveTo(x+sw,-30,x+(i-5)*.9+sw*1.6,-40+l);g.stroke()}
 /* sleeves on the crossbar, both arms out */
 const arm=(dir,c)=>{const tip=dir*40,dy=dir<0?-lg*10:0;g.beginPath();g.moveTo(dir*12,-82);g.lineTo(tip,-79+dy);g.lineTo(tip-dir*1,-68+dy);g.lineTo(dir*12,-64);g.closePath();flrFO(g,c,1.6);
  g.strokeStyle='#00000040';g.lineWidth=1.4;g.beginPath();g.moveTo(dir*20,-80);g.lineTo(dir*20,-65);g.moveTo(dir*30,-79+dy*.6);g.lineTo(dir*30,-67+dy*.6);g.stroke();
  for(let i=0;i<6;i++){const a=(i-2.5)*.32+Math.sin(t*4+i+dir)*.12;g.strokeStyle=i%2?'#f0d070':'#c8962a';g.lineWidth=2;g.beginPath();g.moveTo(tip,-73.5+dy);g.lineTo(tip+dir*Math.cos(a)*11,-73.5+dy+Math.sin(a)*11);g.stroke()}};
 arm(1,'#8a2a1c');
 /* plaid shirt */
 g.beginPath();g.moveTo(-17,-82);g.lineTo(17,-82);g.lineTo(13,-40);g.lineTo(-14,-40);g.closePath();g.fillStyle='#b03a26';g.fill();
 g.save();g.clip();g.fillStyle='#7a221666';for(const x of[-12,-2,8])g.fillRect(x,-84,4,46);for(const y of[-76,-62,-48])g.fillRect(-18,y,36,4);g.strokeStyle='#f0a85066';g.lineWidth=1;for(const x of[-7,3,13]){g.beginPath();g.moveTo(x,-84);g.lineTo(x,-38);g.stroke()}
 g.fillStyle='#3a6aa8';g.fillRect(2,-66,10,10);g.strokeStyle='#e8e0c8';g.setLineDash([2,2]);g.strokeRect(2.5,-65.5,9,9);g.setLineDash([]);g.restore();
 g.beginPath();g.moveTo(-17,-82);g.lineTo(17,-82);g.lineTo(13,-40);g.lineTo(-14,-40);g.closePath();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
 limb(g,-14,-43,13,-43,3.2,'#c8a060');ell(g,-4,-43,2.6,2.2,'#a88040');
 arm(-1,'#a2321f');
 /* burlap head */
 g.beginPath();g.moveTo(-9,-82);g.lineTo(-13,-88);g.lineTo(9,-88);g.lineTo(6,-82);g.closePath();flrFO(g,'#b8925a',1.2);limb(g,-12,-86.5,8,-86.5,2.4,'#7a5a30');
 g.save();g.translate(-3,-101);g.rotate(Math.sin(t*1.3)*.06-lg*.1);
 g.beginPath();g.ellipse(0,0,15.5,16.5,0,0,TAU);g.fillStyle=rgr(g,-5,-6,2,20,'#d8b47a','#a8824a');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
 g.strokeStyle='#8a6a3a55';g.lineWidth=.8;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*4,-15);g.lineTo(i*4.4,15);g.stroke();g.beginPath();g.moveTo(-15,i*4);g.lineTo(15,i*4.2);g.stroke()}
 /* button eye (front) and stitched ember eye (back) */
 ell(g,-8,-2,4.2,4.2,'#2a1a14');for(const [a,b] of[[-9.2,-3.2],[-6.8,-3.2],[-9.2,-.8],[-6.8,-.8]])ell(g,a,b,.7,.7,'#7a5a40');
 const em=.65+.35*Math.sin(t*5.3)+.1*Math.sin(t*17);glow(g,3,-3,9,'#ff9a30'+flrA(.55*em));g.strokeStyle='#2a1810';g.lineWidth=1.6;g.beginPath();g.moveTo(.6,-5.4);g.lineTo(5.4,-.6);g.moveTo(5.4,-5.4);g.lineTo(.6,-.6);g.stroke();ell(g,3,-3,1.2,1.2,'#ffd27a');
 /* stitched grin */
 g.strokeStyle='#2a1810';g.lineWidth=1.7;g.beginPath();g.moveTo(-13,6);g.quadraticCurveTo(-5,11.5,4,7);g.stroke();g.lineWidth=1.1;for(let i=0;i<5;i++){const x=-11+i*3.6,y=7.6+Math.sin((i+.5)/5*Math.PI)*2.4;g.beginPath();g.moveTo(x,y-2.2);g.lineTo(x+.6,y+2.2);g.stroke()}
 /* floppy hat with a sunflower */
 for(let i=0;i<4;i++){g.strokeStyle='#e8c35a';g.lineWidth=1.8;g.beginPath();g.moveTo(-14+i*2,-10);g.lineTo(-19+i*1.2,-3+i*2);g.stroke()}
 g.beginPath();g.ellipse(1,-12,23,5,-.05,0,TAU);flrFO(g,'#6a4a2e',1.6);
 g.beginPath();g.moveTo(-11,-13);g.quadraticCurveTo(-10,-27,1,-29);g.quadraticCurveTo(10,-30,15,-22+Math.sin(t*2)*1.2);g.quadraticCurveTo(13,-18,12,-13);g.closePath();flrFO(g,'#7a5634',1.6);
 g.beginPath();g.moveTo(-11,-14);g.lineTo(12,-14);g.lineTo(12.6,-18);g.lineTo(-10.6,-18);g.closePath();flrFO(g,'#c8402a',0);
 for(let i=0;i<7;i++){const a=i/7*TAU+t*.4;ell(g,8+Math.cos(a)*3.4,-16+Math.sin(a)*3.4,2,1.2,'#ffcc2a',a)}ell(g,8,-16,1.8,1.8,'#5a3a14');
 g.restore();
 /* the crow on the back arm: perches, pecks, flaps up and lands again */
 const u=flrCy(t,5.2);let cy=-80,cx=32,fl=null,pk=0;
 if(u>3.7&&u<4.6){const k=(u-3.7)/.9;cy-=Math.sin(k*Math.PI)*22;cx+=Math.sin(k*Math.PI)*6;fl=Math.sin(u*30)}else if(u>1.2&&u<2.4)pk=Math.max(0,Math.sin((u-1.2)*TAU*2.5));
 g.save();g.translate(cx,cy);g.rotate(pk*.5);flrCrow(g,0,0,.62,fl,u>.4&&u<.7?1:0,fl==null);g.restore();
 /* a strand of straw falls out now and then */
 for(let i=0;i<2;i++){const k=flrCy(t*.45+i*.5,1);g.globalAlpha=(1-k)*.9;g.strokeStyle='#e8c35a';g.lineWidth=1.6;const fx=-8+i*14+Math.sin(k*6+i)*5,fy=-34+k*34;g.beginPath();g.moveTo(fx,fy);g.lineTo(fx+4*Math.cos(k*5+i),fy+4*Math.sin(k*5+i));g.stroke()}g.globalAlpha=1;
 g.restore()};

/* 2. Pie-Crust Mimic: a lattice apple pie on cinnamon-stick legs. The lid is a jaw full of crust teeth; it snaps at the air and eats its own apple slices. */
FLRD.flrpie=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*7.4),u=flrCy(t,2.7);g.save();g.lineJoin='round';g.lineCap='round';
 let a=0;if(u>1.55&&u<1.9)a=flrSm((u-1.55)/.35)*.62;else if(u>=1.9&&u<2.12)a=.62;else if(u>=2.12&&u<2.24)a=.62*(1-(u-2.12)/.12);a=Math.max(a,lg*.75);
 /* cinnamon-stick legs */
 for(const [x,k] of[[-22,0],[16,1],[-10,1],[26,0]]){const sw=(k?s:-s)*6;limb(g,x,-14,x+sw,-2,5.4,'#8a4a22');g.strokeStyle='#5a2a10';g.lineWidth=.9;g.beginPath();g.moveTo(x-1.6,-11);g.lineTo(x+sw*.6+1.6,-6);g.stroke();ell(g,x+sw-1.5,-1,4.2,2.2,'#6a3416')}
 const bob=Math.abs(s)*1.6;g.translate(0,-bob);
 /* tin */
 g.beginPath();g.moveTo(-31,-12);g.lineTo(31,-12);g.lineTo(38,-30);g.lineTo(-38,-30);g.closePath();g.fillStyle=vgr(g,-30,-12,'#d8dce6','#7a8090');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
 g.strokeStyle='#5a607066';g.lineWidth=1;for(let x=-32;x<=32;x+=6){g.beginPath();g.moveTo(x,-29);g.lineTo(x*.82,-13);g.stroke()}
 /* open mouth: dark inside, bubbling filling and a tongue */
 if(a>.03){g.beginPath();g.ellipse(0,-32,37,9+a*14,0,Math.PI,TAU);g.fillStyle='#2a0a08';g.fill();
  g.beginPath();g.ellipse(0,-31,33,6,0,Math.PI,TAU);g.fillStyle='#e89a2e';g.fill();for(let i=0;i<5;i++){const k=flrCy(t*1.4+i*.21,1);ell(g,-24+i*12,-33-k*4,2.2*(1-k)+.4,2*(1-k)+.4,'#ffd27a')}
  g.fillStyle='#f4e0a0';for(const [x,y] of[[-18,-34],[6,-35],[18,-33]])g.fillRect(x,y,5,4);
  g.beginPath();g.moveTo(-14,-33);g.quadraticCurveTo(-30-a*10,-30,-38-a*8,-22+Math.sin(t*6)*2);g.quadraticCurveTo(-28,-24,-8,-31);g.closePath();flrFO(g,'#d8505a',1.2);
  g.fillStyle='#f4e8c8';for(let i=0;i<7;i++){const x=-30+i*10;g.beginPath();g.moveTo(x,-34);g.lineTo(x+4,-41-a*4);g.lineTo(x+8,-34);g.fill()}}
 /* crust rim (lower jaw) */
 g.beginPath();g.moveTo(-41,-27);for(let i=0;i<=10;i++){const x=-41+i*8.2;g.quadraticCurveTo(x+4.1,-37,x+8.2,-27)}g.lineTo(41,-26);g.lineTo(-41,-26);g.closePath();flrFO(g,'#e8a850',1.4);g.fillStyle='#c07a2a88';g.fillRect(-40,-29,80,3);
 /* the apple slice it tosses up and swallows */
 if(u>1.62&&u<2.14){const k=(u-1.62)/.52;g.save();g.translate(-6+k*6,-40-Math.sin(k*Math.PI)*34);g.rotate(k*7);g.beginPath();g.arc(0,0,6,Math.PI*.1,Math.PI*.9+Math.PI);g.closePath();flrFO(g,'#f6eac0',1);g.strokeStyle='#c8382a';g.lineWidth=2;g.beginPath();g.arc(0,0,6,Math.PI*1.1,Math.PI*1.9);g.stroke();g.restore()}
 /* lid: lattice crust on a back hinge */
 g.save();g.translate(38,-32);g.rotate(a);g.translate(-38,32);
 g.beginPath();g.moveTo(-41,-32);g.quadraticCurveTo(-36,-52,0,-54);g.quadraticCurveTo(36,-52,41,-32);g.closePath();g.fillStyle=vgr(g,-54,-32,'#f0c070','#c8843a');g.fill();
 g.save();g.clip();g.fillStyle='#8a3a14';for(let i=0;i<6;i++){const x=-34+i*13.5;g.beginPath();g.ellipse(x,-41,3.2,4.4,0,0,TAU);g.fill()}
 g.strokeStyle='#f8d890';g.lineWidth=5.2;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*14-14,-30);g.lineTo(i*14+12,-58);g.stroke()}g.strokeStyle='#c8843a88';g.lineWidth=1;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*14-11.6,-30);g.lineTo(i*14+14.4,-58);g.stroke()}
 g.strokeStyle='#f0c87a';g.lineWidth=5;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*14+14,-30);g.lineTo(i*14-12,-58);g.stroke()}g.restore();
 g.beginPath();g.moveTo(-41,-32);g.quadraticCurveTo(-36,-52,0,-54);g.quadraticCurveTo(36,-52,41,-32);g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
 g.beginPath();g.moveTo(-42,-32);for(let i=0;i<=10;i++){const x=-42+i*8.4;g.quadraticCurveTo(x+4.2,-27,x+8.4,-32)}g.strokeStyle='#e8a850';g.lineWidth=3.4;g.stroke();
 if(a>.03){g.fillStyle='#f4e8c8';for(let i=0;i<7;i++){const x=-31+i*10;g.beginPath();g.moveTo(x,-31);g.lineTo(x+4,-24);g.lineTo(x+8,-31);g.fill()}}
 /* eyes peeking out of the lattice */
 const bl=flrCy(t,3.3)<.12?.15:1;for(const [x,y] of[[-25,-40],[-13,-44]]){ell(g,x,y,4.2,3.8*bl,'#2a0a04');ell(g,x-.6,y,2.6,2.4*bl,'#ffd040');ell(g,x-1.4,y,1.1,1.6*bl,'#2a0a04')}
 g.restore();
 /* steam from the vents */
 g.lineWidth=2;for(let i=0;i<3;i++){const k=flrCy(t*.6+i*.33,1);g.strokeStyle='#ffffff'+flrA(.42*(1-k));g.beginPath();const x0=-12+i*12;g.moveTo(x0,-54-k*8);g.bezierCurveTo(x0-6,-60-k*20,x0+6,-66-k*24,x0+Math.sin(t*2+i)*4,-74-k*26);g.stroke()}
 g.restore()};

/* 3. Acorn Knight: a nut in an acorn-cap helmet with a twig lance and an oak-leaf shield. Its helmet keeps slipping over its eyes. */
FLRD.flracorn=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*6.4),b=Math.abs(Math.cos(t*6.4))*1.8,u=flrCy(t,6.4);g.save();g.lineJoin='round';g.lineCap='round';
 const slip=u>3.1&&u<4.3?flrSm((u-3.1)/.25)*(1-flrSm((u-3.95)/.3)):0,push=u>3.7&&u<4.3?Math.sin((u-3.7)/.6*Math.PI):0;
 /* twig legs and cap boots */
 for(const [hx,k] of[[5,1],[-5,-1]]){const fx=hx+k*s*7;limb(g,hx,-24,fx,-3,3.4,k>0?'#5a3a1e':'#6a4626');g.beginPath();g.ellipse(fx-2,-2.4,6,3.4,0,Math.PI,TAU);flrFO(g,'#7a5a34',1.1)}
 g.translate(0,-b);
 /* far arm and lance (behind the body) */
 const lx=-lg*16;limb(g,-8,-48,-18+lx*.4,-43,2.8,'#5a3a1e');
 g.save();g.translate(-20+lx,-41);g.rotate(-.12+Math.sin(t*6.4)*.03);limb(g,18,0,-40,0,3,'#7a5a30');g.beginPath();g.moveTo(-40,-2.4);g.lineTo(-50,0);g.lineTo(-40,2.4);g.closePath();flrFO(g,'#e8dcc0',1);
 g.save();g.translate(-30,-1);g.rotate(-1.9+Math.sin(t*7)*.15);flrLeafAt(g,1,0,-6,.5,0,Math.cos(t*7));g.restore();g.restore();
 /* the nut */
 g.beginPath();g.moveTo(-19,-58);g.bezierCurveTo(-23,-36,-10,-22,0,-17);g.bezierCurveTo(10,-22,23,-36,19,-58);g.closePath();g.fillStyle=rgr(g,-6,-46,3,30,'#d89a4a','#7a4416');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
 g.strokeStyle='#ffffff30';g.lineWidth=2.4;g.beginPath();g.moveTo(-13,-52);g.quadraticCurveTo(-15,-38,-8,-28);g.stroke();ell(g,0,-17,1.6,2.6,'#4a2a10');
 /* eyes and a twig moustache under the brim */
 const ey=-49+slip*2,eo=1-slip*.95;ell(g,-11,ey,3.4,2.6*eo+.2,'#1a0c04');ell(g,-3,ey-.4,3,2.4*eo+.2,'#1a0c04');if(eo>.3){ell(g,-11.6,ey,1.4,1.2,'#ffd04a');ell(g,-3.6,ey-.4,1.3,1.1,'#ffd04a')}
 g.strokeStyle='#4a2a10';g.lineWidth=1.8;g.beginPath();g.moveTo(-15,-42.5);g.quadraticCurveTo(-11,-40,-7.5,-43);g.quadraticCurveTo(-4,-40,0,-42.5);g.stroke();
 /* oak-leaf shield on the near arm */
 g.save();g.translate(9-push*3,-33-push*20);g.rotate(.12-push*.6);g.scale(.9,.9);g.beginPath();g.moveTo(0,-17);for(let i=0;i<=6;i++){const y=-17+i*5.4,w=(i%2?9.5:6.5)*(1-Math.abs(i-3)/7);g.lineTo(w,y)}g.lineTo(0,17);for(let i=6;i>=0;i--){const y=-17+i*5.4,w=(i%2?9.5:6.5)*(1-Math.abs(i-3)/7);g.lineTo(-w,y)}g.closePath();g.fillStyle=vgr(g,-17,17,'#a8a03a','#5a6a1e');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.6;g.stroke();
 g.strokeStyle='#e8e08a88';g.lineWidth=1;g.beginPath();g.moveTo(0,-15);g.lineTo(0,15);for(const y of[-9,-2,5]){g.moveTo(0,y);g.lineTo(5,y-3);g.moveTo(0,y);g.lineTo(-5,y-3)}g.stroke();g.restore();
 limb(g,12,-46,9-push*3,-30-push*20,2.6,'#6a4626');
 /* acorn-cap helmet */
 g.save();g.translate(0,slip*6);g.beginPath();g.moveTo(-23,-58);g.quadraticCurveTo(-24,-84,0,-86);g.quadraticCurveTo(24,-84,23,-58);g.closePath();g.fillStyle=vgr(g,-86,-58,'#9a7240','#5a3e1e');g.fill();
 g.save();g.clip();g.strokeStyle='#4a321a';g.lineWidth=1.1;for(let r=0;r<5;r++)for(let i=0;i<8;i++){const x=-24+i*6.4+(r%2)*3.2,y=-80+r*5.4;g.beginPath();g.arc(x,y,3.4,Math.PI*.15,Math.PI*.85);g.stroke()}g.restore();
 g.beginPath();g.moveTo(-23,-58);g.quadraticCurveTo(-24,-84,0,-86);g.quadraticCurveTo(24,-84,23,-58);g.closePath();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
 g.beginPath();g.ellipse(0,-58,25,4.6,0,0,TAU);flrFO(g,'#6a4a26',1.5);
 /* stem with a red leaf plume */
 limb(g,0,-86,2,-93,2.6,'#4a321a');g.save();g.translate(3,-93);g.rotate(-.9+Math.sin(t*5)*.25);flrLeafAt(g,3,0,-7,.62,0,1);g.restore();g.restore();
 g.restore()};

/* 4. Murder of Crows: three crows flying as one. They jostle for the lead and the leader never stops cawing. */
FLRD.flrcrow=(g,t,o)=>{const lg=(o&&o.lg)||0;g.save();g.translate(-lg*14,-50);
 const sw=flrSm(Math.min(1,Math.max(0,(flrCy(t,8)-6.8)/1)))*(flrCy(t,16)<8?1:-1)+(flrCy(t,16)<8?0:1);/* 0..1: leader and wingman trade places every 8 s */
 const P0=[-14,-2],P1=[18,-20];const A=[P0[0]+(P1[0]-P0[0])*sw,P0[1]+(P1[1]-P0[1])*sw],B=[P1[0]+(P0[0]-P1[0])*sw,P1[1]+(P0[1]-P1[1])*sw];
 const L=[[A[0],A[1],1.15,0],[B[0],B[1],.9,1],[14,20,.82,2]].map(([x,y,s,i])=>[x+Math.cos(t*.9+i*2)*5,y+Math.sin(t*1.2+i*1.7)*5,s,i]).sort((p,q)=>q[2]-p[2]);
 for(let k=L.length-1;k>=0;k--){const [x,y,s,i]=L[k],caw=flrCy(t+i*1.1,3.2)<.45?Math.sin(flrCy(t+i*1.1,3.2)/.45*Math.PI):0;flrCrow(g,x,y,s,Math.sin(t*9.5+i*1.9),caw,false);
  if(i===1){ell(g,x-19*s,y-2.4*s,2.4,1.8,'#ffd84a');ell(g,x-19.6*s,y-3*s,.8,.6,'#fff')}}
 /* loose feathers */
 for(let i=0;i<2;i++){const k=flrCy(t*.5+i*.5,1);g.globalAlpha=(1-k)*.8;g.save();g.translate(16+i*10+k*14,6+k*40);g.rotate(k*6+i);g.beginPath();g.ellipse(0,0,4.6,1.6,0,0,TAU);g.fillStyle='#2a2440';g.fill();g.restore()}g.globalAlpha=1;
 g.restore()};

/* 5. Maple Sprite Swarm: a giggling amber sprite in a whirl of maple leaves. The leaves spiral in and burst out again. */
FLRD.flrmaple=(g,t,o)=>{const lg=(o&&o.lg)||0,bob=Math.sin(t*2.4)*6,u=flrCy(t,5);g.save();g.translate(-lg*12,-48+bob);
 let R=30+Math.sin(t*.8)*4;if(u>3.4&&u<4.6){const k=(u-3.4)/1.2;R=k<.5?30-flrSm(k*2)*20:10+flrSm((k-.5)*2)*24}else if(u>=4.6)R=34-(u-4.6)/.4*4;
 const N=7,leaves=[];for(let i=0;i<N;i++){const a=t*1.7+i*TAU/N;leaves.push({x:Math.cos(a)*R*1.15,y:Math.sin(a)*R*.42+Math.sin(a*2+t)*3,z:Math.sin(a),k:i%6,r:a*1.3+t*2})}
 for(const L of leaves)if(L.z<0)flrLeafAt(g,L.k,L.x,L.y,.78,L.r,Math.cos(t*4+L.k));
 glow(g,0,0,40,'#ffb040'+flrA(.42+.12*Math.sin(t*3)));
 /* leaf wings */
 const fw=.55+.45*Math.sin(t*15);g.save();g.translate(5,-5);g.rotate(-.7);g.scale(fw,1);flrLeafAt(g,0,0,-10,.9,0,1);g.restore();g.save();g.translate(7,-3);g.rotate(.5);g.scale(fw*.9,1);flrLeafAt(g,1,0,-9,.8,0,1);g.restore();
 /* the sprite */
 g.beginPath();g.arc(0,0,10.5,0,TAU);g.fillStyle=rgr(g,-3,-3,1,12,'#fff6c8','#ff9a2a');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.5;g.stroke();
 const gig=flrCy(t,2.6)<.5;ell(g,-4.4,-1.4,1.7,gig?.6:2.2,'#5a1a06');ell(g,1.6,-1.8,1.5,gig?.6:2,'#5a1a06');
 g.strokeStyle='#5a1a06';g.lineWidth=1.3;g.beginPath();g.arc(-1.6,2.4,gig?3.4:2.6,Math.PI*.15,Math.PI*.85);g.stroke();ell(g,-6.6,2.2,1.8,1,'#ff7a5a88');
 g.save();g.translate(-1,-11);g.rotate(Math.sin(t*3)*.2);flrLeafAt(g,3,0,-3.6,.4,0,1);g.restore();
 for(const L of leaves)if(L.z>=0)flrLeafAt(g,L.k,L.x,L.y,.95,L.r,Math.cos(t*4+L.k));
 /* sparkle trail */
 for(let i=0;i<4;i++){const k=flrCy(t*1.2+i*.25,1);g.globalAlpha=(1-k)*.9;ell(g,14+k*30,Math.sin(t*3+i)*6+k*4,1.8*(1-k)+.4,1.8*(1-k)+.4,'#fff0b0')}g.globalAlpha=1;
 g.restore()};

/* 6. Wild Turkey Charger: a big bronze turkey at full sprint. Every few strides it stops showing off: the tail fans open and it gobbles. */
FLRD.flrturkey=(g,t,o)=>{const lg=(o&&o.lg)||0,u=flrCy(t,5.2),disp=u>2.9&&u<4.4?flrSm((u-2.9)/.35)*(1-flrSm((u-4.05)/.35)):0,gob=u>3.35&&u<3.95?Math.sin((u-3.35)/.6*Math.PI):0;
 const run=1-disp*.8,s=Math.sin(t*10)*run,b=Math.abs(Math.cos(t*10))*3*run;g.save();g.lineJoin='round';g.lineCap='round';
 /* legs */
 for(const [hx,k] of[[4,1],[14,-1]]){const a=k*s*.62,kx=hx+Math.sin(a)*14,ky=-36+Math.cos(a)*13-13,fx=kx+Math.sin(a*1.3)*12,fy=-2;limb(g,hx,-38,kx,ky+10,4.4,'#b89488');limb(g,kx,ky+10,fx,fy,3.4,'#c8a49a');
  g.strokeStyle='#a8847a';g.lineWidth=2;g.beginPath();g.moveTo(fx,fy);g.lineTo(fx-8,fy+.6);g.moveTo(fx,fy);g.lineTo(fx-5,fy+3);g.moveTo(fx,fy);g.lineTo(fx+4,fy+.4);g.stroke()}
 g.translate(0,-b);const puff=1+disp*.07;
 /* the tail fan: folded while running, a full half-wheel on display */
 const op=.12+disp*.88;g.save();g.translate(22,-58);const ca=-1.2+op*.15;flrFan(g,30+op*22,ca-(.35+op*1.1),ca+(.35+op*1.0),5+Math.round(op*6),0);g.restore();
 /* body */
 g.save();g.translate(6,-52);g.scale(puff,puff);g.beginPath();g.ellipse(0,0,27,21.5,-.1,0,TAU);g.fillStyle=rgr(g,-8,-8,3,30,'#9a6a3a','#3a2414');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.9;g.stroke();
 for(let r=0;r<3;r++)for(let i=0;i<5;i++){const x=-18+i*8.6+(r%2)*4.3,y=-10+r*7;g.strokeStyle=r===1?'#4a8a6a99':'#d8a85a99';g.lineWidth=1.4;g.beginPath();g.arc(x,y,4.2,Math.PI*.1,Math.PI*.9);g.stroke()}
 /* folded wing with barred primaries */
 g.save();g.translate(-8,-6);g.rotate(.12);flrWing(g,36,18);g.restore();
 g.restore();
 /* beard */
 g.strokeStyle='#1a1010';g.lineWidth=1.6;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-16+i,-58);g.quadraticCurveTo(-18+i,-50,-20+i*1.4+Math.sin(t*10+i),-43);g.stroke()}
 /* neck and head (bobs with the stride, pulls back to gobble) */
 const hb=Math.sin(t*10)*3*run,hx=-25+hb-disp*5-lg*12,hy=-86+disp*3+gob*2;
 g.beginPath();g.moveTo(-14,-66);g.quadraticCurveTo(hx+2,-70,hx+2,hy+4);g.lineTo(hx+8,hy+5);g.quadraticCurveTo(hx+9,-66,-6,-62);g.closePath();flrFO(g,'#c8b4c0',1.4);
 for(let i=0;i<4;i++)ell(g,hx+5+i*1.4,hy+10+i*4,2.1,2.1,'#d83838');
 g.save();g.translate(hx,hy);g.rotate(-gob*.2);g.beginPath();g.ellipse(0,0,6.6,6,0,0,TAU);flrFO(g,'#9ac8e8',1.4);
 g.beginPath();g.moveTo(-5.6,-1.6);g.lineTo(-12.6,0+gob*.6);g.lineTo(-5.6,1.4);g.closePath();flrFO(g,'#e8c860',1);if(gob>.2){g.beginPath();g.moveTo(-5.6,1.6);g.lineTo(-11,3.6+gob*2.6);g.lineTo(-5.2,3);g.closePath();flrFO(g,'#d8b050',.8)}
 ell(g,-1.6,-1.6,1.8,1.8,'#1a1010');ell(g,-2,-2,.6,.6,'#fff');
 const sh=Math.sin(t*38)*gob*3;g.beginPath();g.moveTo(-3,-5);g.quadraticCurveTo(-9+sh,-2,-8+sh,9+gob*2);g.quadraticCurveTo(-6+sh,10,-5,7);g.quadraticCurveTo(-5,-1,-1,-4);g.closePath();flrFO(g,'#d83030',.9);
 g.beginPath();g.moveTo(-3,4);g.quadraticCurveTo(-4-sh,12,0-sh*.6,14+gob*2);g.quadraticCurveTo(3,10,2,4);g.closePath();flrFO(g,'#c82828',.9);g.restore();
 if(gob>.4){g.strokeStyle='#ffe8a0'+flrA(gob);g.lineWidth=2;for(let i=0;i<3;i++){const a=-2.6+i*.35;g.beginPath();g.arc(hx-8,hy,16+i*6,a,a+.3);g.stroke()}}
 g.restore()};

/* 7. Gourd Golem: squash legs, a great red pumpkin chest, crookneck arms and a pale gourd head. A little gourd keeps rolling off its shoulder. */
/* 10.4b: the Gourd Golem was the costliest walker to raster (about 30 gradient and ribbed gourds and strokes a frame); its torso
   (the chest pumpkin, its highlight and main vine), its shoulders and its head are now baked once at 3x and only blitted, while the
   parts that move (legs, arms, tendrils, leaves, the rolling gourd, the eyes) are still drawn live. It looks the same. */
const FLRB3={};
function flrB3(key,w,h,ox,oy,draw){let c=FLRB3[key];if(c)return c;c=document.createElement('canvas');c.width=w*3;c.height=h*3;const g=c.getContext('2d');g.setTransform(3,0,0,3,ox*3,oy*3);g.lineJoin='round';g.lineCap='round';try{draw(g)}catch(e){console.error('flrB3 '+key,e)}c.ox=ox;c.oy=oy;c.lw=w;c.lh=h;return FLRB3[key]=c}
const flrB3d=(g,c,x,y)=>g.drawImage(c,x-c.ox,y-c.oy,c.lw,c.lh);
/* one gourd: big ones get a gradient and ribs, small ones a flat fill with a highlight */
function flrGsq(g,x,y,rx,ry,c,rib,rot){g.save();g.translate(x,y);if(rot)g.rotate(rot);g.beginPath();g.ellipse(0,0,rx,ry,0,0,TAU);const big=rx>=20;g.fillStyle=big?rgr(g,-rx*.3,-ry*.35,ry*.1,Math.max(rx,ry)*1.1,shade(c,.3),shade(c,-.25)):c;g.fill();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
  if(!big){g.fillStyle='#ffffff2a';g.beginPath();g.ellipse(-rx*.3,-ry*.4,rx*.4,ry*.22,-.3,0,TAU);g.fill()}
  if(rib){g.strokeStyle=shade(c,-.45)+'aa';g.lineWidth=1.3;g.beginPath();for(let i=1;i<rib;i++){const k=i/rib*2-1,ex=Math.abs(k)*rx*.92+.1;g.moveTo(0,-ry*.96);g.ellipse(0,0,ex,ry*.96,0,k<0?-Math.PI*.5:-Math.PI*.5,k<0?-Math.PI*1.5:Math.PI*.5,k<0)}g.stroke()}g.restore()}
const flrGolemTorso=()=>flrB3('gtorso',100,80,50,118,g=>{flrGsq(g,0,-78,42,32,'#c8501e',7);g.fillStyle='#ffffff22';g.beginPath();g.ellipse(-12,-96,16,6,-.2,0,TAU);g.fill();
  g.strokeStyle='#2a4a1a';g.lineWidth=4.4;g.beginPath();g.moveTo(-36,-104);g.bezierCurveTo(-10,-90,10,-70,38,-62);g.stroke();g.strokeStyle='#4a7a2a';g.lineWidth=1.8;g.stroke()});
const flrGolemShoulders=()=>flrB3('gshoul',104,34,52,121,g=>{flrGsq(g,-36,-104,14,12,'#2a4e2a',4);flrGsq(g,34,-106,14,12,'#2e542c',4)});
const flrGolemHead=()=>flrB3('ghead',60,58,28,34,g=>{flrGsq(g,0,0,23,18,'#e8e0c8',6);
  g.beginPath();g.moveTo(-20,-4);g.quadraticCurveTo(-10,-10,-1,-6);g.lineTo(-1,-3);g.quadraticCurveTo(-10,-6,-20,-1);g.closePath();g.fillStyle='#6a5a3a';g.fill();
  limb(g,2,-17,5,-26,4,'#5a4a22');g.strokeStyle='#4a7a2a';g.lineWidth=1.8;g.beginPath();g.moveTo(5,-24);g.bezierCurveTo(14,-30,16,-20,10,-19);g.stroke()});
FLRD.flrgourd=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*3.2),b=Math.abs(Math.cos(t*3.2))*2.4,u=flrCy(t,7);g.save();g.lineJoin='round';g.lineCap='round';
 const sq=(x,y,rx,ry,c,rib,rot)=>flrGsq(g,x,y,rx,ry,c,rib,rot);
 /* legs: acorn squash */
 sq(-18+s*5,-22,15,22,'#2e5a2e',5,s*.12);sq(-18+s*5+2,-5,17,7,'#3a6a32',0);sq(20-s*5,-22,15,22,'#2a5228',5,-s*.12);sq(20-s*5+2,-5,17,7,'#355e2e',0);
 g.translate(0,-b);
 /* back arm (crookneck) */
 const catchUp=u>4.5&&u<5.7?Math.sin((u-4.5)/1.2*Math.PI):0;g.save();g.translate(38,-98);g.rotate(.25-catchUp*.5+s*.05);sq(0,22,9,24,'#e8c03a',0,.08);sq(2,50,13,12,'#b8a030',4);g.restore();
 /* chest: a deep red Cinderella pumpkin with its vine (baked) */
 flrB3d(g,flrGolemTorso(),0,0);
 /* tendrils that curl */
 for(let i=0;i<3;i++){const x=-24+i*24,y=-96+i*14,c=.6+.4*Math.sin(t*1.6+i*2);g.strokeStyle='#5a8a2e';g.lineWidth=1.4;g.beginPath();for(let k=0;k<=14;k++){const a=k/14*TAU*1.4*c,r=7-k*.42;k?g.lineTo(x+Math.cos(a)*r,y-4-Math.sin(a)*r):g.moveTo(x+r,y-4)}g.stroke()}
 for(const [x,y,r] of[[-30,-100,.2],[14,-74,-.5],[34,-64,.8]]){g.save();g.translate(x,y);g.rotate(r+Math.sin(t*2+x)*.08);g.beginPath();g.moveTo(0,0);for(let i=0;i<=5;i++){const a=-Math.PI*.9+i/5*Math.PI*.8,rr=i%2?12:8;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr)}g.closePath();flrFO(g,'#3a6a2a',1.2);g.restore()}
 /* shoulders (baked) */
 flrB3d(g,flrGolemShoulders(),0,0);
 /* the small gourd: rocks on the shoulder, rolls down the arm, is tossed back up */
 {let gx=32,gy=-124,rot=Math.sin(t*3)*.25;if(u>4&&u<4.6){const k=(u-4)/.6;gx=32+k*12;gy=-124+k*76+Math.sin(k*Math.PI)*-6;rot=k*8}else if(u>=4.6&&u<5.7){gx=44;gy=-50-catchUp*12;rot=0}else if(u>=5.7&&u<6.3){const k=(u-5.7)/.6;gx=44-k*12;gy=-60+(-124+60)*k-Math.sin(k*Math.PI)*30;rot=-k*9}
  g.save();g.translate(gx,gy);g.rotate(rot);g.beginPath();g.ellipse(0,0,7,8.4,0,0,TAU);g.fillStyle='#e8d070';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.3;g.stroke();g.strokeStyle='#4a8a3a';g.lineWidth=2.2;for(const x of[-3.4,0,3.4]){g.beginPath();g.moveTo(x*.6,-7.6);g.quadraticCurveTo(x*1.3,0,x*.6,7.6);g.stroke()}limb(g,0,-8,1.4,-11.5,2,'#5a4a22');g.restore()}
 /* head: a pale gourd (baked) with glowing knots for eyes and a crack of a mouth */
 g.save();g.translate(-6-lg*6,-128+Math.sin(t*1.6)*1.2);g.rotate(-lg*.1);flrB3d(g,flrGolemHead(),0,0);
 const ef=.7+.3*Math.sin(t*4.4);for(const [x,y] of[[-14,0],[-4,-1]]){ell(g,x,y,4.4,3.6,'#2a1608');glow(g,x,y,10,'#ffa030'+flrA(.6*ef));ell(g,x-.6,y,2,1.8,'#ffd060')}
 g.beginPath();g.moveTo(-18,8);g.lineTo(-13,6);g.lineTo(-9,10);g.lineTo(-4,6.5);g.lineTo(0,10);g.lineTo(3,7.4);g.strokeStyle='#ff8a2a';g.lineWidth=2.4;g.stroke();g.strokeStyle='#2a1608';g.lineWidth=1;g.stroke();g.restore();
 /* front arm: a warty fist that swings on the lunge */
 g.save();g.translate(-36,-98);g.rotate(-.35-lg*.9+s*.06);sq(0,20,9,22,'#d8b030',0,-.05);g.save();g.translate(0,46);sq(0,0,15,13,'#8aa03a',4);g.fillStyle='#5a7a2a';for(const [x,y] of[[-6,-4],[5,-6],[-2,5],[7,3]]){g.beginPath();g.arc(x,y,2.2,0,TAU);g.fill()}g.restore();g.restore();
 g.restore()};

/* 8. Corn-Husk Wraith: a hooded figure of dry husks with corn-silk hair and a cob lantern. Kernels drift off it like embers. */
FLRD.flrwraith=(g,t,o)=>{const lg=(o&&o.lg)||0,bob=Math.sin(t*1.8)*6,u=flrCy(t,6.2),raise=u>3.6&&u<5.2?Math.sin((u-3.6)/1.6*Math.PI):0;g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-8+bob);
 const HC=['#e8d49a','#d6b874','#c8a058','#efdcaa'];
 /* robe of husk strips */
 for(let i=0;i<8;i++){const x0=-18+i*5.2,x1=-34+i*10+Math.sin(t*2.2+i*1.3)*7,y1=-6-((i*5)%3)*6;g.beginPath();g.moveTo(x0-5,-104);g.quadraticCurveTo(x0-10+(x1-x0)*.4,-50,x1-3,y1);g.lineTo(x1+1,y1-8);g.lineTo(x1+4,y1+2);g.quadraticCurveTo(x0+12+(x1-x0)*.4,-50,x0+5,-104);g.closePath();g.fillStyle=HC[i%4];g.fill();g.strokeStyle=FLRO;g.lineWidth=1.3;g.stroke();
  g.strokeStyle='#a8844a88';g.lineWidth=.8;g.beginPath();g.moveTo(x0,-100);g.quadraticCurveTo(x0+(x1-x0)*.4,-50,x1,y1+4);g.stroke()}
 /* staff with the corn-cob lantern */
 const lx=28,ly=-128-raise*12;limb(g,26,-26-raise*6,lx,ly+8,3.6,'#5a3e22');
 glow(g,lx,ly,40,'#ffc040'+flrA(.45+.15*Math.sin(t*5)));g.save();g.translate(lx,ly);g.rotate(.1+Math.sin(t*2)*.06);g.beginPath();g.ellipse(0,0,7,15,0,0,TAU);flrFO(g,'#f0c030',1.4);
 for(let r=0;r<6;r++)for(let c=-1;c<=1;c++){ell(g,c*3.6,-11+r*4.4,1.5,1.6,r%2?'#ffe070':'#f8d040')}
 for(const s of[-1,1]){g.beginPath();g.moveTo(0,10);g.quadraticCurveTo(s*14,4,s*11,-12);g.quadraticCurveTo(s*6,2,0,13);g.closePath();flrFO(g,'#c8b070',1.1)}g.restore();
 for(let i=0;i<4;i++){const k=flrCy(t*.55+i*.25,1);g.globalAlpha=Math.sin(k*Math.PI);ell(g,lx+Math.sin(k*5+i*2)*10,ly-12-k*44,1.8,2.2,'#ffd84a')}g.globalAlpha=1;
 limb(g,12,-100,24,-80-raise*8,5,'#d6b874');
 /* hood */
 g.save();g.translate(-4,-108);g.rotate(Math.sin(t*1.1)*.04);
 g.beginPath();g.moveTo(-20,6);g.quadraticCurveTo(-24,-22,-6,-36);g.quadraticCurveTo(6,-46,18,-46+Math.sin(t*2)*2);g.quadraticCurveTo(12,-36,16,-20);g.quadraticCurveTo(20,-4,16,8);g.closePath();g.fillStyle=vgr(g,-46,8,'#efdcaa','#c8a058');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.6;g.stroke();
 g.strokeStyle='#a8844a99';g.lineWidth=.9;for(const x of[-10,-2,6]){g.beginPath();g.moveTo(x,4);g.quadraticCurveTo(x-2,-18,x+6,-34);g.stroke()}
 g.beginPath();g.ellipse(-7,-10,10,12.5,-.1,0,TAU);g.fillStyle='#1a0e06';g.fill();
 const ef=.75+.25*Math.sin(t*3.3);for(const [x,y] of[[-11,-12],[-3,-13]]){glow(g,x,y,9,'#ffd040'+flrA(.7*ef));ell(g,x,y,1.8,2.4,'#fff0a0')}
 /* corn-silk hair flowing back */
 g.strokeStyle='#e8c87a';g.lineWidth=1.1;for(let i=0;i<6;i++){g.beginPath();g.moveTo(10,-20+i*4);g.bezierCurveTo(22,-24+i*4+Math.sin(t*3+i)*3,30,-14+i*5,40+Math.sin(t*2.4+i)*4,-12+i*6);g.stroke()}
 g.restore();
 /* front arm reaching with twig fingers */
 const ax=-40-lg*16,ay=-84-lg*8+Math.sin(t*2)*2;g.beginPath();g.moveTo(-14,-102);g.quadraticCurveTo(-30,-98,ax+4,ay-3);g.lineTo(ax+6,ay+4);g.quadraticCurveTo(-24,-88,-12,-92);g.closePath();flrFO(g,'#d6b874',1.3);
 for(let i=0;i<3;i++)limb(g,ax+4,ay,ax-6-i*1.6,ay-4+i*4+Math.sin(t*4+i)*1.4,1.4,'#6a4a2a');
 g.restore()};

/* 9. Hay-Bale Roller: a round bale that rolls itself to battle with a scowl in the straw. A field mouse runs on top to keep its footing. */
/* the bale's straw (spirals, stalks, outline and rim), baked at 3x (the walker is drawn up to about 1.5x, times the render scale) */
let FLR_BALE=null;
function flrBaleSpr(){if(FLR_BALE)return FLR_BALE;const c=document.createElement('canvas');c.width=c.height=444;const g=c.getContext('2d');g.setTransform(3,0,0,3,222,222);g.lineJoin='round';g.lineCap='round';const R=60;
 g.save();g.beginPath();g.arc(0,0,R-1,0,TAU);g.clip();
 g.strokeStyle='#9a6a1a';g.lineWidth=2.6;g.beginPath();for(let k=0;k<=72;k++){const a=k/72*TAU*4.2,r=4+k/72*54;k?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.stroke();
 g.strokeStyle='#f8e08a';g.lineWidth=1.1;g.beginPath();for(let k=0;k<=72;k++){const a=k/72*TAU*4.2+.5,r=6+k/72*54;k?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.stroke();
 g.strokeStyle='#c8962a';g.lineWidth=1;for(let i=0;i<10;i++){const a=i*.63,r=20+(i*13)%30;g.beginPath();g.moveTo(Math.cos(a)*r,Math.sin(a)*r);g.lineTo(Math.cos(a+.2)*(r+8),Math.sin(a+.2)*(r+8));g.stroke()}g.restore();
 g.beginPath();g.arc(0,0,R,0,TAU);g.strokeStyle=FLRO;g.lineWidth=2.2;g.stroke();
 for(let i=0;i<16;i++){const a=i/16*TAU,l=6+(i*5)%6;g.strokeStyle=i%2?'#f0d070':'#c8962a';g.lineWidth=2;g.beginPath();g.moveTo(Math.cos(a)*(R-2),Math.sin(a)*(R-2));g.lineTo(Math.cos(a+.08)*(R+l),Math.sin(a+.08)*(R+l));g.stroke()}
 return FLR_BALE=c}
FLRD.flrbale=(g,t,o)=>{const lg=(o&&o.lg)||0,rot=-t*1.6-lg*.8,R=60,cy=-61,u=flrCy(t,6.6);g.save();g.lineJoin='round';g.lineCap='round';g.translate(-lg*8,0);
 /* dust and straw kicked up behind */
 for(let i=0;i<3;i++){const k=flrCy(t*1.1+i*.33,1);g.globalAlpha=(1-k)*.5;ell(g,40+k*40,-8-k*14,8+k*10,5+k*6,'#c8a868')}g.globalAlpha=1;
 /* the bale */
 /* 10.4b: the rolling bale (gradient disc, two spirals clipped to it, straws, rim) is baked once and only rotated per frame; drawn live
    it was the costliest walker to raster (a clip, two 72-point spirals and 26 strokes every frame) */
 g.beginPath();g.arc(0,cy,R,0,TAU);g.fillStyle=rgr(g,-14,cy-16,6,R+6,'#f0cc60','#a8781e');g.fill();/* the light stays put while the straw rolls */
 {const B=flrBaleSpr();g.save();g.translate(0,cy);g.rotate(rot);g.drawImage(B,-74,-74,148,148);g.restore()}
 /* the scowl peering out of the straw */
 g.beginPath();g.ellipse(-26,cy-6,22,18,-.1,0,TAU);g.fillStyle='#4a2e0ecc';g.fill();
 const bl=flrCy(t,4.1)<.1?.12:1;for(const [x,y] of[[-36,cy-10],[-20,cy-12]]){ell(g,x,y,5.4,4.6*bl,'#fff4d0');if(bl>.5)ell(g,x-2,y+.6,2.4,2.6,'#1a0c04')}
 g.strokeStyle='#e8c35a';g.lineWidth=2.6;g.beginPath();g.moveTo(-44,cy-19);g.lineTo(-29,cy-15);g.moveTo(-27,cy-17);g.lineTo(-13,cy-22);g.stroke();
 g.beginPath();g.moveTo(-40,cy+5);g.quadraticCurveTo(-28,cy-1,-15,cy+6);g.lineTo(-17,cy+9);g.quadraticCurveTo(-28,cy+4,-39,cy+8);g.closePath();flrFO(g,'#1a0c04',0);g.fillStyle='#f0d070';for(let i=0;i<4;i++)g.fillRect(-37+i*5.6,cy+3.6,2,3.4);
 /* the field mouse on top: runs backwards to stay up, and stumbles now and then */
 const st=u>4.4&&u<5.2,hop=st?Math.sin((u-4.4)/.8*Math.PI)*16:Math.abs(Math.sin(t*12))*2,mx=4+(st?Math.sin((u-4.4)*7)*6:0),my=cy-R-hop;
 g.save();g.translate(mx,my);if(st)g.rotate(Math.sin((u-4.4)*9)*.5);
 const lr=Math.sin(t*22);limb(g,-2,-2,-4+lr*3,1.6,1.6,'#6a5448');limb(g,4,-2,6-lr*3,1.6,1.6,'#5a4438');
 g.strokeStyle='#c89a8a';g.lineWidth=1.3;g.beginPath();g.moveTo(-6,-4);g.bezierCurveTo(-14,-6,-14,-14,-8+Math.sin(t*6)*2,-16);g.stroke();
 g.beginPath();g.ellipse(1,-6,7.4,5,.1,0,TAU);flrFO(g,'#8a7262',1.2);g.beginPath();g.ellipse(8,-9,4.6,3.8,.3,0,TAU);flrFO(g,'#8a7262',1.1);
 ell(g,6,-13.4,2.8,2.8,'#e8a8a0');ell(g,12.2,-8.4,1.2,1.1,'#2a1010');ell(g,9,-10,1,1.1,'#1a0808');g.restore();
 g.restore()};

/* ===================== bosses ===================== */
/* The Gourd Colossus: a mountain of a pumpkin on vine-root legs, gourd fists, a turban-squash head and a crown of the harvest. */
FLRD.bflrgourd=(g,t,o)=>{const lg=(o&&o.lg)||0,br=1+.015*Math.sin(t*1.6),sw=Math.sin(t*1.4),u=flrCy(t,8);g.save();g.lineJoin='round';g.lineCap='round';
 /* vine-root legs */
 for(const [x,ph] of[[-46,0],[48,1.6]]){for(let k=0;k<3;k++){const w=Math.sin(t*1.6+ph+k)*4;g.strokeStyle=['#2a4a18','#3a5e20','#4a7228'][k];g.lineWidth=20-k*5;g.beginPath();g.moveTo(x-8+k*8,-104);g.bezierCurveTo(x+w-12,-70,x-10+k*8-w,-34,x-26+k*20+w,-2);g.stroke()}}
 for(const x of[-46,48])for(let i=0;i<4;i++){g.strokeStyle='#2a4018';g.lineWidth=4;g.beginPath();g.moveTo(x-6+i*4,-4);g.quadraticCurveTo(x-20+i*12,2,x-32+i*20,1);g.stroke()}
 /* back arm */
 g.save();g.translate(86,-176);g.rotate(.45+sw*.04);g.strokeStyle='#2a4a18';g.lineWidth=22;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(18,40,14,82);g.stroke();g.strokeStyle='#4a7228';g.lineWidth=6;g.stroke();
 for(const [x,y,r,c] of[[6,96,20,'#7a9a3a'],[22,86,16,'#d8b030'],[-6,84,14,'#c8501e']]){g.beginPath();g.ellipse(x,y,r,r*.9,0,0,TAU);g.fillStyle=rgr(g,x-r*.3,y-r*.3,2,r*1.1,shade(c,.3),shade(c,-.25));g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke()}g.restore();
 /* the great pumpkin body */
 g.save();g.translate(0,-146);g.scale(br,1/br);
 g.beginPath();g.ellipse(0,0,104,74,0,0,TAU);g.fillStyle=rgr(g,-30,-30,10,120,'#f8b868','#c8641a');g.fill();g.strokeStyle=FLRO;g.lineWidth=3;g.stroke();
 g.strokeStyle='#8a3e0e99';g.lineWidth=2.2;for(const d of[-78,-52,-26,0,26,52,78]){g.beginPath();g.moveTo(d*.4,-72);g.quadraticCurveTo(d*1.35,0,d*.42,72);g.stroke()}
 g.fillStyle='#e8984a';for(const [x,y,r] of[[-60,10,4],[-48,30,3],[40,-20,3.4],[64,24,4],[12,40,3],[-20,-40,3]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.fillStyle='#ffffff26';g.beginPath();g.ellipse(-34,-40,34,10,-.25,0,TAU);g.fill();
 /* vine belt with leaves */
 g.strokeStyle='#2a4a18';g.lineWidth=7;g.beginPath();g.moveTo(-102,8);g.bezierCurveTo(-40,34,40,30,102,0);g.stroke();g.strokeStyle='#5a8a2e';g.lineWidth=2.4;g.stroke();
 for(const [x,y,r] of[[-70,22,.3],[-10,30,-.2],[60,16,.6]]){g.save();g.translate(x,y);g.rotate(r+Math.sin(t*1.8+x)*.06);g.beginPath();g.moveTo(0,0);for(let i=0;i<=6;i++){const a=-Math.PI*.95+i/6*Math.PI*.9,rr=i%2?24:15;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr+6)}g.closePath();flrFO(g,'#3a6a28',1.6);g.restore()}
 g.restore();
 /* a pumpkin bud swells on the shoulder vine and drops off */
 {const k=u<5?u/5:1,dx=-70,dy=-206;if(u<5.6){const r=3+k*9;g.beginPath();g.ellipse(dx,dy+r*.2,r*1.1,r,0,0,TAU);flrFO(g,'#f0902a',1.4)}else{const f=(u-5.6)/2.4;const x=dx-f*60,y=dy+Math.min(1,f*2.2)*206-Math.sin(Math.min(1,f*2.2)*Math.PI)*30;if(f<.98){g.save();g.translate(x,Math.min(-10,y));g.rotate(-f*9);g.beginPath();g.ellipse(0,0,13,11,0,0,TAU);flrFO(g,'#f0902a',1.4);g.restore()}}}
 /* front arm: a cluster of gourds for a fist */
 const fx=-150-lg*46,fy=-140-lg*20+sw*4;g.strokeStyle='#2a4a18';g.lineWidth=24;g.beginPath();g.moveTo(-88,-196);g.quadraticCurveTo(-130,-200,fx+18,fy-8);g.stroke();g.strokeStyle='#4a7228';g.lineWidth=7;g.stroke();
 for(const [x,y,r,c] of[[fx,fy,24,'#c8501e'],[fx+18,fy-18,18,'#7a9a3a'],[fx+10,fy+16,16,'#e8c03a'],[fx-14,fy-14,14,'#e8e0c8']]){g.beginPath();g.ellipse(x,y,r,r*.9,0,0,TAU);g.fillStyle=rgr(g,x-r*.3,y-r*.3,2,r*1.1,shade(c,.3),shade(c,-.25));g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke()}
 /* turban-squash head */
 const hx=-14,hy=-246+Math.sin(t*1.6)*2;g.save();g.translate(hx,hy);g.rotate(sw*.02-lg*.06);
 g.beginPath();g.ellipse(0,6,52,36,0,0,TAU);g.fillStyle=rgr(g,-16,-6,6,60,'#ee7a3a','#a8381a');g.fill();g.strokeStyle=FLRO;g.lineWidth=2.6;g.stroke();
 g.strokeStyle='#6a1e0a88';g.lineWidth=1.6;for(const d of[-34,-17,0,17,34]){g.beginPath();g.moveTo(d*.5,-28);g.quadraticCurveTo(d*1.3,6,d*.55,40);g.stroke()}
 g.beginPath();g.ellipse(4,-26,30,18,0,0,TAU);g.fillStyle='#e8e0b0';g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke();g.save();g.clip();g.fillStyle='#4a8a3a';for(let i=-3;i<=3;i++){g.beginPath();g.ellipse(4+i*9,-26,3.4,18,0,0,TAU);g.fill()}g.restore();
 /* the harvest crown: a mini pumpkin, a corn cob, a striped gourd and wheat */
 for(const [x,y,k,r] of[[-22,-40,0,-.4],[2,-48,1,0],[24,-42,2,.4],[-6,-46,3,-.15],[14,-48,3,.2]]){g.save();g.translate(x,y);g.rotate(r+Math.sin(t*2+x)*.04);
  if(k===0){g.beginPath();g.ellipse(0,-6,10,8,0,0,TAU);flrFO(g,'#f08a2a',1.4);limb(g,0,-13,1,-17,2.4,'#5a4a22')}
  else if(k===1){g.beginPath();g.ellipse(0,-14,6,14,0,0,TAU);flrFO(g,'#f0c030',1.4);for(let i=0;i<5;i++)ell(g,0,-24+i*4.4,3.6,1.4,'#ffe070');for(const s of[-1,1]){g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(s*12,-6,s*8,-22);g.quadraticCurveTo(s*4,-8,0,2);g.closePath();flrFO(g,'#c8b070',1)}}
  else if(k===2){g.beginPath();g.ellipse(0,-9,7,10,0,0,TAU);flrFO(g,'#e8d070',1.3);g.strokeStyle='#4a8a3a';g.lineWidth=2.2;g.beginPath();g.moveTo(-3,-18);g.lineTo(-3,0);g.moveTo(3,-18);g.lineTo(3,0);g.stroke()}
  else{g.strokeStyle='#c8962a';g.lineWidth=1.8;g.beginPath();g.moveTo(0,0);g.lineTo(0,-30);g.stroke();for(let i=0;i<5;i++){ell(g,-2.4,-30+i*4,2.2,3.2,'#e8c35a',-.4);ell(g,2.4,-28+i*4,2.2,3.2,'#d8b04a',.4)}}g.restore()}
 /* face */
 g.fillStyle='#4a1606';g.beginPath();g.moveTo(-46,-4);g.quadraticCurveTo(-28,-16,-14,-8);g.lineTo(-12,-2);g.quadraticCurveTo(-28,-10,-44,2);g.closePath();g.fill();g.beginPath();g.moveTo(-8,-10);g.quadraticCurveTo(6,-18,16,-8);g.lineTo(14,-3);g.quadraticCurveTo(4,-11,-6,-4);g.closePath();g.fill();
 const ef=.7+.3*Math.sin(t*4)+.08*Math.sin(t*13);for(const [x,y,r] of[[-30,4,7],[2,2,6.4]]){ell(g,x,y,r,r*.8,'#1a0804');glow(g,x,y,r*3,'#ff7a1a'+flrA(.55*ef));ell(g,x-1,y,r*.55,r*.45,'#ffd060')}
 g.beginPath();g.moveTo(-42,20);g.lineTo(-32,16);g.lineTo(-26,24);g.lineTo(-16,17);g.lineTo(-8,25);g.lineTo(2,18);g.lineTo(10,24);g.lineTo(16,18);g.strokeStyle='#ff9a3a';g.lineWidth=4.4;g.stroke();g.strokeStyle='#3a0e04';g.lineWidth=1.6;g.stroke();
 g.restore();
 /* embers rising */
 for(let i=0;i<6;i++){const k=flrCy(t*.5+i/6,1);g.globalAlpha=Math.sin(k*Math.PI)*.8;ell(g,-40+i*24+Math.sin(k*5+i)*12,-170-k*140,2.2*(1-k)+.6,2.2*(1-k)+.6,i%2?'#ffd060':'#ff8a2a')}g.globalAlpha=1;
 g.restore()};

/* The Scarecrow King: a towering scarecrow in a patchwork coat and a crown of wheat, with a lantern on a pitchfork and a court of crows. */
FLRD.bflrking=(g,t,o)=>{const lg=(o&&o.lg)||0,sw=Math.sin(t*1.2),tilt=Math.sin(t*.7)*.08;g.save();g.lineJoin='round';g.lineCap='round';
 /* straw roots spreading on the ground and the great pole */
 for(let i=0;i<12;i++){const a=(i/11-.5)*2.6;g.strokeStyle=i%2?'#d8b04a':'#a8802a';g.lineWidth=3;g.beginPath();g.moveTo(0,-16);g.quadraticCurveTo(Math.sin(a)*30,-4,Math.sin(a)*58,2);g.stroke()}
 g.beginPath();g.moveTo(-9,-180);g.lineTo(9,-180);g.lineTo(8,-8);g.lineTo(-8,-8);g.closePath();flrFO(g,'#5a3e22',2.2);
 /* cape of crow feathers behind */
 for(let i=0;i<9;i++){const x=20+i*9,y=-232+i*14,w=Math.sin(t*2.4+i)*5;g.beginPath();g.moveTo(x-6,y);g.quadraticCurveTo(x+18+w,y+20,x+12+w,y+48);g.quadraticCurveTo(x+2,y+30,x-10,y+8);g.closePath();flrFO(g,i%2?'#1c1828':'#262036',1.2)}
 /* the arms on the crossbar */
 const arm=(dir,c)=>{const tip=dir*134,dy=dir<0?-lg*20:0;g.beginPath();g.moveTo(dir*40,-240);g.lineTo(tip,-224+dy);g.lineTo(tip-dir*2,-198+dy);g.lineTo(dir*40,-200);g.closePath();flrFO(g,c,2.2);
  g.strokeStyle='#00000044';g.lineWidth=2;for(const k of[.4,.62,.84]){const x=dir*40+(tip-dir*40)*k;g.beginPath();g.moveTo(x,-238+(-224+dy+238)*k);g.lineTo(x,-202+(-198+dy+202)*k);g.stroke()}
  g.fillStyle=dir<0?'#a8782a':'#4a6a3a';g.fillRect(dir*86-10,-226+dy*.5,20,16);
  for(let i=0;i<8;i++){const a=(i-3.5)*.28+Math.sin(t*3+i)*.1;g.strokeStyle=i%2?'#f0d070':'#c8962a';g.lineWidth=3.2;g.beginPath();g.moveTo(tip,-211+dy);g.lineTo(tip+dir*Math.cos(a)*26,-211+dy+Math.sin(a)*26);g.stroke()}};
 arm(1,'#5a3a7a');
 /* patchwork coat */
 const coat=()=>{g.beginPath();g.moveTo(-46,-244);g.lineTo(46,-246);g.lineTo(62,-160);g.lineTo(82,-84);for(let i=0;i<=8;i++){const x=82-i*20.5;g.lineTo(x-10,-84+(i%2?-10:8)+Math.sin(t*2+i)*3)}g.lineTo(-62,-160);g.closePath()};
 coat();g.fillStyle='#4a2e5e';g.fill();g.save();coat();g.clip();
 for(const [x,y,w,h,c] of[[-50,-236,34,40,'#a8782a'],[18,-210,40,36,'#4a6a3a'],[-60,-160,44,46,'#8a3a22'],[24,-150,48,40,'#5a3a7a'],[-30,-118,40,36,'#4a6a3a'],[40,-110,40,30,'#a8782a']]){g.fillStyle=c;g.fillRect(x,y,w,h);g.strokeStyle='#e8d8b0aa';g.lineWidth=1.4;g.setLineDash([4,3]);g.strokeRect(x+3,y+3,w-6,h-6);g.setLineDash([])}
 g.fillStyle='#e8c35a';g.beginPath();g.moveTo(-14,-244);g.lineTo(14,-244);g.lineTo(8,-170);g.lineTo(-8,-170);g.closePath();g.fill();g.strokeStyle='#c8962a';g.lineWidth=1.6;for(let i=0;i<6;i++){g.beginPath();g.moveTo(-10+i*4,-240);g.lineTo(-8+i*3.2,-176);g.stroke()}
 g.restore();coat();g.strokeStyle=FLRO;g.lineWidth=2.6;g.stroke();
 arm(-1,'#6a4486');
 /* pitchfork sceptre with a swinging lantern */
 const px=-134-lg*30;g.save();g.translate(px,-212-lg*20);g.rotate(-lg*.3);limb(g,0,-96,0,200,6,'#6a4626');limb(g,0,-96,0,200,2,'#9a7244');
 g.strokeStyle='#8a8a92';g.lineWidth=4;g.beginPath();g.moveTo(-18,-140);g.lineTo(-18,-104);g.quadraticCurveTo(-18,-94,0,-94);g.quadraticCurveTo(18,-94,18,-104);g.lineTo(18,-140);g.moveTo(0,-140);g.lineTo(0,-96);g.stroke();
 const la=Math.sin(t*2.2)*.25;g.save();g.translate(0,-104);g.rotate(la);g.strokeStyle='#3a3a42';g.lineWidth=1.6;g.beginPath();g.moveTo(0,0);g.lineTo(0,22);g.stroke();
 glow(g,0,38,48,'#ffb040'+flrA(.5+.15*Math.sin(t*7)));g.fillStyle='#2a2a32';g.fillRect(-9,22,18,4);g.fillRect(-9,50,18,4);g.fillStyle='#ffc860dd';g.beginPath();g.roundRect(-7,26,14,24,3);g.fill();ell(g,0,38,3,6+Math.sin(t*9)*1.2,'#fff4c0');g.strokeStyle=FLRO;g.lineWidth=1.4;g.strokeRect(-7,26,14,24);g.restore();g.restore();
 /* head */
 g.save();g.translate(-6,-270);g.rotate(tilt-lg*.08);
 g.beginPath();g.moveTo(-14,26);g.lineTo(-20,34);g.lineTo(14,34);g.lineTo(10,26);g.closePath();flrFO(g,'#b8925a',1.6);limb(g,-18,30,12,30,3.4,'#7a5a30');
 g.beginPath();g.ellipse(0,0,34,36,0,0,TAU);g.fillStyle=rgr(g,-10,-12,4,44,'#d8b47a','#9a7440');g.fill();g.strokeStyle=FLRO;g.lineWidth=2.4;g.stroke();
 g.strokeStyle='#8a6a3a44';g.lineWidth=1;for(let i=-6;i<=6;i++){g.beginPath();g.moveTo(i*5,-34);g.lineTo(i*5.4,34);g.stroke()}
 const ef=.7+.3*Math.sin(t*3.7)+.1*Math.sin(t*11);for(const [x,y] of[[-17,-4],[3,-6]]){g.beginPath();g.moveTo(x-8,y+2);g.quadraticCurveTo(x,y-7,x+8,y+2);g.quadraticCurveTo(x,y+5,x-8,y+2);g.closePath();g.fillStyle='#1a0804';g.fill();glow(g,x,y,16,'#ffa030'+flrA(.6*ef));ell(g,x,y,2.6,2.2,'#ffe080')}
 g.strokeStyle='#2a1810';g.lineWidth=2.6;g.beginPath();g.moveTo(-26,14);g.quadraticCurveTo(-8,26,14,14);g.stroke();g.lineWidth=1.6;for(let i=0;i<7;i++){const x=-23+i*5.6,y=16+Math.sin((i+.5)/7*Math.PI)*5;g.beginPath();g.moveTo(x,y-3.4);g.lineTo(x+1,y+3.4);g.stroke()}
 /* crown of wheat */
 g.beginPath();g.moveTo(-28,-24);g.quadraticCurveTo(0,-34,28,-24);g.lineTo(26,-16);g.quadraticCurveTo(0,-26,-26,-16);g.closePath();flrFO(g,'#d8a832',1.8);
 for(let i=0;i<7;i++){const x=-24+i*8,h=24+(i%2)*8,a=(i-3)*.08+Math.sin(t*1.8+i)*.04;g.save();g.translate(x,-28+Math.abs(i-3)*1.4);g.rotate(a);g.strokeStyle='#b88a2a';g.lineWidth=1.8;g.beginPath();g.moveTo(0,0);g.lineTo(0,-h);g.stroke();for(let k=0;k<4;k++){ell(g,-2.2,-h+k*4,2,3,'#f0c84a',-.4);ell(g,2.2,-h+2+k*4,2,3,'#e0b03a',.4)}g.restore()}
 g.restore();
 /* the court: crows on the back arm and the crown, taking turns to flap up */
 for(const [x,y,s,i] of[[64,-250,.95,0],[106,-236,.85,1],[-18,-322,.8,2]]){const k=flrCy(t+i*2.1,6.3);let dy=0,fl=null;if(k>4.6&&k<5.6){const q=(k-4.6);dy=-Math.sin(q*Math.PI)*36;fl=Math.sin(k*28)}flrCrow(g,x,y+dy,s,fl,flrCy(t+i,4)<.4?1:0,fl==null)}
 for(let i=0;i<3;i++){const k=flrCy(t*.4+i/3,1);g.globalAlpha=(1-k)*.9;g.strokeStyle='#e8c35a';g.lineWidth=2;const fx=-40+i*40+Math.sin(k*5+i)*10,fy=-90+k*90;g.beginPath();g.moveTo(fx,fy);g.lineTo(fx+6*Math.cos(k*4+i),fy+6*Math.sin(k*4+i));g.stroke()}g.globalAlpha=1;
 g.restore()};

/* The Wild Hunt Gobbler: a colossal turkey with a sunburst tail, stag's antlers hung with autumn leaves and a hunting horn. */
FLRD.bflrgobble=(g,t,o)=>{const lg=(o&&o.lg)||0,u=flrCy(t,6.4),gob=u>4.2&&u<5.1?Math.sin((u-4.2)/.9*Math.PI):0,flare=.82+.18*Math.sin(t*1.4)+gob*.12,st=Math.sin(t*2.2);g.save();g.lineJoin='round';g.lineCap='round';
 /* mist of the hunt around the feet */
 for(let i=0;i<5;i++){const k=flrCy(t*.25+i/5,1);g.globalAlpha=Math.sin(k*Math.PI)*.35;ell(g,-80+i*44+k*30,-14-k*20,40,12,'#c8d8f0')}g.globalAlpha=1;
 /* legs with spurs */
 for(const [hx,k] of[[0,1],[46,-1]]){const a=k*st*.12,kx=hx+Math.sin(a)*20,fx=kx-6;g.strokeStyle=FLRO;g.lineWidth=22;g.beginPath();g.moveTo(hx,-92);g.lineTo(kx,-46);g.lineTo(fx,-4);g.stroke();g.strokeStyle='#8a5a54';g.lineWidth=17;g.stroke();
  g.strokeStyle='#5a3a36';g.lineWidth=2;for(let i=0;i<5;i++){g.beginPath();g.moveTo(kx-5,-40+i*7);g.lineTo(kx+5,-38+i*7);g.stroke()}poly(g,[kx+5,-30,kx+18,-34,kx+6,-24],'#d8c8b0',FLRO,1.4);
  g.strokeStyle='#7a4a44';g.lineWidth=6;g.beginPath();g.moveTo(fx,-3);g.lineTo(fx-26,0);g.moveTo(fx,-3);g.lineTo(fx-16,8);g.moveTo(fx,-3);g.lineTo(fx+14,0);g.stroke()}
 /* the sunburst tail */
 g.save();g.translate(70,-182);flrFan(g,150*(.92+.08*flare),-Math.PI*.5-1.05*flare,-Math.PI*.5+1.25*flare,13,.22+.25*gob);g.restore();
 /* body */
 g.save();g.translate(22,-150);g.scale(1+gob*.05,1+gob*.05);g.beginPath();g.ellipse(0,0,92,72,-.12,0,TAU);g.fillStyle=rgr(g,-26,-26,8,100,'#a8743a','#3a2210');g.fill();g.strokeStyle=FLRO;g.lineWidth=3;g.stroke();
 for(let r=0;r<5;r++)for(let i=0;i<8;i++){const x=-74+i*20+(r%2)*10,y=-46+r*18;if(x*x/8000+y*y/4600>1)continue;g.strokeStyle=r%2?'#5a9a7a88':'#e8b86a99';g.lineWidth=2.4;g.beginPath();g.arc(x,y,9,Math.PI*.1,Math.PI*.9);g.stroke()}
 g.save();g.translate(-30,-22);g.rotate(.14);flrWing(g,118,56);g.restore();
 g.restore();
 /* beard and the hunting horn on its strap */
 g.strokeStyle='#120a08';g.lineWidth=3;for(let i=0;i<6;i++){g.beginPath();g.moveTo(-52+i*2,-168);g.quadraticCurveTo(-58+i*2,-140,-60+i*3+Math.sin(t*2+i)*3,-118);g.stroke()}
 g.strokeStyle='#5a3418';g.lineWidth=5;g.beginPath();g.moveTo(-50,-212);g.quadraticCurveTo(-10,-150,40,-196);g.stroke();
 g.save();g.translate(-2,-150);g.rotate(.22+Math.sin(t*1.6)*.04);g.beginPath();g.moveTo(34,-2);g.quadraticCurveTo(6,-4,-18,-10);g.quadraticCurveTo(-30,-16,-34,-26);g.lineTo(-44,-20);g.quadraticCurveTo(-38,-2,-18,4);g.quadraticCurveTo(8,8,34,4);g.closePath();g.fillStyle=hgr(g,-44,34,'#f4e6c4','#b8986a');g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke();
 g.beginPath();g.ellipse(-39,-23,7,11,-.6,0,TAU);flrFO(g,'#6a4a2a',2);g.strokeStyle='#c8a040';g.lineWidth=4;for(const x of[-14,6,24]){g.beginPath();g.moveTo(x,-8+(x+14)*.06);g.lineTo(x+1,5);g.stroke()}g.restore();
 /* neck and head */
 const hx=-86-lg*40,hy=-246+gob*8+Math.sin(t*1.6)*3;g.beginPath();g.moveTo(-44,-196);g.quadraticCurveTo(hx+6,-212,hx+4,hy+12);g.lineTo(hx+24,hy+16);g.quadraticCurveTo(hx+30,-200,-20,-180);g.closePath();flrFO(g,'#d8c8d8',2);
 for(let i=0;i<6;i++)ell(g,hx+14+i*3,hy+26+i*8,4.4,4.4,'#d03030');
 /* antlers hung with leaves */
 g.save();g.translate(hx+6,hy-18);g.scale(1.55,1.55);g.strokeStyle='#3a2414';g.lineCap='round';
 const ant=(s)=>{g.lineWidth=7;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(s*10,-30,s*30,-58);g.stroke();g.lineWidth=5;for(const [k,l,a] of[[.35,24,-1.1],[.6,30,-.5],[.85,20,.1]]){const bx=s*30*k*k+s*2,by=-58*k;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+s*Math.cos(a)*l,by+Math.sin(a)*l-l*.4);g.stroke()}g.strokeStyle='#5a3a22';g.lineWidth=2;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(s*10,-30,s*30,-58);g.stroke();g.strokeStyle='#3a2414'};
 ant(-1);ant(1);for(const [x,y,k] of[[-26,-52,0],[22,-60,2],[-12,-30,1],[34,-38,3],[6,-44,4]])flrLeafAt(g,k,x,y+Math.sin(t*2+x)*1.4,.95,Math.sin(t*1.7+x)*.4,1);
 glow(g,0,-40,30,'#7ac8ff'+flrA(.25+.15*Math.sin(t*2)));g.restore();
 g.save();g.translate(hx,hy);g.rotate(-gob*.18);g.scale(1.3,1.3);g.beginPath();g.ellipse(0,0,18,16,0,0,TAU);flrFO(g,'#a8d0ec',2);
 g.beginPath();g.moveTo(-15,-4);g.lineTo(-34,0+gob);g.lineTo(-15,4);g.closePath();flrFO(g,'#e8c860',1.6);if(gob>.2){g.beginPath();g.moveTo(-15,4);g.lineTo(-30,9+gob*6);g.lineTo(-14,8);g.closePath();flrFO(g,'#d8b050',1.2)}
 const ef=.75+.25*Math.sin(t*5);ell(g,-5,-5,4.4,4.4,'#1a0804');glow(g,-5,-5,14,'#ffb030'+flrA(.6*ef));ell(g,-5.6,-5.4,2,2,'#ffe080');
 const sh=Math.sin(t*36)*gob*6;g.beginPath();g.moveTo(-8,-14);g.quadraticCurveTo(-24+sh,-6,-22+sh,22+gob*4);g.quadraticCurveTo(-17+sh,26,-14,18);g.quadraticCurveTo(-14,-2,-3,-12);g.closePath();flrFO(g,'#d82828',1.4);
 g.beginPath();g.moveTo(-8,10);g.quadraticCurveTo(-12-sh,30,-2-sh*.6,36+gob*4);g.quadraticCurveTo(8,26,6,10);g.closePath();flrFO(g,'#c82020',1.4);g.restore();
 if(gob>.35){g.strokeStyle='#ffe8a0'+flrA(gob);g.lineWidth=4;for(let i=0;i<3;i++){const a=-2.7+i*.32;g.beginPath();g.arc(hx-26,hy,40+i*16,a,a+.34);g.stroke()}}
 /* falling feathers */
 for(let i=0;i<3;i++){const k=flrCy(t*.35+i/3,1);g.globalAlpha=(1-k)*.85;g.save();g.translate(60+i*40-k*30,-260+k*250);g.rotate(Math.sin(k*8+i)*.8);g.beginPath();g.ellipse(0,0,4,13,0,0,TAU);g.fillStyle=i%2?'#8a4a1a':'#d8a050';g.fill();g.restore()}g.globalAlpha=1;
 g.restore()};

/* ---------- registration ---------- */
const FLRM={
 flrscare:{n:'Straw Scarecrow',h:126,sp:50,th:122,ds:'Hops off its pole when the moon turns gold. The crow on its arm is the one giving the orders.'},
 flrpie:{n:'Pie-Crust Mimic',h:92,sp:58,th:84,tr:'bomb',ds:'Fresh from the windowsill and still too hot to touch. If it reaches you, it bursts in a spray of boiling filling.'},
 flracorn:{n:'Acorn Knight',h:102,sp:52,th:96,pj:'acorn',rgp:.5,ds:'Sworn to the old oak. Its helmet is a size too big, so it throws acorns from a safe distance.'},
 flrcrow:{n:'Murder of Crows',h:98,sp:118,th:84,fly:1,ds:'Three crows who share one bad idea. They steal anything shiny, including letters.'},
 flrmaple:{n:'Maple Sprite Swarm',h:96,sp:76,th:90,fly:1,tr:'blink',ds:'A giggle in a whirl of red leaves. It scatters on the wind and gathers again closer than before.'},
 flrturkey:{n:'Wild Turkey Charger',h:116,sp:124,th:104,cx:-6,tr:'charge',ds:'Fast, proud and very loud. It stops to show off its tail, then charges anyone who did not clap.'},
 flrgourd:{n:'Gourd Golem',h:224,sp:28,th:152,tr:'shield',ds:'Every gourd that rolled off the cart and kept rolling. Its rind is thick enough to turn a blade.'},
 flrwraith:{n:'Corn-Husk Wraith',h:190,sp:36,th:154,fly:1,tr:'summon',ds:'The last sheaf of the harvest, left standing in the field too long. It calls the crows to its side.'},
 flrbale:{n:'Hay-Bale Roller',h:196,sp:32,th:128,ds:'A bale with a grudge and a passenger. The mouse on top has no idea where they are going.'},
 bflrgourd:{n:'The Gourd Colossus',h:380,sp:46,th:330,tw:330,boss:1,ds:'Ruler of the pumpkin patch, grown on a hundred harvests. Every vine in the field answers to it.'},
 bflrking:{n:'The Scarecrow King',h:392,sp:50,th:340,tw:300,boss:1,cx:-20,ds:'He has watched the corn maze for a hundred autumns. His crows tell him where you are.'},
 bflrgobble:{n:'The Wild Hunt Gobbler',h:384,sp:56,th:370,tw:340,boss:1,cx:-10,ds:'Leader of the wild hunt that rides under the harvest moon. Its gobble is a hunting horn.'}};
Object.assign(DR,FLRD);Object.assign(MON,FLRM);for(const k in FLRD)MON[k].d=FLRD[k];
Object.assign(ROARK,{bflrgourd:'rumble',bflrking:'hollow',bflrgobble:'howl'});
/* the monsters by role (0 walkers, 1 fast or flying, 2 heavies) and the bosses; hoisted functions so earlier modules can ask safely */
function flrMobIds(){return[['flrpie','flrscare','flracorn'],['flrmaple','flrcrow','flrturkey'],['flrgourd','flrwraith','flrbale']]}
function flrBossIds(){return['bflrgourd','bflrking','bflrgobble']}
const FLR_MOBS=flrMobIds(),FLR_BOSS=flrBossIds();
/* the Acorn Knight's thrown acorn */
{const p0=projArt;projArt=function(g,j,t){if(j.k!=='acorn')return p0.apply(this,arguments);const x=j.x,y=j.y;g.save();g.translate(x,y);g.rotate(-t*14);
 g.beginPath();g.moveTo(-8,-3);g.bezierCurveTo(-9,6,-3,10,0,12);g.bezierCurveTo(3,10,9,6,8,-3);g.closePath();flrFO(g,'#b8742e',1.4);
 g.beginPath();g.ellipse(0,-4,10,5.4,0,0,TAU);flrFO(g,'#6a4a26',1.4);limb(g,0,-9,1,-13,2,'#4a321a');g.restore();
 g.fillStyle='#e8c35a66';for(let i=1;i<4;i++){g.beginPath();g.arc(x+i*9,y+Math.sin(t*12+i)*2,3-i*.6,0,TAU);g.fill()}}}
