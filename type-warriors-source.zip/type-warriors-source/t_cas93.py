# python3 t_cas93.py : 9.3 casino limits - 5,000 max bet in every casino game except Blackjack, Higher or Lower and Tower Climb (Mines was removed from the casino);
# the roulette table limit; Mines is no longer listed or reachable.
import asyncio
from playwright.async_api import async_playwright
H='file:///home/user/type-warriors/type-warriors-source/out.html'
FAIL=[];N=[0]
def chk(name,ok,r):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(r)))
    if not ok:FAIL.append(name)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500)
        E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=1e6}")
        want={'bj':7500,'hl':5000,'tw':7500,'rk':5000,'sl':5000,'ro':5000,'di':5000,'pl':5000,'wh':5000,'qz':1000}
        for gid,cap in want.items():
            r=await E("async(id)=>{casinoOpen();await new Promise(r=>setTimeout(r,300));gameOpen(id);await new Promise(r=>setTimeout(r,250));CAS.bet=99999;betRefresh();const s=ov.querySelector('.bv small');return [CAS.cap,CAS.bet,s?s.textContent:'']}",gid)
            chk(f'{gid}: bets stop at {cap:,} and the bar says so',r[0]==cap and r[1]==cap and r[2].replace(',','')=='max '+str(cap),r)
        r=await E("async()=>{casinoOpen();await new Promise(r=>setTimeout(r,300));gameOpen('ro');await new Promise(r=>setTimeout(r,250));return [typeof CAS_LIM,CAS_LIM]}")
        chk('roulette: the table limit per spin is 5,000',r==['number',5000],r)
        # Mines was removed from the casino at the owner's request
        r=await E("async()=>{casinoOpen();await new Promise(r=>setTimeout(r,300));const t=[...document.querySelectorAll('.gt,.gdgrid [data-g]')].some(x=>/Mines/.test(x.textContent)||x.dataset.g==='mi');gameOpen('mi');await new Promise(r=>setTimeout(r,250));return [GAMES.some(g=>g.id==='mi'),t,!!document.getElementById('mg'),!!document.getElementById('gdgrid')]}")
        chk('mines is gone: not listed, no tile, and opening it stays in the lobby',r==[False,False,False,True],r)
        chk('no page errors',not er,er)
        print(f'{N[0]-len(FAIL)} / {N[0]} passed');await b.close()
asyncio.run(main())
