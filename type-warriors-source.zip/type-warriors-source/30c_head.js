const HWH={},HWC={},HWFX={},HWA={},HWG={}; /* Halloween gear hooks, filled in 83_hw_gear.js */
/* ---- head: shell (face + headgear) and crest ---- */
function arFeather(g,L,col,w){arBev(g,[0,-w*.5,L*.32,-w,L*.72,-w*.82,L,0,L*.72,w*.82,L*.32,w,0,w*.5],col,{sm:1,ow:1.1})}
function arCrown(g,x0,x1,yb,K,c){const {T,acc,t}=c,ice=K.crown==='ice',n=ice?6:5,hs=ice?[13,24,17,28,15,21]:[10,15,19,15,10];
 if(!ice)arBev(g,[x0,yb+3,x1,yb+2,x1,yb-2,x0,yb-1],T,{ow:1.1});
 for(let i=0;i<n;i++){const x=x0+(x1-x0)*(i+.5)/n,h=hs[i],w=ice?3.4:4;arBev(g,[x-w,yb,x,yb-h,x+w,yb],ice?(i%2?'#dff6ff':'#bfeaff'):T,{ow:1.1,flat:ice?0:0});if(!ice)rivet(g,x,yb-2.6,1,shade(T,-.2))}
 if(!ice){const x=(x0+x1)/2;glow(g,x,yb-1,6,acc+'99');ell(g,x,yb,2.2,2.2,acc)}}
function arHead(g,K,c,hx,hy){const {M,D,T,hc,t,acc,tier,lg}=c,h=K.helm,sw=Math.sin(t*3)*2+lg*-3;
 const face=(fx,fy,rx,ry)=>{ell(g,fx,fy,rx,ry,rgr(g,fx-4,fy-5,1,rx+5,'#f6dab6','#c49a74'));const ex=fx+rx*.42,ey=fy-1;ell(g,ex,ey,3,2.5,'#ffffff');ell(g,ex+.8,ey,1.7,1.8,'#3a6ad8');ell(g,ex+1,ey,.8,.9,'#10102a');
  g.strokeStyle='#3a2410';g.lineWidth=1.4;g.beginPath();g.moveTo(ex-3.4,ey-4.4);g.lineTo(ex+3.6,ey-3.4);g.stroke();g.strokeStyle='#9a5a48';g.lineWidth=1.2;g.beginPath();g.moveTo(fx+rx*.28,fy+ry*.52);g.lineTo(fx+rx*.7,fy+ry*.5);g.stroke()};
 const mail=(g2,b)=>arMail(g2,b),HM=K.helmc||M;
 if(HWH[h])return HWH[h](g,K,c,hx,hy,face);
 if(h==='bare'||h==='circ'){const hair=K.hair||(h==='circ'?(K.crown==='ice'?'#eaf6ff':'#7a5a3a'):'#6a4a2a');
  if(h==='circ')arBev(g,[hx-8,hy-8,hx-20-sw*.4,hy+6,hx-17-sw*.5,hy+24,hx-4,hy+16,hx+2,hy+2],shade(hair,-.12),{sm:1,ow:1.1});
  ell(g,hx-6,hy-1,11,12,shade(hair,-.2));face(hx,hy,14.5,15.5);
  g.beginPath();g.ellipse(hx-1,hy-7,15.8,10.5,-.08,Math.PI,TAU);g.closePath();g.fillStyle=hgr(g,hx-16,hx+15,shade(hair,.22),shade(hair,-.12));g.fill();g.strokeStyle='#000000a8';g.lineWidth=1.2;g.stroke();
  g.fillStyle=shade(hair,.1);g.beginPath();g.moveTo(hx+3,hy-14);g.quadraticCurveTo(hx+12,hy-13,hx+14.5,hy-5);g.quadraticCurveTo(hx+8,hy-8,hx+3,hy-9);g.closePath();g.fill();
  if(h==='bare')arBev(g,[hx-15.8,hy-10,hx+15,hy-12.5,hx+15.6,hy-8,hx-15.8,hy-5.6],K.band||T,{ow:1.1});
  else{arBev(g,[hx-15.6,hy-11,hx+15.4,hy-13,hx+15.8,hy-9.4,hx-15.8,hy-7.4],T,{ow:1.1});glow(g,hx+13,hy-10.5,6,acc+'88');ell(g,hx+13,hy-10.8,2.1,2.1,acc);ell(g,hx+12.5,hy-11.3,.8,.8,'#ffffff')}}
 else if(h==='hood'||h==='cowl'){const dark=h==='cowl',hc2=K.hoodc||M;
  arBev(g,[hx-15,hy+6,hx-20,hy+17,hx-8,hy+25,hx+6,hy+20,hx+13,hy+14,hx-2,hy+9],shade(hc2,-.08),{sm:1,ow:1.2});
  arBevE(g,hx-3,hy+1,17.5,18.2,hc2,{ow:1.3});
  ell(g,hx+3.8,hy+1.6,12.8,14.4,shade(D,-.6));
  if(dark){ell(g,hx+4.4,hy+1.8,11.4,13.2,'#07030f');const pu=.8+.2*Math.sin(t*3);g.globalAlpha=pu;eye(g,hx+7.5,hy-1.4,2.4,acc);eye(g,hx+12.4,hy-1.4,1.8,acc);g.globalAlpha=1}
  else face(hx+3.6,hy+1.6,11.6,13.2);
  arBev(g,[hx-17.5,hy+3,hx-16,hy-9,hx-6,hy-19,hx+7,hy-18.5,hx+15.5,hy-9,hx+13.6,hy-5.4,hx+8,hy-10,hx,hy-12.4,hx-8,hy-8,hx-11,hy+2],hc2,{sm:1,edge:K.hoodedge?T:null,ew:1.6});
  if(K.fur){for(let i=0;i<7;i++){const a=Math.PI*(1.02+i*.14);ell(g,hx+1+Math.cos(a)*14.5,hy-3+Math.sin(a)*15,4.3,3.8,i%2?'#f6f2e6':'#ddd6c2')}}
  else if(!dark){g.save();g.setLineDash([2,2]);g.strokeStyle='#e8c890aa';g.lineWidth=.9;g.beginPath();g.ellipse(hx+1,hy-3,13.6,13,0,Math.PI*1.04,Math.PI*1.84);g.stroke();g.restore()}}
 else if(h==='coif'){
  arBev(g,[hx-14,hy+7,hx+13,hy+9,hx+12,hy+20,hx,hy+25,hx-13,hy+19],M,{sm:1,tex:mail});
  arBevE(g,hx-2,hy+1,17,17.6,M,{tex:mail});
  face(hx+4,hy+1.6,11.4,13);
  arBev(g,[hx-17,hy+1,hx-14.5,hy-11,hx-4,hy-19,hx+8,hy-18,hx+15.4,hy-8,hx+9.2,hy-6.8,hx,hy-11,hx-9,hy-6,hx-12,hy+3],M,{sm:1,tex:mail,edge:T,ew:1.4})}
 else if(h==='cap'){
  arBev(g,[hx-17,hy-4,hx-15,hy+11,hx-5,hy+15,hx-3,hy-3],shade(HM,-.14),{ow:1.1});
  face(hx,hy,14.5,15.5);
  arBev(g,arEl(hx,hy-7,16.6,13.4,Math.PI,TAU,18),HM,{sm:0});
  g.strokeStyle=shade(HM,-.3);g.lineWidth=1.1;g.beginPath();g.moveTo(hx-1,hy-20);g.lineTo(hx+6,hy-8);g.stroke();g.strokeStyle='#ffffff50';g.beginPath();g.moveTo(hx-3,hy-19);g.lineTo(hx+3,hy-9);g.stroke();
  arBev(g,[hx-17.6,hy-10.6,hx+16.6,hy-11.6,hx+17.2,hy-6,hx-17.6,hy-5],T,{ow:1.1});for(const x of[-11,-3,5,13])rivet(g,hx+x,hy-8.2,1.1,T);
  arBev(g,[hx+9.6,hy-5.4,hx+12.6,hy-5.4,hx+12.6,hy+6,hx+9.6,hy+7],shade(HM,.06),{ow:1})}
 else if(h==='great'){
  const HP=[hx-16.4,hy-3,hx-14.4,hy-15.5,hx-1,hy-19.6,hx+12.6,hy-16,hx+17.4,hy-6,hx+17.6,hy+6,hx+12.6,hy+14.6,hx+2,hy+18.4,hx-8.6,hy+15,hx-15.4,hy+6];
  arBev(g,HP,M,{sm:1});
  g.save();arPP(g,HP,1);g.clip();g.fillStyle=hgr(g,hx-17,hx+17,'#ffffff2a','#00000040');g.fillRect(hx-18,hy-19,36,38);
  g.strokeStyle=shade(M,-.34);g.lineWidth=1.2;g.beginPath();g.moveTo(hx+6.5,hy-2);g.lineTo(hx+6.5,hy+16);g.stroke();g.fillStyle='#00000066';for(let i=0;i<4;i++)g.fillRect(hx+9,hy+3+i*3.1,6.4,1.1);
  g.restore();
  arBev(g,[hx+.5,hy-6.8,hx+17,hy-8.4,hx+17,hy-1.2,hx+.5,hy-2.6],'#0a0a14',{flat:1,ow:1.1});
  if(tier>=2||K.eyes){const pu=.8+.2*Math.sin(t*3);glow(g,hx+10,hy-4.8,9+tier,acc+'88');g.globalAlpha=pu;g.fillStyle='#ffffff';g.fillRect(hx+6.2,hy-5.7,8.4,1.5);g.fillStyle=acc;g.fillRect(hx+5.4,hy-6,9.6,2.4);g.globalAlpha=1}
  else{g.fillStyle='#ffffff55';g.fillRect(hx+11,hy-5.6,4,1)}
  g.save();arPP(g,HP,1);g.clip();arBev(g,[hx-18,hy-15.4,hx+18,hy-16.6,hx+18,hy-10.8,hx-18,hy-10.2],T,{ow:1.1});g.restore();g.strokeStyle='#000000b8';g.lineWidth=1.25;arPP(g,HP,1);g.stroke();rivet(g,hx-11,hy-13,1.1,T);rivet(g,hx+10,hy-13.6,1.1,T)}
 else if(h==='kabuto'){
  arBev(g,[hx-15,hy-7,hx-31,hy+5,hx-27,hy+18,hx-12,hy+15,hx+1,hy+5],shade(M,-.12),{edge:T,ew:1.8,tex:(g2,b)=>{g2.strokeStyle='#00000040';g2.lineWidth=.9;for(let y=b[1];y<b[3];y+=4){g2.beginPath();g2.moveTo(b[0],y);g2.lineTo(b[2],y+1);g2.stroke()}}});
  face(hx+1,hy+1,13.6,15);
  arBev(g,arEl(hx,hy-6,16.4,13.6,Math.PI,TAU,18),M,{});
  g.strokeStyle='#00000050';g.lineWidth=1;for(const x of[-9,-4.5,0,4.5,9]){g.beginPath();g.moveTo(hx+x*1.4,hy-6);g.lineTo(hx+x*.5,hy-19);g.stroke()}
  arBev(g,[hx-17,hy-9,hx+14,hy-10.4,hx+21,hy-6.4,hx+18,hy-3.4,hx+9,hy-6,hx-17,hy-4.6],T,{ow:1.1});for(const x of[-10,-2,6])rivet(g,hx+x,hy-6.6,1,T);
  arBev(g,[hx-2,hy+4.6,hx+14.4,hy+3.4,hx+13,hy+15,hx+3,hy+17.6,hx-5,hy+12],shade(M,-.1),{edge:T,ew:1.6});g.fillStyle='#00000055';for(let i=0;i<3;i++)g.fillRect(hx+4,hy+8+i*2.7,6.6,.9)}
 /* -- crests -- */
 const cr=K.crest;
 if(cr==='plume'){const pl=K.pl||hc;arBev(g,[hx-9,hy-20.5,hx+4,hy-21.5,hx+5,hy-15.5,hx-9,hy-15.5],T,{ow:1.1});
  g.beginPath();g.moveTo(hx-7,hy-19);g.quadraticCurveTo(hx-12,hy-42,hx-36-sw,hy-26-sw*.5);g.quadraticCurveTo(hx-24,hy-24,hx+3,hy-18);g.closePath();g.fillStyle=hgr(g,hx-36,hx+3,shade(pl,-.3),shade(pl,.18));g.fill();g.strokeStyle='#000000a8';g.lineWidth=1.2;g.stroke();
  g.strokeStyle='#ffffff30';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(hx-4-i*3,hy-20);g.quadraticCurveTo(hx-14-i*4,hy-36+i*3,hx-30-sw-i*2,hy-26-sw*.5+i*1.6);g.stroke()}}
 else if(cr==='crown')arCrown(g,hx-14.5,hx+15.5,h==='great'?hy-16.4:hy-10.4,K,c);
 else if(cr==='horns'){const hc2=K.hornc||T;arTusk(g,hx-8,hy-11,-2.45,30,.95,7.4,shade(hc2,-.25),{});arTusk(g,hx-2,hy-14.5,-2.25,27,.95,7.4,hc2,{})}
 else if(cr==='bonehorn'){arTusk(g,hx-8,hy-12,-2.5,22,1.1,6,'#d8d0b4',{});arTusk(g,hx-1,hy-15,-2.3,19,1,6,'#efe8d4',{})}
 else if(cr==='maedate'){arTusk(g,hx+8,hy-12.6,-2.15,26,.8,5.2,T,{});arTusk(g,hx+9,hy-12.6,-.95,25,-.8,5.2,shade(T,-.12),{});arBevE(g,hx+8.6,hy-13,3.4,3.4,'#e8352a',{ow:1})}
 else if(cr==='wings'){for(let k=0;k<2;k++){g.save();g.translate(hx-9,hy-9);g.rotate(k?-.18:0);for(let i=0;i<4;i++){g.save();g.rotate(-3.08+i*.23+k*.1);arFeather(g,[30,33,29,22][i]-k*4,i%2?mixc(M,T,.5):'#ffffff',5.4);g.restore()}g.restore()}}
 else if(cr==='spikes'){for(let i=0;i<5;i++)arTusk(g,hx-11+i*6.2,hy-15.5,-1.57+(i-2)*.14,9+((i%2)?0:4)+(i===2?4:0),0,5.2,i%2?shade(T,-.12):T,{})}
 else if(cr==='flame'){const pu=Math.sin(t*9);glow(g,hx-3,hy-26,17,'#ff8a2a88');for(const [dx,s,ph] of[[-9,.8,1],[3,1.1,0],[12,.7,2]]){const w=Math.sin(t*9+ph)*2.4,bx=hx+dx,by=hy-16;poly(g,[bx-5*s,by,bx-3*s+w,by-14*s,bx+w*1.5,by-25*s,bx+3*s+w,by-14*s,bx+5*s,by],'#ff7a1a');poly(g,[bx-2.6*s,by,bx+w,by-14*s,bx+2.6*s,by],'#ffd060')}}
 else if(cr==='fin'){const pts=[hx+9,hy-14,hx+5,hy-26,hx-2,hy-18,hx-6,hy-31,hx-13,hy-19,hx-20,hy-26,hx-20,hy-9,hx-6,hy-12];arBev(g,pts,M,{sm:0,edge:T,ew:1.8});g.strokeStyle='#00000040';g.lineWidth=1;g.beginPath();for(const [a,b] of[[5,-26],[-6,-31],[-20,-26]]){g.moveTo(hx+a,hy+b+3);g.lineTo(hx+a-1,hy-14)}g.stroke()}
 else if(cr==='antler'){const ac=K.antc||'#d2bf92';for(const [bx,by,sd] of[[hx-6,hy-14,1],[hx+3,hy-15.5,.8]]){const C=arTusk(g,bx,by,-2.1+sd*.15,28*sd,1.1,5.4,ac,{});for(const u of[4,7]){const q=C[u];arTusk(g,q[0],q[1],q[2]-.8,12*sd,.6,3.4,ac,{})}}}
 else if(cr==='moon'){const p=[],cx=hx+1,cy=hy-23;for(let i=0;i<=14;i++){const a=Math.PI*.35+(Math.PI*1.3)*i/14;p.push(cx+Math.cos(a)*9,cy+Math.sin(a)*9)}for(let i=14;i>=0;i--){const a=Math.PI*.38+(Math.PI*1.24)*i/14;p.push(cx+3.8+Math.cos(a)*7,cy+Math.sin(a)*7)}arBev(g,p,T,{ow:1.1});glow(g,cx,cy,12,acc+'55')}
 else if(cr==='bolt'){for(const sd of[0,1]){g.save();g.translate(hx-6+sd*9,hy-10);g.scale(1,1);const pp=sd?[0,0,5,-8,2,-9,10,-20,-1,-13,2,-12,-4,-4]:[0,0,-4,-10,0,-11,-8,-23,2,-14,-1,-13,5,-5];arBev(g,pp,sd?T:shade(T,-.18),{ow:1.1,flat:1});g.restore()}}
 else if(cr==='void'){for(let i=0;i<3;i++){const a=t*1.2+i*TAU/3,x=hx-2+Math.cos(a)*15,y=hy-27+Math.sin(a)*4.5;g.save();g.translate(x,y);g.rotate(t+i);glow(g,0,0,7,acc+'88');poly(g,[0,-4.4,3,0,0,4.4,-3,0],i%2?acc:'#c8a0ff','#000000a0',1);g.restore()}}
 else if(cr==='blades'){for(const [dx,a,L] of[[-5,-2.45,26],[3,-2.2,22]]){g.save();g.translate(hx+dx,hy-15);g.rotate(a);arBev(g,[0,-4.5,L*.35,-6.2,L,0,L*.35,6.2,0,4.5],dx<0?M:mixc(M,T,.35),{sm:0,edge:T,ew:1.4});g.restore()}}}
function arCrestBack(g,K,c,hx,hy){const cr=K.crest,{T,acc,t}=c;if(HWC[cr]){HWC[cr](g,K,c,hx,hy);return}
 if(cr==='corona'){g.save();g.translate(hx-1,hy-3);glow(g,0,0,52,acc+'55');g.rotate(t*.12);g.fillStyle=acc+'dd';for(let i=0;i<20;i++){g.rotate(TAU/20);const L=i%2?27:34;g.beginPath();g.moveTo(-1.6,-21);g.lineTo(0,-L);g.lineTo(1.6,-21);g.closePath();g.fill()}g.restore();
  ell(g,hx-1,hy-3,22.5,22.5,'#06030f');g.strokeStyle=acc;g.lineWidth=2.2;g.beginPath();g.arc(hx-1,hy-3,22.5,0,TAU);g.stroke();g.strokeStyle=acc+'88';g.lineWidth=1;g.beginPath();g.arc(hx-1,hy-3,19.5,0,TAU);g.stroke()}}
/* ---- pauldrons ---- */
function arPauld(g,K,c,x,y,front){const {M,D,T,acc,tier,t}=c,k=K.pauld,dm=v=>front?v:shade(v,-.26),cl=dm(K.paulc||M);
 switch(k){
 case 'soft':arBevE(g,x,y+3,10.6,7.6,cl,{});g.strokeStyle='#00000040';g.lineWidth=1.2;g.beginPath();g.moveTo(x-6,y+1);g.quadraticCurveTo(x,y+7,x+6,y+2);g.stroke();g.strokeStyle=dm(T);g.lineWidth=1.6;g.beginPath();g.ellipse(x,y+3,8.6,5.6,0,.15,Math.PI-.15);g.stroke();break;
 case 'strap':arBevE(g,x,y+5.2,11.4,5.8,dm(shade(D,.1)),{ow:1.1});arBevE(g,x,y+1,11.6,7.8,cl,{});g.save();g.setLineDash([2,2]);g.strokeStyle='#e8c890bb';g.lineWidth=.9;g.beginPath();g.ellipse(x,y+1,8.6,5.2,0,0,TAU);g.stroke();g.restore();rivet(g,x,y-3,1.5,T);break;
 case 'fur':arBevE(g,x,y+4,11.4,6.6,dm(shade(M,-.2)),{ow:1.1});for(let i=0;i<5;i++)ell(g,x-8.4+i*4.2,y+Math.sin(i*2)*1.6-.4,5.6,4.4,front?(i%2?'#f6f2e6':'#ddd6c2'):(i%2?'#b8b4a8':'#a8a398'));break;
 case 'mail':arBevE(g,x,y+2,12.4,9.6,cl,{tex:(g2,b)=>arMail(g2,b),edge:T,ew:1.6});break;
 case 'leaf':for(let i=0;i<5;i++){g.save();g.translate(x,y+4);g.rotate(-2.75+i*.62);const L=15-Math.abs(i-2)*1.6,col=dm(i%2?mixc(M,T,.2):M);arBev(g,[0,-3,L*.45,-6.2,L,0,L*.45,6.2,0,3],col,{sm:1,ow:1.1});g.strokeStyle='#00000055';g.lineWidth=.9;g.beginPath();g.moveTo(2,0);g.lineTo(L*.85,0);g.stroke();g.restore()}break;
 case 'sode':for(let i=0;i<3;i++){const yy=y-3.5+i*5.6,w=12.4-i*.4;arBev(g,[x-w,yy,x+w,yy,x+w-.8,yy+6.2,x-w+.8,yy+6.2],dm(i%2?shade(M,-.1):M),{ow:1.1,edge:i===0?T:null,ew:1.6})}g.strokeStyle=dm(T);g.lineWidth=1;for(const dx of[-7,7]){g.beginPath();g.moveTo(x+dx,y-3);g.lineTo(x+dx*.95,y+12.4);g.stroke()}break;
 case 'dome':arBevE(g,x,y+2.4,16.2,12.8,cl,{edge:T,ew:2.6});g.strokeStyle=dm(T);g.lineWidth=1.5;g.beginPath();g.ellipse(x,y+2.4,10.6,7.8,0,Math.PI*1.05,Math.PI*1.95);g.stroke();for(const dx of[-9,0,9])rivet(g,x+dx,y+9,1.5,T);arTusk(g,x,y-7,-1.57,8,0,6.4,dm(T),{});break;
 default:{ /* stacked lames: lames, spike, crystal, fin, wing */
  const cr=k==='crystal';
  if(k==='wing'){for(let i=0;i<3;i++){g.save();g.translate(x-2,y);g.rotate(-2.5+i*.36);arFeather(g,23-i*2.4,dm(i%2?mixc(M,T,.5):T),5.6);g.restore()}}
  const dome=(cy,rx,ry,col,o2)=>arBev(g,arEl(x,cy,rx,ry,Math.PI,TAU,16),col,Object.assign({sm:0,ow:1.15},o2||{}));
  dome(y+10,13.8,7.4,shade(cl,-.16));dome(y+6.4,13.4,7.8,shade(cl,-.07));dome(y+2.4,12.8,9.2,cl,{edge:T,ew:2.4,tex:cr?(g2,b)=>arFacets(g2,b,M,t):null});
  g.strokeStyle='#ffffff55';g.lineWidth=1.3;g.beginPath();g.ellipse(x,y+2.4,9.4,6.6,0,Math.PI*1.1,Math.PI*1.62);g.stroke();
  if(k==='spike'){arTusk(g,x-3,y-6,-1.95,16,.35,6.4,dm(T),{});arTusk(g,x+5,y-6,-1.3,12,-.15,5,shade(dm(T),-.2),{})}
  else if(cr){poly(g,[x-8,y-3,x-3,y-23,x+2,y-3],dm('#e8faff'),'#ffffffaa',1);poly(g,[x,y-3,x+7,y-19,x+11,y-2],dm('#bfe8ff'),'#ffffffaa',1)}
  else if(k==='fin'){arTusk(g,x-4,y-5,-2.2,18,.8,6,dm(T),{});arTusk(g,x+4,y-5,-1.5,14,.4,5,shade(dm(T),-.15),{})}}}
 if(tier>=3&&k!=='soft'&&k!=='strap'&&k!=='fur'&&k!=='leaf'&&k!=='sode'){const gy=k==='dome'?y-6.5:y-5.6;glow(g,x,gy,6,acc+'88');poly(g,[x,gy-3.2,x+2.4,gy,x,gy+3.2,x-2.4,gy],acc,'#000000a0',.9);poly(g,[x,gy-3.2,x+2.4,gy,x,gy],'#ffffff88')}}
/* ---- atmosphere: quiet, consistent, scales with tier ---- */
function arFxBack(g,K,c,hx,hy){const {acc,tier,t,my}=c;
 if(tier>=3&&!K.aura)glow(g,0,-72,tier>=4?88:72,acc+(tier>=4?'30':'20'));
 if(my===1){g.save();g.translate(hx-1,hy-3);g.rotate(t*.25);g.globalAlpha=.2;for(let i=0;i<14;i++){g.rotate(TAU/14);poly(g,[-3,-26,3,-26,0,-86-(i%2)*14],'#fff6d0')}g.restore()}}
function arFx(g,K,c){const {acc,tier,t,my}=c,f=K.fx;
 const rise=(n,fn)=>{for(let i=0;i<n;i++){const u=(t*.5+i/n)%1;fn(i,u)}};
 if(HWFX[f])HWFX[f](g,K,c,rise);else if(f==='embers')rise(7,(i,u)=>{g.globalAlpha=Math.sin(u*Math.PI);ell(g,Math.sin(i*4.3+t)*24,-34-u*96,2.1*(1-u)+.5,2.1*(1-u)+.5,i%2?'#ffd060':'#ff7a2a')});
 else if(f==='snow')rise(7,(i,u)=>{const x=Math.sin(i*5+t*.8)*28,y=-130+u*100;g.globalAlpha=Math.sin(u*Math.PI)*.9;poly(g,[x,y-2.6,x+1.7,y,x,y+2.6,x-1.7,y],'#ffffff')});
 else if(f==='bubbles')rise(4,(i,u)=>{g.globalAlpha=(1-u)*.85;g.strokeStyle='#dffffa';g.lineWidth=1.2;g.beginPath();g.arc(Math.sin(i*4+t)*26,-30-u*100,2+i%3*1.1,0,TAU);g.stroke()});
 else if(f==='petals')rise(6,(i,u)=>{const x=Math.sin(i*3.7+t*.9)*28+u*10,y=-124+u*92;g.save();g.translate(x,y);g.rotate(t*2+i);g.globalAlpha=Math.sin(u*Math.PI)*.95;ell(g,0,0,3.2,1.5,i%2?acc:mixc(acc,'#ffffff',.5));g.restore()});
 else if(f==='souls')rise(4,(i,u)=>{g.globalAlpha=Math.sin(u*Math.PI)*.55;ell(g,Math.sin(i*6+t)*22,-34-u*90,4.4*(1-u)+1.4,8*(1-u)+2,acc)});
 else if(f==='stars')for(let i=0;i<5;i++){const a=t*.5+i*TAU/5,r=40+i%2*12,x=Math.cos(a)*r,y=-84+Math.sin(a)*r*.72,tw=.5+.5*Math.sin(t*4+i*1.6);g.globalAlpha=.4+.6*tw;g.fillStyle='#ffffff';g.fillRect(x-.8,y-3.4,1.6,6.8);g.fillRect(x-3.4,y-.8,6.8,1.6);glow(g,x,y,6,acc+'66')}
 else if(f==='void')for(let i=0;i<4;i++){const a=t*.7+i*TAU/4,r=38+i%2*10,x=Math.cos(a)*r,y=-82+Math.sin(a)*r*.7;g.save();g.translate(x,y);g.rotate(t+i);g.globalAlpha=.55+.4*Math.sin(t*3+i);poly(g,[0,-4,3,0,0,4,-3,0],i%2?'#ff6ad8':'#c8a0ff');g.restore()}
 else if(f==='motes')rise(5,(i,u)=>{g.globalAlpha=Math.sin(u*Math.PI)*.9;ell(g,Math.sin(i*6)*24,-40-u*90,1.8*(1-u)+.6,1.8*(1-u)+.6,'#fff6b0')});
 else if(f==='bolt'){const sn=Math.floor(t*10),r=n=>{const s=Math.sin(sn*12.9898+n*78.233)*43758.5453;return s-Math.floor(s)};g.strokeStyle='#fff7b0';g.lineWidth=1.6;g.shadowColor='#ffe36a';g.shadowBlur=7;for(const [sx,k] of[[-15,0],[19,1]]){if(r(k)<.5)continue;g.beginPath();g.moveTo(sx,-94);let px=sx,py=-94;for(let i=1;i<4;i++){px+=(r(i+k*9)-.2)*(k?9:-9)+(k?4:-4);py-=7+r(i+3)*5;g.lineTo(px,py)}g.stroke()}g.shadowBlur=0}
 g.globalAlpha=1;
 if(my===1){for(let i=0;i<7;i++){const u=(t*.5+i/7)%1;g.globalAlpha=Math.sin(u*Math.PI)*.9;g.fillStyle=hsx(i*50+t*100,100,76);g.fillRect(Math.sin(i*5.1)*30-1.2,-36-u*100,2.4,2.4)}g.globalAlpha=1}}
