/* ===== RUNESTONE RAMPARTS 8.7: towers, build pads and projectiles (95c, art only) =====
   Seen from a 3/4 top-down angle: a ground circle of radius r is an ellipse r x r*RPSQ on the pads and towers (RPSQ = .42) and
   r x r*RPFX.sq for ground effects (burst, frost pulse, slow field; the mode may change RPFX.sq to match its range rings).
   Baked once (2x sprites in RPSPR, lazily, keyed by type|tier|skin): the stone pad, each tower's static body (a back layer and,
   where something live sits inside it, a front layer: the brazier's front lip, the belfry's front pillars and roof), the
   ballista turret in RPFX.dirs (32) yaw frames, the bells, 8 flame frames per palette, bolts, embers, snowflakes, the slow-field
   rune circle and one radial glow sprite per colour (turret frames at 1.5x to keep memory down: about 3-7 MB per tier and skin). Live each frame: drawImage of those plus a few short paths (the loaded
   ballista bolts, lightning, sparks). Glows are the baked radial sprite drawn with 'lighter'; no shadowBlur, no ctx.filter.
   API
     RPTW, RPSKIN                        names, roles, colours; skins per tower (the second one is the unlockable reward)
     rpTowerDraw(g,type,tier,skin,t,o)   tower on its pad, pad centre at (0,0); o = {aim, fire 0..1, over 0..1, sel, ghost}
     rpTowerBuild(g,type,tier,skin,k,t,o) the tower being built (k 0..1, about .9 s; o.from = the previous tier for an upgrade);
                                         at k>=1 it is exactly rpTowerDraw. Tier pips (1-3 gold gems) sit on the front of the pad.
     rpPadDraw(g,t,state)                empty pad: 'idle' | 'hover' | 'valid' | 'invalid' | 'none'
     tiers 1-5: 4 = Mythic (violet stone, violet/gold inlays, orbiting rune rings, a sigil turning on the ground), 5 = Celestial (white
       marble, halo, gold fins, a ring of light with stars, sparkles, prismatic shimmer). rpTowerBuild with o.from 3->4 or 4->5 plays the
       ascension (sky pillar, converging rune rings, flash, shockwave, shards, the new form swelling out of rays); RPFX.lite = true trims
       the tier 4-5 live layer on slow devices. rpBolt/rpEmber/rpBurst/rpFrostPulse/rpBolt2 take an optional trailing tier (4-5 richer).
     rpTowerIcon(type,tier,skin,size)    cached transparent size x size canvas
     rpBolt rpEmber rpBurst rpFrostPulse rpBolt2 rpChill rpSlowField rpOvercharge   projectiles and effects
     rpTowerTop(type,tier)               height above the pad centre of the tower's top (for health bars, labels, fx anchors)
     rpTowerWarm(type,tier,skin)         optional: bake a tower's sprites (and all 32 ballista turret frames) ahead of time
   o.ph (optional) is a per-tower phase so neighbouring towers do not flicker or sway in sync; o.ign (0..1, build only) scales the brazier flames.
   rpTowerBuild timeline: rune circle and light column, stones and planks drop and bounce, a scaffold grows, the tower rises through a
   bottom-up reveal with a bright rune line, gold flash and squash-and-stretch pop, pips pop in; every effect settles by k=.97. */
const RPTO='#12081f',RPK=2,RPSQ=.42,RPSPR=new Map(),RPGLW=new Map(),RPFX={sq:.55,dirs:32,lite:false};
let RPGA=1,RPNOPAD=0,RPPADT=0;
const RPTW={ballista:{n:'Rune Ballista',role:'Precision',col:'#5ab8ff'},brazier:{n:'Ember Blazer',role:'Splash',col:'#ff8a3a'},frost:{n:'Frost Spire',role:'Slow',col:'#8ae6ff'},bell:{n:'Storm Bell',role:'Flying foes',col:'#ffd45a'}};
const RPSKIN={ballista:['base','gilded'],brazier:['base','azure'],frost:['base','aurora'],bell:['base','thunderking']};
const RPSTONE={
 pad:{l:'#a7a3c0',m:'#83809e',d:'#5b5876',k:'#2c2940',top:'#b6b2cc',topD:'#8b87a6'},
 base:{l:'#a39fbd',m:'#7e7a9a',d:'#575472',k:'#2a273e',top:'#b2aecb',topD:'#8884a4'},
 marble:{l:'#fbf7ef',m:'#ddd5c6',d:'#aea392',k:'#5c5246',top:'#fffdf8',topD:'#d9d0c0'},
 violet:{l:'#ad98d0',m:'#856ca8',d:'#5c467e',k:'#2a1c40',top:'#bea9de',topD:'#8f78b2'}};
const RPPAL={
 ballista:{
  base:{wood:'#a3683a',woodL:'#d4955c',woodD:'#5e3519',iron:'#3c5694',ironL:'#7ea4e6',ironD:'#1e2a58',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',rune:'#5ab8ff',runeL:'#e2f6ff',str:'#efe2c4',stone:RPSTONE.base,flag:'#3264c8',flagD:'#1c3478',bolt:'#5ab8ff',boltL:'#e2f6ff',shaft:'#d9a86a'},
  gilded:{wood:'#efe6d4',woodL:'#ffffff',woodD:'#b6a27e',iron:'#e2aa30',ironL:'#ffe88e',ironD:'#93600f',trim:'#ffffff',trimL:'#ffffff',trimD:'#c6b48e',rune:'#ffbe3a',runeL:'#fff6c8',str:'#fff4d0',stone:RPSTONE.marble,flag:'#f6eedc',flagD:'#c9b48a',bolt:'#ffc23a',boltL:'#fffbe0',shaft:'#fff2d0',sun:1}},
 brazier:{
  base:{iron:'#4c4460',ironL:'#80769a',ironD:'#241e32',trim:'#e2a244',trimL:'#ffdc90',trimD:'#8a5418',rune:'#ff8a3a',coal:'#ff6a1a',coalL:'#ffd27a',coalD:'#7a1a0a',stone:RPSTONE.base,fl:['#d6301a','#ff8a1e','#ffd54a','#fff6c8'],glow:'#ff7a2a',glow2:'#ffc860'},
  azure:{iron:'#38497a',ironL:'#7d96d0',ironD:'#18203e',trim:'#cfe0ff',trimL:'#ffffff',trimD:'#6a7cae',rune:'#4ac8ff',coal:'#2a8cff',coalL:'#c4f2ff',coalD:'#0c2a7a',stone:RPSTONE.base,fl:['#1e46d8','#2ea8ff','#8ce8ff','#f2feff'],glow:'#2a8cff',glow2:'#8adcff'}},
 frost:{
  base:{metal:'#2f5cae',metalL:'#6e9eec',metalD:'#182f6a',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',cr:[{l:'#e8fbff',m:'#80d8ff',d:'#2f80e0',k:'#1a3a96'}],ring:'#c6f6ff',glow:'#62d4ff',glow2:'#c6f6ff',rune:'#8ae6ff',stone:RPSTONE.base},
  aurora:{metal:'#4c2c7e',metalL:'#8e6ccc',metalD:'#24123e',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',cr:[{l:'#fff0fa',m:'#ff9ce0',d:'#d0509e',k:'#842a78'},{l:'#effff8',m:'#8affd2',d:'#28b890',k:'#126e68'}],ring:'#ffd0f2',glow:'#ff74d4',glow2:'#6effc4',rune:'#9affd8',stone:RPSTONE.violet}},
 bell:{
  base:{stone:RPSTONE.base,wood:'#74482a',woodL:'#a8744a',woodD:'#40240f',bell:['#fff5b8','#ffd45a','#d8962a','#8a5414'],band:'#a8681a',roof:'#3c4c92',roofL:'#7086d2',roofD:'#202a5e',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',bolt:'#9adcff',rune:'#7ad0ff',glow:'#5ac0ff',iron:'#4a4458',ironL:'#7a7490'},
  thunderking:{stone:RPSTONE.violet,wood:'#4e2c64',woodL:'#7e54a0',woodD:'#26122e',bell:['#fff3c4','#ffd45a','#c98a1c','#5a2a72'],band:'#7a36b0',roof:'#5c2a92',roofL:'#a466e2',roofD:'#2c1052',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',bolt:'#c890ff',rune:'#d4a4ff',glow:'#a460ff',iron:'#3e2c58',ironL:'#7a64a0',crown:1}}};
/* tier 4 builds in violet stone, tier 5 in white marble; the skin still sets wood, metal, crystals, flames and bells */
const RPPT=new Map();function rpPalT(type,skin,tier){const P=RPPAL[type][skin];if(tier<4)return P;const k=type+skin+tier;let q=RPPT.get(k);if(!q){q=Object.assign({},P,{stone:tier>=5?RPSTONE.marble:RPSTONE.violet});RPPT.set(k,q)}return q}
const RPLC={base:'#9adcff',thunderking:'#c890ff',gold:'#ffd45a',frost:'#c6f6ff'};

/* ---------- small helpers ---------- */
const rpR=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
function rpHx(h){h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)]}
function rpMix(a,b,t){t=t<0?0:t>1?1:t;const A=rpHx(a),B=rpHx(b);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')}
function rpA(h,a){const A=rpHx(h);return 'rgba('+A[0]+','+A[1]+','+A[2]+','+a+')'}
function rpSpr(key,x0,y0,w,h,fn,k){let s=RPSPR.get(key);if(s)return s;k=k||RPK;const c=document.createElement('canvas');c.width=Math.ceil(w*k);c.height=Math.ceil(h*k);const g=c.getContext('2d');
 g.setTransform(k,0,0,k,-x0*k,-y0*k);g.lineJoin='round';g.lineCap='round';try{fn(g)}catch(e){console.error(e)}s={c,x0,y0,w,h};RPSPR.set(key,s);return s}
const rpPut=(g,s,dx,dy)=>g.drawImage(s.c,s.x0+(dx||0),s.y0+(dy||0),s.w,s.h);
function rpOut(g,lw){g.lineWidth=lw;g.strokeStyle=RPTO;g.stroke()}
function rpHG(g,x0,x1,a,b,c){const q=g.createLinearGradient(x0,0,x1,0);q.addColorStop(0,a);q.addColorStop(.42,b);q.addColorStop(1,c);return q}
function rpVG(g,y0,y1,a,b){const q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,a);q.addColorStop(1,b);return q}
function rpRiv(g,x,y,r,col){g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=col;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.arc(x-r*.35,y-r*.35,r*.38,0,TAU);g.fill()}
/* a glow: one baked radial sprite per colour, stamped with 'lighter' (the caller sets the composite) */
function rpGlowC(col){let c=RPGLW.get(col);if(c)return c;c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),q=g.createRadialGradient(32,32,0,32,32,32);
 q.addColorStop(0,rpA(col,1));q.addColorStop(.2,rpA(col,.62));q.addColorStop(.5,rpA(col,.2));q.addColorStop(1,rpA(col,0));g.fillStyle=q;g.fillRect(0,0,64,64);RPGLW.set(col,c);return c}
function rpGlow(g,x,y,rx,ry,col,a){if(a<=.01)return;g.globalAlpha=Math.min(1,a)*RPGA;g.drawImage(rpGlowC(col),x-rx,y-ry,rx*2,ry*2)}
/* sides of an upright cylinder whose bottom ellipse is centred on (cx,cy), height h, bottom radius rx, top radius rxT */
function rpSide(g,cx,cy,rx,rxT,h){g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,Math.PI,0,true);g.lineTo(cx+rxT,cy-h);g.ellipse(cx,cy-h,rxT,rxT*RPSQ,0,0,Math.PI,false);g.closePath()}
function rpTube(g,cx,cy,rx,rxT,h,cl,cm,cd,lw){rpSide(g,cx,cy,rx,rxT,h);g.fillStyle=rpHG(g,cx-rx,cx+rx,cl,cm,cd);g.fill();
 g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=Math.max(1,rx*.08);g.beginPath();g.moveTo(cx-rx*.62,cy+rx*RPSQ*.7-2);g.lineTo(cx-rxT*.62,cy-h+rxT*RPSQ*.7+2);if(h>6)g.stroke();
 rpSide(g,cx,cy,rx,rxT,h);rpOut(g,lw||2.4)}
function rpCap(g,cx,cy,rx,cl,cd,lw){g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,0,TAU);const q=g.createLinearGradient(cx-rx,cy-rx*RPSQ,cx+rx*.6,cy+rx*RPSQ);q.addColorStop(0,cl);q.addColorStop(1,cd);g.fillStyle=q;g.fill();rpOut(g,lw||2.4)}
/* a metal band around a cylinder, with rivets on its visible half */
function rpBand(g,cx,cy,rx,z,th,cl,cm,cd,nr,rc){rpTube(g,cx,cy-z,rx,rx,th,cl,cm,cd,1.8);if(nr)for(let i=0;i<nr;i++){const a=(i+.5)/nr*Math.PI;rpRiv(g,cx+Math.cos(a)*rx*.97,cy-z-th/2+Math.sin(a)*rx*RPSQ,Math.max(1,th*.22),rc||cl)}}
/* carved masonry on a cylinder: bevelled blocks shaded by the upper-left light */
function rpMason(g,cx,cy,rx,rxT,h,C,rows,cols,seed){rpSide(g,cx,cy,rx,rxT,h);g.fillStyle=C.k;g.fill();const rAt=z=>rx+(rxT-rx)*z/h,P=Math.PI;
 for(let r=0;r<rows;r++){const z0=h*r/rows+.8,z1=h*(r+1)/rows-.8,off=(r%2)*.5;
  for(let c=-1;c<cols;c++){let a0=(c+off)/cols*P,a1=(c+1+off)/cols*P;a0=Math.max(0,a0)+.03;a1=Math.min(P,a1)-.03;if(a1-a0<.06)continue;
   const r0=rAt(z0),r1=rAt(z1),am=(a0+a1)/2,L=(1-Math.cos(am))/2,n=seed*31+r*7+c;
   g.beginPath();g.ellipse(cx,cy-z0,r0,r0*RPSQ,0,a0,a1,false);g.ellipse(cx,cy-z1,r1,r1*RPSQ,0,a1,a0,true);g.closePath();
   g.fillStyle=rpMix(C.d,C.l,.08+.82*L+(rpR(n)-.5)*.2);g.fill();
   g.lineWidth=1.3;g.strokeStyle='rgba(255,255,255,.32)';g.beginPath();g.ellipse(cx,cy-z1+.9,r1,r1*RPSQ,0,a0+.03,a1-.03);g.stroke();
   g.strokeStyle='rgba(18,8,31,.38)';g.beginPath();g.ellipse(cx,cy-z0-.7,r0,r0*RPSQ,0,a0+.03,a1-.03);g.stroke();
   if(rpR(n+.37)>.78){const aa=a0+(a1-a0)*rpR(n+2),zz=z0+(z1-z0)*(.3+rpR(n+3)*.4),rr=rAt(zz);g.fillStyle='rgba(18,8,31,.3)';g.beginPath();g.arc(cx+Math.cos(aa)*rr,cy-zz+Math.sin(aa)*rr*RPSQ,1.2+rpR(n+4)*1.6,0,TAU);g.fill()}}}
 g.save();rpSide(g,cx,cy,rx,rxT,h);g.clip();const q=g.createLinearGradient(cx-rx,0,cx+rx,0);q.addColorStop(0,'rgba(255,255,255,.1)');q.addColorStop(.35,'rgba(255,255,255,0)');q.addColorStop(.72,'rgba(18,8,31,.06)');q.addColorStop(1,'rgba(18,8,31,.42)');g.fillStyle=q;g.fillRect(cx-rx-2,cy-h-rx,2*rx+4,h+2*rx);g.restore();
 rpSide(g,cx,cy,rx,rxT,h);rpOut(g,2.6)}
/* the flat top of a stone drum: flagstones split by radial seams and a carved ring */
function rpTopStone(g,cx,cy,rx,C,seed,ring){g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,0,TAU);const q=g.createLinearGradient(cx-rx,cy-rx*RPSQ,cx+rx,cy+rx*RPSQ);q.addColorStop(0,C.top);q.addColorStop(1,C.topD);g.fillStyle=q;g.fill();
 g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1.2;const n=5+(seed%3);for(let i=0;i<n;i++){const a=i/n*TAU+rpR(seed+i)*.5;g.beginPath();g.moveTo(cx+Math.cos(a)*rx*.45,cy+Math.sin(a)*rx*RPSQ*.45);g.lineTo(cx+Math.cos(a)*rx*.97,cy+Math.sin(a)*rx*RPSQ*.97);g.stroke()}
 g.beginPath();g.ellipse(cx,cy,rx*.45,rx*.45*RPSQ,0,0,TAU);g.stroke();g.strokeStyle='rgba(255,255,255,.25)';g.beginPath();g.ellipse(cx,cy+.8,rx*.45,rx*.45*RPSQ,0,.2,Math.PI-.2);g.stroke();
 if(ring){g.strokeStyle=ring;g.lineWidth=1.4;g.beginPath();g.ellipse(cx,cy,rx*.72,rx*.72*RPSQ,0,0,TAU);g.stroke()}
 g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,0,TAU);rpOut(g,2.4)}
/* chunky stroked beam: outline, colour, highlight line on its upper side */
function rpBeam(g,x0,y0,x1,y1,lw,col,hi,cv){g.beginPath();g.moveTo(x0,y0);if(cv)g.quadraticCurveTo(cv[0],cv[1],x1,y1);else g.lineTo(x1,y1);g.lineWidth=lw+3.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=lw;g.strokeStyle=col;g.stroke();
 if(hi){const o=lw*.24;g.beginPath();g.moveTo(x0-o*.4,y0-o);if(cv)g.quadraticCurveTo(cv[0]-o*.4,cv[1]-o,x1-o*.4,y1-o);else g.lineTo(x1-o*.4,y1-o);g.lineWidth=Math.max(1,lw*.28);g.strokeStyle=hi;g.stroke()}}
function rpGrass(g,x,y,s,seed){for(let i=0;i<5;i++){const dx=(i-2)*2.4*s,h=(6+rpR(seed+i)*6)*s,l=(i-2)*1.6*s+(rpR(seed+i*3)-.5)*3;g.beginPath();g.moveTo(x+dx,y);g.quadraticCurveTo(x+dx+l*.3,y-h*.6,x+dx+l,y-h);g.lineWidth=3.6*s;g.strokeStyle=RPTO;g.stroke()}
 for(let i=0;i<5;i++){const dx=(i-2)*2.4*s,h=(6+rpR(seed+i)*6)*s,l=(i-2)*1.6*s+(rpR(seed+i*3)-.5)*3;g.beginPath();g.moveTo(x+dx,y);g.quadraticCurveTo(x+dx+l*.3,y-h*.6,x+dx+l,y-h);g.lineWidth=1.8*s;g.strokeStyle=i%2?'#5aa040':'#7cc24e';g.stroke()}}
function rpMoss(g,x,y,s,seed){const b=[[0,0,5],[-5,1,3.6],[5,1.2,3.8],[2,-2.4,3.2]];g.fillStyle=RPTO;for(const [dx,dy,r] of b){g.beginPath();g.arc(x+dx*s,y+dy*s,(r+1.2)*s,0,TAU);g.fill()}
 g.fillStyle='#3f7a34';for(const [dx,dy,r] of b){g.beginPath();g.arc(x+dx*s,y+dy*s,r*s,0,TAU);g.fill()}g.fillStyle='#6cb04a';for(const [dx,dy,r] of b){g.beginPath();g.arc(x+(dx-.8)*s,y+(dy-1.2)*s,r*.62*s,0,TAU);g.fill()}
 g.fillStyle='#3f7a34';g.beginPath();g.ellipse(x+(rpR(seed)*4-2)*s,y+4*s,1.6*s,3.4*s,0,0,TAU);g.fill()}

/* ---------- the build pad ---------- */
function rpPadArt(g){if(RPNOPAD)return;const C=RPPADT>=5?RPSTONE.marble:RPSTONE.pad,P=Math.PI;
 g.fillStyle='rgba(8,4,20,.42)';g.beginPath();g.ellipse(4,18,60,23,0,0,TAU);g.fill();
 rpMason(g,0,15,50,48,15,C,2,7,3);
 g.beginPath();g.ellipse(0,0,48,48*RPSQ,0,0,TAU);g.fillStyle=C.k;g.fill();
 const n=12;for(let i=0;i<n;i++){const a0=i/n*TAU+.2+.03,a1=(i+1)/n*TAU+.2-.03,am=(a0+a1)/2,fr=Math.sin(am)>0;
  g.beginPath();g.ellipse(0,0,46.8,46.8*RPSQ,0,a0,a1);g.ellipse(0,0,31.5,31.5*RPSQ,0,a1,a0,true);g.closePath();
  g.fillStyle=rpMix(C.topD,C.top,.45+(-Math.cos(am)*.18)+(rpR(i+9)-.5)*.3);g.fill();
  g.lineWidth=1.3;g.strokeStyle=fr?'rgba(255,255,255,.35)':'rgba(18,8,31,.3)';g.beginPath();g.ellipse(0,0,32.6,32.6*RPSQ,0,a0+.03,a1-.03);g.stroke();
  g.strokeStyle=fr?'rgba(18,8,31,.25)':'rgba(255,255,255,.3)';g.beginPath();g.ellipse(0,0,45.6,45.6*RPSQ,0,a0+.03,a1-.03);g.stroke();
  if(rpR(i+40)>.7){g.fillStyle='rgba(18,8,31,.22)';const aa=a0+(a1-a0)*.6;g.beginPath();g.arc(Math.cos(aa)*40,Math.sin(aa)*40*RPSQ,1.8,0,TAU);g.fill()}}
 g.beginPath();g.ellipse(0,0,30.5,30.5*RPSQ,0,0,TAU);let q=g.createLinearGradient(-30,-12,30,12);q.addColorStop(0,C.m);q.addColorStop(1,C.d);g.fillStyle=q;g.fill();g.lineWidth=1.6;g.strokeStyle=RPTO;g.stroke();
 g.lineWidth=2;g.strokeStyle='rgba(18,8,31,.55)';g.beginPath();g.ellipse(0,-.4,21,21*RPSQ,0,0,TAU);g.stroke();g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.28)';g.beginPath();g.ellipse(0,.9,21,21*RPSQ,0,.15,P-.15);g.stroke();
 for(let i=0;i<4;i++){const a=i*P/2+P/4,x=Math.cos(a)*21,y=Math.sin(a)*21*RPSQ;g.fillStyle='rgba(18,8,31,.5)';g.beginPath();g.moveTo(x,y-2.6);g.lineTo(x+2.6,y);g.lineTo(x,y+2.6);g.lineTo(x-2.6,y);g.closePath();g.fill()}
 g.beginPath();g.ellipse(0,0,48,48*RPSQ,0,0,TAU);rpOut(g,3);
 g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=1.5;g.beginPath();g.ellipse(0,0,47,47*RPSQ,0,P*1.08,P*1.55);g.stroke();
 rpMoss(g,-40,8,1,1);rpMoss(g,33,13,.8,2);rpMoss(g,-14,-19,.7,3);
 rpGrass(g,-47,26,1,5);rpGrass(g,42,28,.9,9);rpGrass(g,-29,35,.75,13);
 if(RPPADT>=4){const A=RPASC[RPPADT];rpBand(g,0,15,49.6,5.6,4.2,A.gL,A.g,A.gD,0);g.strokeStyle=rpA(A.a,.85);g.lineWidth=1.6;g.beginPath();g.ellipse(0,0,39.5,39.5*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<8;i++){const a=(i+.5)/8*TAU;rpGemArt(g,Math.cos(a)*39.5,Math.sin(a)*39.5*RPSQ,2.6,A)}
  for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI;rpGemArt(g,Math.cos(a)*49.6,15-7.7+Math.sin(a)*49.6*RPSQ,2.4,A)}}}
const rpPadT=tr=>tr>=4?rpSpr('pad|'+tr,-64,-28,130,72,g=>{RPPADT=tr;try{rpPadArt(g)}finally{RPPADT=0}}):rpPadS();
function rpMedalArt(g,red){const M=red?['#ffc2c2','#ff5a64','#8a1824','#3a0c18','#14040a','#ff8a8a','#ffd6d6','#ffb0b0']:['#fff2a8','#ffd45a','#a8701a','#2a1f5e','#0e0824','#ffd45a','#fff3b8','#ffe48a'];
 g.beginPath();g.arc(0,0,16,0,TAU);g.fillStyle=RPTO;g.fill();g.beginPath();g.arc(0,0,14.4,0,TAU);let q=g.createLinearGradient(-14,-14,14,14);q.addColorStop(0,M[0]);q.addColorStop(.45,M[1]);q.addColorStop(1,M[2]);g.fillStyle=q;g.fill();
 g.beginPath();g.arc(0,0,10.6,0,TAU);q=g.createLinearGradient(-10,-10,10,10);q.addColorStop(0,M[3]);q.addColorStop(1,M[4]);g.fillStyle=q;g.fill();rpOut(g,1.6);
 g.save();if(red)g.rotate(Math.PI/4);g.beginPath();for(const [x,y,w,h] of [[-2.6,-8,5.2,16],[-8,-2.6,16,5.2]])g.rect(x,y,w,h);g.fillStyle=RPTO;g.fill();
 g.fillStyle=M[5];g.fillRect(-1.6,-7,3.2,14);g.fillRect(-7,-1.6,14,3.2);g.fillStyle=M[6];g.fillRect(-1.6,-7,1.4,6);g.fillRect(-7,-1.6,6,1.4);g.restore();
 g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.6;g.beginPath();g.arc(0,0,12.6,Math.PI*1.05,Math.PI*1.5);g.stroke();
 for(let i=0;i<8;i++){const a=i*Math.PI/4;rpRiv(g,Math.cos(a)*12.6,Math.sin(a)*12.6,.9,M[7])}}
/* a faceted diamond gem (inlays, pips, bow tips): A = {a,aL,aD} */
function rpGemArt(g,x,y,w,A){const h=w*1.35;g.beginPath();g.moveTo(x,y-h);g.lineTo(x+w,y);g.lineTo(x,y+h);g.lineTo(x-w,y);g.closePath();g.fillStyle=A.a;g.fill();
 g.beginPath();g.moveTo(x,y-h);g.lineTo(x-w,y);g.lineTo(x,y);g.closePath();g.fillStyle=A.aL;g.fill();g.beginPath();g.moveTo(x,y);g.lineTo(x+w,y);g.lineTo(x,y+h);g.closePath();g.fillStyle=A.aD;g.fill();
 g.beginPath();g.moveTo(x,y-h);g.lineTo(x+w,y);g.lineTo(x,y+h);g.lineTo(x-w,y);g.closePath();g.lineWidth=Math.max(1,w*.32);g.strokeStyle=RPTO;g.stroke();g.fillStyle='rgba(255,255,255,.95)';g.beginPath();g.arc(x-w*.3,y-h*.42,Math.max(.6,w*.18),0,TAU);g.fill()}
/* tier pips: a small indigo plaque with 1-3 gold gems on the front face of the pad (baked into each tower's back sprite) */
const RPPIPY=28;
function rpPipArt(g,n){const w=8+n*10,h=12,c5=n>=5;
 if(c5){g.beginPath();g.moveTo(-7,-5);g.lineTo(-8,-12);g.lineTo(-4,-9);g.lineTo(0,-14);g.lineTo(4,-9);g.lineTo(8,-12);g.lineTo(7,-5);g.closePath();g.fillStyle=rpVG(g,-14,-5,'#fff6c8','#d8a23a');g.fill();rpOut(g,1.6);for(const [x,y] of [[-8,-12],[0,-14],[8,-12]]){g.beginPath();g.arc(x,y,1.4,0,TAU);g.fillStyle='#fff';g.fill()}}
 g.beginPath();g.roundRect(-w/2,-h/2,w,h,4);g.fillStyle=n===4?rpVG(g,-h/2,h/2,'#4a2896','#1a0a3a'):c5?rpVG(g,-h/2,h/2,'#fffaf0','#d8c49a'):rpVG(g,-h/2,h/2,'#2e2470','#120a2c');g.fill();rpOut(g,2.4);
 g.beginPath();g.roundRect(-w/2+1.7,-h/2+1.7,w-3.4,h-3.4,3);g.lineWidth=1;g.strokeStyle=c5?'rgba(200,150,40,.8)':'rgba(255,212,90,.6)';g.stroke();
 const RB=['#ff8aa8','#ffd45a','#8affb4','#7ad8ff','#c8a0ff'];
 for(let i=0;i<n;i++){const x=(i-(n-1)/2)*10,cl=n===4?['#f0e0ff','#b07aff','#5a2aa8']:c5?['#ffffff',RB[i],rpMix(RB[i],'#5a3a20',.45)]:['#fff4b0','#ffd45a','#b07a1a'];
  g.beginPath();g.moveTo(x,-5.4);g.lineTo(x+3.9,0);g.lineTo(x,5.4);g.lineTo(x-3.9,0);g.closePath();g.fillStyle=rpHG(g,x-3.9,x+3.9,cl[0],cl[1],cl[2]);g.fill();g.lineWidth=1.3;g.strokeStyle=RPTO;g.stroke();
  g.fillStyle='rgba(255,255,255,.95)';g.beginPath();g.moveTo(x-.4,-3.6);g.lineTo(x-2.2,-.2);g.lineTo(x-.4,-.6);g.closePath();g.fill()}}
const rpPipS=n=>rpSpr('pip|'+n,-32,-16,64,24,g=>rpPipArt(g,n));
/* a rim around the pad top (gold, red...), drawn live */
function rpRim(g,y,col,colL,a){g.globalAlpha=a*RPGA;g.beginPath();g.ellipse(0,y,48,48*RPSQ,0,0,TAU);g.lineWidth=5.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3;g.strokeStyle=col;g.stroke();
 g.lineWidth=1.3;g.strokeStyle=colL;g.beginPath();g.ellipse(0,y-1.2,47.6,47.6*RPSQ,0,Math.PI*1.04,Math.PI*1.96);g.stroke()}
const rpPadS=()=>rpSpr('pad',-64,-28,130,72,rpPadArt);
function rpPadDraw(g,t,state){t=t||0;const s=rpPadS(),hv=state==='hover',va=state==='valid',bad=state==='invalid';
 g.save();
 if(va||bad){const p=.5+.5*Math.sin(t*5);g.globalCompositeOperation='lighter';rpGlow(g,0,8,74,34,bad?'#ff4a5a':'#ffc94a',bad?.2:.22+.18*p);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 const ly=hv?-3:0;if(hv){g.globalAlpha=.3*RPGA;g.fillStyle=RPTO;g.beginPath();g.ellipse(3,22,58,20,0,0,TAU);g.fill();g.globalAlpha=RPGA}
 rpPut(g,s,0,ly);if(state==='none'){g.restore();return}
 const m=bad?rpSpr('padmx',-18,-18,36,36,q=>rpMedalArt(q,1)):rpSpr('padm',-18,-18,36,36,q=>rpMedalArt(q,0));
 if(va){const p=.5+.5*Math.sin(t*5);g.globalCompositeOperation='lighter';g.globalAlpha=RPGA;
  g.lineWidth=9;g.strokeStyle='rgba(255,200,74,'+(.1+.12*p).toFixed(3)+')';g.beginPath();g.ellipse(0,0,50,50*RPSQ,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over';
  rpRim(g,0,'#ffc94a','#fff3c0',.55+.45*p);g.globalCompositeOperation='lighter';
  for(let i=0;i<5;i++){const k=(t*.45+i/5)%1,a=i*2.4+1;rpGlow(g,Math.cos(a)*40,Math.sin(a)*15-k*34,4,4,'#ffd45a',(1-k)*.9)}
  g.globalCompositeOperation='source-over'}
 if(hv){rpRim(g,ly,'#ffd45a','#fffbe0',1);g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*.5;g.lineWidth=8;g.strokeStyle='rgba(255,212,90,.35)';g.beginPath();g.ellipse(0,ly,50,50*RPSQ,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over'}
 if(bad){const p=.5+.5*Math.sin(t*4);rpRim(g,0,'#ff4a5a','#ffc0c0',.7+.3*p)}
 const lift=hv?6+Math.sin(t*4)*1.5:va?3+Math.sin(t*3)*2:bad?0:Math.sin(t*2)*1;
 g.globalAlpha=RPGA*.4;g.fillStyle=RPTO;g.beginPath();g.ellipse(0,1+ly,12-lift*.4,4.6-lift*.15,0,0,TAU);g.fill();
 if(hv||va){g.globalCompositeOperation='lighter';rpGlow(g,0,-16-lift+ly,30,30,'#ffd45a',hv?.6:.4+.2*Math.sin(t*5));g.globalCompositeOperation='source-over'}
 g.globalAlpha=RPGA*(bad?.85:1);const sc=hv?1.12:1;g.translate(bad?Math.sin(t*30)*(Math.sin(t*3)>.85?1.2:0):0,-16-lift+ly);g.scale(sc,sc);rpPut(g,m);g.restore()}

/* ---------- flames: 8 baked frames per palette ---------- */
function rpFlameArt(g,fl,i){const ph=i/8*TAU,sw=Math.sin(ph)*4;
 const tongue=(x,w,h,s)=>{g.beginPath();g.moveTo(x-w,0);g.bezierCurveTo(x-w,-h*.38,x-w*.42+s*.5,-h*.66,x+s,-h);g.bezierCurveTo(x+w*.5+s*.4,-h*.62,x+w,-h*.36,x+w,0);g.closePath();g.fill()};
 [[fl[0],1,0],[fl[1],.8,1.5],[fl[2],.58,3],[fl[3],.32,4.2]].forEach(([c,k,dy],j)=>{g.fillStyle=c;g.beginPath();g.ellipse(0,-dy,15*k,8*k,0,0,TAU);g.fill();
  tongue(0,13*k,(56+5*Math.sin(ph+j))*k+dy,sw*k);tongue(-8*k,8*k,(34+9*Math.sin(ph*2+1+j))*k,-sw*.6*k-2);tongue(8.5*k,8*k,(40+9*Math.sin(ph*2+3.2+j))*k,sw*.5*k+2);
  if(j<2)tongue(-13*k,4.5*k,(18+7*Math.sin(ph+4))*k,-3*k)})}
function rpFlame(g,x,y,sc,t,ph,fl,key){const f=((t*13+ph*8)|0)%8,s=rpSpr('fl|'+key+'|'+f,-26,-74,52,82,q=>rpFlameArt(q,fl,f)),fy=1+.06*Math.sin(t*17+ph*9);
 g.drawImage(s.c,x-26*sc,y-74*sc*fy,52*sc,82*sc*fy)}
function rpSparks(g,x,y,t,n,h,col,ph,w){for(let i=0;i<n;i++){const k=(t*.9+i/n+ph)%1;rpGlow(g,x+Math.sin(k*9+i*2.1+ph*7)*(w||8),y-k*h,2.6+(1-k)*1.6,2.6+(1-k)*1.6,col,(1-k)*1.1)}}

/* ---------- crystals and bells ---------- */
function rpCrystal(g,x,y,h,w,tilt,C){g.save();g.translate(x,y);g.rotate(tilt);const hw=w/2,cw=w*.2,sh=h*.7,shc=sh+w*.16,b=w*.12;
 const poly=(pts,f)=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)g.lineTo(pts[i][0],pts[i][1]);g.closePath();g.fillStyle=f;g.fill()};
 poly([[-hw,0],[-hw,-sh],[-cw,-shc],[-cw,b]],rpVG(g,-sh,0,C.l,C.m));
 poly([[-cw,b],[-cw,-shc],[cw,-shc],[cw,b]],rpVG(g,-shc,b,rpMix(C.m,C.l,.35),rpMix(C.d,C.m,.4)));
 poly([[cw,b],[cw,-shc],[hw,-sh],[hw,0]],rpVG(g,-sh,0,C.d,C.k));
 poly([[-hw,-sh],[0,-h],[-cw,-shc]],'#ffffff');poly([[-cw,-shc],[0,-h],[cw,-shc]],C.l);poly([[cw,-shc],[0,-h],[hw,-sh]],C.m);
 g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.moveTo(-cw,b);g.lineTo(-cw,-shc);g.lineTo(0,-h);g.stroke();g.strokeStyle=rpA(C.k,.6);g.beginPath();g.moveTo(cw,b);g.lineTo(cw,-shc);g.lineTo(-cw,-shc);g.stroke();
 g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=Math.max(1.2,w*.07);g.beginPath();g.moveTo(-hw+w*.12,-3);g.lineTo(-hw+w*.12,-sh+2);g.stroke();
 g.lineWidth=Math.max(.8,w*.04);g.beginPath();g.moveTo(-cw*.2,-sh*.25);g.lineTo(-cw*.2,-sh*.6);g.stroke();
 g.beginPath();g.moveTo(-hw,0);g.lineTo(-hw,-sh);g.lineTo(0,-h);g.lineTo(hw,-sh);g.lineTo(hw,0);g.lineTo(cw,b);g.lineTo(-cw,b);g.closePath();rpOut(g,Math.max(1.6,w*.11));g.restore()}
function rpShardArt(g,C){g.beginPath();g.moveTo(0,-11);g.lineTo(5,0);g.lineTo(0,11);g.lineTo(-5,0);g.closePath();g.fillStyle=rpVG(g,-11,11,C.l,C.d);g.fill();
 g.beginPath();g.moveTo(0,-11);g.lineTo(0,11);g.lineTo(5,0);g.closePath();g.fillStyle=rpA(C.k,.45);g.fill();g.beginPath();g.moveTo(0,-11);g.lineTo(5,0);g.lineTo(0,11);g.lineTo(-5,0);g.closePath();rpOut(g,1.8);
 g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.2;g.beginPath();g.moveTo(-2.4,-3);g.lineTo(-.6,-8);g.stroke()}
function rpBellArt(g,w,h,P){const B=P.bell;
 g.beginPath();g.arc(0,h*1.02,w*.09+1,0,TAU);g.fillStyle=B[3];g.fill();rpOut(g,1.6);
 g.beginPath();g.ellipse(0,0,w*.11,w*.13,0,0,TAU);g.lineWidth=w*.08+2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=w*.08;g.strokeStyle=B[2];g.stroke();
 const t0=w*.1,path=()=>{g.beginPath();g.moveTo(-w*.24,t0+h*.06);g.quadraticCurveTo(0,t0-h*.08,w*.24,t0+h*.06);g.bezierCurveTo(w*.33,t0+h*.2,w*.3,h*.6,w*.5,h*.9);g.quadraticCurveTo(0,h*1.08,-w*.5,h*.9);g.bezierCurveTo(-w*.3,h*.6,-w*.33,t0+h*.2,-w*.24,t0+h*.06);g.closePath()};
 path();const q=g.createLinearGradient(-w*.5,0,w*.5,0);q.addColorStop(0,B[1]);q.addColorStop(.2,B[0]);q.addColorStop(.48,B[1]);q.addColorStop(.82,B[2]);q.addColorStop(1,B[3]);g.fillStyle=q;g.fill();
 g.save();path();g.clip();g.strokeStyle=P.band;g.lineWidth=Math.max(1.4,h*.06);g.beginPath();g.moveTo(-w*.4,t0+h*.26);g.quadraticCurveTo(0,t0+h*.32,w*.4,t0+h*.26);g.stroke();g.beginPath();g.moveTo(-w*.6,h*.76);g.quadraticCurveTo(0,h*.86,w*.6,h*.76);g.stroke();
 g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=Math.max(.8,h*.025);g.beginPath();g.moveTo(-w*.4,t0+h*.22);g.quadraticCurveTo(0,t0+h*.28,w*.4,t0+h*.22);g.stroke();
 const ey=h*.52,es=w*.13;g.beginPath();if(P.crown){g.moveTo(-es*1.2,ey+es*.6);g.lineTo(-es*1.2,ey-es*.5);g.lineTo(-es*.6,ey);g.lineTo(0,ey-es);g.lineTo(es*.6,ey);g.lineTo(es*1.2,ey-es*.5);g.lineTo(es*1.2,ey+es*.6)}
 else{g.moveTo(es*.3,ey-es*1.3);g.lineTo(-es*.7,ey+es*.15);g.lineTo(-es*.05,ey+es*.15);g.lineTo(-es*.4,ey+es*1.3);g.lineTo(es*.8,ey-es*.25);g.lineTo(es*.1,ey-es*.25)}g.closePath();g.fillStyle=P.band;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=Math.max(1.2,w*.06);g.beginPath();g.moveTo(-w*.16,t0+h*.12);g.quadraticCurveTo(-w*.26,h*.45,-w*.36,h*.82);g.stroke();g.restore();
 g.beginPath();g.moveTo(-w*.5,h*.9);g.quadraticCurveTo(0,h*1.08,w*.5,h*.9);g.lineWidth=Math.max(2,h*.08)+2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=Math.max(2,h*.08);g.strokeStyle=B[2];g.stroke();g.lineWidth=1;g.strokeStyle=B[0];g.beginPath();g.moveTo(-w*.42,h*.89);g.quadraticCurveTo(-w*.2,h*.96,0,h*.97);g.stroke();
 path();rpOut(g,Math.max(1.8,w*.08))}
const rpBellS=(P,skin,w,h)=>rpSpr('bl|'+skin+'|'+w,-w*.6,-w*.25,w*1.2,h*1.25+w*.3,g=>rpBellArt(g,w,h,P));

/* ---------- layouts (screen offsets from the pad centre) ---------- */
const RPLAY={
 ballista:[0,{zt:38,s:1.2,top:72,runes:[]},{zt:43,s:1.36,top:84,runes:[[0,6]]},{zt:49,s:1.52,top:120,runes:[[Math.cos(1.2)*35,Math.sin(1.2)*35*RPSQ-11],[Math.cos(1.94)*35,Math.sin(1.94)*35*RPSQ-11]]}],
 brazier:[0,{rim:-38,rx:30,top:88,vents:[[0,-38,.9]],runes:[[0,-23]]},{rim:-52,rx:33,top:108,vents:[[-31,-70,.5],[31,-70,.5],[0,-52,1.05]],runes:[[0,-36],[0,-10]]},
  {rim:-66,rx:38,top:132,vents:[[-38,-90,.58],[38,-90,.58],[-27,-43,.34],[27,-43,.34],[0,-66,1.25]],runes:[[0,-48],[0,-17]]}],
 frost:[0,{top:84,cr:[-20,-74],gl:[[0,-46,26]],rings:[]},{top:104,cr:[-30,-98],gl:[[0,-62,30],[-16,-50,18],[16,-50,18]],rings:[[-60,42]]},{top:136,cr:[-42,-122],gl:[[0,-82,34],[-19,-64,20],[19,-66,20]],rings:[[-64,48],[-96,36]],shard:-136,runes:[[Math.cos(1.25)*29,Math.sin(1.25)*29*RPSQ-22],[Math.cos(1.89)*29,Math.sin(1.89)*29*RPSQ-22]]}],
 bell:[0,{top:80,hang:-60,bw:28,bh:25,rod:-78,runes:[[0,-12]]},{top:116,hang:-80,bw:30,bh:27,rod:-114,runes:[[0,-16]]},{top:136,hang:-92,bw:34,bh:30,rod:-134,orb:-134,runes:[[0,-20]],minis:[[-54,-84],[54,-80]]}]};
/* tiers 4 (Mythic: violet and gold) and 5 (Celestial: white gold) reuse the tier 3 frame and add their own ornaments and live layer */
const RPASC={4:{a:'#a66cff',aL:'#e8d6ff',aD:'#4a1e96',g:'#ffd45a',gL:'#fff0a8',gD:'#b07a1a',glow:'#9a5cff',glow2:'#ffd45a',n:'Mythic'},
 5:{a:'#fffaf0',aL:'#ffffff',aD:'#d8b060',g:'#ffe27a',gL:'#fffbe6',gD:'#c99a2a',glow:'#fff0c0',glow2:'#9ae8ff',n:'Celestial'}};
{const X={ballista:[{s:1.56,top:128,inl:[[0,4,4.6],[-27,-1,3.6],[27,-1,3.6]]},{s:1.6,top:140,inl:[[0,4,4.8],[-27,-1,3.8],[27,-1,3.8]]}],
  brazier:[{top:138,inl:[[-19,-8,4.4],[19,-8,4.4],[0,-36,3.6]]},{top:146,inl:[[-19,-8,4.6],[19,-8,4.6],[0,-36,3.8]]}],
  frost:[{top:140,inl:[[0,7,4.4],[-22,4,3.8],[22,4,3.8]]},{top:146,inl:[[0,7,4.6],[-22,4,4],[22,4,4]]}],
  bell:[{top:140,inl:[[0,4,4.2],[-18,-12,3.8],[18,-12,3.8]]},{top:146,inl:[[0,4,4.4],[-18,-12,4],[18,-12,4]]}]};
 for(const ty in X){RPLAY[ty][4]=Object.assign({},RPLAY[ty][3],X[ty][0]);RPLAY[ty][5]=Object.assign({},RPLAY[ty][3],X[ty][1])}}
function rpTowerTop(type,tier){const L=RPLAY[type];return L?L[Math.max(1,Math.min(5,tier|0||1))].top:100}

/* ---------- Rune Ballista ---------- */
function rpBallBase(g,tier,P){const S=P.stone;rpPadArt(g);
 const leg=(th,r0,z0,r1,z1,lw,col,hi)=>rpBeam(g,Math.cos(th)*r0,Math.sin(th)*r0*RPSQ-z0,Math.cos(th)*r1,Math.sin(th)*r1*RPSQ-z1,lw,col,hi);
 if(tier===1){const L=[-2.25,-.85,.62,2.5];for(const a of L)if(Math.sin(a)<0)leg(a,7,22,31,-1,5.5,P.wood,P.woodL);
  rpTube(g,0,0,11,10,32,P.woodL,P.wood,P.woodD);rpBand(g,0,0,11.2,7,4,P.ironL,P.iron,P.ironD,3);rpBand(g,0,0,10.6,22,4,P.ironL,P.iron,P.ironD,3);
  for(const a of L)if(Math.sin(a)>=0){leg(a,7,22,31,-1,5.5,P.wood,P.woodL);rpRiv(g,Math.cos(a)*31,Math.sin(a)*31*RPSQ+1,2.4,P.ironL)}
  rpTube(g,0,-32,21,21,6,P.ironL,P.iron,P.ironD);rpCap(g,0,-38,21,P.ironL,P.iron);g.strokeStyle=rpA(P.rune,.8);g.lineWidth=1.4;g.beginPath();g.ellipse(0,-38,14,14*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<5;i++){const a=(i+.5)/5*Math.PI;rpRiv(g,Math.cos(a)*20,-35+Math.sin(a)*20*RPSQ,1.5,P.ironL)}}
 else if(tier===2){rpMason(g,0,0,31,29,14,S,1,5,11);rpBand(g,0,0,30.4,4.6,3.6,P.trimL,P.trim,P.trimD,6,P.trimL);rpTopStone(g,0,-14,29,S,4,rpA(P.rune,.45));rpRunePlate(g,0,6,5.4,P,'bolt');
  const L=[-2.36,-.78,.78,2.36];for(const a of L)if(Math.sin(a)<0)leg(a,9,34,25,13,5,P.iron,P.ironL);
  rpTube(g,0,-14,12,11,22,P.woodL,P.wood,P.woodD);rpBand(g,0,-14,12.2,3,4,P.ironL,P.iron,P.ironD,3);rpBand(g,0,-14,11.4,15,4,P.ironL,P.iron,P.ironD,3);
  for(const a of L)if(Math.sin(a)>=0){leg(a,9,34,25,13,5,P.iron,P.ironL);rpRiv(g,Math.cos(a)*25,Math.sin(a)*25*RPSQ-13,2.6,P.trim)}
  rpTube(g,0,-36,25,25,7,P.ironL,P.iron,P.ironD);rpCap(g,0,-43,25,P.ironL,P.iron);g.strokeStyle=rpA(P.rune,.85);g.lineWidth=1.6;g.beginPath();g.ellipse(0,-43,17,17*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI;rpRiv(g,Math.cos(a)*24.5,-39.5+Math.sin(a)*25*RPSQ,1.7,P.trim)}}
 else{/* banner pole at the back left */
  for(const sx of [1,-1]){g.save();g.scale(sx,1);const px=-25,py=-28,hy=sx>0?0:10;rpBeam(g,px,py,px,-120+hy,3.4,P.ironD,P.ironL);g.translate(0,hy);
  g.beginPath();g.moveTo(px,-116);g.quadraticCurveTo(px-18,-112,px-38,-114);g.lineTo(px-30,-104);g.lineTo(px-40,-94);g.quadraticCurveTo(px-20,-96,px,-92);g.closePath();g.fillStyle=rpHG(g,px-40,px,P.flagD,P.flag,P.flag);g.fill();rpOut(g,2.2);
  g.strokeStyle=P.trim;g.lineWidth=1.4;g.beginPath();g.moveTo(px-2,-113);g.quadraticCurveTo(px-18,-110,px-34,-112);g.stroke();
  g.fillStyle=P.trim;g.beginPath();g.moveTo(px-14,-109);g.lineTo(px-10,-104);g.lineTo(px-14,-99);g.lineTo(px-18,-104);g.closePath();g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
  rpRiv(g,px,-122,3.4,P.trim);g.restore()}
  rpMason(g,0,0,37,34,22,S,2,6,17);rpBand(g,0,0,34.6,18,4.5,P.trimL,P.trim,P.trimD,8,P.trimL);rpBand(g,0,0,36.4,3,3.4,P.trimL,P.trim,P.trimD,8,P.trimL);rpTopStone(g,0,-22.5,34,S,7,rpA(P.rune,.5));
  {const M=[];for(let i=0;i<10;i++){const a=(i+.5)/10*TAU;M.push([Math.cos(a)*31.5,Math.sin(a)*31.5*RPSQ-22.5])}M.sort((a,b)=>a[1]-b[1]);
   for(const [x,y] of M){rpTube(g,x,y,4.4,4.2,7,S.l,S.m,S.d,1.8);rpCap(g,x,y-7,4.2,P.trimL,P.trim,1.6)}}
  for(const [x,y] of RPLAY.ballista[3].runes){g.beginPath();g.moveTo(x,y-7);g.lineTo(x+5.5,y);g.lineTo(x,y+7);g.lineTo(x-5.5,y);g.closePath();g.fillStyle=P.ironD;g.fill();rpOut(g,1.8);g.strokeStyle=rpA(P.rune,.9);g.lineWidth=1.3;g.beginPath();g.moveTo(x,y-4);g.lineTo(x,y+4);g.moveTo(x-2.5,y-1);g.lineTo(x+2.5,y+1.5);g.stroke()}
  const L=[-2.36,-.78,.78,2.36];for(const a of L)if(Math.sin(a)<0)leg(a,10,40,31,22,6,P.iron,P.ironL);
  rpTube(g,0,-23,15,14,18,P.woodL,P.wood,P.woodD);rpBand(g,0,-23,15.1,2,4,P.trimL,P.trim,P.trimD,3,P.trimL);rpBand(g,0,-23,14.4,12,4,P.ironL,P.iron,P.ironD,3);
  for(const a of L)if(Math.sin(a)>=0){leg(a,10,40,31,22,6,P.iron,P.ironL);rpRiv(g,Math.cos(a)*31,Math.sin(a)*31*RPSQ-22,3,P.trim)}
  rpTube(g,0,-41,31,31,8,P.ironL,P.iron,P.ironD);rpBand(g,0,-41,31.4,5,3.4,P.trimL,P.trim,P.trimD);rpCap(g,0,-49,31,P.ironL,P.iron);
  g.strokeStyle=rpA(P.rune,.9);g.lineWidth=1.6;g.beginPath();g.ellipse(0,-49,21,21*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<12;i++){const a=i/12*TAU;g.beginPath();g.moveTo(Math.cos(a)*23,-49+Math.sin(a)*23*RPSQ);g.lineTo(Math.cos(a)*27,-49+Math.sin(a)*27*RPSQ);g.stroke()}}}
/* the turret, baked in RPFX.dirs yaw frames; u = forward, v = right, z = up, origin on the turntable top. It is projected a
   little steeper (RPTQ) than the ground so the bow reads clearly when it points at the camera. */
const RPTQ=.58;
function rpBallTopArt(g,tier,d,P){const s=RPLAY.ballista[tier].s,yw=d/RPFX.dirs*TAU,ca=Math.cos(yw),sa=Math.sin(yw),Q=RPTQ;
 const pr=(u,v,z)=>[(u*ca-v*sa)*s,((u*sa+v*ca)*Q-z)*s];
 const poly=(pts,fill,lw)=>{g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fillStyle=fill;g.fill();rpOut(g,lw||2)};
 const box=(u0,u1,v0,v1,z0,z1,cT,cS,cE,lw)=>{if(sa>.03)poly([pr(u1,v0,z0),pr(u1,v1,z0),pr(u1,v1,z1),pr(u1,v0,z1)],cE,lw);else if(sa<-.03)poly([pr(u0,v0,z0),pr(u0,v1,z0),pr(u0,v1,z1),pr(u0,v0,z1)],cE,lw);
  const vv=ca>0?v1:v0;if(Math.abs(ca)>.03)poly([pr(u0,vv,z0),pr(u1,vv,z0),pr(u1,vv,z1),pr(u0,vv,z1)],cS,lw);poly([pr(u0,v0,z1),pr(u1,v0,z1),pr(u1,v1,z1),pr(u0,v1,z1)],cT,lw)};
 const ln=(a,b,lw,col,hi,c)=>rpBeam(g,a[0],a[1],b[0],b[1],lw*s,col,hi,c);
 const T3=tier>=3,R=tier===1?29:tier===2?33:35,zA=17;
 const yoke=()=>{for(const k of (ca>0?[-1,1]:[1,-1]))box(-9,1,k*9-1.6,k*9+1.6,0,11,P.wood,P.woodD,P.woodD,1.6)};
 const stock=()=>{box(-31,30,-4.6,4.6,8,14.5,P.woodL,P.wood,P.woodD);
  const a=pr(-27,0,14.5),b=pr(26,0,14.5);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineWidth=1.6*s;g.strokeStyle=rpA(P.woodD,.8);g.stroke();
  for(const u of [-15,4])box(u-1.6,u+1.6,-5.2,5.2,7.6,15.1,P.ironL,P.iron,P.ironD,1.4)};
 const winch=()=>{const a=pr(-26,-11,13),b=pr(-26,11,13);ln(a,b,6,P.iron,P.ironL);for(const k of [-1,1]){const e=pr(-26,k*11.6,13);rpRiv(g,e[0],e[1],3.2*s,P.trim)}};
 const riser=()=>{box(17,27,-8,8,4,17,P.ironL,P.iron,P.ironD,2.2);
  if(sa>.03){const zc=10.5,k=6.2,pts=[pr(27,0,zc+k),pr(27,k*1.1,zc),pr(27,0,zc-k),pr(27,-k*1.1,zc)];poly(pts,P.ironD,1.6);
   const m=pr(27,0,zc),in2=pts.map(p=>[m[0]+(p[0]-m[0])*.55,m[1]+(p[1]-m[1])*.55]);poly(in2,P.rune,1.2);
   g.strokeStyle=P.runeL;g.lineWidth=1.2*s;const a=pr(27,0,zc+k*.42),b=pr(27,0,zc-k*.42);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.stroke();
   for(const p of pts)rpRiv(g,p[0],p[1],1.3*s,P.trim)}
  for(const k of [-1,1]){const tp=pr(22,k*8,17);rpRiv(g,tp[0],tp[1],2.2*s,P.trim)}};
 const arms=(z,reach,lw,gold)=>{const order=ca>0?[-1,1]:[1,-1],tips=[];
  for(const k of order){const A=pr(23,k*7,z),C=pr(31,k*reach*.55,z),B=pr(17,k*reach,z),M=pr(26.5,k*reach*.5,z);
   ln(A,B,lw*.78,P.wood,P.woodL,C);ln(A,M,lw,P.wood,P.woodL,pr(28,k*reach*.3,z));
   if(tier>1){const m=pr(27.5,k*reach*.62,z);rpRiv(g,m[0],m[1],2.3*s,P.ironL)}
   const tc=pr(19,k*(reach+1.5),z);ln(B,tc,lw*.7,gold?P.trim:P.iron,gold?P.trimL:P.ironL);tips.push(B)}return order[0]<0?tips:[tips[1],tips[0]]};
 const str=(tp,z)=>{const n2=pr(-6,0,z);g.beginPath();g.moveTo(tp[0][0],tp[0][1]);g.lineTo(n2[0],n2[1]);g.lineTo(tp[1][0],tp[1][1]);g.lineWidth=2.8;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.3;g.strokeStyle=P.str;g.stroke();rpRiv(g,n2[0],n2[1],2*s,P.trim)};
 const bows=()=>{if(T3)arms(zA-8,R*.86,6.4,1);const tp=arms(zA,R,tier===1?7:8,T3);if(tier>=4)for(const q of tp)rpGemArt(g,q[0],q[1]-1,3.4*s,RPASC[tier])};
 yoke();
 if(sa>=0){winch();stock();bows();riser()}else{riser();stock();winch();bows()}}
function rpBallTopS(tier,skin,d){const s=RPLAY.ballista[tier].s,R=(44*s)+10;return rpSpr('bt|'+tier+'|'+skin+'|'+d,-R,-(30*s+R*RPTQ+6),2*R,30*s+2*R*RPTQ+16,g=>rpBallTopArt(g,tier,d,RPPAL.ballista[skin]),1.5)}
/* the loaded bolt(s), live: they leave on a shot and slide back in while fire falls from .55 to 0 */
function rpBallBolts(g,tier,P,yw,fire,ox,oy){const s=RPLAY.ballista[tier].s,ca=Math.cos(yw),sa=Math.sin(yw),pr=(u,v,z)=>[ox+(u*ca-v*sa)*s,oy+((u*sa+v*ca)*RPTQ-z)*s];
 if(fire>.55)return null;const sl=fire>0?(fire/.55)*-16:0,zb=19.5,vs=tier>=5?[-3.8,0,3.8]:tier>=3?[-2.8,2.8]:[0],heads=[];
 for(const v of vs){const sp=0,a=pr(-8+sl,v,zb),b=pr(36+sl,v+sp*4,zb),hd=pr(47+sl,v+sp*5.3,zb),w1=pr(37+sl,v+sp*4+4.2,zb),w2=pr(37+sl,v+sp*4-4.2,zb),bk=pr(40+sl,v+sp*4.4,zb),f1=pr(-8+sl,v+2.8,zb+1),f2=pr(-8+sl,v-2.8,zb+1),f0=pr(-1+sl,v,zb);
  g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineWidth=2.6*s+2.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6*s;g.strokeStyle=P.shaft;g.stroke();
  for(const f of [f1,f2]){g.beginPath();g.moveTo(f[0],f[1]);g.lineTo(f0[0],f0[1]);g.lineTo(a[0]+(f0[0]-a[0])*.3,a[1]+(f0[1]-a[1])*.3);g.closePath();g.fillStyle=P.bolt;g.fill();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke()}
  g.beginPath();g.moveTo(hd[0],hd[1]);g.lineTo(w1[0],w1[1]);g.lineTo(bk[0],bk[1]);g.lineTo(w2[0],w2[1]);g.closePath();g.fillStyle=P.bolt;g.fill();g.lineWidth=1.6;g.strokeStyle=RPTO;g.stroke();
  g.fillStyle=P.runeL;g.beginPath();g.arc((hd[0]+bk[0])/2,(hd[1]+bk[1])/2,1.4*s,0,TAU);g.fill();heads.push([(hd[0]*2+bk[0])/3,(hd[1]*2+bk[1])/3])}
 return heads}
/* live parts of the turret: the bow string (drawn back while loaded, snaps forward and twangs on a shot, then is cranked back while the
   next bolt slides in) and the two winch cranks (they spin while reloading) */
function rpBallStr(g,tier,P,yq,fire,ox,oy,t){const s=RPLAY.ballista[tier].s,ca=Math.cos(yq),sa=Math.sin(yq),pr=(u,v,z)=>[ox+(u*ca-v*sa)*s,oy+((u*sa+v*ca)*RPTQ-z)*s];
 const R=tier===1?29:tier===2?33:35,zA=17;let un,th;
 if(fire>.55){const q=(fire-.55)/.45;un=17+Math.sin((1-q)*20)*5*q*q;th=Math.PI*.5}else{const r=fire/.55;un=-6+23*r*r*(3-2*r)-(fire>0?0:.8+.8*Math.sin(t*2.2));th=Math.PI*.5+r*TAU*2}
 g.beginPath();const ks=[];for(const k of [-1,1]){const h=pr(-26,k*12.8,13),e=pr(-26+Math.cos(th)*6,k*12.8,13+Math.sin(th)*6);g.moveTo(h[0],h[1]);g.lineTo(e[0],e[1]);ks.push(e)}g.lineWidth=2*s+3.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2*s;g.strokeStyle=P.ironL;g.stroke();
 g.beginPath();for(const e of ks){g.moveTo(e[0]+2.2*s,e[1]);g.arc(e[0],e[1],2.2*s,0,TAU)}g.fillStyle=P.woodL;g.fill();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke();
 const bw=tier>=3?[[zA-8,R*.86],[zA,R]]:[[zA,R]];
 for(const [z,rc] of bw){const a=pr(17,-rc,z),b=pr(17,rc,z),n=pr(un,0,z);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(n[0],n[1]);g.lineTo(b[0],b[1]);g.lineWidth=2.8;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.3;g.strokeStyle=P.str;g.stroke();
  if(z===zA)rpRiv(g,n[0],n[1],2*s,P.trim)}}
function rpBallLive(g,tier,skin,P,t,o,L){const aim=o.aim==null?.5:o.aim,fire=o.fire||0,yw=Math.atan2(Math.sin(aim)/RPTQ,Math.cos(aim)),N=RPFX.dirs;
 let d=Math.round(yw/TAU*N)%N;if(d<0)d+=N;const yq=d/N*TAU,s=L.s,rc=fire*fire*6*s,ox=-Math.cos(aim)*rc,oy=-L.zt-Math.sin(aim)*rc*.6,sa=Math.sin(yq),ca=Math.cos(yq);
 rpPut(g,rpBallTopS(tier,skin,d),ox,oy);
 rpBallStr(g,tier,P,yq,fire,ox,oy,t+(o.ph||0));
 const hs=rpBallBolts(g,tier,P,yq,fire,ox,oy);
 g.globalCompositeOperation='lighter';
 if(hs)for(const h of hs)rpGlow(g,h[0],h[1],9*s,9*s,P.bolt,.7+.25*Math.sin(t*6));
 if(sa>.05){const px=ox+27*s*ca,py=oy+(27*sa*RPTQ-10.5)*s;rpGlow(g,px,py,12*s,12*s,P.rune,(.5+.2*Math.sin(t*3))*Math.min(1,sa*2))}
 if(fire>.01){const mx=ox+50*s*ca,my=oy+(50*sa*RPTQ-19.5)*s;rpGlow(g,mx,my,34*fire*s,34*fire*s,P.bolt,fire);rpGlow(g,mx,my,14*fire*s,14*fire*s,'#ffffff',fire)}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
/* ---------- Ember Blazer ---------- */
function rpBowl(g,cy,rx,dep,P,tier,part){const ry=rx*RPSQ;
 if(part!=='front'){
  g.beginPath();g.moveTo(-rx,cy);g.bezierCurveTo(-rx,cy+dep*.8,-rx*.52,cy+dep,0,cy+dep);g.bezierCurveTo(rx*.52,cy+dep,rx,cy+dep*.8,rx,cy);g.ellipse(0,cy,rx,ry,0,0,Math.PI,false);g.closePath();
  g.fillStyle=rpHG(g,-rx,rx,P.ironL,P.iron,P.ironD);g.fill();
  g.save();g.clip();for(let i=1;i<6;i++){const a=i/6*Math.PI,x=Math.cos(a)*rx*.98;g.beginPath();g.moveTo(x,cy+Math.sin(a)*ry);g.quadraticCurveTo(x*.92,cy+dep*.75,x*.5,cy+dep*1.02);g.lineWidth=3.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.8;g.strokeStyle=i<3?P.ironL:P.iron;g.stroke()}
  g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.ellipse(-rx*.55,cy+dep*.42,rx*.12,dep*.3,.35,0,TAU);g.fill();g.restore();
  g.beginPath();g.moveTo(-rx,cy);g.bezierCurveTo(-rx,cy+dep*.8,-rx*.52,cy+dep,0,cy+dep);g.bezierCurveTo(rx*.52,cy+dep,rx,cy+dep*.8,rx,cy);rpOut(g,2.8);
  /* the coals inside */
  g.beginPath();g.ellipse(0,cy,rx-3,ry-1.4,0,0,TAU);let q=g.createRadialGradient(0,cy+1,1,0,cy,rx);q.addColorStop(0,P.coalL);q.addColorStop(.35,P.coal);q.addColorStop(.8,P.coalD);q.addColorStop(1,'#1a0808');g.fillStyle=q;g.fill();
  for(let i=0;i<9;i++){const a=rpR(i+tier*13)*TAU,r=rpR(i+5)*.75,x=Math.cos(a)*(rx-6)*r,y=cy+Math.sin(a)*(ry-2)*r;g.beginPath();g.ellipse(x,y,3+rpR(i+9)*2.4,1.8+rpR(i+3),0,0,TAU);g.fillStyle=rpA(P.coalD,.85);g.fill();g.fillStyle=rpA(P.coalL,.7);g.beginPath();g.ellipse(x-.8,y-.6,1.4,.8,0,0,TAU);g.fill()}
  /* back half of the rim */
  g.beginPath();g.ellipse(0,cy,rx,ry,0,Math.PI,TAU);g.lineWidth=8;g.strokeStyle=RPTO;g.stroke();g.lineWidth=5;g.strokeStyle=P.trimD;g.stroke();g.lineWidth=1.4;g.strokeStyle=P.trim;g.beginPath();g.ellipse(0,cy-1.2,rx,ry,0,Math.PI,TAU);g.stroke()}
 if(part!=='back'){g.beginPath();g.ellipse(0,cy,rx,ry,0,0,Math.PI);g.lineWidth=9;g.strokeStyle=RPTO;g.stroke();g.lineWidth=6;g.strokeStyle=rpHG(g,-rx,rx,P.trimL,P.trim,P.trimD);g.stroke();
  g.lineWidth=1.6;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.ellipse(0,cy-1.6,rx,ry,0,Math.PI*.55,Math.PI*.98);g.stroke();
  for(let i=0;i<9;i++){const a=(i+.5)/9*Math.PI;rpRiv(g,Math.cos(a)*rx,cy+Math.sin(a)*ry,1.5,P.trimL)}}}
function rpRunePlate(g,x,y,w,P,glyph){g.beginPath();g.moveTo(x,y-w*1.15);g.lineTo(x+w,y);g.lineTo(x,y+w*1.15);g.lineTo(x-w,y);g.closePath();g.fillStyle=rpHG(g,x-w,x+w,P.trimL,P.trim,P.trimD);g.fill();rpOut(g,2);
 g.beginPath();g.moveTo(x,y-w*.75);g.lineTo(x+w*.62,y);g.lineTo(x,y+w*.75);g.lineTo(x-w*.62,y);g.closePath();g.fillStyle='#1c0e18';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.strokeStyle=P.rune;g.lineWidth=1.5;g.beginPath();if(glyph==='bolt'){g.moveTo(x+w*.15,y-w*.5);g.lineTo(x-w*.2,y+w*.05);g.lineTo(x+w*.2,y-w*.05);g.lineTo(x-w*.15,y+w*.5)}else if(glyph==='flake'){for(let i=0;i<3;i++){const a=i*Math.PI/3+Math.PI/2;g.moveTo(x+Math.cos(a)*w*.45,y+Math.sin(a)*w*.5);g.lineTo(x-Math.cos(a)*w*.45,y-Math.sin(a)*w*.5)}}
 else{g.moveTo(x,y+w*.5);g.quadraticCurveTo(x-w*.4,y,x,y-w*.55);g.quadraticCurveTo(x+w*.4,y,x,y+w*.5)}g.stroke()}
function rpChimney(g,x,yb,yt,w,P){g.beginPath();g.rect(x-w/2,yt,w,yb-yt);g.fillStyle=rpHG(g,x-w/2,x+w/2,P.ironL,P.iron,P.ironD);g.fill();rpOut(g,2.2);
 for(const y of [yb-5,(yb+yt)/2])rpBand(g,x,y+2,w*.62,0,2.6,P.trimL,P.trim,P.trimD);
 rpTube(g,x,yt+2,w*.8,w*.95,5,P.trimL,P.trim,P.trimD,2);g.beginPath();g.ellipse(x,yt-3,w*.95,w*.95*RPSQ,0,0,TAU);g.fillStyle='#1a0808';g.fill();g.lineWidth=2;g.strokeStyle=P.trimD;g.stroke();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke()}
function rpBrazBack(g,tier,P){const S=P.stone,L=RPLAY.brazier[tier];rpPadArt(g);
 const legs=(y0,y1,sp,lw)=>{for(const [x,b] of [[-sp,-1],[sp,-1],[-sp*.7,1],[sp*.7,1]]){const fy=y1+b*4;rpBeam(g,x*.55,y0,x,fy,lw,P.iron,P.ironL,[x*1.05,(y0+fy)/2]);g.beginPath();g.ellipse(x+(x<0?-2:2),fy+1,4.6,2.2,0,0,TAU);g.fillStyle=P.ironD;g.fill();rpOut(g,1.6)}};
 if(tier===1){legs(-24,0,24,4.6);rpBowl(g,L.rim,L.rx,24,P,1,'back');rpRunePlate(g,0,-23,6.5,P)}
 else if(tier===2){rpMason(g,0,0,24,21,26,S,2,5,21);
  g.beginPath();g.moveTo(-7,-3);g.lineTo(-7,-12);g.quadraticCurveTo(0,-20,7,-12);g.lineTo(7,-3);g.closePath();g.fillStyle='#1a0808';g.fill();rpOut(g,2);
  for(const x of [-3.5,0,3.5]){g.beginPath();g.moveTo(x,-3);g.lineTo(x,x?-12:-15);g.lineWidth=1.6;g.strokeStyle=P.iron;g.stroke()}
  legs(-32,-22,18,4);rpChimney(g,-31,-50,-66,8,P);rpChimney(g,31,-50,-66,8,P);rpBowl(g,L.rim,L.rx,24,P,2,'back');rpRunePlate(g,0,-36,7,P)}
 else{rpMason(g,0,0,32,26,40,S,3,6,29);rpBand(g,0,0,26.6,36,5,P.trimL,P.trim,P.trimD,7,P.trimL);
  g.beginPath();g.moveTo(-9,-4);g.lineTo(-9,-19);g.quadraticCurveTo(0,-30,9,-19);g.lineTo(9,-4);g.closePath();g.fillStyle='#1a0808';g.fill();g.lineWidth=5;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6;g.strokeStyle=P.trimD;g.stroke();
  for(const x of [-4.5,0,4.5]){g.beginPath();g.moveTo(x,-4);g.lineTo(x,x?-20:-24);g.lineWidth=1.8;g.strokeStyle=P.iron;g.stroke()}
  for(const k of [-1,1]){rpChimney(g,k*27,-36,-46,6,P)}
  rpChimney(g,-38,-62,-86,9,P);rpChimney(g,38,-62,-86,9,P);
  for(let i=0;i<7;i++){const a=Math.PI+(i+.5)/7*Math.PI,x=Math.cos(a)*L.rx,y=L.rim+Math.sin(a)*L.rx*RPSQ;rpSpike(g,x,y,P)}
  rpBowl(g,L.rim,L.rx,26,P,3,'back');rpRunePlate(g,0,-48,7.5,P)}}
function rpSpike(g,x,y,P){g.beginPath();g.moveTo(x-3.6,y+1);g.lineTo(x,y-11);g.lineTo(x+3.6,y+1);g.closePath();g.fillStyle=rpHG(g,x-3.6,x+3.6,P.trimL,P.trim,P.trimD);g.fill();rpOut(g,1.8)}
function rpBrazFront(g,tier,P){const L=RPLAY.brazier[tier];rpBowl(g,L.rim,L.rx,24,P,tier,'front');
 if(tier>=3)for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI,x=Math.cos(a)*L.rx,y=L.rim+Math.sin(a)*L.rx*RPSQ;rpSpike(g,x,y+1,P)}}
/* the bellows on the pad (right front): one baked sprite squashed from its bottom as it pumps (slowly at rest, hard on a shot) */
function rpBellowsArt(g,P){const W='#a3683a',WL='#d4955c',WD='#5e3519';
 g.beginPath();g.moveTo(-9,-3.4);g.lineTo(-19,-3);g.lineTo(-19,-.6);g.lineTo(-9,-.4);g.closePath();g.fillStyle=rpVG(g,-3.4,-.4,P.trimL,P.trimD);g.fill();rpOut(g,1.6);
 g.beginPath();g.moveTo(-9,-1);g.lineTo(13,-1);g.lineTo(13,-13);g.lineTo(-9,-5);g.closePath();g.fillStyle=rpVG(g,-13,-1,'#8a4a32','#4a2016');g.fill();rpOut(g,1.6);
 g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=1.1;for(const f of [.3,.55,.8]){g.beginPath();g.moveTo(-9+22*f,-1);g.lineTo(-9+22*f,-5-8*f);g.stroke()}
 g.strokeStyle='rgba(255,220,180,.35)';for(const f of [.42,.67]){g.beginPath();g.moveTo(-9+22*f,-1.6);g.lineTo(-9+22*f,-4.6-8*f);g.stroke()}
 g.beginPath();g.moveTo(-10,1.6);g.lineTo(14,1.6);g.lineTo(14,-1.6);g.lineTo(-10,-1.6);g.closePath();g.fillStyle=rpVG(g,-1.6,1.6,W,WD);g.fill();rpOut(g,1.6);
 g.beginPath();g.moveTo(-10,-3.6);g.lineTo(14,-12.4);g.lineTo(14.6,-15.6);g.lineTo(-10,-6.6);g.closePath();g.fillStyle=rpVG(g,-15.6,-3.6,WL,W);g.fill();rpOut(g,1.6);
 rpBeam(g,14.4,-14,20,-16.6,2.2,W,WL);rpRiv(g,20.4,-16.8,1.8,P.trim);for(const x of [-4,7])rpRiv(g,x,-5.4-(x+10)*.36,1.2,P.trimL);rpRiv(g,-9,-2.2,1.6,P.trim)}
function rpBrazLive(g,tier,skin,P,t,o,L,ph){const fire=o.fire||0,fb=1+fire*.6,bs=rpSpr('bel|'+skin,-21,-19,44,22,q=>rpBellowsArt(q,P));
 const pu=Math.max(.5+.5*Math.sin(t*2.6+ph*5),fire>.01?Math.sin(Math.PI*Math.min(1,(1-fire)*1.6+.2)):0),sq=1-.42*pu;
 g.save();g.translate(29,15);g.scale(1.4+.08*pu,1.4*sq);g.globalAlpha=RPGA;rpPut(g,bs);g.restore();
 if(pu>.6){g.globalCompositeOperation='lighter';rpGlow(g,4,11,8,6,P.glow2,(pu-.6)*1.4);g.globalCompositeOperation='source-over'}
 if(fire>.01){g.globalCompositeOperation='lighter';rpGlow(g,0,L.rim-14,L.rx*2.4,L.rx*2,P.glow2,fire*.75);rpGlow(g,0,L.rim-4,L.rx*1.1,L.rx*.6,'#ffffff',fire*fire*.6);g.globalCompositeOperation='source-over'}g.globalAlpha=RPGA;return fb}
function rpBrazFlames(g,tier,skin,P,t,o,L,ph,fb){const ig=o.ign==null?1:o.ign;let i=0;if(ig>.04){for(const [x,y,s] of L.vents){rpFlame(g,x,y+2,s*fb*ig,t,ph+i*.37,P.fl,skin);i++}if(tier>=4){const v=L.vents[L.vents.length-1];rpFlame(g,v[0],v[1]+2,v[2]*fb*ig*.62,t*1.2,ph+.5,tier>=5?RPFLC:RPFLM,tier>=5?'cel':'myth')}}
 g.globalAlpha=RPGA;rpPut(g,rpSpr('bz|'+tier+'|'+skin+'|f',-64,-(L.top+20),128,L.top+66,q=>rpBrazFront(q,tier,P)));
 g.globalCompositeOperation='lighter';const v=L.vents[L.vents.length-1],fire=o.fire||0;if(ig>.5){rpSparks(g,v[0],v[1]-30*v[2],t,tier+2,80*v[2],P.glow2,ph,10*v[2]);
  if(fire>.05){const ga=RPGA;RPGA*=fire;rpSparks(g,v[0],v[1]-36*v[2],t*2.2,5,120*v[2],P.fl[2],ph+.5,20*v[2]);RPGA=ga}}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}

/* ---------- Frost Spire ---------- */
function rptRing(g,cy,rx,P,half){const ry=rx*RPSQ,a0=half?0:Math.PI,a1=half?Math.PI:TAU;g.save();if(!half)g.globalAlpha=.8;
 g.beginPath();g.ellipse(0,cy,rx,ry,0,a0,a1);g.lineWidth=5;g.strokeStyle=rpA('#12081f',.8);g.stroke();g.lineWidth=2.6;g.strokeStyle=half?P.ring:rpMix(P.ring,P.metal,.35);g.stroke();
 g.lineWidth=1;g.strokeStyle='#ffffff';g.beginPath();g.ellipse(0,cy-.9,rx,ry,0,a0+.15,a1-.15);g.stroke();
 for(let i=0;i<3;i++){const a=a0+(i+.5)/3*(a1-a0)+.3,x=Math.cos(a)*rx,y=cy+Math.sin(a)*ry;g.beginPath();g.moveTo(x,y-5.5);g.lineTo(x+3,y);g.lineTo(x,y+5.5);g.lineTo(x-3,y);g.closePath();g.fillStyle=half?P.ring:rpMix(P.ring,P.metal,.35);g.fill();rpOut(g,1.4);g.fillStyle='#fff';g.fillRect(x-1.2,y-3,1,2.4)}
 g.restore()}
function rpFrostArt(g,tier,P){const S=P.stone,C=P.cr,c2=C[1]||C[0],L=RPLAY.frost[tier];rpPadArt(g);
 if(tier===1){rpMason(g,0,0,24,21,14,S,1,5,41);rpTopStone(g,0,-14,21,S,3);
  rpTube(g,0,-13,17,15,9,P.metalL,P.metal,P.metalD);rpBand(g,0,-13,17.2,6,3,P.trimL,P.trim,P.trimD,5,P.trimL);
  rpCrystal(g,0,-17,60,22,0,C[0]);
  for(const k of [-1,1])rpBeam(g,k*14,-21,k*9,-34,3,P.trim,P.trimL)}
 else if(tier===2){rpMason(g,0,0,29,26,20,S,2,5,43);rpTopStone(g,0,-20,26,S,5);rptRing(g,-60,42,P,0);
  rpTube(g,0,-20,22,20,10,P.metalL,P.metal,P.metalD);rpBand(g,0,-20,22.2,7,3.4,P.trimL,P.trim,P.trimD,6,P.trimL);
  rpCrystal(g,-13,-28,42,15,-.32,c2);rpCrystal(g,14,-28,46,16,.3,c2);rpCrystal(g,0,-26,74,24,0,C[0]);
  for(const k of [-1,1])rpBeam(g,k*18,-30,k*11,-44,3.2,P.trim,P.trimL);rptRing(g,-60,42,P,1)}
 else{rpMason(g,0,0,35,33,14,S,1,6,47);rpTopStone(g,0,-14,33,S,6);rpMason(g,0,-14,28,26,18,S,2,5,49);rpBand(g,0,-14,26.6,15,4,P.trimL,P.trim,P.trimD,6,P.trimL);
  for(const [x,y] of L.runes)rpRunePlate(g,x,y,5,{trim:P.metal,trimL:P.metalL,trimD:P.metalD,rune:P.rune},'flake');
  rptRing(g,-64,48,P,0);rptRing(g,-96,36,P,0);
  rpTube(g,0,-32,25,23,11,P.metalL,P.metal,P.metalD);rpBand(g,0,-32,25.2,8,3.6,P.trimL,P.trim,P.trimD,7,P.trimL);
  rpCrystal(g,-9,-44,40,13,-.12,c2);rpCrystal(g,10,-44,44,13,.14,C[0]);
  rpCrystal(g,-17,-38,52,17,-.34,C[0]);rpCrystal(g,18,-38,56,17,.32,c2);rpCrystal(g,0,-37,88,27,0,C[0]);
  for(const k of [-1,1])rpBeam(g,k*20,-42,k*12,-58,3.6,P.trim,P.trimL);for(const k of [-1,1])rpRiv(g,k*12,-58,2.4,P.trimL);
  rptRing(g,-64,48,P,1);rptRing(g,-96,36,P,1)}}
function rpShardS(skin,k,C,P){return rpSpr('fs|'+skin+'|'+k,-16,-20,32,40,q=>{q.globalCompositeOperation='lighter';q.globalAlpha=.55;q.drawImage(rpGlowC(k?P.glow2||P.glow:P.glow),-16,-18,32,36);q.globalAlpha=1;q.globalCompositeOperation='source-over';rpShardArt(q,C)})}
function rpFrostLive(g,tier,skin,P,t,o,L,ph,pass){const fire=o.fire||0,C=P.cr,c2=C[1]||C[0];
 if(tier>1){const n=tier>=5?6:tier>=4?5:tier===3?4:3,R=tier>=3?46:40,zc=tier>=3?-78:-60,s0=rpShardS(skin,0,C[0],P),s1=rpShardS(skin,1,c2,P);g.globalAlpha=RPGA*(pass?1:.7);
  for(let i=0;i<n;i++){const a=t*.9+i/n*TAU+ph,sn=Math.sin(a);if(pass===0&&sn>=0||pass===1&&sn<0)continue;const x=Math.cos(a)*R,y=zc+sn*R*RPSQ+Math.sin(t*2+i)*3,w=32*(.8+.2*Math.abs(Math.cos(a)));
   g.drawImage((i%2?s1:s0).c,x-w/2,y-20,w,40)}g.globalAlpha=RPGA}
 if(tier===1){const sf=rpFlakeS(P.ring);for(let i=0;i<2;i++){const a=t*.7+i*Math.PI+ph,sn=Math.sin(a);if(pass===0&&sn>=0||pass===1&&sn<0)continue;
   g.save();g.translate(Math.cos(a)*28,-50+sn*28*RPSQ+Math.sin(t*1.7+i)*3);g.rotate(t*.8+i);const sc=.55+.12*sn;g.scale(sc,sc);g.globalAlpha=RPGA*(pass?1:.7);rpPut(g,sf);g.restore()}g.globalAlpha=RPGA}
 if(pass===0)return;
 if(fire>.01){const ga=RPGA;for(let i=0;i<5;i++){const a=i/5*TAU+ph,d=22+40*(1-fire);RPGA=ga*fire*.55;rpGlow(g,Math.cos(a)*d,8+Math.sin(a)*d*RPSQ-(1-fire)*10,18+14*(1-fire),11+8*(1-fire),'#e6fbff',1)}RPGA=ga}
 g.globalCompositeOperation='lighter';
 {const u=((t+ph*3)*.42)%1;if(u<.32){const v=u/.32,y=L.cr[0]+(L.cr[1]-L.cr[0])*v;rpGlow(g,-2,y,9,7,'#ffffff',Math.sin(Math.PI*v)*.95);rpGlow(g,-2,y,22,14,P.glow,Math.sin(Math.PI*v)*.5)}}
 for(let k=0;k<4;k++){const a=k*2.4+ph,tw=Math.sin(t*3.2+k*1.9);if(tw<.3)continue;const x=Math.cos(a)*(10+k*3),y=-L.top*(.35+.14*k);const r=3+tw*4;g.globalAlpha=RPGA*tw;g.fillStyle='#ffffff';g.fillRect(x-r,y-.6,r*2,1.2);g.fillRect(x-.6,y-r,1.2,r*2)}
 for(const [cy,rx] of L.rings){const a=t*1.4+ph+rx,sn=Math.sin(a);if(sn>-.2)rpGlow(g,Math.cos(a)*rx,cy+sn*rx*RPSQ,7,7,'#ffffff',.9)}
 if(fire>.01)rpGlow(g,0,-L.top*.55,70*fire,50*fire,P.glow2||P.glow,fire*.8);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 if(L.shard){const y=L.shard+Math.sin(t*1.8+ph)*4,s0=rpShardS(skin,0,C[0],P);g.drawImage(s0.c,-21,y-26,42,52)}}

/* ---------- Storm Bell ---------- */
function rpPillar(g,x,yb,yt,w,P){rpBeam(g,x,yb,x,yt,w,P.stone.m,P.stone.l);rpTube(g,x,yb+2,w*.8,w*.75,4,P.stone.l,P.stone.m,P.stone.d,1.8);rpTube(g,x,yt+3,w*.7,w*.8,4,P.trimL,P.trim,P.trimD,1.8)}
function rpRoof(g,cy,rx,ay,P){g.beginPath();g.moveTo(-rx,cy);g.lineTo(0,ay);g.lineTo(rx,cy);g.ellipse(0,cy,rx,rx*RPSQ,0,0,Math.PI,false);g.closePath();g.fillStyle=rpHG(g,-rx,rx,P.roofL,P.roof,P.roofD);g.fill();
 g.save();g.clip();g.strokeStyle=rpA(P.roofD,.9);g.lineWidth=1.4;for(let k=1;k<4;k++){const f=k/4,r=rx*f,yy=ay+(cy-ay)*f;g.beginPath();g.ellipse(0,yy,r,r*RPSQ,0,.05,Math.PI-.05);g.stroke()}
 for(let i=1;i<8;i++){const a=i/8*Math.PI;g.beginPath();g.moveTo(0,ay);g.lineTo(Math.cos(a)*rx,cy+Math.sin(a)*rx*RPSQ);g.stroke()}
 g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2;g.beginPath();g.moveTo(-2,ay+4);g.lineTo(-rx*.62,cy+rx*RPSQ*.5);g.stroke();g.restore();
 g.beginPath();g.moveTo(-rx,cy);g.lineTo(0,ay);g.lineTo(rx,cy);g.ellipse(0,cy,rx,rx*RPSQ,0,0,Math.PI,false);g.closePath();rpOut(g,2.8);
 g.beginPath();g.ellipse(0,cy,rx,rx*RPSQ,0,0,Math.PI);g.lineWidth=6.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3.6;g.strokeStyle=rpHG(g,-rx,rx,P.trimL,P.trim,P.trimD);g.stroke();
 for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI;rpRiv(g,Math.cos(a)*rx,cy+Math.sin(a)*rx*RPSQ,1.4,P.trimL)}}
function rpBellBack(g,tier,P){const S=P.stone,L=RPLAY.bell[tier];rpPadArt(g);
 if(tier===1){rpMason(g,0,0,25,23,24,S,2,5,61);rpTopStone(g,0,-24,23,S,2);rpRunePlate(g,0,-12,6.5,P,'bolt');
  for(const k of [-1,1]){rpBeam(g,k*19,-24,k*17,-66,6.5,P.wood,P.woodL);rpBeam(g,k*17,-38,k*8,-60,3.4,P.woodD)}}
 else{const zb=tier===2?32:42,zt=tier===2?84:98,px=tier===2?20:23,pz=8;
  rpMason(g,0,0,tier===2?29:33,tier===2?27:30,zb,S,tier===2?3:3,6,63+tier);if(tier>=3)rpBand(g,0,0,30.4,zb-5,5,P.trimL,P.trim,P.trimD,7,P.trimL);
  rpTopStone(g,0,-zb,tier===2?27:30,S,4,rpA(P.rune,.5));rpRunePlate(g,0,L.runes[0][1],7,P,'bolt');
  for(const k of [-1,1])rpPillar(g,k*px,-zb-pz*RPSQ,-zt-pz*RPSQ,7,P);
  g.beginPath();g.moveTo(0,-zt+2);g.lineTo(0,L.hang);g.lineWidth=4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2;g.strokeStyle=P.iron;g.stroke()}}
function rpBellFront(g,tier,P){const L=RPLAY.bell[tier];
 if(tier===1){rpBeam(g,-26,-64,26,-64,7.5,P.wood,P.woodL);for(const k of [-1,1])rpRiv(g,k*17,-64,2.4,P.trim);
  rpBeam(g,0,-68,0,-76,3,P.iron,P.ironL);rpRiv(g,0,-78,3.6,P.trim)}
 else{const zb=tier===2?32:42,zt=tier===2?84:98,px=tier===2?20:23,pz=8,rx=tier===2?30:35,ay=tier===2?-108:-124;
  for(const k of [-1,1])rpPillar(g,k*px,-zb+pz*RPSQ,-zt+pz*RPSQ,7.5,P);
  rpRoof(g,-zt,rx,ay,P);
  if(tier===2){rpBeam(g,0,ay+2,0,L.rod+4,2.8,P.iron,P.ironL);rpRiv(g,0,ay+1,3.4,P.trim);rpRiv(g,0,L.rod+2,3,P.trim)}
  else{rpBeam(g,0,ay+2,0,L.orb+6,3.2,P.iron,P.ironL);for(const y of [ay-2,ay-7])rpBand(g,0,y+1.5,4.6,0,2.4,P.trimL,P.trim,P.trimD);rpRiv(g,0,ay+1,3.8,P.trim);
   g.beginPath();g.arc(0,L.orb,6.5,0,TAU);g.fillStyle=rpMix(P.bolt,'#ffffff',.5);g.fill();rpOut(g,2.2);g.fillStyle='#ffffff';g.beginPath();g.arc(-2,L.orb-2,2,0,TAU);g.fill();
   if(tier>=4){const A=RPASC[tier];rpGemArt(g,0,L.orb,6.2,A);for(const k of [-1,1])rpGemArt(g,k*rx*.62,-zt+rx*RPSQ*.78+1,3,A);
    if(tier>=5){const y=ay+3;g.beginPath();g.moveTo(-9,y);g.lineTo(-10,y-9);g.lineTo(-5,y-5);g.lineTo(0,y-11);g.lineTo(5,y-5);g.lineTo(10,y-9);g.lineTo(9,y);g.closePath();g.fillStyle=rpVG(g,y-11,y,A.gL,A.gD);g.fill();rpOut(g,1.8);for(const [x,yy] of [[-10,y-9],[0,y-11],[10,y-9]])rpRiv(g,x,yy,1.6,'#ffffff')}}}}}
function rpBellLive(g,tier,skin,P,t,o,L,ph){const fire=o.fire||0,sw=Math.sin(t*1.9+ph)*.09+fire*Math.sin(fire*18)*.42;
 g.save();g.translate(0,L.hang);g.rotate(sw);rpPut(g,rpBellS(P,skin,L.bw,L.bh));g.restore()}
function rpBellTopLive(g,tier,skin,P,t,o,L,ph){const fire=o.fire||0,col=RPLC[skin]||RPLC.base;
 if(fire>.01){const by=L.hang+L.bh*.7;for(let i=0;i<2;i++){const u=Math.min(1,(1-fire)*1.25+i*.28);if(u>=1)continue;const R=L.bw*.6+u*(56+tier*8);
   g.globalAlpha=RPGA*(1-u)*.9;g.beginPath();g.ellipse(0,by,R,R*.5,0,0,TAU);g.lineWidth=5*(1-u)+2;g.strokeStyle=rpA(col,.6);g.stroke();g.lineWidth=1.6;g.strokeStyle='#ffffff';g.stroke()}g.globalAlpha=RPGA}
 g.globalCompositeOperation='lighter';
 {const sd=Math.floor(t*7+ph*13);if(rpR(sd)>(tier===1?.84:.72)){const a=rpR(sd+1)*TAU,tp=L.orb||L.rod,r=12+rpR(sd+2)*10;rpZap(g,0,tp,Math.cos(a)*r,tp+Math.sin(a)*r*.6,t,col,.7);g.globalCompositeOperation='lighter'}}
 const tip=L.orb||L.rod;if(fire>.01)rpGlow(g,0,tip,16+fire*30,16+fire*30,P.glow,fire);
 if(L.minis){for(let i=0;i<2;i++){const [x,y]=L.minis[i],yy=y+Math.sin(t*2.2+i*2+ph)*4;rpGlow(g,x,yy+8,16,16,P.glow,.45+.4*fire);rpZap(g,0,tip,x,yy-2,t+i*.37,col,.85);g.globalCompositeOperation='lighter'}
  const sd=Math.floor(t*6+ph*7);if(fire>.3||rpR(sd)>.74){const y0=L.minis[0][1]+Math.sin(t*2.2+ph)*4+6,y1=L.minis[1][1]+Math.sin(t*2.2+2+ph)*4+6;const za=fire>.3?1:.55,yt=L.orb-18;rpZap(g,L.minis[0][0],y0-4,0,yt,t+.7,col,za);g.globalCompositeOperation='lighter';rpZap(g,0,yt,L.minis[1][0],y1-4,t+.9,col,za);g.globalCompositeOperation='lighter'}}
 else if(fire>.2)for(let i=0;i<2;i++){const a=-Math.PI/2+(i?.8:-.8);rpZap(g,0,tip,Math.cos(a)*24,tip+Math.sin(a)*-8+10,t+i,col,fire)}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 if(L.minis)for(let i=0;i<2;i++){const [x,y]=L.minis[i],yy=y+Math.sin(t*2.2+i*2+ph)*4;g.save();g.translate(x,yy-8);g.rotate(Math.sin(t*2.6+i)*.14);rpPut(g,rpBellS(P,skin,16,15));g.restore()}}

/* ---------- tiers 4-5: baked ornaments ---------- */
const RPCRY={4:{l:'#f2e6ff',m:'#b98cff',d:'#7440d0',k:'#3a1a7a'},5:{l:'#ffffff',m:'#fff4d2',d:'#e6bd62',k:'#8a6420'}};
const RPFLM=['#4a1e96','#8a4aff','#d6b0ff','#ffffff'],RPFLC=['#d89a2a','#ffd45a','#fff4c0','#ffffff'];
function rpAscArt(g,type,tier,P,L){const A=RPASC[tier];
 if(type==='frost')for(const k of [-1,1])rpCrystal(g,k*31,-10,tier>=5?30:26,10,k*.42,RPCRY[tier]);
 for(const [x,y,w] of L.inl){g.beginPath();g.moveTo(x,y-w*1.35-3);g.lineTo(x+w+2.4,y);g.lineTo(x,y+w*1.35+3);g.lineTo(x-w-2.4,y);g.closePath();g.fillStyle=rpHG(g,x-w-2,x+w+2,A.gL,A.g,A.gD);g.fill();rpOut(g,1.6);rpGemArt(g,x,y,w,A)}
 if(type==='ballista'){rpGemArt(g,-25,-125,3.8,A);rpGemArt(g,25,-115,3.8,A)}
 if(type==='brazier'){const L3=RPLAY.brazier[3];for(const k of [-1,1])rpGemArt(g,k*38,-60,3.6,A)}}
/* ---------- tiers 4-5: live layer (ground sigil, orbiting runes, halo, wings, sparkles, prismatic shimmer) ---------- */
function rpRuneRing(g,r,n,sz){g.beginPath();for(let i=0;i<n;i++){const a=i/n*TAU,c=Math.cos(a),s=Math.sin(a),X=(u,v)=>[c*r+(u*-s+v*c)*sz,s*r+(u*c+v*s)*sz],v=i%4,m=(u,w)=>{const q=X(u,w);g.moveTo(q[0],q[1])},l=(u,w)=>{const q=X(u,w);g.lineTo(q[0],q[1])};
  if(v===0){m(0,-6);l(0,6);m(-4,-2);l(4,2)}else if(v===1){m(-4,-5);l(0,5);l(4,-5)}else if(v===2){m(-4,5);l(-4,-5);l(4,0);l(-4,5)}else{m(0,-6);l(0,6);m(0,-1);l(4,-5);m(0,1);l(-4,5)}}g.stroke()}
function rpSigilArt(g,tier){const A=RPASC[tier];g.lineCap='round';g.lineJoin='round';
 for(const [lw,c] of [[9,'rgba(18,8,31,.6)'],[3.6,A.g],[1.3,A.gL]]){g.lineWidth=lw;g.strokeStyle=c;for(const r of [97,78]){g.beginPath();g.arc(0,0,r,0,TAU);g.stroke()}g.lineWidth=lw*.85;rpRuneRing(g,87.5,18,1)}
 g.lineWidth=2.2;g.strokeStyle=tier>=5?'#ffffff':A.a;rpRuneRing(g,87.5,18,1);
 if(tier>=5){g.lineWidth=2.4;g.strokeStyle=A.g;g.beginPath();for(let i=0;i<24;i++){const a=(i+.5)/24*TAU,r2=i%2?103:109;g.moveTo(Math.cos(a)*100,Math.sin(a)*100);g.lineTo(Math.cos(a)*r2,Math.sin(a)*r2)}g.stroke()}
 for(let i=0;i<6;i++){const a=i/6*TAU;rpGemArt(g,Math.cos(a)*97,Math.sin(a)*97,5.5,A)}}
const rpSigilS=tr=>rpSpr('sig|'+tr,-114,-114,228,228,g=>rpSigilArt(g,tr),.7);
function rpGlyphArt(g,tier,v){const A=RPASC[tier];g.drawImage(rpGlowC(A.glow),-9,-9,18,18);g.lineCap='round';g.lineJoin='round';
 const f=()=>{g.beginPath();if(v===0){g.moveTo(0,-5);g.lineTo(0,5);g.moveTo(-3.4,-1.6);g.lineTo(3.4,1.6)}else if(v===1){g.moveTo(-3.4,-4);g.lineTo(0,4.4);g.lineTo(3.4,-4)}else if(v===2){g.moveTo(-3.4,4);g.lineTo(-3.4,-4.4);g.lineTo(3.4,0);g.lineTo(-3.4,4)}else{g.moveTo(0,-5);g.lineTo(0,5);g.moveTo(0,-1);g.lineTo(3.4,-4.4);g.moveTo(0,1);g.lineTo(-3.4,4.4)}g.stroke()};
 g.lineWidth=3.4;g.strokeStyle=A.aD;f();g.lineWidth=1.7;g.strokeStyle=A.aL;f()}
const rpGlyphS=(tr,v)=>rpSpr('gly|'+tr+'|'+v,-9,-9,18,18,g=>rpGlyphArt(g,tr,v));
function rpStarArt(g){g.drawImage(rpGlowC('#fff2c0'),-12,-12,24,24);g.beginPath();g.moveTo(0,-10);g.quadraticCurveTo(1,-1,10,0);g.quadraticCurveTo(1,1,0,10);g.quadraticCurveTo(-1,1,-10,0);g.quadraticCurveTo(-1,-1,0,-10);g.fillStyle='#ffffff';g.fill()}
const rpStarS=()=>rpSpr('star',-12,-12,24,24,rpStarArt);
function rpHaloArt(g){const A=RPASC[5];g.lineCap='round';
 g.lineWidth=2.6;g.strokeStyle=A.gL;g.beginPath();for(let i=0;i<20;i++){const a=i/20*TAU,r2=i%2?96:106;g.moveTo(Math.cos(a)*78,Math.sin(a)*78);g.lineTo(Math.cos(a)*r2,Math.sin(a)*r2)}g.stroke();
 for(const [lw,c] of [[16,RPTO],[11,A.gD],[7,A.g],[2.6,'#ffffff']]){g.lineWidth=lw;g.strokeStyle=c;g.beginPath();g.arc(0,0,70,0,TAU);g.stroke()}
 for(let i=0;i<8;i++){const a=i/8*TAU;rpGemArt(g,Math.cos(a)*70,Math.sin(a)*70,6,{a:['#ff8aa8','#ffd45a','#8affb4','#7ad8ff'][i%4],aL:'#ffffff',aD:'#c8a060'})}}
const rpHaloS=()=>rpSpr('halo',-112,-112,224,224,rpHaloArt,1);
function rpWingArt(g){const A=RPASC[5];for(let i=3;i>=0;i--){const L=25-i*3.6,a=-1.32+i*.34;g.save();g.rotate(a);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(L*.45,-7,L,-1);g.quadraticCurveTo(L*.55,4,0,3);g.closePath();
  g.fillStyle=rpHG(g,0,L,'#ffffff',i===1?'#fff4d0':'#ffe7a8',A.gD);g.fill();rpOut(g,1.6);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1;g.beginPath();g.moveTo(2,-.6);g.quadraticCurveTo(L*.45,-3.6,L*.86,-1.2);g.stroke();g.restore()}
 rpGemArt(g,0,0,2.6,{a:'#7ad8ff',aL:'#ffffff',aD:'#2a7ac0'})}
const rpWingS=()=>rpSpr('wing',-6,-36,42,46,rpWingArt);
function rpPrismArt(g){const q=g.createLinearGradient(-60,0,60,0);['#ff5a7a','#ffb84a','#fff27a','#6aff9a','#5ac8ff','#9a7aff','#ff6ad8'].forEach((c,i)=>q.addColorStop(i/6,c));g.fillStyle=q;g.fillRect(-60,-14,120,28);
 g.globalCompositeOperation='destination-in';g.save();g.scale(1,.23);const r=g.createRadialGradient(0,0,0,0,0,60);r.addColorStop(0,'rgba(0,0,0,1)');r.addColorStop(.5,'rgba(0,0,0,.55)');r.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=r;g.fillRect(-60,-61,120,122);g.restore();g.globalCompositeOperation='source-over'}
const rpPrismS=()=>rpSpr('prism',-60,-14,120,28,rpPrismArt,1);
function rpRaysArt(g){for(let i=0;i<16;i++){const a=i/16*TAU,w=i%2?.07:.12,l=i%2?84:118;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(a-w)*l,Math.sin(a-w)*l);g.lineTo(Math.cos(a+w)*l,Math.sin(a+w)*l);g.closePath();
  const q=g.createRadialGradient(0,0,0,0,0,l);q.addColorStop(0,'rgba(255,255,255,.95)');q.addColorStop(.5,'rgba(255,240,190,.5)');q.addColorStop(1,'rgba(255,220,140,0)');g.fillStyle=q;g.fill()}}
const rpRaysS=()=>rpSpr('rays',-120,-120,240,240,rpRaysArt,1);
const RPHALO={ballista:[-128,26],brazier:[-98,34],frost:[-130,22],bell:[-142,24]},RPWING={ballista:[37,-26],brazier:[35,-26],frost:[36,-34],bell:[37,-26]};
/* the sigil ring turning on the ground around the pad (a = alpha, sc = extra scale) */
function rpAscGround(g,tier,t,ph,a,sc){if(a<=.01)return;sc=(sc||1)*.6;g.save();
 g.translate(0,16);g.scale(sc,sc*RPSQ);g.rotate(t*(tier>=5?.22:-.18)+ph);g.globalAlpha=RPGA*a;rpPut(g,rpSigilS(tier));g.restore();g.globalAlpha=RPGA}
/* a ring of runes (tier 4) or star motes (tier 5) orbiting the tower at height cy; pass 0 = back half, 1 = front half */
function rpRingArt(g,tier,R,half){const A=RPASC[tier],ry=R*RPSQ,arc=()=>{g.beginPath();if(half)g.ellipse(0,0,R,ry,0,0,Math.PI);else g.ellipse(0,0,R,ry,0,Math.PI,TAU)};
 arc();g.globalAlpha=.5;g.lineWidth=4;g.strokeStyle=A.glow;g.stroke();g.globalAlpha=half?.95:.6;g.lineWidth=1.3;g.strokeStyle=A.aL;g.stroke();g.globalAlpha=1}
const rpRingS=(tr,R,h)=>rpSpr('orh|'+tr+'|'+R+'|'+h,-R-4,-R*RPSQ-4,2*R+8,2*R*RPSQ+8,g=>rpRingArt(g,tr,R,h));
function rpOrbit(g,tier,t,ph,cy,R,n,spd,pass,a){const ry=R*RPSQ;g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*a;rpPut(g,rpRingS(tier,R,pass),0,cy);
 const st=tier>=5?rpStarS():null;
 for(let i=0;i<n;i++){const an=t*spd+i/n*TAU+ph,sn=Math.sin(an);if(pass?sn<0:sn>=0)continue;const sc=.78+.26*sn;g.globalAlpha=RPGA*a*(.6+.4*sn);
  if(st){const z=(8+3*Math.sin(t*5+i*2))*sc;g.drawImage(st.c,Math.cos(an)*R-z,cy+sn*ry-z,z*2,z*2)}else{const gs=rpGlyphS(tier,i%4).c;g.drawImage(gs,Math.cos(an)*R-9*sc,cy+sn*ry-9*sc,18*sc,18*sc)}}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
function rpAscLive(g,type,tier,t,ph,L,pass){const A=RPASC[tier],top=L.top,lt=RPFX.lite;
 if(tier===4){rpOrbit(g,4,t,ph,-top*.3,44,lt?3:5,.8,pass,1);if(!lt)rpOrbit(g,4,t,ph+1,-top*.64,34,4,-1.1,pass,.9);return}
 /* celestial */
 if(pass===0){const w=RPWING[type],ws=rpWingS(),fl=Math.sin(t*2.6+ph)*.14,by=Math.sin(t*1.7+ph)*3;g.globalAlpha=RPGA;
  for(const k of [-1,1]){g.save();g.translate(k*w[0],w[1]+by);g.scale(k,1);g.rotate(-fl);rpPut(g,ws);g.restore()}
}
 rpOrbit(g,5,t,ph,-top*.42,46,lt?3:6,.7,pass,1);
 if(pass===0)return;
 const h=RPHALO[type],hy=h[0]+Math.sin(t*1.6+ph)*2;g.save();g.globalCompositeOperation='lighter';rpGlow(g,0,hy,h[1]*1.7,h[1]*.8,A.glow,.24+.08*Math.sin(t*3+ph));g.globalCompositeOperation='source-over';
 g.translate(0,hy);g.scale(h[1]/70,h[1]/70*.4);g.rotate(t*.5+ph);g.globalAlpha=RPGA;rpPut(g,rpHaloS());g.restore();g.globalAlpha=RPGA;
 g.globalCompositeOperation='lighter';const st=rpStarS().c;
 if(!lt)for(let i=0;i<4;i++){const q=t*.8+i/4+ph,u=q%1,n=Math.floor(q),x=(rpR(i*13+n)-.5)*104,y=-top*(.12+.82*rpR(i*7+n+3)),z=(5+7*rpR(i+n))*Math.sin(Math.PI*u);if(z<.5)continue;g.globalAlpha=RPGA;g.drawImage(st,x-z,y-z,z*2,z*2)}
 if(!lt){const u=((t+ph)*.3)%1;if(u<.42){const v=u/.42,y=14-v*(top+24);g.globalAlpha=RPGA*Math.sin(Math.PI*v)*.55;g.save();g.translate(0,y);g.rotate(-.22);g.drawImage(rpPrismS().c,-56,-12,112,24);g.restore()}}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}

/* ---------- lightning ---------- */
function rpZigPath(g,x1,y1,x2,y2,seed,amp){const dx=x2-x1,dy=y2-y1,d=Math.hypot(dx,dy)||1,n=Math.max(3,Math.min(14,d/12|0)),nx=-dy/d,ny=dx/d;g.beginPath();g.moveTo(x1,y1);
 for(let i=1;i<n;i++){const f=i/n,o=(rpR(seed*13.7+i)-.5)*2*amp*Math.sin(Math.PI*f);g.lineTo(x1+dx*f+nx*o,y1+dy*f+ny*o)}g.lineTo(x2,y2)}

/* ---------- the tower ---------- */
function rpBodyArt(g,type,tier,P){if(type==='ballista')rpBallBase(g,tier,P);else if(type==='brazier')rpBrazBack(g,tier,P);else if(type==='frost')rpFrostArt(g,tier,P);else rpBellBack(g,tier,P);if(tier>=4)rpAscArt(g,type,tier,P,RPLAY[type][tier])}
/* pad + static body + tier pips (what rpTowerDraw stamps), and the body alone (for the build animation, baked on first use) */
function rpBack(type,tier,skin){const P=rpPalT(type,skin,tier),top=RPLAY[type][tier].top;return rpSpr('tw|'+type+'|'+tier+'|'+skin,-66,-(top+18),132,top+64,g=>{RPPADT=tier;try{rpBodyArt(g,type,tier,P)}finally{RPPADT=0}g.save();g.translate(0,RPPIPY);rpPipArt(g,tier);g.restore()})}
function rpBody(type,tier,skin){const P=rpPalT(type,skin,tier),top=RPLAY[type][tier].top;return rpSpr('twb|'+type+'|'+tier+'|'+skin,-66,-(top+18),132,top+64,g=>{RPNOPAD=1;try{rpBodyArt(g,type,tier,P)}finally{RPNOPAD=0}})}
/* every static glow of a tower in one baked layer (tight bounds), stamped with 'lighter' and a pulsing alpha */
function rpGlowList(type,tier,P,L){const G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]);
 if(type==='ballista'){for(const [x,y] of L.runes)A(x,y,12,12,P.rune,.7);A(0,-L.zt,26*L.s,11*L.s,P.rune,.35)}
 else if(type==='brazier'){A(0,L.rim-10,L.rx*1.9,L.rx*1.5,P.glow,.5);for(const [x,y] of L.runes)A(x,y,12,12,P.rune,.8);for(const [x,y,s] of L.vents)A(x,y-14*s,26*s,24*s,P.glow2,.4)}
 else if(type==='frost'){let i=0;for(const [x,y,r] of L.gl){A(x,y,r*1.5,r*1.7,i%2&&P.glow2?P.glow2:P.glow,.42);i++}if(L.runes)for(const [x,y] of L.runes)A(x,y,10,10,P.rune,.7);if(L.shard)A(0,L.shard,22,22,P.glow,.6)}
 else{for(const [x,y] of L.runes)A(x,y,12,12,P.rune,.8);A(0,L.orb||L.rod,17,17,P.glow,.75)}if(tier>=4){const A4=RPASC[tier];for(const [x,y,z] of L.inl)A(x,y,z*3.4,z*3.4,A4.glow,.85);A(0,-L.top*.5,46,L.top*.5,A4.glow,.16)}return G}
function rpGlowLayer(type,tier,skin){const k='gl|'+type+'|'+tier+'|'+skin,s=RPSPR.get(k);if(s)return s;const P=RPPAL[type][skin],L=RPLAY[type][tier],G=rpGlowList(type,tier,P,L);
 let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const [x,y,rx,ry] of G){x0=Math.min(x0,x-rx);y0=Math.min(y0,y-ry);x1=Math.max(x1,x+rx);y1=Math.max(y1,y+ry)}
 const ts=[0,.85,1.05,1.3,1.4,1.5][tier];return rpSpr(k,Math.floor(x0),Math.floor(y0),Math.ceil(x1-x0)+1,Math.ceil(y1-y0)+1,g=>{const ga=RPGA;RPGA=1;g.globalCompositeOperation='lighter';for(const [x,y,rx,ry,c,a] of G)rpGlow(g,x,y,rx,ry,c,a*ts);RPGA=ga})}
const RPPULSE={ballista:[2.4,.22],brazier:[9,.16],frost:[2.6,.25],bell:[4,.2]};
function rpTowerDraw(g,type,tier,skin,t,o){o=o||{};t=t||0;if(!RPPAL[type])return;tier=Math.max(1,Math.min(5,tier|0||1));if(!RPPAL[type][skin])skin='base';
 const P=RPPAL[type][skin],L=RPLAY[type][tier],over=o.over||0,ph=o.ph||0;
 g.save();RPGA=o.ghost?.5:1;g.globalAlpha=RPGA;g.lineJoin='round';g.lineCap='round';
 if(o.sel){const p=.5+.5*Math.sin(t*4);g.globalCompositeOperation='lighter';rpGlow(g,0,14,82,36,'#ffc94a',.3+.15*p);
  g.globalAlpha=RPGA;g.lineWidth=7;g.strokeStyle='rgba(255,201,74,.25)';g.beginPath();g.ellipse(0,15,64,26,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over';
  g.lineWidth=5;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6;g.strokeStyle='rgba(255,212,90,'+(.75+.25*p).toFixed(3)+')';g.stroke()}
 rpTowerParts(g,type,tier,skin,t,o,0);
 if(over>.01&&!o.ghost)rpOvercharge(g,0,0,t,over,L.top);
 g.restore();RPGA=1}
/* the tower itself (static sprite, pulsing glow layer, live parts); nopad: the body without the pad and pips (build animation) */
function rpTowerParts(g,type,tier,skin,t,o,nopad){const P=rpPalT(type,skin,tier),L=RPLAY[type][tier],ph=o.ph||0;
 if(tier>=4){if(!nopad)rpAscGround(g,tier,t,ph,1);rpAscLive(g,type,tier,t,ph,L,0)}
 if(type==='frost')rpFrostLive(g,tier,skin,P,t,o,L,ph,0);
 g.globalAlpha=RPGA;rpPut(g,nopad?rpBody(type,tier,skin):rpBack(type,tier,skin));
 {const q=RPPULSE[type];g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*(1-q[1]+q[1]*Math.sin(t*q[0]+ph*7));rpPut(g,rpGlowLayer(type,tier,skin));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 if(!nopad){const u=((t+ph*2.3)*.28)%1;if(u<.12){const v=u/.12*tier,i=Math.min(tier-1,v|0);g.globalCompositeOperation='lighter';rpGlow(g,(i-(tier-1)/2)*10,RPPIPY-1,8,8,'#fff6c8',Math.sin(Math.PI*(v-i))*.95);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
 if(type==='ballista')rpBallLive(g,tier,skin,P,t,o,L);
 else if(type==='brazier'){const fb=rpBrazLive(g,tier,skin,P,t,o,L,ph);rpBrazFlames(g,tier,skin,P,t,o,L,ph,fb)}
 else if(type==='frost')rpFrostLive(g,tier,skin,P,t,o,L,ph,1);
 else{rpBellLive(g,tier,skin,P,t,o,L,ph);g.globalAlpha=RPGA;rpPut(g,rpSpr('bf|'+tier+'|'+skin,-66,-(L.top+18),132,L.top,q=>rpBellFront(q,tier,P)));rpBellTopLive(g,tier,skin,P,t,o,L,ph)}
 if(tier>=4)rpAscLive(g,type,tier,t,ph,L,1);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}

/* ---------- build and upgrade animation ---------- */
const rpSeg=(k,a,b)=>k<=a?0:k>=b?1:(k-a)/(b-a),rpEO=u=>1-(1-u)*(1-u)*(1-u),rpEIO=u=>u<.5?4*u*u*u:1-Math.pow(2-2*u,3)/2,rpEB=u=>{u-=1;return 1+u*u*(2.9*u+1.9)};
function rpBnc(u){if(u<1/2.75)return 7.5625*u*u;if(u<2/2.75){u-=1.5/2.75;return 7.5625*u*u+.75}if(u<2.5/2.75){u-=2.25/2.75;return 7.5625*u*u+.9375}u-=2.625/2.75;return 7.5625*u*u+.984375}
/* the glowing rune circle stamped on the pad (radius 100 in circle space, squashed to the ground when drawn) */
function rpBRingArt(g){g.lineCap='round';g.lineJoin='round';
 g.globalAlpha=.5;g.fillStyle='#1c1446';g.beginPath();g.arc(0,0,99,0,TAU);g.fill();g.globalAlpha=1;
 for(const [lw,c,glyph] of [[9,'rgba(18,8,31,.75)',1],[4.4,'#ffc94a',1],[1.8,'#fff6c8',0]]){
  for(const r of [96,64]){g.beginPath();g.arc(0,0,r,0,TAU);g.lineWidth=r>90?lw+1:lw*.8;g.strokeStyle=c;g.stroke()}
  g.beginPath();for(let i=0;i<4;i++){const a=i/4*TAU+Math.PI/4;g.moveTo(Math.cos(a)*64,Math.sin(a)*64);g.lineTo(Math.cos(a+Math.PI/2)*64,Math.sin(a+Math.PI/2)*64)}g.lineWidth=lw*.7;g.strokeStyle=c;g.stroke();
  if(glyph){g.lineWidth=lw*.85;g.strokeStyle=c;rpBRuneG(g)}}
 g.lineWidth=1.6;g.strokeStyle='#fff6c8';rpBRuneG(g);
 for(let i=0;i<8;i++){const a=i/8*TAU;g.beginPath();g.arc(Math.cos(a)*96,Math.sin(a)*96,6,0,TAU);g.fillStyle='#fff3c0';g.fill();g.lineWidth=2;g.strokeStyle=RPTO;g.stroke()}}
function rpBRuneG(g){for(let i=0;i<12;i++){const a=i/12*TAU;g.save();g.translate(Math.cos(a)*77,Math.sin(a)*77);g.rotate(a+Math.PI/2);g.beginPath();const v=i%4;
  if(v===0){g.moveTo(0,-6);g.lineTo(0,6);g.moveTo(-4,-2);g.lineTo(4,2)}else if(v===1){g.moveTo(-4,-5);g.lineTo(0,5);g.lineTo(4,-5)}else if(v===2){g.moveTo(-4,5);g.lineTo(-4,-5);g.lineTo(4,0);g.lineTo(-4,5)}else{g.moveTo(0,-6);g.lineTo(0,6);g.moveTo(0,-1);g.lineTo(4,-5);g.moveTo(0,1);g.lineTo(-4,5)}g.stroke();g.restore()}}
/* building material: a stone block (kind 0) or a plank (kind 1) */
function rpChunkArt(g,kind){if(kind){g.beginPath();g.rect(-12,-3,24,6);g.fillStyle=rpVG(g,-3,3,'#d4955c','#7a4524');g.fill();rpOut(g,1.8);
  g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1;g.beginPath();g.moveTo(-8,-.4);g.lineTo(5,-.4);g.stroke();rpRiv(g,-9,0,1.2,'#9ab6e8');rpRiv(g,9,0,1.2,'#9ab6e8');return}
 const C=RPSTONE.base;const q=(pts,f)=>{g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fillStyle=f;g.fill()};
 q([[-8,-3],[-4,-7],[10,-7],[6,-3]],C.top);q([[-8,-3],[6,-3],[6,5],[-8,5]],C.m);q([[6,-3],[10,-7],[10,1],[6,5]],C.d);
 g.beginPath();g.moveTo(-8,-3);g.lineTo(-4,-7);g.lineTo(10,-7);g.lineTo(10,1);g.lineTo(6,5);g.lineTo(-8,5);g.closePath();rpOut(g,1.8);
 g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=1;g.beginPath();g.moveTo(-7,-2.2);g.lineTo(5.4,-2.2);g.stroke()}
const rpChunkS=kd=>rpSpr('bch|'+kd,-15,-10,30,18,q=>rpChunkArt(q,kd));
/* the wooden scaffold: back poles and ledgers (behind the tower) or front poles and side braces (in front) */
function rpScafArt(g,H,front){const W='#a3683a',WL='#d4955c',WD='#5e3519';
 if(!front){for(const x of [-27,27])rpBeam(g,x,-10,x,-H,2.8,WD,W);for(let y=-34;y>-H+6;y-=34)rpBeam(g,-29,y,29,y,2.4,WD,W)}
 else{for(const x of [-40,40])rpBeam(g,x,13,x,-H+12,3.2,W,WL);
  for(let y=-20;y>-H+16;y-=34)for(const sx of [-1,1]){rpBeam(g,sx*40,y+8,sx*27,y,2.4,W,WL);rpRiv(g,sx*40,y+8,1.6,'#ffd45a')}
  for(const sx of [-1,1])rpRiv(g,sx*40,-H+11,2.2,'#ffd45a')}}
const rpScafS=(H,f)=>rpSpr('scf|'+H+'|'+f,-52,-H-8,104,H+30,q=>rpScafArt(q,H,f));
/* a sprite cut off above screen y (a cheap bottom-up reveal) */
function rpPutBelow(g,s,y,dx,dy){dx=dx||0;dy=dy||0;const y0=s.y0+dy,yy=Math.max(y0,Math.min(y0+s.h,y)),h=y0+s.h-yy;if(h<=.5)return;const K=s.c.height/s.h;g.drawImage(s.c,0,(yy-y0)*K,s.c.width,h*K,s.x0+dx,yy,s.w,h)}
const RPDROP=[[-27,5,0,0],[25,7,0,0],[-25,-2,0,1],[32,-5,1,0],[-6,14,1,0],[10,-9,0,0],[27,0,0,1],[-34,-8,1,0]];
function rpDust(g,x,y,u,s){if(u<=0||u>=1)return;const r=(5+13*rpEO(u))*s,a=RPGA*.75*(1-u);g.globalAlpha=a;const c=rpGlowC('#f2e8d6');g.drawImage(c,x-r*1.7-8*u*s,y-r*.8-4*u,r*2.2,r*1.4);g.drawImage(c,x-r*.5+8*u*s,y-r*.8-5*u,r*2.2,r*1.4)}
/* ascension to tier 4 or 5 (k 0..1 over about 1.4 s): a pillar of light falls from the sky, three rune rings converge on the
   trembling tower, a radiant flash and shockwave burst it into shards, and the new form swells out of the light with rays and stars */
function rpAscend(g,type,tier,skin,from,k,t,o){const A=RPASC[tier],L=RPLAY[type][tier],Lf=RPLAY[type][from],top=L.top,ph=o.ph||0,oo={aim:o.aim,ph:o.ph,fire:0,over:0},kf=.5,hc=-top*.45;
 g.save();RPGA=1;g.globalAlpha=1;g.lineJoin='round';g.lineCap='round';g.globalCompositeOperation='source-over';
 /* ground: the old sigil (tier 4 to 5) fades, the new one grows out of the shockwave */
 if(from>=4&&k<kf+.1)rpAscGround(g,from,t,ph,1-rpSeg(k,kf-.1,kf+.1));
 {const u=rpSeg(k,kf-.02,kf+.28);if(u>0)rpAscGround(g,tier,t,ph,Math.min(1,u*1.6),u<1?.6+.4*rpEB(u):1)}
 /* pad and pips */
 if(k<kf+.14)rpPut(g,rpPadT(from));if(k>=kf){g.globalAlpha=rpSeg(k,kf,kf+.12);rpPut(g,rpPadT(tier));g.globalAlpha=1}
 {const n=k<kf?from:tier,pk=rpSeg(k,kf+.12,kf+.32);g.save();g.translate(0,RPPIPY);const sc=k>=kf&&pk<1?.6+.4*rpEB(pk):1;g.scale(sc,sc);rpPut(g,rpPipS(n));g.restore();
  if(k>=kf&&pk<1){g.globalCompositeOperation='lighter';rpGlow(g,0,RPPIPY,30,18,A.glow,1-pk);g.globalCompositeOperation='source-over';g.globalAlpha=1}}
 /* the pillar of light from the sky (soft outer beam behind the tower) */
 const pin=rpSeg(k,0,.16),pout=1-rpSeg(k,.58,.86),pb=-700+(10+700)*rpEO(pin);
 g.globalCompositeOperation='lighter';
 if(pin>0&&pout>0){const w=(30+10*Math.sin(t*30))*(.6+.4*pin);rpGlow(g,0,(pb-700)/2,w*1.6,(pb+700)/2+40,A.glow,.45*pout);rpGlow(g,0,pb,70,28,A.glow,.7*pin*pout);
  g.globalCompositeOperation='source-over';g.globalAlpha=.55*pout;g.drawImage(rpGlowC(tier>=5?'#fffbe8':'#e6d2ff'),-w*.9,-700,w*1.8,pb+700+30)}
 g.globalCompositeOperation='source-over';g.globalAlpha=1;
 /* the old tower trembles and fills with light */
 if(k<kf){const ch=rpSeg(k,.12,kf),j=ch*ch*2.2;g.save();g.translate(Math.sin(t*71)*j,-ch*4+Math.cos(t*53)*j*.5);RPGA=1;rpTowerParts(g,type,from,skin,t,oo,1);
  g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,ch*1.1);rpPut(g,rpBody(type,from,skin));g.restore();RPGA=1;g.globalAlpha=1;g.globalCompositeOperation='source-over'}
 /* rays and the new form */
 if(k>=kf){const u=rpSeg(k,kf,kf+.2),pu=rpSeg(k,kf+.2,.92),ra=Math.min(1,rpSeg(k,kf,kf+.05))*(1-rpSeg(k,kf+.12,.9));
  if(ra>0){g.save();g.globalCompositeOperation='lighter';g.translate(0,hc);g.rotate(t*.7);const rs=(.55+.35*rpEO(u))*(top/120);g.scale(rs,rs);g.globalAlpha=ra*.85;rpPut(g,rpRaysS());g.restore();g.save();g.globalCompositeOperation='lighter';rpGlow(g,0,hc,80,top*.6,A.glow,ra*.6);g.restore();g.globalAlpha=1}
  let sx=1,sy=1;if(pu>0){const a=Math.pow(1-pu,1.5),w=Math.sin(pu*Math.PI*2.5);sy=1-.12*w*a;sx=1+.08*w*a}const sc=u<1?.72+.28*rpEB(u):1;
  g.save();g.scale(sx*sc,sy*sc);RPGA=1;rpTowerParts(g,type,tier,skin,t,oo,1);const wf=1-rpSeg(k,kf,kf+.3);if(wf>0){g.globalCompositeOperation='lighter';g.globalAlpha=wf;rpPut(g,rpBody(type,tier,skin))}g.restore();RPGA=1;g.globalAlpha=1;g.globalCompositeOperation='source-over'}
 g.globalCompositeOperation='lighter';
 /* white core of the pillar, in front */
 if(pin>0&&pout>0){const w=10+4*Math.sin(t*40);rpGlow(g,0,(pb-700)/2,w,(pb+700)/2+20,'#ffffff',.55*pout*(k<kf?1:.5))}
 /* three rune rings converge on the tower */
 for(let j=0;j<3;j++){const u=rpSeg(k,.06+j*.05,.44+j*.02),fa=1-rpSeg(k,kf-.04,kf+.02);if(u<=0||fa<=0)continue;const R=(132-104*rpEIO(u))/100,y=[4,hc,-top*.85][j];
  g.save();g.translate(0,y);g.scale(R,R*RPSQ);g.rotate(t*(j%2?1.7:-1.4)+j);g.globalAlpha=Math.min(1,u*2.5)*fa*.95;rpPut(g,rpSigilS(tier));g.restore()}
 /* the flash */
 const fl=k<kf?Math.pow(rpSeg(k,kf-.14,kf),2):1-rpSeg(k,kf,kf+.28);
 if(fl>0){rpGlow(g,0,hc,110*fl+30,top*.9,A.glow,.85*fl);rpGlow(g,0,hc,60,top*.6,'#ffffff',fl)}
 /* shockwaves on the ground */
 for(let j=0;j<2;j++){const u=rpSeg(k,kf+j*.07,kf+.36+j*.07);if(u<=0||u>=1)continue;const R=36+(120+j*24)*rpEO(u);g.globalCompositeOperation='source-over';g.globalAlpha=1-u;g.beginPath();g.ellipse(0,10,R,R*RPSQ,0,0,TAU);
  g.lineWidth=8*(1-u)+2;g.strokeStyle=RPTO;g.stroke();g.lineWidth=6*(1-u)+1.4;g.strokeStyle=j?A.a:A.g;g.stroke();g.lineWidth=1.4;g.strokeStyle='#ffffff';g.stroke();g.globalCompositeOperation='lighter'}
 /* shards burst out of the old shell */
 {const u=rpSeg(k,kf,kf+.4);if(u>0&&u<1){g.globalCompositeOperation='source-over';for(let i=0;i<14;i++){const a=i/14*TAU+rpR(i)*.4,v=(60+70*rpR(i+3))*(.6+.4*(i%2)),x=Math.cos(a)*v*u,y=hc+Math.sin(a)*v*u*.8-40*u+150*u*u*rpR(i+5),sz=(4.4+3.6*rpR(i+9))*(1-u*.5);
   g.globalAlpha=1-u*u;g.globalCompositeOperation='lighter';rpGlow(g,x,y,sz*4,sz*4,A.glow,(1-u)*.9);g.globalCompositeOperation='source-over';g.globalAlpha=1-u*u;g.save();g.translate(x,y);g.rotate(u*8*(i%2?1:-1)+i);rpGemArt(g,0,0,sz,i%3?A:RPASC[5]);g.restore()}g.globalCompositeOperation='lighter'}}
 /* stars */
 {const u=rpSeg(k,kf+.04,.97);if(u>0&&u<1){const st=rpStarS().c;for(let i=0;i<10;i++){const q=u*2.2+i/10,v=q%1,x=(rpR(i*5+Math.floor(q))-.5)*120,y=hc+(rpR(i*3+Math.floor(q)+1)-.5)*top*.95,z=(5+8*rpR(i))*Math.sin(Math.PI*v)*(1-u*.5);if(z>.5){g.globalAlpha=1;g.drawImage(st,x-z,y-z,z*2,z*2)}}}}
 g.restore();RPGA=1}
function rpTowerBuild(g,type,tier,skin,k,t,o){o=o||{};t=t||0;if(!RPPAL[type])return;tier=Math.max(1,Math.min(5,tier|0||1));if(!RPPAL[type][skin])skin='base';
 if(!(k<1)){rpTowerDraw(g,type,tier,skin,t,o);return}k=Math.max(0,k);
 const from=o.from>=1&&o.from<tier?o.from|0:0,L=RPLAY[type][tier],top=L.top,G='#ffd45a',tc=RPTW[type].col,oo={aim:o.aim,ph:o.ph,fire:0,over:0};
 if(from&&tier>=4){rpAscend(g,type,tier,skin,from,k,t,o);return}
 g.save();RPGA=1;g.globalAlpha=1;g.lineJoin='round';g.lineCap='round';g.globalCompositeOperation='source-over';
 if(tier>=4)rpAscGround(g,tier,t,o.ph||0,rpSeg(k,.6,.95));
 rpPut(g,rpPadT(from||tier));
 /* rune circle on the pad and a column of light */
 const rc=rpSeg(k,0,.16),rf=1-rpSeg(k,from?.7:.8,.97),pil=rpSeg(k,.04,.22)*rf;
 if(rc>0&&rf>0){g.save();const sc=(.4+.6*rpEB(rc))*.44;g.save();g.scale(sc,sc*RPSQ);g.rotate(t*1.3);g.globalAlpha=Math.min(1,rc*1.5)*rf;rpPut(g,rpSpr('brc',-106,-106,212,212,rpBRingArt));g.restore();
  g.globalCompositeOperation='lighter';rpGlow(g,0,1,50*sc/.44,22*sc/.44,G,(.3+.15*Math.sin(t*9))*rc*rf);g.restore();g.globalAlpha=1}
 /* tier pips (a new one pops in) */
 {const n=from?(k<.62?from:tier):(k<.82?0:tier),pk=from?rpSeg(k,.62,.82):rpSeg(k,.82,.97);
  if(n){g.save();g.translate(0,RPPIPY);const sc=pk<1&&(!from||k>=.62)?(from?.75+.25*rpEB(pk):rpEB(pk)):1;g.scale(sc,sc);rpPut(g,rpPipS(n));g.restore();
   if(pk>0&&pk<1){g.globalCompositeOperation='lighter';rpGlow(g,(n-1)/2*10,RPPIPY,16,16,'#fff6c8',1-pk);g.globalCompositeOperation='source-over';g.globalAlpha=1}}}
 if(pil>0){g.globalCompositeOperation='lighter';rpGlow(g,0,-top*.42,30+12*pil,top*.85,G,.32*pil);rpGlow(g,0,-top*.3,12,top*.6,'#ffffff',.22*pil);g.globalCompositeOperation='source-over';g.globalAlpha=1}
 let sx=1,sy=1;
 if(!from){
  /* falling stones and planks that bounce and stack, then are drawn into the rising tower */
  for(let i=0;i<RPDROP.length;i++){const [x,y,kd,st]=RPDROP[i],t0=.02+i*.04,u=rpSeg(k,t0,t0+.16),ab=rpSeg(k,.4+i*.025,.52+i*.025);if(u<=0||ab>=1)continue;
   const yy=y-st*7-(1-rpBnc(u))*140;g.save();g.translate(x*(1-ab*.7),yy-ab*(14+i*2));g.rotate((1-u)*(i%2?2.4:-2.4)+(kd?(i%3-1)*.25:0));const sc=1-ab*ab;g.scale(sc,sc);g.globalAlpha=1-ab*ab;rpPut(g,rpChunkS(kd));g.restore();
   if(ab>0){g.globalCompositeOperation='lighter';rpGlow(g,x*(1-ab*.7),yy-ab*(14+i*2),10,10,G,Math.sin(Math.PI*ab));g.globalCompositeOperation='source-over'}
   rpDust(g,x,y+3,rpSeg(k,t0+.16*.364,t0+.16*.364+.16),.8);g.globalAlpha=1}
  /* scaffold (back) */
  const sg=rpSeg(k,.08,.34),sd=rpSeg(k,.66,.84),H=Math.round(top*.78);
  if(sg>0&&sd<1){g.globalAlpha=1-sd;rpPutBelow(g,rpScafS(H,0),20-rpEO(sg)*(H+34),0,sd*sd*24);g.globalAlpha=1}
  /* the tower is revealed bottom-up while it rises, then pops with a squash and stretch */
  const e0=rpSeg(k,.2,.8),e=e0*e0*(3-2*e0),ry=28-e*(top+50),pu=rpSeg(k,.8,.97);
  if(pu>0){const a=Math.pow(1-pu,1.5),w=Math.sin(pu*Math.PI*2.5);sy=1-.17*w*a;sx=1+.11*w*a}else sy=.95+.05*e;
  if(e>0){g.save();if(e<1){g.beginPath();g.rect(-110,ry,220,160);g.clip()}g.translate(0,(1-e)*16);g.scale(sx,sy);oo.ign=rpSeg(k,.55,.92);rpTowerParts(g,type,tier,skin,t,oo,1);g.restore();RPGA=1;g.globalAlpha=1}
  if(e>0&&e<1){g.globalCompositeOperation='lighter';const ew=42+6*Math.sin(t*24);rpGlow(g,0,ry,ew+22,14,tc,.95);rpGlow(g,0,ry,ew,6,'#ffffff',1);g.globalAlpha=1;g.fillStyle='#fff6c8';g.fillRect(-ew*.85,ry-1.2,ew*1.7,2.4);
   for(let i=0;i<7;i++){const q=t*2.6+i/7,u=q%1,n=Math.floor(q),dx=(rpR(i*7+n)-.5)*2;rpGlow(g,dx*(26+u*34),ry-u*22+u*u*34,3.6,3.6,i%2?G:'#ffffff',(1-u)*1.3)}
   g.globalCompositeOperation='source-over';g.globalAlpha=1}
  /* scaffold (front) */
  if(sg>0&&sd<1){g.globalAlpha=1-sd;rpPutBelow(g,rpScafS(H,1),20-rpEO(sg)*(H+34),0,sd*sd*24);g.globalAlpha=1}
  rpDust(g,0,10,rpSeg(k,.8,.96),2.2);g.globalAlpha=1}
 else{
  /* upgrade: the old tier glows, shrinks and fades under a burst of light while the new tier drops in from above */
  const ch=rpSeg(k,0,.34),of=rpSeg(k,.3,.56);
  if(of<1){g.save();const e1=rpEIO(of);g.scale(1-.1*e1,1-.24*e1);RPGA=1-of*of;rpTowerParts(g,type,from,skin,t,oo,1);g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,(.1+.75*ch)*(1-of));rpPut(g,rpBody(type,from,skin));g.restore();RPGA=1;g.globalAlpha=1}
  const du=rpSeg(k,.3,.62),pu=rpSeg(k,.62,.95);
  if(pu>0){const a=Math.pow(1-pu,1.5),w=Math.sin(pu*Math.PI*2.5);sy=1-.2*w*a;sx=1+.13*w*a}else{sy=1+.08*du;sx=1-.04*du}
  if(du>0){g.save();g.translate(0,-(1-du*du)*72);g.scale(sx,sy);RPGA=Math.min(1,rpSeg(k,.3,.42));oo.ign=1;rpTowerParts(g,type,tier,skin,t,oo,1);g.restore();RPGA=1;g.globalAlpha=1}
  const rb=rpSeg(k,.62,.97);
  if(rb>0&&rb<1)for(let j=0;j<2;j++){const u=Math.min(1,rb*(1+j*.5));if(u>=1)continue;const R=34+(70+j*26)*rpEO(u);g.globalAlpha=(1-u);g.beginPath();g.ellipse(0,6,R,R*RPSQ,0,0,TAU);g.lineWidth=7*(1-u)+2;g.strokeStyle=RPTO;g.stroke();g.lineWidth=5*(1-u)+1.4;g.strokeStyle=G;g.stroke();g.lineWidth=1.2;g.strokeStyle='#fff6c8';g.stroke()}
  g.globalAlpha=1;rpDust(g,-30,10,rpSeg(k,.62,.86),1.3);rpDust(g,30,12,rpSeg(k,.62,.88),1.3);g.globalAlpha=1}
 /* the flash (gold for a build, white-gold for an upgrade) and a spray of sparkles */
 const k0=from?.46:.8,fl=k<k0?rpSeg(k,k0-(from?.22:.1),k0):1-rpSeg(k,k0,from?.75:.97),sp=rpSeg(k,from?.62:.8,.97);
 g.globalCompositeOperation='lighter';
 if(fl>0){rpGlow(g,0,-top*.45,72+24*fl,top*.78,G,.75*fl*fl);rpGlow(g,0,-top*.45,36,top*.42,'#ffffff',(from?1:.8)*fl*fl*fl)}
 if(sp>0&&sp<1){for(let i=0;i<12;i++){const a=i/12*TAU+.26,d=(16+62*rpEO(sp))*(.65+rpR(i+tier)*.55);rpGlow(g,Math.cos(a)*d,-top*.48+Math.sin(a)*d*.75+sp*sp*28,4.2,4.2,i%3?'#fff0a8':tc,(1-sp)*1.3)}}
 if(!from){const rb=rpSeg(k,.8,.97);if(rb>0&&rb<1){const R=32+64*rpEO(rb);g.globalCompositeOperation='source-over';g.globalAlpha=1-rb;g.beginPath();g.ellipse(0,6,R,R*RPSQ,0,0,TAU);g.lineWidth=6*(1-rb)+2;g.strokeStyle=RPTO;g.stroke();g.lineWidth=4*(1-rb)+1.2;g.strokeStyle=G;g.stroke()}}
 g.restore();RPGA=1}
/* bake everything a tower needs up front (all turret directions for a ballista), e.g. when the mode opens, so nothing is painted mid-fight */
function rpTowerWarm(type,tier,skin){if(!RPPAL[type])return;skin=RPPAL[type][skin]?skin:'base';const tr0=Math.max(1,Math.min(5,tier|0||1));tier=Math.max(1,Math.min(5,tier|0||1));
 if(tier>=4){rpPadT(tier);rpBody(type,tier,skin);rpSigilS(tier);rpPipS(tier);if(tier===4){for(let v=0;v<4;v++)rpGlyphS(4,v);for(const h of [0,1]){rpRingS(4,44,h);rpRingS(4,34,h)}}else{rpStarS();rpHaloS();rpWingS();rpPrismS();for(const h of [0,1])rpRingS(5,46,h)}rpRaysS()}const P=rpPalT(type,skin,tr0),L=RPLAY[type][tr0];rpPadS();rpBack(type,tier,skin);rpBody(type,tier,skin);rpGlowLayer(type,tier,skin);
 if(type==='ballista')for(let d=0;d<RPFX.dirs;d++)rpBallTopS(tier,skin,d);
 else if(type==='brazier'){rpSpr('bel|'+skin,-21,-19,44,22,q=>rpBellowsArt(q,P));rpSpr('bz|'+tier+'|'+skin+'|f',-64,-(L.top+20),128,L.top+66,q=>rpBrazFront(q,tier,P));for(let f=0;f<8;f++)rpSpr('fl|'+skin+'|'+f,-26,-74,52,82,q=>rpFlameArt(q,P.fl,f))}
 else if(type==='frost'){rpShardS(skin,0,P.cr[0],P);rpShardS(skin,1,P.cr[1]||P.cr[0],P)}
 else{rpSpr('bf|'+tier+'|'+skin,-66,-(L.top+18),132,L.top,q=>rpBellFront(q,tier,P));rpBellS(P,skin,L.bw,L.bh);if(L.minis)rpBellS(P,skin,16,15)}}
function rpTowerIcon(type,tier,skin,size){size=Math.max(16,size|0||96);const key='ic|'+type+'|'+tier+'|'+skin+'|'+size;let s=RPSPR.get(key);if(s)return s.c;
 const c=document.createElement('canvas');c.width=c.height=size;const top=rpTowerTop(type,tier)+6,h=top+46,k=Math.min(size*.95/h,size*.95/134),g=c.getContext('2d');g.translate(size/2,size/2+(top-46)/2*k);g.scale(k,k);
 try{rpTowerDraw(g,type,tier,skin,.42,{aim:.55,ph:.3})}catch(e){console.error(e)}RPSPR.set(key,{c});return c}

/* ---------- projectiles and effects ---------- */
function rpBoltArt(g,P){g.beginPath();g.moveTo(-40,0);g.lineTo(-6,0);g.lineWidth=5.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3;g.strokeStyle=P.shaft;g.stroke();g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.moveTo(-38,-.8);g.lineTo(-8,-.8);g.stroke();
 for(const k of [-1,1]){g.beginPath();g.moveTo(-42,k*6);g.lineTo(-33,0);g.lineTo(-28,0);g.lineTo(-36,k*6);g.closePath();g.fillStyle=P.bolt;g.fill();g.lineWidth=1.3;g.strokeStyle=RPTO;g.stroke()}
 for(const x of [-24,-16])rpRiv(g,x,0,1.4,P.bolt);
 g.beginPath();g.moveTo(6,0);g.lineTo(-8,-6);g.lineTo(-4,0);g.lineTo(-8,6);g.closePath();g.fillStyle=rpHG(g,-8,6,P.boltL,P.bolt,P.bolt);g.fill();g.lineWidth=1.8;g.strokeStyle=RPTO;g.stroke();
 g.fillStyle='#ffffff';g.beginPath();g.arc(-3,0,1.4,0,TAU);g.fill();
 if(P.sun){g.strokeStyle=P.boltL;g.lineWidth=1.5;for(let i=0;i<8;i++){const a=i*Math.PI/4;g.beginPath();g.moveTo(-1+Math.cos(a)*8,Math.sin(a)*8);g.lineTo(-1+Math.cos(a)*11.5,Math.sin(a)*11.5);g.stroke()}}}
function rpBolt(g,x,y,ang,skin,tier){const sk=RPPAL.ballista[skin]?skin:'base',P=RPPAL.ballista[sk],T=tier|0,sc=T>=5?1.5:T>=4?1.36:1.2;g.save();g.translate(x,y);g.rotate(ang);
 if(T>=4){const A=RPASC[T];g.globalCompositeOperation='lighter';g.globalAlpha=.9;g.drawImage(rpSpr('btr|t'+T,-130,-10,134,20,q=>{const r=q.createLinearGradient(-130,0,0,0);r.addColorStop(0,rpA(A.glow,0));r.addColorStop(.7,rpA(A.glow,.6));r.addColorStop(1,rpA(A.aL,1));q.fillStyle=r;q.beginPath();q.moveTo(-130,0);q.lineTo(0,-7);q.lineTo(0,7);q.closePath();q.fill()}).c,-130,-10,134,20);
  for(let i=0;i<4;i++){const d=24+i*22,w=Math.sin(x*.06+y*.04+i*1.7)*6;rpGlow(g,-d,w,7-i,7-i,i%2?A.g:A.aL,1-i*.2)}rpGlow(g,0,0,34,26,A.glow,.75);
  if(T>=5){g.globalAlpha=1;const z=12+3*Math.sin(x*.1);g.save();g.translate(4,0);g.rotate(x*.03);g.drawImage(rpStarS().c,-z,-z,z*2,z*2);g.restore()}g.globalCompositeOperation='source-over';g.globalAlpha=1}
 g.scale(sc,sc);g.globalCompositeOperation='lighter';
 g.globalAlpha=.8;g.drawImage(rpSpr('btr|'+sk,-84,-7,90,14,q=>{const r=q.createLinearGradient(-84,0,0,0);r.addColorStop(0,rpA(P.bolt,0));r.addColorStop(1,rpA(P.bolt,.95));q.fillStyle=r;q.beginPath();q.moveTo(-84,0);q.lineTo(0,-4);q.lineTo(0,4);q.closePath();q.fill()}).c,-84,-7,90,14);
 rpGlow(g,-1,0,18,18,P.bolt,.9);g.globalCompositeOperation='source-over';g.globalAlpha=1;rpPut(g,rpSpr('bo|'+sk,-46,-13,60,26,q=>rpBoltArt(q,P)));
 g.globalCompositeOperation='lighter';rpGlow(g,0,0,8,8,'#ffffff',.9);g.restore()}
function rpEmberArt(g,P){g.beginPath();g.arc(0,0,10,0,TAU);const r=g.createRadialGradient(-3,-3,0,0,0,10);r.addColorStop(0,P.fl[3]);r.addColorStop(.4,P.fl[2]);r.addColorStop(.8,P.fl[1]);r.addColorStop(1,P.fl[0]);g.fillStyle=r;g.fill();rpOut(g,2.2);
 g.fillStyle=rpA(P.coalD,.55);for(const [a,b,c] of [[3.6,2.4,2],[-2.6,4.6,1.6],[4.6,-2.4,1.4],[-4.8,-.6,1.2]]){g.beginPath();g.arc(a,b,c,0,TAU);g.fill()}
 g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.ellipse(-3.6,-4,2.6,1.6,-.6,0,TAU);g.fill()}
function rpEmber(g,x,y,t,skin,tier){const T=tier|0;if(T>=4){const A=RPASC[T],sc=T>=5?1.3:1.15;g.save();g.globalCompositeOperation='lighter';rpGlow(g,x,y,52,52,A.glow,.6);
  const st=T>=5?rpStarS().c:null;for(let i=0;i<4;i++){const a=t*5+i/4*TAU,px=x+Math.cos(a)*20,py=y+Math.sin(a)*10;if(st){const z=6+2*Math.sin(t*9+i);g.globalAlpha=1;g.drawImage(st,px-z,py-z,z*2,z*2)}else rpGlow(g,px,py,6,6,i%2?A.g:A.aL,1)}
  g.restore();g.save();g.translate(x,y);g.scale(sc,sc);rpEmber(g,0,0,t,skin);if(T>=5){g.globalCompositeOperation='lighter';rpGlow(g,0,-4,14,18,'#ffffff',.8)}else{g.globalCompositeOperation='source-over';rpFlame(g,0,2,.36,t*1.3,.6,RPFLM,'myth')}g.restore();return}
 const sk=RPPAL.brazier[skin]?skin:'base',P=RPPAL.brazier[sk];g.save();g.globalCompositeOperation='lighter';rpGlow(g,x,y,34,34,P.glow,.8);
 g.globalCompositeOperation='source-over';g.globalAlpha=1;for(let i=0;i<4;i++){const k=(t*2.2+i/4)%1,r=(1-k)*3.2+.8;g.fillStyle=i%2?P.fl[2]:P.fl[1];g.beginPath();g.arc(x+Math.sin(i*2.1+t*4)*5,y-k*22+2,r,0,TAU);g.fill()}
 rpFlame(g,x,y+3,.66,t,.2,P.fl,sk);rpPut(g,rpSpr('em|'+sk,-13,-13,26,26,q=>rpEmberArt(q,P)),x,y);
 g.globalCompositeOperation='lighter';rpGlow(g,x-2,y-2,9,9,'#ffffff',.7);g.restore()}
function rpPuff(g,x,y,R,cols){const o=[[0,0,1],[-.55,.15,.7],[.55,.12,.72],[-.25,-.45,.66],[.3,-.42,.62]];g.fillStyle=RPTO;for(const [a,b,c] of o){g.beginPath();g.arc(x+a*R,y+b*R,c*R+2.2,0,TAU);g.fill()}
 for(let j=0;j<cols.length;j++){g.fillStyle=cols[j];const sh=1-j*.26;for(const [a,b,c] of o){g.beginPath();g.arc(x+a*R*sh-j*R*.06,y+b*R*sh-j*R*.08,c*R*sh,0,TAU);g.fill()}}}
function rpBurst(g,x,y,k,r,skin,tier){if(!(k>=0&&k<=1))return;if(tier>=4)rpTierRing(g,x,y,k,r*1.05,tier,1);rpBurst0(g,x,y,k,r,skin);if(tier>=5)rpTierStar(g,x,y-r*.2,k,r)}
function rpBurst0(g,x,y,k,r,skin){const sk=RPPAL.brazier[skin]?skin:'base',P=RPPAL.brazier[sk],e=1-Math.pow(1-k,3),sq=RPFX.sq,f=1-k;g.save();g.lineCap='round';
 g.fillStyle='rgba(24,8,8,'+(.32*f).toFixed(3)+')';g.beginPath();g.ellipse(x,y,r*.62,r*.62*sq,0,0,TAU);g.fill();
 g.globalCompositeOperation='lighter';rpGlow(g,x,y-r*.15,r*(.7+.5*e),r*(.6+.4*e),P.glow,f*f*1.2);g.globalCompositeOperation='source-over';
 const R=r*(.2+.82*e);g.globalAlpha=Math.min(1,f*1.4);g.lineWidth=3+7*f;g.strokeStyle=P.fl[1];g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.stroke();g.lineWidth=1+2*f;g.strokeStyle=P.fl[3];g.beginPath();g.ellipse(x,y,R*.94,R*.94*sq,0,0,TAU);g.stroke();
 if(k>.3){const s=(k-.3)/.7;g.globalAlpha=.55*(1-s);for(let i=0;i<4;i++){const a=i*1.7+.5;g.fillStyle=i%2?'#4a4058':'#5e5470';g.beginPath();g.arc(x+Math.cos(a)*r*.3*(1+s),y-r*(.15+.45*s)-i*3,r*(.14+.12*s),0,TAU);g.fill()}}
 g.globalAlpha=1;if(k<.55){const kk=k/.55;rpPuff(g,x,y-r*.16-kk*r*.12,r*.3*(.7+.5*Math.sin(Math.PI*Math.min(1,kk*1.6)))*(1-kk*.55),[P.fl[0],P.fl[1],P.fl[2],P.fl[3]])}
 for(let i=0;i<9;i++){const a=i/9*TAU+.4,d=r*(.12+.8*e)*(.75+rpR(i)*.35),lift=Math.sin(Math.PI*Math.min(1,k*1.25))*r*.5*(.5+rpR(i+3)),rr=(2.4+rpR(i+7)*3)*f+1;if(k>.95||k<.14)break;const px=x+Math.cos(a)*d,py=y+Math.sin(a)*d*sq-lift;
  g.fillStyle=RPTO;g.beginPath();g.arc(px,py,rr+1.4,0,TAU);g.fill();g.fillStyle=i%2?P.fl[2]:P.fl[1];g.beginPath();g.arc(px,py,rr,0,TAU);g.fill()}
 g.globalCompositeOperation='lighter';if(k<.3)rpGlow(g,x,y-r*.2,r*.5,r*.5,'#ffffff',(1-k/.3)*.9);g.restore()}
/* tier 4-5 additions to the impact effects: a turning sigil ring that expands, and (tier 5) a burst of rays and stars */
function rpTierRing(g,x,y,k,r,tier,boom){const e=1-Math.pow(1-k,2.2),f=1-k,R=r*(.3+.8*e)/100,sq=RPFX.sq;g.save();g.translate(x,y);g.scale(R,R*sq);g.rotate(k*(boom?2.4:-1.8));g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,f*1.6)*.9;rpPut(g,rpSigilS(tier));g.restore()}
function rpTierStar(g,x,y,k,r){if(k>.6)return;const f=1-k/.6;g.save();g.globalCompositeOperation='lighter';g.translate(x,y);g.save();g.rotate(k*2);const s=r/110*(.5+.8*k);g.scale(s,s);g.globalAlpha=f*.85;rpPut(g,rpRaysS());g.restore();
 const st=rpStarS().c;g.globalAlpha=1;for(let i=0;i<6;i++){const a=i/6*TAU+.3,d=r*(.2+.7*k),z=(6+5*f)*f;if(z>.5)g.drawImage(st,Math.cos(a)*d-z,Math.sin(a)*d*.6-z-k*14,z*2,z*2)}g.restore()}
function rpFlakeArt(g,col){g.lineCap='round';for(const [lw,c] of [[3.6,RPTO],[1.8,col]]){g.lineWidth=lw;g.strokeStyle=c;g.beginPath();for(let i=0;i<6;i++){const a=i*Math.PI/3,ca=Math.cos(a),sa=Math.sin(a);g.moveTo(0,0);g.lineTo(ca*9,sa*9);
  const bx=ca*5.4,by=sa*5.4;for(const s of [-1,1]){const b=a+s*.8;g.moveTo(bx,by);g.lineTo(bx+Math.cos(b)*3.2,by+Math.sin(b)*3.2)}}g.stroke()}
 g.fillStyle='#ffffff';g.beginPath();g.arc(0,0,1.8,0,TAU);g.fill()}
const rpFlakeS=col=>rpSpr('fk|'+col,-11,-11,22,22,q=>rpFlakeArt(q,col));
function rpFrostPulse(g,x,y,k,r,skin,tier){if(!(k>=0&&k<=1))return;if(tier>=4)rpTierRing(g,x,y,k,r*.92,tier,0);rpFrostPulse0(g,x,y,k,r,skin);if(tier>=5)rpTierStar(g,x,y,k,r*.8)}
function rpFrostPulse0(g,x,y,k,r,skin){const sk=RPPAL.frost[skin]?skin:'base',P=RPPAL.frost[sk],e=1-Math.pow(1-k,2.4),f=1-k,sq=RPFX.sq,R=r*(.15+.85*e);g.save();
 g.globalCompositeOperation='lighter';rpGlow(g,x,y,R*1.1,R*sq*1.2,P.glow,f*.5);g.globalCompositeOperation='source-over';
 g.globalAlpha=f*.35;g.fillStyle=P.ring;g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.fill();
 g.globalAlpha=Math.min(1,f*1.5);g.lineWidth=6*f+3;g.strokeStyle=rpA(P.cr[0].d,.75);g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.stroke();g.lineWidth=3*f+1.4;g.strokeStyle=P.ring;g.stroke();
 g.lineWidth=1.2;g.strokeStyle='#ffffff';g.beginPath();g.ellipse(x,y-1,R*.97,R*.97*sq,0,Math.PI*1.05,Math.PI*1.95);g.stroke();
 const n=10;for(let i=0;i<n;i++){const a=i/n*TAU+k*.8,px=x+Math.cos(a)*R,py=y+Math.sin(a)*R*sq-6*Math.sin(Math.PI*k),s=(.65+.5*f)*(i%2?.75:1);g.globalAlpha=Math.min(1,f*1.8);
  g.save();g.translate(px,py);g.rotate(k*3+i);g.scale(s,s);rpPut(g,rpFlakeS(i%2&&P.cr[1]?P.cr[1].m:P.ring));g.restore()}
 g.restore()}
function rpZap(g,x1,y1,x2,y2,t,col,a){const sd=Math.floor(t*22),amp=Math.min(16,Math.hypot(x2-x1,y2-y1)*.14),op=g.globalCompositeOperation;rpZigPath(g,x1,y1,x2,y2,sd,amp);
 g.globalCompositeOperation='lighter';g.globalAlpha=.35*a*RPGA;g.lineWidth=10;g.strokeStyle=col;g.stroke();g.globalCompositeOperation='source-over';g.globalAlpha=.95*a*RPGA;g.lineWidth=3.4;g.stroke();g.lineWidth=1.4;g.strokeStyle='#ffffff';g.stroke();
 g.globalCompositeOperation=op;g.globalAlpha=RPGA}
function rpBolt2(g,x1,y1,x2,y2,t,skin,tier){if(tier>=4){const A=RPASC[tier];g.save();g.lineJoin='round';g.lineCap='round';rpZap(g,x1+3,y1-2,x2+2,y2-3,t+.31,A.glow,.75);g.globalCompositeOperation='lighter';rpGlow(g,x2,y2,40,40,A.glow,.8);
  if(tier>=5){const z=18+5*Math.sin(t*20);g.globalAlpha=1;g.drawImage(rpStarS().c,x2-z,y2-z,z*2,z*2);g.save();g.translate(x2,y2);g.rotate(t*3);g.scale(.32,.32);g.globalAlpha=.7;rpPut(g,rpRaysS());g.restore()}g.restore()}rpBolt20(g,x1,y1,x2,y2,t,skin)}
function rpBolt20(g,x1,y1,x2,y2,t,skin){const col=RPLC[skin]||RPLC.base;g.save();g.lineJoin='round';g.lineCap='round';
 rpZap(g,x1,y1,x2,y2,t,col,1);const sd=Math.floor(t*22);if(rpR(sd)>.35){const f=.35+rpR(sd+1)*.3,mx=x1+(x2-x1)*f,my=y1+(y2-y1)*f,a=Math.atan2(y2-y1,x2-x1)+(rpR(sd+2)-.5)*1.8,l=Math.hypot(x2-x1,y2-y1)*.25;rpZap(g,mx,my,mx+Math.cos(a)*l,my+Math.sin(a)*l,t+.5,col,.6)}
 g.globalCompositeOperation='lighter';rpGlow(g,x1,y1,14,14,col,.8);rpGlow(g,x2,y2,24,24,col,1);rpGlow(g,x2,y2,9,9,'#ffffff',1);g.restore()}
function rpChill(g,x,y,t){g.save();g.globalCompositeOperation='lighter';rpGlow(g,x,y-2,24,16,'#62d4ff',.45);g.globalCompositeOperation='source-over';
 for(let i=0;i<3;i++){const a=t*1.6+i/3*TAU,px=x+Math.cos(a)*18,py=y+Math.sin(a)*8-6+Math.sin(t*3+i)*2,s=.62+.14*Math.sin(t*4+i);
  g.globalAlpha=Math.sin(a)<0?.7:1;g.save();g.translate(px,py);g.rotate(t+i);g.scale(s,s);rpPut(g,rpFlakeS('#c6f6ff'));g.restore()}
 g.globalAlpha=1;for(let i=0;i<3;i++){const tw=Math.sin(t*5+i*2.3);if(tw<0)continue;const px=x+(i-1)*11,py=y-16+((i*7)%5),r=2+tw*3.4;g.fillStyle='#ffffff';g.fillRect(px-r,py-.7,r*2,1.4);g.fillRect(px-.7,py-r,1.4,r*2)}
 g.restore()}
function rpSlowArt(g){const C='#a6ecff';g.lineCap='round';for(const [r,lw] of [[96,3.6],[82,2.2],[56,1.8]]){g.beginPath();g.arc(0,0,r,0,TAU);g.lineWidth=lw+3.4;g.strokeStyle='rgba(20,60,140,.55)';g.stroke();g.lineWidth=lw;g.strokeStyle=C;g.stroke()}
 g.strokeStyle='#effcff';g.lineWidth=2.4;for(let i=0;i<12;i++){const a=i/12*TAU,cx=Math.cos(a)*89,cy=Math.sin(a)*89;g.save();g.translate(cx,cy);g.rotate(a+Math.PI/2);g.beginPath();
  const v=i%4;if(v===0){g.moveTo(0,-4.5);g.lineTo(0,4.5);g.moveTo(-3,-1.5);g.lineTo(3,1.5)}else if(v===1){g.moveTo(-3,-4);g.lineTo(0,4);g.lineTo(3,-4)}else if(v===2){g.moveTo(-3,4);g.lineTo(-3,-4);g.lineTo(3,0);g.lineTo(-3,4)}else{g.moveTo(0,-4.5);g.lineTo(0,4.5);g.moveTo(0,-1);g.lineTo(3,-4);g.moveTo(0,1);g.lineTo(-3,4)}g.stroke();g.restore()}
 g.strokeStyle=C;g.lineWidth=2;g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU-Math.PI/2,b=a+2*TAU/6;g.moveTo(Math.cos(a)*56,Math.sin(a)*56);g.lineTo(Math.cos(b)*56,Math.sin(b)*56)}g.stroke();
 for(let i=0;i<6;i++){const a=i/6*TAU;g.beginPath();g.arc(Math.cos(a)*69,Math.sin(a)*69,3.4,0,TAU);g.fillStyle='#effcff';g.fill();g.lineWidth=1.2;g.strokeStyle='rgba(20,60,140,.6)';g.stroke()}}
function rpSlowField(g,x,y,r,t,k){k=k==null?1:Math.max(0,Math.min(1,k));if(k<=0)return;const s=r/100,sq=RPFX.sq,sp=rpSpr('slowf',-102,-102,204,204,rpSlowArt);g.save();
 g.globalAlpha=.28*k;g.fillStyle='#2a6ad8';g.beginPath();g.ellipse(x,y,r*.98,r*.98*sq,0,0,TAU);g.fill();
 g.globalCompositeOperation='lighter';rpGlow(g,x,y,r*1.1,r*1.1*sq,'#3aa8ff',.5*k);g.globalCompositeOperation='source-over';
 g.translate(x,y);g.scale(s,s*sq);g.save();g.rotate(t*.35);g.globalAlpha=k*(.8+.15*Math.sin(t*3));rpPut(g,sp);g.restore();
 g.rotate(-t*.5);g.scale(.55,.55);g.globalAlpha=k*.6;rpPut(g,sp);g.restore();
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const p=(t*.5+i/6)%1,a=i*2.4+1.3,d=r*(.2+.6*rpR(i));rpGlow(g,x+Math.cos(a)*d,y+Math.sin(a)*d*sq-p*34,4,4,'#c6f6ff',k*(1-p)*1.3)}g.restore()}
function rpOvercharge(g,x,y,t,a,h){a=a==null?1:a;h=h||100;if(a<=.01)return;g.save();g.lineJoin='round';g.lineCap='round';const p=.5+.5*Math.sin(t*6);g.globalCompositeOperation='lighter';
 rpGlow(g,x,y-h*.48,70+8*p,h*.78+8*p,'#ff9a1e',(.6+.2*p)*a);rpGlow(g,x,y-h*.45,34,h*.55,'#ffe08a',(.35+.15*p)*a);rpGlow(g,x,y+6,86,36,'#ffb52e',.55*a);
 for(let i=0;i<4;i++){const k=(t*.55+i/4)%1,xx=x+(i-1.5)*22;g.globalAlpha=a*Math.sin(Math.PI*k)*.6;g.drawImage(rpGlowC('#ffc94a'),xx-5,y-h*(.15+k*.9)-26,10,52)}
 g.globalCompositeOperation='source-over';g.globalAlpha=a*(.7+.3*p);g.lineWidth=5;g.strokeStyle='rgba(18,8,31,.6)';g.beginPath();g.ellipse(x,y+8,60+p*4,(60+p*4)*RPSQ,0,0,TAU);g.stroke();g.lineWidth=2.6;g.strokeStyle='#ffd45a';g.stroke();
 for(let i=0;i<3;i++){const sd=Math.floor(t*14)+i*7,a0=rpR(sd)*TAU,a1=a0+.6+rpR(sd+1)*.8,yy=y-h*(.2+.6*rpR(sd+2)),rx=40+rpR(sd+3)*10;
  rpZap(g,x+Math.cos(a0)*rx,yy+Math.sin(a0)*rx*.5,x+Math.cos(a1)*rx,yy+Math.sin(a1)*rx*.5-10,t+i,'#ffc94a',a)}
 g.globalCompositeOperation='lighter';for(let i=0;i<7;i++){const k=(t*.7+i/7)%1,ang=i*2.2;rpGlow(g,x+Math.cos(ang)*(34+8*Math.sin(i))*(1-k*.3),y-k*h*1.05+Math.sin(ang)*10,4,4,'#fff0a8',a*(1-k)*1.3)}
 g.restore()}
