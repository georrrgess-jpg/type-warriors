/* ---------- crate opening: scenes and sound ---------- */
const CTM={O:[2.5,2.5,2.7,3.1,4.9,9.4],D:[1.6,1.6,1.7,2.0,3.0,7.2]},CCY=640;
const nf=n=>440*2**((n-69)/12);

/* --- sound building blocks (all take an output node o and a start time t) --- */
let _nb=null;
const axOn=()=>!!(ac&&sg&&ST.svol>0);
function cNoiseBuf(){if(_nb&&_nb.sampleRate===ac.sampleRate)return _nb;const n=ac.sampleRate*2,b=ac.createBuffer(1,n,ac.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;return _nb=b}
function cTone(o,t,f,d,ty,v,x){x=x||{};try{const os=ac.createOscillator(),g=ac.createGain(),a=x.a||.01;os.type=ty||'sine';os.frequency.setValueAtTime(f,t);if(x.f2)os.frequency.exponentialRampToValueAtTime(x.f2,t+d);if(x.det)os.detune.value=x.det;
 g.gain.setValueAtTime(.0001,t);
 if(x.swell){g.gain.exponentialRampToValueAtTime(v,t+d-.03);g.gain.linearRampToValueAtTime(.0001,t+d)}
 else{g.gain.linearRampToValueAtTime(v,t+a);if(x.hold)g.gain.setValueAtTime(v,t+Math.max(a,d-(x.r||.3)));g.gain.exponentialRampToValueAtTime(.0001,t+d)}
 let n=os;if(x.lp){const b=ac.createBiquadFilter();b.type='lowpass';b.frequency.setValueAtTime(x.lp,t);if(x.lp2)b.frequency.exponentialRampToValueAtTime(x.lp2,t+d);b.Q.value=x.q||.8;os.connect(b);n=b}
 n.connect(g);g.connect(o);os.start(t);os.stop(t+d+.05)}catch(e){}}
function cNoise(o,t,d,v,x){x=x||{};try{const s=ac.createBufferSource();s.buffer=cNoiseBuf();s.loop=true;const f=ac.createBiquadFilter();f.type=x.type||'lowpass';f.frequency.setValueAtTime(x.f1||2000,t);f.frequency.exponentialRampToValueAtTime(Math.max(40,x.f2||x.f1||2000),t+d);f.Q.value=x.q||.7;const g=ac.createGain();
 if(x.rev){g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+d);g.gain.setValueAtTime(.0001,t+d+.01)}
 else{g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+(x.a||.02));g.gain.exponentialRampToValueAtTime(.0001,t+d)}
 s.connect(f);f.connect(g);g.connect(o);s.start(t,Math.random());s.stop(t+d+.05)}catch(e){}}
function cBell(o,t,f,v,d){d=d||1.6;for(const m of[[1,1,1],[2.76,.45,.6],[5.4,.22,.35],[8.93,.1,.2]])cTone(o,t,f*m[0],d*m[2],'sine',v*m[1],{a:.004})}
function cKick(o,t,v,f0,f1,d){cTone(o,t,f0,d,'sine',v,{f2:f1,a:.004});cNoise(o,t,.05,v*.5,{f1:2500,f2:600})}
function cPad(o,t,fs,d,v,lp){for(const f of fs)for(const det of[-7,7])cTone(o,t,f,d,'sawtooth',v,{det,a:.5,hold:1,r:1,lp,lp2:lp*.5})}
function cBrass(o,t,f,d,v){cTone(o,t,f,d,'sawtooth',v,{a:.03,lp:3200,lp2:1100,hold:1,r:.08});cTone(o,t,f*2,d,'square',v*.22,{a:.03,lp:1800,hold:1,r:.08});cTone(o,t,f*.5,d,'sawtooth',v*.5,{a:.03,lp:900,hold:1,r:.08})}
function cTimp(o,t,n,gap,v){for(let i=0;i<n;i++)cTone(o,t+i*gap,95-i*1.5,.28,'sine',v*(.6+.4*i/n),{f2:55,a:.003})}
const cSpark=(o,t,n,span,base,v)=>{for(let i=0;i<n;i++)cBell(o,t+Math.random()*span,nf(base+(Math.random()*14|0)),v*(1-i/n*.6),1.1)};

function altFinale(o,t,tier){const k=Math.floor(Math.random()*6),v=1+tier*.22,nf=n=>440*Math.pow(2,(n-69)/12);
 if(k===0){cBrass(o,t+.05,nf(60+tier*2),.9,.06*v);cBrass(o,t+.05,nf(67+tier*2),.9,.04*v);cTimp(o,t+.05,3,.07,.14*v)}
 else if(k===1){for(let i=0;i<3;i++){const tt=t+.04+i*.11;cNoise(o,tt,.22,.16*v,{type:'bandpass',f1:5200,f2:3400,q:2});cTone(o,tt,1800+i*400,.18,'square',.05*v,{f2:900,a:.002})}}
 else if(k===2){for(let i=0;i<10+tier*2;i++){const tt=t+.03+i*.045;cTone(o,tt,2200+Math.random()*1800,.07,'square',.035*v,{a:.002});cNoise(o,tt,.04,.05*v,{type:'highpass',f1:6000,f2:6000})}}
 else if(k===3){cTone(o,t+.02,180,.7,'sawtooth',.07*v,{f2:2600,a:.01,lp:3000,lp2:3000});cTone(o,t+.02,190,.7,'square',.03*v,{f2:2700,a:.01});cSpark(o,t+.5,6+tier*2,.8,90,.03)}
 else if(k===4){cTimp(o,t,8+tier,.05,.2*v);cKick(o,t+.55,.7,90,30,.9);cNoise(o,t+.55,.6,.14,{type:'lowpass',f1:3000,f2:200})}
 else{[62,66,69].forEach((n,i)=>{cBrass(o,t+.05+i*.16,nf(n+tier),.5+(i===2?.5:0),.06*v);cBrass(o,t+.05+i*.16,nf(n+tier-5),.5,.035*v)})}}
/* heavenly mythic music: a soft choir ("aah" pads with vibrato), harp arpeggios, a rising bell melody and a final golden chord */
function cChoir(o,t,f,d,v){for(const [m,vv,det] of[[1,1,-6],[1,1,6],[2,.4,0],[.5,.5,0]]){try{const os=ac.createOscillator(),lf=ac.createOscillator(),lg=ac.createGain(),g=ac.createGain(),b=ac.createBiquadFilter(),b2=ac.createBiquadFilter();os.type='triangle';os.frequency.value=f*m;os.detune.value=det;lf.frequency.value=5.2+Math.random();lg.gain.value=f*m*.006;lf.connect(lg);lg.connect(os.frequency);b.type='bandpass';b.frequency.value=700;b.Q.value=2.2;b2.type='peaking';b2.frequency.value=1150;b2.gain.value=7;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v*vv,t+Math.min(1.2,d*.4));g.gain.setValueAtTime(v*vv,t+Math.max(.2,d-1.1));g.gain.exponentialRampToValueAtTime(.0001,t+d);os.connect(b);b.connect(b2);b2.connect(g);g.connect(o);os.start(t);lf.start(t);os.stop(t+d+.05);lf.stop(t+d+.05)}catch(e){}}}
function cHarp(o,t,f,v){cTone(o,t,f,1.6,'triangle',v,{a:.004,lp:3600,lp2:900});cTone(o,t,f*2,.9,'sine',v*.35,{a:.003})}
function heavenSong(o,t,full){const nf=n=>440*Math.pow(2,(n-69)/12);
 const prog=[[50,57,62,66,69],[45,57,61,64,69],[47,59,62,66,71],[43,55,62,67,71],[50,57,62,66,74]];
 const n=full?prog.length:2;
 for(let i=0;i<n;i++){const tt=t+.15+i*(full?1.75:1.5),d=i===n-1?(full?3.4:2.6):2.1;for(const m of prog[i])cChoir(o,tt,nf(m+12),d,.026);cTone(o,tt,nf(prog[i][0]-12),d,'sine',.12,{a:.5,hold:1,r:.9})}
 const sc=[74,76,78,81,83,86,85,83,81,86,90];if(full){let tt=t+.5;sc.forEach((m,i)=>{cBell(o,tt,nf(m),.07,2.2);tt+=i<8?.2:.5})}
 else{[78,81,86].forEach((m,i)=>cBell(o,t+.4+i*.25,nf(m),.075,2))}
 const arp=[62,66,69,74,78,81,86,90];const ra=full?3:1;for(let k=0;k<ra;k++)arp.forEach((m,i)=>cHarp(o,t+.05+k*1.75+i*.085,nf(m),.06));
 if(full){for(let i=0;i<30;i++)cBell(o,t+1.2+Math.random()*6,nf(86+Math.random()*12|0),.03,1.4);cChoir(o,t+7.1,nf(74),2.4,.03);cChoir(o,t+7.1,nf(86),2.4,.025);cChoir(o,t+7.1,nf(90),2.4,.02);cBell(o,t+7.1,nf(98),.06,3)}}
function revealSfx(o,t,tier,full){
 cKick(o,t,.4+tier*.07,110,32,.9+tier*.12);cNoise(o,t,.8+tier*.35,.2+tier*.03,{f1:5000+tier*1200,f2:180,q:.6});cNoise(o,t,.1,.25,{type:'bandpass',f1:1400,f2:700});
 if(tier<4)altFinale(o,t,tier);
 if(tier===2)cPad(o,t,[nf(48),nf(55),nf(60),nf(64)],1.6,.03,1800);
 else if(tier===3){cPad(o,t,[nf(38),nf(50),nf(57),nf(62),nf(66)],2.2,.035,2200);cSpark(o,t+.5,10,1.4,90,.035)}
 else if(tier===4){
  cPad(o,t,[nf(45),nf(52),nf(57),nf(61),nf(64),nf(69)],3.8,.04,2600);cTone(o,t,nf(33),1.8,'sine',.22,{a:.02});
  const pent=[0,2,4,7,9];for(let i=0;i<18;i++)cBell(o,t+.05+i*.045,nf(57+pent[i%5]+12*((i/5)|0)),.085,1.5);
  if(full){
   let tt=t+.9;for(const [n,d] of[[69,.22],[69,.22],[73,.22],[76,.55],[74,.22],[76,.22],[81,1.5]]){cBrass(o,tt,nf(n),d+.15,.06);cBrass(o,tt,nf(n-5),d+.15,.035);cBell(o,tt,nf(n+12),.05,1.2);tt+=d}
   cTimp(o,t+.9,10,.07,.16);cNoise(o,t+.9,2.6,.13,{type:'highpass',f1:5500,f2:5600});cPad(o,t+2.4,[nf(57),nf(61),nf(64),nf(69)],2,.03,2400);cSpark(o,t+1.4,16,2,88,.035)
  }else{cBrass(o,t+.35,nf(81),1.2,.07);cBrass(o,t+.35,nf(76),1.2,.04);cNoise(o,t+.3,1.8,.12,{type:'highpass',f1:5500,f2:5600})}
 }else{
  cPad(o,t,[nf(38),nf(45),nf(50),nf(54),nf(57),nf(62),nf(66),nf(69)],9,.02,3000);cTone(o,t,nf(26),2.4,'sine',.28,{a:.02});
  cKick(o,t+.12,.5,58,28,1.7);
  for(let i=0;i<14;i++)cBell(o,t+.02+i*.028,nf(84+i),.09,1.2);
  const pent=[0,2,4,7,9];for(let i=0;i<30;i++)cBell(o,t+.3+i*.055,nf(62+pent[i%5]+12*(((i/5)|0)%3)),.07,1.5);
  cPad(o,t+.4,[nf(62),nf(69),nf(74)],5,.03,1500);
  heavenSong(o,t+.35,full);if(full){cTimp(o,t+1.0,6,.14,.1);cNoise(o,t+1.3,3.2,.1,{type:'highpass',f1:5000,f2:5100});cSpark(o,t+1.6,44,7,84,.03)}else{cNoise(o,t+.35,2.4,.12,{type:'highpass',f1:5000,f2:5100});cSpark(o,t+.8,14,1.6,86,.03)}
 }}

function crateAudio(q){if(!axOn())return;const tier=q.tier,O=q.O,o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;const T=ac.currentTime+.06;
 cNoise(o,T,.55,.14,{type:'bandpass',f1:2400,f2:260,q:.8});
 for(const d of[[.55,.42],[.8,.22],[.95,.1]]){cKick(o,T+d[0],d[1],95,42,.4);cNoise(o,T+d[0],.12,d[1]*.3,{f1:900,f2:200})}
 cNoise(o,T+.8,.6,.1,{type:'bandpass',f1:500,f2:2400,q:2});
 cBell(o,T+1.9,1568,.09,.9);cTone(o,T+1.9,2400,.05,'square',.06);cNoise(o,T+1.9,.06,.12,{type:'highpass',f1:4000,f2:4100});
 const ch=O-1.9;
 if(tier>=1)cNoise(o,T+1.9,ch,.05+tier*.03,{rev:1,f1:120+tier*40,f2:260+tier*90,q:1});
 if(tier>=3){
  cNoise(o,T+1.9,ch,.13,{rev:1,type:'bandpass',f1:300,f2:tier>=5?6500:4500,q:1.4});
  cTone(o,T+1.9,160,ch,'sine',.1,{f2:tier>=5?3600:2200,swell:1});
  cTone(o,T+1.9,55,ch,'sawtooth',.06,{swell:1,lp:200,lp2:2600});
  const i0=.85,i1=tier>=5?.2:.32;let tb=T+2.2,i=0;while(tb<T+O-.15){const u=(tb-T-1.9)/ch,v=.16+.34*u;cKick(o,tb,v,80,40,.28);cKick(o,tb+.13,v*.55,70,38,.2);tb+=i0+(i1-i0)*Math.min(1,u*1.05);if(++i>60)break}
  const nsp=tier>=5?46:16;for(let j=0;j<nsp;j++){const u=Math.pow(Math.random(),.6),tt=T+1.9+u*(ch-.3);cNoise(o,tt,.04,.1,{type:'highpass',f1:5000,f2:6000});if(tier>=5&&j%2)cTone(o,tt,1000+Math.random()*3000,.03,'square',.035)}
  cNoise(o,T+O-.75,.7,.24,{rev:1,type:'highpass',f1:800,f2:9000});
 }
 if(tier>=5){cTone(o,T+1.9,41,ch,'sine',.22,{swell:1});[62,66,69,74,78].forEach((m,ix)=>cChoir(o,T+O-4.4+ix*.45,440*Math.pow(2,(m-69)/12),3.6-ix*.45+ix*.45,.016));for(const f of[220,329.6,440])for(const det of[-8,8])cTone(o,T+2.5,f,ch-.6,'sawtooth',.03,{swell:1,det,lp:500,lp2:2400});cNoise(o,T+2.2,ch-.6,.08,{rev:1,type:'bandpass',f1:900,f2:2400,q:6})}
 q.aT=T}
function crateFade(q,tc){try{if(q&&q.aud){q.aud.gain.cancelScheduledValues(ac.currentTime);q.aud.gain.setTargetAtTime(0,ac.currentTime,tc||.06)}}catch(e){}}
function crateEnd(){const q=S.cr2;if(q&&q.t>=q.O)crateFade(q,.35);else crateFade(q,.06);S.cr2=null}

/* --- scene --- */
function fxAdd(q,p){if(q.fx.length<1300)q.fx.push(p)}
function cBurst(q,x,y,c,n,v,l){for(let i=0;i<n;i++){const a=Math.random()*TAU,s=v*(.3+Math.random());fxAdd(q,{x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-80,l:l*(.6+Math.random()*.6),g:700,dr:.5,s:2+Math.random()*4,c,ty:'dot'})}}
function fxStep(q,dt){for(const p of q.fx){p.l-=dt;if(p.sp){p.a+=p.ra*dt;p.r-=p.rv*dt;p.x=W/2+Math.cos(p.a)*p.r;p.y=CCY-40+Math.sin(p.a)*p.r*.7;if(p.r<10)p.l=0}else{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=(p.g||0)*dt;if(p.dr){const k=Math.max(0,1-p.dr*dt);p.vx*=k;p.vy*=k}}}
 q.fx=q.fx.filter(p=>p.l>0)}
function openFx(q){const tier=q.tier,col=q.it.col,cx=W/2;q.fl=1;q.shk=[14,14,16,20,34,48][tier];
 const n=[70,90,120,190,340,540][tier];
 for(let i=0;i<n;i++){const a=Math.random()*TAU,v=200+Math.random()*(tier>=5?1200:tier>=4?950:640);const c=tier>=5?hsx(Math.random()*360,100,65):tier>=4?hsx(38+Math.random()*22,100,60+Math.random()*20):col;fxAdd(q,{x:cx,y:CCY-40,vx:Math.cos(a)*v,vy:Math.sin(a)*v-260,l:1+Math.random()*(tier>=4?2.4:1),g:520,dr:.6,s:2+Math.random()*(tier>=4?7:4),c,ty:Math.random()<.3?'star':'dot'})}
 const nr=[1,1,2,3,4,7][tier];for(let i=0;i<nr;i++)q.rings.push({t0:q.t+i*(tier>=5?.11:.09),x:cx,y:CCY-40,c:tier>=5?null:tier>=4?'#ffd76a':col,max:[500,500,600,760,1000,1500][tier]*(1+i*.12),dur:[1,1,1.2,1.4,1.7,2.2][tier],i})}
function cStar(c,x,y,r,rot){c.beginPath();for(let i=0;i<8;i++){const a=rot+i*Math.PI/4,rr=i%2?r*.28:r;c.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}c.closePath();c.fill()}

function premRoll(){const isM=Math.random()<.10,want=isM?5:4,pool=[];
 for(const id in WP)if(!WP[id].hw&&RKM[WP[id].r]===want&&(isSpecial(id)?pathOpen(WP[id].p):true))pool.push({kind:'w',id,own:!!P.own[id]});
 for(const id in AR)if(!AR[id].pr&&!AR[id].hw&&RKM[AR[id].r]===want)pool.push({kind:'a',id,own:!!P.ownA[id]});
 const nw=pool.filter(x=>!x.own),use=nw.length&&Math.random()<.88?nw:pool;return use[Math.random()*use.length|0]}
/* one crate roll: spends the crate, picks the item, and applies pity, duplicate conversion and stats */
function crateRoll(k){const cn=CN[k];if(!(P[cn]>=1))return null;P[cn]--;let kind=k,id;
 if(k==='p'||k==='h'){const r=k==='h'?hwRoll():premRoll();kind=r.kind;id=r.id}
 const T=kind==='a'?AR:WP,o=kind==='a'?'ownA':'own';
 if(k!=='p'&&k!=='h'){
 const ks=Object.keys(T).filter(x=>!T[x].pr&&!T[x].hw).filter(x=>k==='a'||(k==='w'?!isSpecial(x):isSpecial(x)&&pathOpen(WP[x].p)));const wt=x=>T[x].w*(k==='w'?({Rare:1.4,Epic:2.2}[T[x].r]||1):1)*(P[o][x]&&RKM[T[x].r]>=4?.3:1);let r=Math.random()*ks.reduce((n,x)=>n+wt(x),0);id=ks[0];for(const x of ks){r-=wt(x);if(r<=0){id=x;break}}
 let pf=0;if(P.pity+1>=PITY()&&RKM[T[id].r]<3){const el=ks.filter(x=>RKM[T[x].r]>=3);if(el.length){const nw=el.filter(x=>!P[o][x]),pool=nw.length?nw:el;let r2=Math.random()*pool.reduce((n,x)=>n+wt(x),0);id=pool[0];for(const x of pool){r2-=wt(x);if(r2<=0){id=x;break}}pf=1}}
 window.__pf=pf}else window.__pf=0;
 const pf=window.__pf,it=T[id],dup=!!P[o][id];if(k==='h'){hwPityStep(it);stat('hcr',1,'add')}else if(k!=='p')P.pity=RKM[it.r]>=3?0:P.pity+1;else stat('pcr',1,'add');stat('crates',1,'add');if(RKM[it.r]>=3)stat('epic',RKM[it.r],'max');P[o][id]=1;if(dup){P.xp+=40;P.gold+=GOLDDUP[it.r]}save();
 return{kind,id,it,dup,pf,T,o}}
function crateStart(k){const r0=crateRoll(k);if(!r0)return;const{kind,id,it,dup,pf}=r0;
 const img=document.createElement('canvas');img.width=img.height=260;art(img,kind==='a'?'a':'w',id,0);
 const tier=RKM[it.r]||0,stars=[];for(let i=0;i<140;i++)stars.push([Math.random()*W,Math.random()*H,Math.random()*2+.4,Math.random()*TAU]);
 S.mode='crate';S.cr2={k:kind,ck:k,id,it,dup,pf,t:-.06,img,fired:{},done:false,tier,O:CTM.O[tier],E:CTM.O[tier]+CTM.D[tier],fx:[],rings:[],fl:0,shk:0,bolts:[],bt:0,acc:0,acc2:0,acc3:0,last:performance.now(),stars};
 show('<button class="sm" id="sk">Skip</button>','clear');$('sk').onclick=crateSkip;crateAudio(S.cr2)}
function crateSkip(){const q=S.cr2;if(!q||q.done)return;
 if(q.t<q.O-.05){crateFade(q,.05);if(axOn()){const o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;revealSfx(o,ac.currentTime+.05,q.tier,false)}q.t=q.O-.05;q.skipped=1}
 else if(q.t<q.E)q.t=q.E}
function crateUpdate(dt){const q=S.cr2;if(!q)return;const now=performance.now();dt=Math.min(.1,Math.max(0,(now-q.last)/1000));q.last=now;q.t+=dt;const t=q.t,tier=q.tier,O=q.O;
 q.shk=Math.max(0,q.shk-dt*46);q.fl=Math.max(0,q.fl-dt*(tier>=5?.75:tier>=4?1.1:2));
 if(!q.fired.rv&&q.aud&&!q.skipped&&t>=O-1.3){q.fired.rv=1;revealSfx(q.aud,q.aT+O,tier,true)}
 if(t>.55&&!q.fired.land){q.fired.land=1;q.shk=Math.max(q.shk,tier>=4?12:6)}
 if(t>1.9&&!q.fired.click){q.fired.click=1;cBurst(q,W/2+40,GY-150,'#ffe08a',18,340,.6)}
 if(t>1.9&&t<O&&!q.skipped){const ch=sstep(1.9,O,t),cx=W/2,hot=tier>=3;
  q.acc+=[0,0,10,34,80,150][tier]*ch*dt+([0,0,0,0,0,0][tier]);
  while(q.acc>=1){q.acc--;const a=Math.random()*TAU,r=380+Math.random()*420,l=.8+Math.random()*.6;const c=tier>=5?hsx(a*57.3+S.t*120,100,68):tier>=4?hsx(38+Math.random()*20,100,68):tier>=3?'#d68cff':'#8ad4ff';fxAdd(q,{sp:1,a,r,rv:r/l,ra:(2+Math.random()*2.4)*(Math.random()<.5?1:-1),l,x:cx,y:CCY,s:2+Math.random()*3,c,ty:Math.random()<.25?'star':'dot',lp:1})}
  if(tier>=4){q.acc2+=(22+ch*40)*dt;while(q.acc2>=1){q.acc2--;const x=cx+(Math.random()-.5)*260,c=tier>=5?hsx(Math.random()*360,100,70):'#ffd76a';fxAdd(q,{x,y:CCY-100,vx:(Math.random()-.5)*120,vy:-160-Math.random()*300,l:.7+Math.random()*.6,g:60,s:2+Math.random()*3,c,ty:'dot'})}}
  if(tier>=5){q.acc3+=(30+ch*160)*dt;while(q.acc3>=1){q.acc3--;const a=Math.random()*TAU,r=700+Math.random()*300,l=.32,v=r/l;fxAdd(q,{x:cx+Math.cos(a)*r,y:CCY+Math.sin(a)*r*.75,vx:-Math.cos(a)*v,vy:-Math.sin(a)*v*.75,l,s:2,c:hsx(a*57.3+S.t*90,100,80),ty:'line'})}
   if(t>2.6&&S.t-q.bt>.08){q.bt=S.t;q.bolts=[];const n=2+Math.floor(ch*6);for(let i=0;i<n;i++){let a=Math.random()*TAU,x=cx,y=CCY-40;const pts=[[x,y]],len=300+Math.random()*750;for(let d=0;d<len;d+=42){a+=(Math.random()-.5)*.95;x+=Math.cos(a)*42;y+=Math.sin(a)*34;pts.push([x,y])}q.bolts.push(pts)}}}
  if(hot&&Math.random()<dt*(2+ch*8)*(tier-2))q.shk=Math.max(q.shk,3+ch*8)}
 if(t>=O&&!q.fired.open){q.fired.open=1;q.bolts=[];openFx(q)}
 if(t>=O){const post=t-O;
  if(tier>=3){q.acc+=(tier>=5?70:tier>=4?45:16)*dt;while(q.acc>=1){q.acc--;const a=Math.random()*TAU,rr=120+Math.random()*180,c=tier>=5?hsx(Math.random()*360,100,72):tier>=4?hsx(40+Math.random()*16,100,72):q.it.col;const u=sstep(O+.3,O+.3+(tier>=4?1.6:1.1),t),iy=lerp(CCY-100,330,u);fxAdd(q,{x:W/2+Math.cos(a)*rr,y:iy+Math.sin(a)*rr*.8,vx:Math.cos(a)*30,vy:-40-Math.random()*60,l:.8+Math.random()*.9,g:-20,s:2+Math.random()*4,c,ty:Math.random()<.5?'star':'dot'})}}
  if(tier>=5&&post<8){q.acc2+=70*dt;while(q.acc2>=1){q.acc2--;fxAdd(q,{x:Math.random()*W,y:-10,vx:(Math.random()-.5)*60,vy:60+Math.random()*120,l:5,g:50,s:3+Math.random()*4,c:hsx(Math.random()*360,100,65),ty:Math.random()<.3?'star':'dot'})}}}
 fxStep(q,dt);
 if(t>=q.E&&!q.done){q.done=true;crateResult()}}
function crateResult(){const q=S.cr2,it=q.it,tier=q.tier;if(tier<4&&axOn()){const o=ac.createGain();o.gain.value=1;o.connect(sg);altFinale(o,ac.currentTime+.02,0)}
 const more=P[CN[q.ck||q.k]]>0,cls=q.ck==='h'&&tier>=4?'hwtxt':tier>=5?'mythtxt':tier>=4?'legtxt':'';
 show(`<div style="margin-top:auto"></div><h2 class="${cls}" style="${cls?'':`color:${it.col};text-shadow:0 0 30px ${it.col}`}">${it.r}: ${it.n}</h2><p>${it.d}${q.k!=='a'&&it.p!=='knight'?` &middot; ${PATHS[it.p].n} path`:''}</p><p>${q.dup?`Duplicate, converted into 40 XP and ${GOLDDUP[it.r]} gold.`:'<b style="color:var(--gold)">New!</b> Added to your armory.'}</p><div class="row"><button id="a">Equip</button>${more?'<button class="sm" id="m">Open another</button>':''}<button class="sm" id="b">Back</button></div>`,'clear');
 achCheck();$('a').onclick=()=>{if(q.k==='a'){P.armor=q.id;save()}else setWeapon(q.id);crateEnd();title()};if(more)$('m').onclick=()=>{crateEnd();crateStart(q.ck||q.k)};$('b').onclick=()=>{crateEnd();title()}}

function drawCrateScene(){const q=S.cr2,t=q.t,c=ctx,cx=W/2,by=GY-30,tier=q.tier,O=q.O,col=q.it.col;
 const ch=sstep(1.9,O,t),post=Math.max(0,t-O),hot=tier>=4,my=tier>=5;
 const rb=off=>my?hsx(S.t*230+(off||0),100,65):hsx(44+Math.sin(S.t*2.4+(off||0)*.02)*9,100,60+Math.sin(S.t*3+(off||0)*.05)*8);
 const rainbow=hot?rb(0):col;
 let z=1;if(hot)z=1+ch*.045*(tier-3)+(t>=O?(my?.24:.13)*Math.exp(-post*3):0);
 c.save();c.translate(cx,CCY);c.scale(z,z);c.translate(-cx,-CCY);
 if(q.shk>0&&ST.shake)c.translate((Math.random()-.5)*q.shk,(Math.random()-.5)*q.shk);
 /* backdrop */
 const dk=.55+(hot?ch*.3*(1-sstep(O,O+.35,t))+(t>=O?.12*Math.exp(-post*2):0):0);
 c.fillStyle='rgba(4,2,12,'+dk.toFixed(3)+')';c.fillRect(-160,-160,W+320,H+320);
 if(hot&&t<O+(my?7.5:3)){for(const s of q.stars){c.globalAlpha=Math.max(0,(.3+.7*Math.abs(Math.sin(S.t*1.5+s[3])))*Math.min(1,ch*2+(t>=O?1:0))*(t>O+(my?6:2)?1-(t-O-(my?6:2))/(my?1.5:1):1));c.fillStyle='#fff';c.fillRect(s[0],s[1],s[2],s[2])}c.globalAlpha=1}
 if(ch>0&&tier>=3){const hh=q.ck==='h',tc=my?rb(0):tier>=4?(hh?'#ff9a30':'#ffb020'):(hh?'#7affc8':'#a050ff');c.globalCompositeOperation='lighter';glow(c,cx,CCY-40,(300+ch*420)*(t>=O?1.2:1),tc+Math.round(Math.min(255,ch*(my?110:90))).toString(16).padStart(2,'0'));c.globalCompositeOperation='source-over'}
 /* chest */
 const drop=t<.8?1-sstep(0,.8,t):0,bounce=t>.55&&t<.9?Math.abs(Math.sin((t-.55)*Math.PI*3))*(.9-t)*40:0;
 const lev=hot?ch*(my?76:44)*(t<O?1:Math.max(0,1-post*3.5)):0;
 const by2=by-drop*520-lev;
 const open=sstep(O,O+.5,t),shk=t>1.9&&t<O?Math.sin(t*70)*(2+ch*(8+tier*4)):0,os=open>0?1+Math.sin(open*Math.PI)*.08:1;
 if(t>1.9){const p=Math.min(1,(t-1.9)/.6)*(open>0?1.6:1);c.globalCompositeOperation='lighter';glow(c,cx,by2-70,260*p+40,rainbow+'55');c.globalCompositeOperation='source-over'}
 if(open>0||(hot&&ch>0)){c.save();c.globalCompositeOperation='lighter';c.translate(cx,by2-100);const nrays=14,len=(hot?900:440)*Math.max(open,ch*.4);
  for(let layer=0;layer<(hot?2:1);layer++){c.save();c.rotate(S.t*(layer?-.25:.4));c.globalAlpha=(hot?.5:.55)*Math.min(1,open+(layer?0:ch*.3))*(layer?.7:1);for(let i=0;i<nrays;i++){c.rotate(TAU/nrays);const cc=my?hsx(i*(360/nrays)+S.t*80,100,66):i%2?rainbow:'#fff8c0';poly(c,[-16,-40,16,-40,0,-len],cc)}c.restore()}c.restore()}
 if(t>1.9&&t<O+.2&&tier>=2){const a=(ch*ch+(t>O?1:0)).toFixed(3),w=(60+ch*260)*(t>O?1.5:1);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=Math.min(1,a);c.shadowColor=rainbow;c.shadowBlur=30+ch*50;c.fillStyle=hot?'#fff':rainbow;c.fillRect(cx-w/2+shk,by2-70*2.1*.98-2,w,4+ch*(hot?9:4));c.restore()}
 chest(c,cx+shk,by2-bounce,2.1*os,open,q.ck||q.k,S.t);
 if(t>.8&&t<2.2){const u=t<1.5?sstep(.8,1.5,t):1,r=t<1.5?0:sstep(1.5,1.9,t)*Math.PI/2;const kx=lerp(cx-560,cx+2,u),ky=lerp(by-560,by-172,u)-Math.sin(u*Math.PI)*120;keyArt(c,kx,ky,lerp(-1.1,-.05,u)+r,1.9)}
 /* shockwave rings */
 for(const r of q.rings){const u=(t-r.t0)/r.dur;if(u<=0||u>=1)continue;const e=1-Math.pow(1-u,2.4);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=(1-u)*.9;c.strokeStyle=r.c||hsx(S.t*260+r.i*50,100,65);c.lineWidth=2+(1-u)*(tier>=5?22:14);c.shadowColor=c.strokeStyle;c.shadowBlur=24;c.beginPath();c.ellipse(r.x,r.y,e*r.max,e*r.max*.42,0,0,TAU);c.stroke();c.beginPath();c.arc(r.x,r.y,e*r.max*.75,0,TAU);c.globalAlpha*=.5;c.stroke();c.restore()}
 /* mythic lightning */
 if(q.bolts.length&&t<O){c.save();c.globalCompositeOperation='lighter';c.lineJoin='round';for(const b of q.bolts){c.beginPath();b.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.strokeStyle=rb(b[3]?b[3][0]:0)+'55';c.lineWidth=12;c.stroke();c.strokeStyle='#fff';c.lineWidth=2.5;c.stroke()}c.restore()}
 /* item */
 if(t>O+.25){const u=sstep(O+.3,O+.3+(hot?1.6:1.1),t),y=lerp(by-160,by-410,u)+Math.sin(S.t*2)*(u>.98?8:0),sc=lerp(.4,1.36,u);
  if(hot){try{art(q.img,q.k==='a'?'a':'w',q.id,S.t)}catch(e){}}
  c.save();c.translate(cx,y);c.scale(sc,sc);c.rotate(Math.sin(S.t*2)*.05);
  if(hot){c.save();c.globalCompositeOperation='lighter';for(let layer=0;layer<2;layer++){c.save();c.rotate(S.t*(layer?-.5:.35));c.globalAlpha=.35*u;for(let i=0;i<12;i++){c.rotate(TAU/12);poly(c,[-22,-120,22,-120,0,-(layer?380:520)],my?hsx(i*30+S.t*100,100,68):layer?'#fff4b8':'#ffcf4a')}c.restore()}c.restore()}
  c.globalCompositeOperation='lighter';glow(c,0,0,hot?300:220,rainbow+'88');c.globalCompositeOperation='source-over';
  c.strokeStyle=rainbow;c.lineWidth=5;c.shadowColor=rainbow;c.shadowBlur=24;c.beginPath();c.arc(0,0,150,0,TAU);c.stroke();
  if(hot){c.lineWidth=2.5;c.beginPath();c.arc(0,0,172+Math.sin(S.t*3)*6,0,TAU);c.stroke();if(my){c.save();c.lineWidth=5;c.strokeStyle='#fff6c0';c.shadowColor='#ffd76a';c.shadowBlur=26;c.globalAlpha=.9*u;c.beginPath();c.ellipse(0,-196+Math.sin(S.t*2)*4,92,22,0,0,TAU);c.stroke();c.restore();c.lineWidth=2;c.beginPath();c.ellipse(0,0,230,70,S.t*.6,0,TAU);c.stroke();c.beginPath();c.ellipse(0,0,230,70,-S.t*.6+1.2,0,TAU);c.stroke()}}
  c.shadowBlur=0;c.drawImage(q.img,-130,-130,260,260);
  if(hot){c.globalCompositeOperation='lighter';for(let i=0;i<(my?8:5);i++){const a=S.t*(my?1.4:1)+i*TAU/(my?8:5),rr=my?215:185;c.fillStyle=my?hsx(i*45+S.t*120,100,75):'#fff0a0';cStar(c,Math.cos(a)*rr,Math.sin(a)*rr*.62,10+Math.sin(S.t*6+i)*4,S.t*2+i)}}
  c.restore()}
 /* particles */
 c.save();c.globalCompositeOperation='lighter';for(const p of q.fx){const al=Math.max(0,Math.min(1,p.l*(p.lp?1.6:1.2)));c.globalAlpha=al;c.fillStyle=c.strokeStyle=p.c;
  if(p.ty==='star')cStar(c,p.x,p.y,p.s*2.2,p.l*3);else if(p.ty==='line'){c.lineWidth=p.s;c.beginPath();c.moveTo(p.x,p.y);c.lineTo(p.x-p.vx*.05,p.y-p.vy*.05);c.stroke()}else c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}c.restore();
 c.restore();
 /* letterbox and title */
 if(my){const bu=sstep(2.2,O-.6,t)*(1-sstep(O+1.4,O+2.6,t)),bar=78*bu;if(bar>.5){c.fillStyle='#000';c.fillRect(0,0,W,bar);c.fillRect(0,H-bar,W,bar)}}
 if(tier>=2&&post>0){const word=q.it.r.toUpperCase(),big=tier>=4,size=big?(my?138:112):(tier>=3?70:56),sp=big?24:10,start=my?1.0:big?.7:.5;
  c.save();c.font='400 '+size+'px "Pirata One",Georgia,serif';c.textAlign='center';c.textBaseline='middle';const ws=[...word].map(g=>c.measureText(g).width+sp),tot=ws.reduce((a,b)=>a+b,0);let x=cx-tot/2;const ty=big?96:96;
  for(let i=0;i<word.length;i++){const u=sstep(start+i*.09,start+i*.09+.35,post);if(u>0){const sc=1+(1-u)*2.4,fc=my?hsx(S.t*170+i*40,100,68):big?hsx(45,100,60+Math.sin(S.t*4+i)*9):col;c.save();c.translate(x+ws[i]/2,ty);c.scale(sc,sc);c.globalAlpha=u;c.shadowColor=fc;c.shadowBlur=32;c.lineWidth=big?9:5;c.strokeStyle='#000c';c.lineJoin='round';c.strokeText(word[i],0,0);c.fillStyle=fc;c.fillText(word[i],0,0);c.restore()}x+=ws[i]}
  c.restore()}
 /* flash */
 if(q.fl>0){c.fillStyle='rgba(255,255,255,'+Math.min(1,q.fl*.9).toFixed(3)+')';c.fillRect(0,0,W,H)}
 if(my&&post>0&&post<4.5){const a=(1-post/4.5)*.4;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=a;const g=c.createRadialGradient(cx,CCY-40,0,cx,CCY-40,1100);g.addColorStop(0,hsx(S.t*200,100,60));g.addColorStop(.5,hsx(S.t*200+120,100,50));g.addColorStop(1,hsx(S.t*200+240,100,40)+'00');c.fillStyle=g;c.fillRect(0,0,W,H);c.restore()}
}

/* open ten at once: rolls instantly, then shows every pull in a summary */
const CRN={w:'Weapon crate',a:'Armor crate',s:'Special crate',p:'Eclipse Chest',h:'Graveyard Crate'};
function crateBatch(k,n){n=Math.min(n,P[CN[k]]||0);if(n<1)return;const R=[];let xp=0,gd=0;
 for(let i=0;i<n;i++){const r=crateRoll(k);if(!r)break;if(r.dup){xp+=40;gd+=GOLDDUP[r.it.r]}R.push(r)}
 R.forEach(r=>{const img=document.createElement('canvas');img.width=img.height=200;try{art(img,r.kind==='a'?'a':'w',r.id,0);r.url=img.toDataURL()}catch(e){r.url=''}r.tier=RKM[r.it.r]||0});
 R.sort((a,b)=>b.tier-a.tier||(a.dup-b.dup));
 const nw=R.filter(r=>!r.dup).length,best=R[0],left=P[CN[k]]||0;S.mode='title';S.view='menu';
 show(`<h2>${R.length} ${CRN[k]}${R.length>1?'s':''} opened</h2><div class="cbs"><span><b>${nw}</b><small>new</small></span><span><b>${R.length-nw}</b><small>duplicates</small></span>${gd?`<span><b>+${gd}</b><small>gold</small></span><span><b>+${xp}</b><small>XP</small></span>`:''}<span style="--c:${best.it.col}"><b class="cbb">${best.it.r}</b><small>best pull</small></span></div>
 <div class="cbg">${R.map((r,q)=>`<div class="cbk${r.tier>=4?' hi':''}" style="--c:${r.it.col};--n:${q}"><img src="${r.url}" alt=""><b>${r.it.n}</b><em>${r.it.r}</em><i class="${r.dup?'dp':'nw'}">${r.dup?'Duplicate':'NEW'}</i></div>`).join('')}</div>
 <div class="row">${left>=10?`<button class="gd" id="m10">Open 10 more</button>`:''}${left>0&&left<10?`<button class="sm" id="m1">Open another</button>`:''}<button class="sm" id="b">Back to crates</button></div>`,'m top');
 save();achCheck();S.back=crateHub;$('b').onclick=crateHub;if($('m10'))$('m10').onclick=()=>crateBatch(k,10);if($('m1'))$('m1').onclick=()=>crateStart(k);
 jingle(best.tier>=4?'win':best.tier>=2?'boon':'wave');if(best.tier>=4)for(let q=0;q<3;q++)setTimeout(()=>beep(880+q*220,.12,'triangle',.5),q*140)}
