import asyncio,os
from playwright.async_api import async_playwright
COUNT="""(sel)=>new Promise(res=>{const c=document.querySelector(sel+' canvas[data-pc]');const g=c.getContext('2d');let d=0;const o=g.clearRect;g.clearRect=function(...a){d++;return o.apply(this,a)};
 let f=0;const st=()=>{f++;if(f<60)requestAnimationFrame(st);else{g.clearRect=o;res({draws:d,loops:LIVE.filter(L=>L.cv.matches&&L.cv.matches('#ptrg canvas[data-pc]')).length,on:c.closest('.ptc').classList.contains('on')})}};requestAnimationFrame(st)})"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        await E("()=>{RS_ASK=false;P.petSt=2;P.pets={ember:{b:300},bramble:{b:120},antler:{b:50},sol:{b:40},yeti:{b:10}};P.pet='ember';petNorm();PTX.sel='ember';petHall('Pets')}");await pg.wait_for_timeout(800)
        bad=0
        for pid in ['bramble','antler','sol','yeti','ember']:
            s=f'.ptc[data-p="{pid}"]'
            await pg.hover(s);await pg.wait_for_timeout(250);await pg.click(s);await pg.wait_for_timeout(120)
            r=await E(COUNT,s);ok=r['draws']<=26 and r['loops']==1 and r['on'];bad+=not ok;print('click',pid,r,'OK' if ok else 'BAD')
        # clicking the selected card again must not stack loops
        for i in range(3):await pg.click('.ptc[data-p="ember"]');await pg.wait_for_timeout(60)
        r=await E(COUNT,'.ptc[data-p="ember"]');ok=r['draws']<=26 and r['loops']==1;bad+=not ok;print('reclick x3',r,'OK' if ok else 'BAD')
        # the card that lost the selection is still once the mouse is away
        await pg.mouse.move(5,5);await pg.wait_for_timeout(200)
        r=await E(COUNT,'.ptc[data-p="yeti"]');ok=r['draws']==0;bad+=not ok;print('old card still',r,'OK' if ok else 'BAD')
        # hover greeting still works on an unselected card (one loop, every frame)
        await pg.hover('.ptc[data-p="bramble"]');await pg.wait_for_timeout(100)
        r=await E(COUNT,'.ptc[data-p="bramble"]');ok=45<=r['draws']<=61;bad+=not ok;print('hover greet',r,'OK' if ok else 'BAD')
        # the arrows in the detail panel change selection too
        await pg.mouse.move(5,5);await pg.click('.ptar[data-d="1"]');await pg.wait_for_timeout(150)
        r=await E("()=>[PTX.sel,LIVE.filter(L=>L.cv.matches&&L.cv.matches('#ptrg canvas[data-pc]')).length,petOwned(PTX.sel)?1:0]");ok=r[1]==r[2];bad+=not ok;print('arrow',r,'OK' if ok else 'BAD')
        await pg.screenshot(path='shots/petclick.png')
        # backdrop canvases only ever run their own painter
        r=await E("()=>LIVE.filter(L=>L.cv.classList&&L.cv.classList.contains('mybg')).every(L=>L.fn===L.cv._fn)");ok=r;bad+=not ok;print('mythic backdrop owns its canvas',r,'OK' if ok else 'BAD')
        print('bad',bad);print(er);await b.close()
asyncio.run(main())
