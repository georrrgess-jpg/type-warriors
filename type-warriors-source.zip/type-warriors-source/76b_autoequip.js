/* ---------- auto equip: picks the best owned weapon (for the current class) and the best armor ----------
   Each owned item is read from its numeric stats and, for anything the numbers do not cover, from its description text.
   Every weapon and armor pairing is then put through the same seeded test run (a 60-wave typing run that uses the
   game's own score, slow, shield, HP, fury, combo, crit and chain rules), and the pairing that earns the most wins.
   Rarity is the first rule: only the highest-rarity weapons and armor you own compete, and the test run picks the best of them. */
const AEK={sc:1,sl:1,fu:1,cq:0,hp:0,sh:0,cr:0,ch:0,gm:0};
function aeStats(it){
 const s=Object.assign({},AEK),d=String(it.d||'');
 for(const k in AEK)if(typeof it[k]==='number')s[k]=it[k];
 const has=k=>typeof it[k]==='number';
 let m;
 if(!has('sc')&&(m=d.match(/\+(\d+)% score/)))s.sc=1+m[1]/100;
 if(!has('sl')&&(m=d.match(/(?:foes|enemies)(?: are)? (\d+)% slower/i)))s.sl=1-m[1]/100;
 if(!has('hp')&&(m=d.match(/\+(\d+) max HP/i)))s.hp=+m[1];
 if(!has('sh')&&(m=d.match(/(\d+|a|two|three) (?:starting )?shields?/i))){const n={a:1,two:2,three:3}[m[1].toLowerCase()];s.sh=n||+m[1]||0}
 if(!has('fu')&&(m=d.match(/fury (?:charges )?(?:\+)?(\d+)%/i)))s.fu=1+m[1]/100;
 if(!has('cr')&&(m=d.match(/\+(\d+)% crit/i)))s.cr=m[1]/100;
 if(!has('ch')&&(m=d.match(/(\d+)% chance a kill chains/i)))s.ch=m[1]/100;
 if(!has('gm')&&(m=d.match(/\+(\d+)% gold/i)))s.gm=m[1]/100;
 if(!has('cq')&&/combos build faster|faster combos/i.test(d))s.cq=1;
 s.ab=it.ab||'';return s}
function aeRng(seed){let a=seed>>>0;return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}
/* one test run of a loadout: returns points */
function aeRun(w,a,pa,rnd,up){
 const sc=w.sc*a.sc*(pa.sc||1)*(1+.1*(up.pres||0)),slow=Math.max(.6,w.sl*a.sl)*(up.slow||1),fu=w.fu*(pa.fu||1)*(up.fu||1),cq=w.cq,crit=(pa.cr||0)+w.cr,chain=w.ch;
 const step=Math.max(4,10-2*cq),abil=(w.ab?.06:0)+(a.ab?.08:0)+(w.ab&&w.ab===a.ab?.06:0);
 let hp=3+a.hp+up.hp,sh=a.sh+(pa.sh||0)+up.sh,combo=0,pts=0,fury=0;
 for(let wave=1;wave<=60&&hp>0;wave++){
  const foes=Math.min(20,4+wave*.45|0),len=4+Math.min(6,wave/9),base=Math.min(.34,.012+wave*.0021);
  for(let i=0;i<foes&&hp>0;i++){
   const risk=base*Math.pow(slow,2.6)*(fury>=100?.15:1)*(.75+rnd()*.5);
   if(rnd()<risk){if(sh>0)sh--;else hp--;combo=0;continue}
   const mult=Math.min(10,1+Math.floor(combo/step));
   let k=1;if(chain&&rnd()<chain)k=2;
   pts+=len*10*mult*sc*(1+crit)*k*(1+abil);combo+=len*k;fury+=len*.9*fu;
   if(fury>=100&&i%5===4){fury=0;pts+=foes*.5*len*10*mult*sc}
  }
  if(wave%5===0)combo=Math.floor(combo*.5)
 }
 return pts*(1+.1*(w.gm+(up.gm||0)))}
function aeScore(w,a,pa,up,trials){let t=0;for(let i=0;i<trials;i++)t+=aeRun(w,a,pa,aeRng(9001+i*131),up);return t/trials}
function aeUp(){let u=k=>{try{return typeof U==='function'?U(k)||0:0}catch(e){return 0}};return{hp:u('hardy')+(P.pres>=5?1:0),sh:u('iron')+(P.pres>=3?1:0),slow:1-.02*u('calm'),fu:1+.05*u('kind'),gm:.04*u('prosp')+.05*(P.pres||0),pres:P.pres||0}}
function autoPick(trials){
 const pa=PATHS[P.path]||{},up=aeUp();
 const wids=Object.keys(WP).filter(id=>P.own[id]&&(WP[id].p||'knight')===P.path),aids=Object.keys(AR).filter(id=>P.ownA[id]);
 if(!wids.length)wids.push(P.weapon);if(!aids.length)aids.push(P.armor);
 const topR=(ids,T)=>{const m=Math.max(...ids.map(i=>RKM[T[i].r]||0));return ids.filter(i=>(RKM[T[i].r]||0)===m)};
 const wAll=wids.slice(),aAll=aids.slice();/* rarity comes first: only the highest rarity you own is considered, and the test run settles it within that tier */
 wids.splice(0,wids.length,...topR(wAll,WP));aids.splice(0,aids.length,...topR(aAll,AR));
 const WS={},AS={};for(const id of wAll)WS[id]=aeStats(WP[id]);for(const id of aAll)AS[id]=aeStats(AR[id]);
 const tier=id=>{try{return typeof wTier==='function'?wTier(id)||0:0}catch(e){return 0}};
 trials=trials||(wids.length*aids.length>500?6:wids.length*aids.length>150?10:16);
 let best=null;const all=[];
 for(const wi of wids)for(const ai of aids){const s=aeScore(WS[wi],AS[ai],pa,up,trials);all.push([wi,ai,s])}
 /* within the top rarity tier, a loadout within 0.5% of the best score is a tie: weapon mastery decides */
 const top=Math.max(...all.map(x=>x[2]));
 const near=all.filter(x=>x[2]>=top*.995).sort((x,y)=>tier(y[0])-tier(x[0])||y[2]-x[2]);
 best=near[0];
 const cur=aeScore(WS[P.weapon]||aeStats(WP[P.weapon]),AS[P.armor]||aeStats(AR[P.armor]),pa,up,trials);
 /* best weapon and armor on their own, for the report */
 return{w:best[0],a:best[1],score:best[2],cur,ws:WS[best[0]],as:AS[best[1]],tested:all.length}}
function aeChips(s,isA){const c=[];
 if(s.sc>1)c.push(`+${Math.round((s.sc-1)*100)}% score`);if(s.hp)c.push(`+${s.hp} HP`);if(s.sh)c.push(`${s.sh} shield${s.sh>1?'s':''}`);
 if(s.sl<1)c.push(`foes ${Math.round((1-s.sl)*100)}% slower`);if(s.fu>1)c.push(`fury +${Math.round((s.fu-1)*100)}%`);if(s.cq)c.push('fast combos');
 if(s.cr)c.push(`+${Math.round(s.cr*100)}% crit`);if(s.ch)c.push(`${Math.round(s.ch*100)}% chain`);if(s.gm)c.push(`+${Math.round(s.gm*100)}% gold`);if(s.ab)c.push('special ability');
 return c.length?c:['no bonuses']}
function autoEquip(){
 const oldW=P.weapon,oldA=P.armor,r=autoPick(),gainPct=Math.round((r.score/Math.max(1,r.cur)-1)*100);
 const changedW=r.w!==oldW,changedA=r.a!==oldA;
 if(changedW)setWeapon(r.w);if(changedA){P.armor=r.a;save()}
 try{beep&&beep(660,.09,'triangle',.25);setTimeout(()=>beep(990,.14,'triangle',.25),90)}catch(e){}
 return{r,oldW,oldA,changedW,changedA,gainPct}}
function autoEquipUI(){
 const res=autoEquip(),{r}=res;armory();
 const m=$('armod');if(!m)return;m.hidden=false;
 const none=!res.changedW&&!res.changedA;
 const card=(kind,id,T,chg,st,oldId)=>{const it=T[id],col=it.col||it.c||it.m||'#ffd76a';return `<div class="aaitem${chg?' ch':''}" style="--c:${col}"><canvas width="132" height="132" data-aa="${kind}:${id}"></canvas><div><u>${kind==='w'?'WEAPON':'ARMOR'} · ${chg?'EQUIPPED':'ALREADY BEST'}</u><b>${esc(it.n)}</b><em style="color:${RC[it.r]||'#fff'}">${it.r}</em><div class="aach">${aeChips(st).map(x=>`<i>${esc(x)}</i>`).join('')}</div>${chg?`<small>Replaced ${esc(T[oldId].n)}</small>`:''}</div></div>`};
 m.innerHTML=`<div class="armb aamb" role="dialog" aria-modal="true" aria-label="Auto-Equip result"><button class="armx" id="armx" aria-label="Close">×</button><h3>${none?'Already optimal':'Auto-Equip complete'}</h3><p class="aasub">${none?'Your current weapon and armor are already the strongest pairing you own.':`Best loadout for your ${esc((PATHS[P.path]||{}).n||'warrior')} class${res.gainPct>=1?`, ${res.gainPct}% stronger in testing than before`:''}.`}</p>${card('w',r.w,WP,res.changedW,r.ws,res.oldW)}${card('a',r.a,AR,res.changedA,r.as,res.oldA)}<p class="aafoot">Highest rarity first. Among your top-rarity gear, ${r.tested.toLocaleString()} pairing${r.tested>1?'s were':' was'} put through a seeded 60-wave test run using the game\'s score, HP, shield, slow, fury, combo, crit and chain rules.</p><div class="aabtn">${none?'':'<button class="aaundo" id="aaundo">Undo</button>'}<button class="aaok" id="aaok">${none?'Close':'Keep it'}</button></div></div>`;
 m.querySelectorAll('canvas[data-aa]').forEach(c=>{const [k,id]=c.dataset.aa.split(':');try{art(c,k,id,0)}catch(e){}});
 const cl=()=>{m.hidden=true;m.innerHTML='';S.back=title};S.back=cl;$('armx').onclick=cl;$('aaok').onclick=cl;m.onclick=e=>{if(e.target===m)cl()};
 if($('aaundo'))$('aaundo').onclick=()=>{if(res.changedW)setWeapon(res.oldW);if(res.changedA){P.armor=res.oldA;save()}armory();const t=$('armod');if(t){t.hidden=true;t.innerHTML=''}S.back=title;try{beep(330,.12,'triangle',.22)}catch(e){}};
 try{$('aaok').focus()}catch(e){}}
