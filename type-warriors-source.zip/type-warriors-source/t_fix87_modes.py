# Update 8.7, stream "modes": checks for 94b_fix_modes.js (and the small edits in 89d_wc_menus.js / 70_main.js).
#   Riddle   A3 the daily result is paid in the same save as the state change (reload inside the flip, double Enter, reload after the
#            flip, a loss), the load-time recovery of old saves (win, loss, older day behind a newer one, exactly once), practice untouched;
#            A10 the answer is never in the save before it is solved, a stale one is stripped;
#            B2 the four dead trophies (dc1, dc7, dcw5, dcS) follow the daily Riddle stats, total stays 103, earned state kept.
#   Wildcard A5 the Game menu pauses solo and same-screen tables (bot turns, WILD! window, timers, moves; resumes with the time that
#            was left; online rooms and ranked keep running); A8 no console error after leaving mid-animation (reduced motion and normal);
#            B6 the +150 first-win bonus only for staked games inside the 15-game cap.
#   Arena    A7 Enter on the result screen presses "Fight again"; the menu track plays while paused or over.
# Run from the source folder against out.html:  python3 t_fix87_modes.py [riddle|trophy|wc|arena]   (no argument = everything)
import asyncio,os,sys,json
from playwright.async_api import async_playwright
URL='file://'+os.path.abspath('out.html')
SHOTS=os.environ.get('SHOTS','')   # optional folder for screenshots
bad=0;er=[]
def chk(name,r,ok):
    global bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD',flush=True)
async def page(b,rm=False,w=1600,h=900,ctx=None,touch=False):
    kw=dict(viewport={'width':w,'height':h},reduced_motion='reduce' if rm else 'no-preference')
    if touch:kw.update(has_touch=True,is_mobile=True)
    ctx=ctx or await b.new_context(**kw);pg=await ctx.new_page()
    pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
    pg.on('console',lambda m:er.append('CE '+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text else None)
    await pg.goto(URL);await pg.wait_for_timeout(1200);return pg
async def typ(pg,w):
    for c in w:await pg.keyboard.press(c);await pg.wait_for_timeout(8)

# --------------------------------------------------------------------------------------------------------------------
async def riddle(b):
    pg=await page(b);E=pg.evaluate
    ALL4="P.ach.dc1=P.ach.dc7=P.ach.dcw5=P.ach.dcS=1;"   # keep trophy gold out of the payout arithmetic
    await E("()=>{RS_ASK=false;P.gold=10000;"+ALL4+"delete P.rr;save();title()}");await E("()=>rrMenu(title)");await pg.wait_for_timeout(700)
    r=await E("()=>{const k=rrKey(),e=rrCur(),w=rrWord(k);save();const s=JSON.parse(localStorage.getItem(KEY)).rr.d[k];return [e.w===w,Object.keys(e).includes('w'),'w' in s,JSON.stringify(s).includes(w)]}")
    chk('A10 a daily entry reads the answer through rrCur() but the save has no answer',r,r==[True,False,False,False])
    r=await E("()=>{const k=rrKey(),R=RRP();delete R.d[k].w;R.d[k].w='stale';save();const had=JSON.parse(localStorage.getItem(KEY)).rr.d[k].w;const w=rrCur().w;save();return [had,w===rrWord(k),'w' in JSON.parse(localStorage.getItem(KEY)).rr.d[k]]}")
    chk('(setup) an old-style stale answer sits in the save; the next rrCur() derives the real one and hides it again',r,r==['stale',True,False])
    # ---- A3: type the answer, Enter, reload inside the tile-flip delay
    ans=await E("()=>rrCur().w");g0=await E("()=>P.gold")
    await typ(pg,ans);await pg.keyboard.press('Enter');await pg.keyboard.press('Enter');await pg.wait_for_timeout(120)
    r=await E("()=>{const k=rrKey(),R=RRP(),e=R.d[k];return [e.st,e.c,P.gold,R.wins,R.dist[0],R.st,R.last===k,R.pl,JSON.parse(localStorage.getItem(KEY)).rr.d[k].c]}")
    chk('A3 right after Enter (double Enter): payout, stats and streak are already in the save, paid once',r,r==['w',1500,g0+1500,1,1,1,True,1,1500])
    await pg.reload();await pg.wait_for_timeout(1500)
    r=await E("()=>{const k=rrKey(),R=RRP(),e=R.d[k];return [e.st,e.c,P.gold,R.wins,R.dist[0],R.st,R.last===k,R.pl,'w' in e]}")
    chk('A3 reload inside the flip delay keeps result and payout',r,r==['w',1500,g0+1500,1,1,1,True,1,False])
    await E("()=>{RR=null;title();rrMenu(title)}");await pg.wait_for_timeout(900)
    r=await E("()=>{rrResult(false);const t=document.querySelector('#rrres .rrpay .tot b');return [t&&t.textContent,P.gold]}")
    chk('reopening shows the result without paying again',r,r==['+1,500',g0+1500])
    await pg.reload();await pg.wait_for_timeout(1500)
    r=await E("()=>{const R=RRP();return [P.gold,R.wins,R.pl,R.dist[0]]}")
    chk('reload after the flip does not pay a second time',r,r==[g0+1500,1,1,1])
    # ---- the loss path pays its 25 coins in the same save
    k=await E("()=>rrKey()")
    await E("()=>{const R=RRP(),k=rrKey(),w=rrWord(k);R.st=4;R.last=rrPrev(k);delete R.d[k];save();RR=null;title();rrMenu(title);const e=rrCur();e.g=RR_ANS.filter(x=>x!==w).slice(0,5);save();rrMenu(title)}");await pg.wait_for_timeout(700)
    g1=await E("()=>P.gold");wrong=await E("()=>RR_ANS.filter(x=>x!==rrCur().w&&!rrCur().g.includes(x))[0]")
    await typ(pg,wrong);await pg.keyboard.press('Enter');await pg.wait_for_timeout(100)
    await pg.reload();await pg.wait_for_timeout(1500)
    r=await E("()=>{const R=RRP(),e=R.d[rrKey()];return [e.st,e.c,P.gold,R.st,R.pl,R.wins,R.dist.reduce((a,b)=>a+b,0)]}")
    chk('A3 a lost riddle: 25 coins and the streak reset survive a reload inside the flip',r,r==['l',25,g1+25,0,2,1,1])
    # ---- load-time recovery of saves hit by the old order (st set, no c)
    async def craft(js):
        await E("()=>{"+js+";save()}");await pg.reload();await pg.wait_for_timeout(1500)
    K="const k=rrKey(),y=rrPrev(k),y2=rrPrev(y),R=RRP(),w=rrWord(k),wy=rrWord(y);for(const a of ACH)P.ach[a.id]=P.ach[a.id]||1;"  # every trophy is marked earned so no trophy gold (riddle trophies, gold milestones) lands inside these gold checks
    await craft(K+"P.gold=5000;delete R.d[k];R.d[y]={g:[wy],st:'w',pw:{r:0,s:0},rv:[],sh:[],w:wy};R.d[k]={g:[],st:'p',pw:{r:0,s:0},rv:[],sh:[]};R.st=3;R.last=y2;R.wins=3;R.pl=3;R.best=3;R.dist=[1,1,1,0,0,0]")
    r=await E("()=>{const k=rrKey(),y=rrPrev(k),R=RRP(),e=R.d[y];return [e.c,e.cb,P.gold,R.wins,R.pl,R.dist[0],R.st,R.last===y,R.best,'w' in e]}")
    chk('A3 recovery: an old win with no payout is settled once (1500, streak 4)',r,r[0]==1500 and r[1]==0 and r[2]==6500 and r[3]==4 and r[4]==4 and r[5]==2 and r[6]==4 and r[7] and r[8]==4)
    await pg.reload();await pg.wait_for_timeout(1500)
    r=await E("()=>{const R=RRP();return [P.gold,R.wins,R.pl,R.st]}")
    chk('recovery runs exactly once (second reload changes nothing)',r,r==[6500,4,4,4])
    r=await E("()=>{const k=rrKey(),e=RRP().d[k];return [e.st,'w' in e,JSON.stringify(JSON.parse(localStorage.getItem(KEY)).rr.d[k]).includes(rrWord(k))]}")
    chk('A10 a stale answer on the unsolved day is stripped on load',r,r==['p',False,False])
    await craft(K+"P.gold=5000;delete R.d[k];const l=RR_ANS.filter(x=>x!==wy).slice(0,6);R.d[y]={g:l,st:'l',pw:{r:0,s:0},rv:[],sh:[]};R.st=5;R.last=y2;R.wins=5;R.pl=5;R.best=5;R.dist=[1,1,1,1,1,0]")
    r=await E("()=>{const y=rrPrev(rrKey()),R=RRP(),e=R.d[y];return [e.c,P.gold,R.st,R.pl,R.wins,R.best]}")
    chk('recovery: an old loss pays 25 and resets the streak',r,r==[25,5025,0,6,5,5])
    await craft(K+"P.gold=5000;R.d[k]={g:[w],st:'w',pw:{r:0,s:0},rv:[],sh:[],c:1500,cb:0};R.d[y]={g:[wy],st:'w',pw:{r:1,s:0},rv:[],sh:[]};R.d[y2]={g:[rrWord(y2)],st:'w',pw:{r:0,s:0},rv:[],sh:[],c:1500,cb:0};R.st=1;R.last=k;R.wins=2;R.pl=2;R.best=1;R.dist=[2,0,0,0,0,0]")
    r=await E("()=>{const k=rrKey(),y=rrPrev(k),R=RRP(),e=R.d[y];return [e.c,P.gold,R.wins,R.pl,R.dist[0],R.st,R.last===k,R.best]}")
    chk('recovery: yesterday behind a settled today pays (power trim kept), streak becomes the real chain of 3',r,r==[1275,6275,3,3,3,3,True,3])
    await craft(K+"P.gold=5000;delete R.d[y];delete R.d[y2];R.d[k]={g:[w],st:'w',pw:{r:0,s:0},rv:[],sh:[]};R.st=6;R.last=y;R.wins=6;R.pl=6;R.best=6;R.dist=[6,0,0,0,0,0];R.ttl=0")
    r=await E("()=>{const e=RRP().d[rrKey()],R=RRP();return [e.c,e.cb,P.gold,R.st]}")
    chk('recovery of the 7th day in a row keeps the +500 streak bonus',r,r==[2000,500,7000,7])
    r=await E("()=>{delete P.rr;const n=rrRecover();return [n,P.rr===undefined]}");chk('a save with no riddle history is left alone (no P.rr created by the recovery)',r,r==[0,True])
    # ---- practice is untouched: stats after the flip, nothing paid, the practice answer stays where it was
    await E("()=>{RS_ASK=false;P.gold=5000;"+ALL4+"delete P.rr;save();title();rrMenu(title,'p')}");await pg.wait_for_timeout(800)
    pa=await E("()=>rrCur().w");await typ(pg,pa);await pg.keyboard.press('Enter');await pg.wait_for_timeout(120)
    r=await E("()=>{const R=RRP();return [rrCur().st,P.gold,R.pr.wins,R.pr.pl,R.wins,R.pl,R.st,'w' in JSON.parse(localStorage.getItem(KEY)).rr.pr.cur]}")
    chk('practice: nothing paid, daily counters untouched, stats arrive with the flip (as before)',r,r==['w',5000,0,0,0,0,0,True])
    await pg.wait_for_timeout(1900)
    r=await E("()=>{const R=RRP();return [P.gold,R.pr.wins,R.pr.pl,R.pr.dist[0],R.wins,R.pl]}")
    chk('practice: counted once the flip is done',r,r==[5000,1,1,1,0,0])
    await pg.close()

# --------------------------------------------------------------------------------------------------------------------
async def trophy(b):
    pg=await page(b);E=pg.evaluate
    r=await E("()=>[ACH.length,['dc1','dc7','dcw5','dcS'].every(i=>ACH.some(a=>a.id===i)),new Set(ACH.map(a=>a.id)).size,ACAT.includes('Runestone Riddle'),ACH.filter(a=>a.cat==='Runestone Riddle').map(a=>a.id).join()]")
    chk('B2 total stays 103, ids kept, one Runestone Riddle category with the four',r,r==[103,True,103,True,'dc1,dc7,dcw5,dcS'])
    r=await E("()=>ACH.filter(a=>a.cat==='Runestone Riddle').map(a=>[a.id,a.t,a.g,a.sp,a.tg,a.n.length<=18,!/Daily Challenge/.test(a.n+a.d)])")
    chk('tiers, rewards and targets kept; short names; no Daily Challenge wording',r,json.dumps(r)==json.dumps([['dc1',0,100,0,1,True,True],['dc7',1,400,1,7,True,True],['dcw5',1,250,0,5,True,True],['dcS',2,500,1,1,True,True]]))
    await E("()=>{RS_ASK=false;P.gold=0;P.spb=0;P.ach={};delete P.rr;delete P.dc;save();title()}")
    r=await E("()=>['dc1','dc7','dcw5','dcS'].map(i=>ACH.find(a=>a.id===i).v())");chk('no riddle history = zero progress (old Daily Challenge data is not used)',r,r==[0,0,0,0])
    r=await E("()=>{P.dc={days:{a:{win:1,grade:'S'},b:{win:1,grade:'S'}},streak:9,best:9};const v=['dc1','dc7','dcw5','dcS'].map(i=>ACH.find(a=>a.id===i).v());delete P.dc;return v}")
    chk('old Daily Challenge records do not count',r,r==[0,0,0,0])
    r=await E("()=>{P.rr={d:{},wins:3,best:5,st:2,dist:[0,0,2,1,0,0],pl:4};return ['dc1','dc7','dcw5','dcS'].map(i=>ACH.find(a=>a.id===i).v())}")
    chk('progress follows the riddle stats: wins, best streak, wins, guesses 1-2',r,r==[3,5,3,0])
    r=await E("()=>{P.rr.dist=[0,1,2,0,0,0];P.rr.wins=5;P.rr.best=7;achCheck();const a=['dc1','dc7','dcw5','dcS'].map(i=>!!P.ach[i]);return [a,P.gold,P.spb]}")
    chk('all four are earned by the rules (7-day streak, 5 solved, 2 guesses): 100+400+250+500 gold, 2 skill points',r,r==[[True,True,True,True],1250,2])
    r=await E("()=>{const g=P.gold;achCheck();achCheck();return P.gold-g}");chk('awarded once only',r,r==0)
    # earned state of an old holder is kept even though the new rule would not give it
    await E("()=>{P.ach={dc1:111,dcS:222};delete P.rr;save();achCheck()}")
    r=await E("()=>[P.ach.dc1,P.ach.dcS,!!P.ach.dc7,ACH.find(a=>a.id==='dc1').v()]");chk('earned state is kept (timestamps untouched, nothing re-awarded)',r,r==[111,222,False,0])
    # 7-day streak = best OR current; one guess counts for the 1-2 guess trophy
    r=await E("()=>{P.ach={};P.rr={d:{},wins:1,best:0,st:7,dist:[1,0,0,0,0,0],pl:1};return ['dc7','dcS'].map(i=>ACH.find(a=>a.id===i).v())}");chk('current streak and a solve in one guess both count',r,r==[7,1])
    # the trophy case
    await E("()=>{P.ach={dc1:111};P.rr={d:{},wins:3,best:5,st:2,dist:[0,0,2,1,0,0],pl:4};profile.cat='Runestone Riddle';profile(1)}");await pg.wait_for_timeout(700)
    r=await E("()=>{const t=document.querySelector('#tc');return [document.querySelector('.ctabs .tab.on').textContent.trim(),[...document.querySelectorAll('#tc .tabs .tab')].map(x=>x.textContent).join('|'),document.querySelector('#tc .sec').textContent.replace(/\\s+/g,' '),[...document.querySelectorAll('#tc .tr')].map(x=>x.querySelector('b').textContent+':'+(x.classList.contains('on')?'Earned':(x.querySelector('.pv')||{}).textContent)).join(' | ')]}")
    chk('profile(1): Trophies tab, the new category tab, "1 of 103", the four with their progress',r,r[0].startswith('Trophies 1/103') and 'Runestone Riddle' in r[1] and '1 of 103' in r[2] and r[3]=='Riddle Apprentice:Earned | Rune Regular:5 / 7 | Stone Scholar:3 / 5 | Rune Whisperer:0 / 1')
    if SHOTS:await pg.screenshot(path=SHOTS+'/modes_trophies_1600x900.png')
    r=await E("()=>{profile.cat='All';profile(1);return [document.querySelectorAll('#tc .tr').length,document.querySelector('.ctabs .tab.on').textContent.trim()]}");chk('All tab lists every trophy',r,r==[103,'Trophies 1/103'])
    await pg.close()
    # narrow phone layout of the same screen
    pg=await page(b,w=390,h=844,touch=True);E=pg.evaluate
    await E("()=>{RS_ASK=false;P.ach={dc1:111};P.rr={d:{},wins:3,best:5,st:2,dist:[0,0,2,1,0,0],pl:4};profile.cat='Runestone Riddle';profile(1)}");await pg.wait_for_timeout(800)
    r=await E("()=>{const tabs=document.querySelector('#tc .tabs');const R=tabs.getBoundingClientRect();return [[...tabs.children].every(c=>{const q=c.getBoundingClientRect();return q.right<=R.right+1&&q.left>=R.left-1}),document.documentElement.scrollWidth<=innerWidth+1]}")
    chk('390x844: category tabs stay inside the row, no sideways page scroll',r,r==[True,True])
    if SHOTS:await pg.screenshot(path=SHOTS+'/modes_trophies_390x844.png')
    await pg.close()

# --------------------------------------------------------------------------------------------------------------------
async def wc(b):
    pg=await page(b,rm=True);E=pg.evaluate;sl=pg.wait_for_timeout
    async def settle(mx=20000):
        for _ in range(mx//100):
            if await E("()=>!!$('wct')&&!WX.busy&&!!WX.G"):return True
            await sl(100)
        return False
    await E("()=>{RS_ASK=false;P.gold=50000;delete P.wc;save();title()}");await sl(400)
    await E("()=>{wcHome();wcStartSolo('c250',true)}");ok=await settle();await sl(300)
    chk('(setup) a solo practice table is dealt',ok,ok is True)
    S1="()=>[WX.G.turns,WX.G.turn,WX.G.P[1].hand.length,WX.G.P[2].hand.length,WX.G.P[3].hand.length,WX.G.disc.length]"
    # ---- A5 scenario 1: a bot's turn is due, the menu opens, nothing happens until Resume
    await E("()=>{const G=WX.G;G.phase='play';G.turn=1;G.one=null;G.stack=0;wcStep()}")
    t0=await E(S1);await E("()=>wcMenu()");await sl(60)
    r=await E("()=>[wcPaused(),!$('wcmod').hidden,$('wcmod').classList.contains('wcmn'),WCPZ.recs.size>0,[...WCPZ.recs].every(x=>x.id===0)]")
    chk('A5 the Game menu is open: paused, the pending bot move is frozen',r,r==[True,True,True,True,True])
    await sl(3500);t1=await E(S1)
    chk('A5 3.5 s later nobody has moved (turn count, hands, pile)',t1,t1==t0)
    await E("()=>$('wcres').click()");await sl(150)
    r=await E("()=>[wcPaused(),WCPZ.on,[...WCPZ.recs].every(x=>x.id!==0)]");chk('Resume thaws the timer',r,r==[False,False,True])
    await sl(3200);t2=await E(S1)
    chk('A5 after Resume the bot plays',t2,t2[0]>t0[0])
    # ---- exactness: a 1.5 s timer paused with ~1.1 s left fires about 1.1 s after Resume, not at once and not early
    await settle()
    await E("()=>{const G=WX.G;G.phase='play';G.turn=0;G.one=null;G.stack=0;wcClear();window.__f=0;wcLater(()=>{window.__f=performance.now()},1500)}");await sl(400);await E("()=>wcMenu()");await sl(2000)
    f_p=await E("()=>window.__f");await E("()=>{window.__r=performance.now();$('wcres').click()}");await sl(1500)
    r=await E("()=>[window.__f-window.__r]");chk('A5 a timer resumes with the time it had left (about 1.1 s)',[f_p,round(r[0])],f_p==0 and 800<r[0]<1450)
    # ---- WILD! window: nobody catches a missed call and the window does not close while the menu is open
    await settle()
    await E("()=>{const G=WX.G;G.phase='play';G.turn=0;G.stack=0;const p=G.P[1];p.hand=p.hand.slice(0,1);p.called=0;G.P.forEach(q=>{if(q.kind==='bot')q.diff='h'});G.one={p:1,n:G.seq};wcSync();wcStep()}")
    await E("()=>wcMenu()");await sl(4200)
    r=await E("()=>[!!WX.G.one,WX.G.P[1].caught,WX.G.P[1].hand.length]");chk('A5 WILD! window: still open after 4.2 s in the menu, no catch (window is 3.2 s)',r,r==[True,0,1])
    await E("()=>$('wcres').click()");await sl(4300)
    r=await E("()=>[!!WX.G.one,WX.G.P[1].hand.length>=1]");chk('A5 after Resume the window runs out or is caught',r,r==[False,True])
    # ---- pump waits: an event that arrives while paused is not animated until Resume
    await settle()
    await E("()=>{const G=WX.G;G.phase='play';G.turn=2;G.one=null;G.stack=0;wcClear()}")
    await E("()=>wcMenu()");await sl(60);d0=await E("()=>document.querySelectorAll('#wcfx .wcfly').length")
    await E("()=>wcBotMove(2)");await sl(1200)
    r=await E("()=>[WX.busy,document.querySelectorAll('#wcfx .wcfly').length,WCPZ.gates.length]");chk('A5 an event applied while paused waits at the gate (pump busy, no card in the air)',r,r==[True,0,1])
    await E("()=>$('wcres').click()");ok=await settle(8000)
    r=await E("()=>[WX.busy,WCPZ.gates.length]");chk('A5 Resume lets the pump finish',r,ok and r==[False,0])
    # ---- user moves are ignored while paused, work after
    await E("()=>{const G=WX.G;G.phase='play';G.turn=0;G.one=null;G.stack=0;G.P[0].lack={};wcClear();wcRender()}");await sl(200)
    h0=await E("()=>WX.G.P[0].hand.length");await E("()=>wcMenu()");await sl(60);await E("()=>wcSend({t:'draw'})");await sl(300)
    r=await E("()=>[WX.G.P[0].hand.length,WX.G.turn]");chk('A5 a draw sent while paused is ignored',r,r==[h0,0])
    await E("()=>$('wcres').click()");await sl(150);await E("()=>wcSend({t:'draw'})");await sl(300)
    r=await E("()=>WX.G.P[0].hand.length");chk('...and works after Resume',r,r>h0)
    await settle()
    # ---- Esc toggles the menu and resumes; How to play opened from the menu keeps the pause
    await E("()=>{const G=WX.G;G.phase='play';G.turn=0;G.one=null;G.stack=0;wcClear()}")
    await pg.keyboard.press('Escape');await sl(200);r=await E("()=>[wcPaused(),$('wcmod').classList.contains('wcmn')]");chk('Esc opens the menu and pauses',r,r==[True,True])
    await E("()=>$('wcrules').click()");await sl(200);r=await E("()=>[wcPaused(),!$('wcmod').hidden,$('wcmod').classList.contains('wcmn'),!!document.querySelector('.wchw')]")
    chk('How to play opened from the menu: still paused',r,r==[True,True,False,True])
    await E("()=>document.querySelector('#wcmod .wcmx').click()");await sl(150);r=await E("()=>wcPaused()");chk('closing it resumes',r,r==False)
    await pg.keyboard.press('Escape');await sl(150);await pg.keyboard.press('Escape');await sl(200);r=await E("()=>[wcPaused(),$('wcmod').hidden]");chk('Esc again closes the menu and resumes',r,r==[False,True])
    # ---- a colour picker or a curtain in the same modal is not a pause
    await E("()=>{const m=$('wcmod');m.hidden=false;m.className='wcmod wcpk';m.innerHTML='<div>pick</div>'}");r=await E("()=>wcPaused()");chk('another modal on #wcmod (colour picker) does not pause',r,r==False)
    await E("()=>{const m=$('wcmod');m.hidden=true;m.innerHTML=''}")
    # ---- online rooms and ranked are never paused
    for mode,js in (('net',"WX.mode='net'"),('ranked',"WX.rk={r:0}")):
        await E("()=>{"+js+";window.__n=0;wcMenu();wcLater(()=>{window.__n=1},150)}");await sl(500)
        r=await E("()=>[window.__n,wcPaused(),!$('wcmod').hidden]");chk('A5 '+mode+' table: the timer still fires with the menu open (never paused)',r,r==[1,False,True])
        await E("()=>{WX.mode='solo';WX.rk=null;const m=$('wcmod');m.hidden=true;m.innerHTML='';wcPauseSync()}");await sl(100)
    # ---- leaving or restarting while paused cannot leave a stale pause behind
    await E("()=>{wcMenu()}");await sl(100);await E("()=>$('wcquit').click()");await sl(400)
    r=await E("()=>[wcPaused(),WCPZ.on,WCPZ.gates.length,WCPZ.recs.size]");chk('leaving the table from the menu clears the pause',r,r==[False,False,0,0])
    await E("()=>{wcHome();wcStartSolo('c250',true)}");ok=await settle();r=await E("()=>[wcPaused(),WX.G&&WX.G.P[0].hand.length]");chk('a new table after that starts unpaused and deals',r,ok and r==[False,7])
    # ---- same-screen table (pass and play) pauses too
    await E("()=>{wcExit();wcLobby();WCL.seats=[{k:'you',name:'Ann'},{k:'local',name:'Bob'},{k:'bot'},{k:'bot'}];wcLobbyStart()}");await sl(1500)
    r=await E("()=>[WX.mode,WX.G.P.map(p=>p.kind).join()]");chk('(setup) a same-screen table',r,r[0]=='pp')
    await E("()=>{const m=$('wcmod');if(m&&!m.hidden){m.hidden=true;m.innerHTML=''}WX.cover=false}");await settle(6000)
    await E("()=>{const G=WX.G;G.phase='play';G.turn=2;G.one=null;G.stack=0;wcStep()}");q0=await E(S1);await E("()=>wcMenu()");await sl(3500)
    r=await E(S1);chk('A5 same screen: no bot move while the menu is open',r,r==q0)
    await E("()=>$('wcres').click()");await sl(3200);r=await E(S1);chk('...and the bot plays after Resume',r,r[0]>q0[0])
    await E("()=>wcExit()");await sl(300)
    # ---- A8: leaving with a card in the air must not throw (reduced motion and normal motion)
    for lap in range(6):
        await E("()=>{wcHome();wcStartSolo('c250',true)}");await settle();await sl(100)
        await E("()=>{const G=WX.G;G.phase='play';G.one=null;G.stack=0;if(G.P[G.turn].kind!=='bot'){G.turn=1}wcClear();wcBotMove(G.turn)}")
        busy=await E("()=>WX.busy");await sl(5+lap*8);await E("()=>wcExit()");await sl(700)
    real=lambda:[x for x in er if 'WebSocket' not in x]
    chk('A8 reduced motion: six exits with a card in the air, no console errors',real()[:3],real()==[])
    pg2=await page(b,rm=False);E2=pg2.evaluate;pg2.on('pageerror',lambda e:er.append('PE2 '+str(e)[:200]))
    await E2("()=>{RS_ASK=false;P.gold=50000;delete P.wc;save();title()}");await pg2.wait_for_timeout(500)
    for lap in range(4):
        await E2("()=>{wcHome();wcStartSolo('c250',true)}")
        for _ in range(200):
            if await E2("()=>!!$('wct')&&!WX.busy&&!!WX.G"):break
            await pg2.wait_for_timeout(100)
        await E2("()=>{const G=WX.G;G.phase='play';G.one=null;G.stack=0;if(G.P[G.turn].kind!=='bot'){G.turn=1}wcClear();wcBotMove(G.turn)}")
        await pg2.wait_for_timeout(30+lap*60);await E2("()=>wcExit()");await pg2.wait_for_timeout(900)
    chk('A8 normal motion: four exits with a card in the air, no console errors',real()[:3],real()==[])
    await pg2.close()
    # ---- B6 first-win bonus
    async def play_win(stake_game,pre=""):
        # start a table, make the human the winner, record it; returns [bonus, gold change, fw set, dayN]
        await E("()=>{RS_ASK=false;"+pre+"}")
        await E("()=>{wcHome();wcStartSolo('c250',"+('false' if stake_game else 'true')+")}");await settle()
        return await E("()=>{const G=WX.G,W=wcSt(),g0=P.gold;G.P[0].hand=[];G.phase='over';G.win=0;const R=wcRecord();return [R.bonus,P.gold-g0-0,W.fw===wcDay(),W.dayN,WX.stake,R.pay]}")
    await E("()=>{P.gold=50000;delete P.wc;save()}")
    r=await play_win(False,"")   # free practice win
    chk('B6 a free practice win does not pay the first-win bonus and keeps it for later',r,r[0]==0 and r[2]==False and r[4]==0)
    r=await play_win(True,"")
    chk('B6 the first staked win of the day pays +150 (plus the pot)',r,r[0]==150 and r[2]==True and r[4]==250 and r[1]==r[5]+150)
    r=await play_win(True,"")
    chk('B6 a second staked win the same day pays no bonus',r,r[0]==0)
    r=await play_win(False,"wcSt().fw='';wcSt().dayN=15")
    chk('B6 past the 15-game cap the table is free and pays no bonus',r,r[0]==0 and r[2]==False and r[4]==0 and r[3]==15)
    r=await play_win(True,"wcSt().fw='';wcSt().dayN=14")
    chk('B6 the 15th staked game (still inside the cap) pays the bonus',r,r[0]==150 and r[3]==15)
    r=await E("()=>{const W=wcSt();W.fw='';W.dayN=16;wcReset({mode:'solo',tbl:'c250',stake:250,fee:WCFEE,cfg:{timer:0}});WX.G=wcNew({players:[{id:'me',name:'Me',kind:'you',av:wcMyAv()},{id:'a',name:'A',kind:'bot',av:{t:'hero'}}],hand:3,rules:{stack:1},seed:5});WX.G.P[0].hand=[];WX.G.phase='over';WX.G.win=0;const R=wcRecord();return [R.bonus,W.fw]}")
    chk('B6 a stake counted past the cap (dayN 16) pays no bonus',r,r==[0,''])
    # the +150 badge on the Solo card follows the same rule
    await E("()=>{wcSt().fw='';wcSt().dayN=0;wcSt().fr=0;wcHome()}");await sl(700)
    a=await E("()=>$('wcfwb').hidden");await E("()=>$('wcfrc').click()");await sl(100);b2=await E("()=>$('wcfwb').hidden");await E("()=>$('wcfrc').click()");await sl(100);c=await E("()=>$('wcfwb').hidden")
    chk('B6 the "First win today +150" badge hides for practice and returns for staked play',[a,b2,c],[a,b2,c]==[False,True,False])
    await E("()=>{wcSt().dayN=15;wcHome()}");await sl(500);r=await E("()=>$('wcfwb').hidden");chk('...and is hidden once the cap is used up',r,r==True)
    await pg.close()

# --------------------------------------------------------------------------------------------------------------------
async def arena(b):
    pg=await page(b);E=pg.evaluate;sl=pg.wait_for_timeout
    await E("()=>{RS_ASK=false;P.gold=5000;P.petSt=2;P.pets={bramble:{b:0}};P.pet='bramble';petNorm();delete P.wa;save();title()}")
    await E("()=>{waStart(0)}");await sl(500)
    Q="()=>[S.mode,!!S.wa,S.wa&&S.wa.pause,S.wa&&S.wa.over,mk(),ov.className.indexOf('hide')<0]"
    r=await E(Q);chk('first fight opens its guide: paused, menu track',r,r==['arena',True,True,False,'m',True])
    await pg.keyboard.press('Enter');await sl(300);r=await E(Q);chk('guide closed: fight music (campaign track)',r,r[:5]==['arena',True,False,False,'c'])
    await pg.keyboard.press('Escape');await sl(250);r=await E(Q);chk('Esc pauses: menu track',r,r[:5]==['arena',True,True,False,'m'])
    await pg.keyboard.press('Escape');await sl(250);r=await E(Q);chk('Esc resumes: fight track again',r,r[:5]==['arena',True,False,False,'c'])
    await E("()=>{S.wa.boss=true}");r=await E("()=>mk()");chk('a boss duel keeps the boss track while fighting',r,r=='b')
    await E("()=>{S.wa.pause=true}");r=await E("()=>mk()");chk('...and the menu track while paused',r,r=='m')
    await E("()=>{S.wa.pause=false;S.wa.boss=false}")
    # lose the fight by stepping the simulation
    for _ in range(80):
        r=await E("()=>{for(let i=0;i<120;i++){if(!S.wa||S.wa.over)break;update(1/30)}return S.wa&&S.wa.over}")
        if r:break
    await sl(300)
    runs=await E("()=>waP().runs");r=await E("()=>[S.mode,S.wa.over,mk(),!!$('wa1'),(document.querySelector('#ov h2')||{}).textContent]");chk('defeat screen: menu track, "Fight again" button',r,r==['arena',True,'m',True,'Defeated'])
    await pg.keyboard.press('Enter');await sl(300);r=await E("()=>[!!S.wa&&!S.wa.over,S.mode]");chk('Enter within 0.9 s of the result is ignored (no accidental restart)',r,r==[False,'arena'])
    await sl(900)
    if SHOTS:await pg.screenshot(path=SHOTS+'/modes_arena_result.png')
    await pg.keyboard.press('Enter');await pg.keyboard.press('Enter');await sl(500)
    r=await E("()=>[S.mode,!!S.wa,S.wa&&S.wa.over,waP().runs,mk(),ov.className.indexOf('hide')>=0]");chk('Enter on the result starts a new fight once (double Enter: still one run)',r,r[0]=='arena' and r[1] and r[2]==False and r[3]==runs and r[5])
    # a focused button keeps its own Enter: Tab to "Arena menu" and press Enter there
    for _ in range(80):
        r=await E("()=>{for(let i=0;i<120;i++){if(!S.wa||S.wa.over)break;update(1/30)}return S.wa&&S.wa.over}")
        if r:break
    await sl(1300)
    await E("()=>$('wa3').focus()");await pg.keyboard.press('Enter');await sl(500)
    r=await E("()=>[S.mode,!!document.querySelector('.wam'),!!S.wa&&!S.wa.over]");chk('Enter on a focused "Arena menu" button opens the Arena menu, not a new fight',r,r==['title',True,False])
    r=await E("()=>[S.mode,mk()]");chk('after leaving the arena the music follows the menu',r,r[1]=='m')
    await pg.close()

async def main():
    which=sys.argv[1:] or ['riddle','trophy','wc','arena']
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for w in which:await {'riddle':riddle,'trophy':trophy,'wc':wc,'arena':arena}[w](b)
        print('bad',bad);print([x for x in er if 'WebSocket' not in x][:8]);await b.close()
asyncio.run(main())
