# python3 t_pool.py : 9.4 The Crooked Cue (pool): code hygiene, save repair, physics and rules, the AI, hub and cue rack, a real match
# (stake, shot, payout), pause/forfeit/resume/shot clock, first-time tips, Trick Shots, trophies and frame cost.
import asyncio,os,sys,re,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=100000;P.pz=null;save()}"
HELP=r"""window.SC={
 ready:async()=>{for(let i=0;i<120&&!(PZ.ph==='aim'&&PZ.mode==='aim');i++)await new Promise(r=>setTimeout(r,100))},
 skip:()=>{const i=document.getElementById('pzintro');if(i)i.click()},
 on8:()=>{const B=PZ.B,st=PZ.st;st.brk=false;st.open=false;st.grp=['s','t'];for(const b of B)if((b.id>=1&&b.id<=7)||(b.id>=9&&b.id<=14))b.on=false;B[0].x=300;B[0].y=300;B[0].vx=B[0].vy=0;B[8].x=640;B[8].y=170;B[15].x=500;B[15].y=380;PZ.mode='aim';PZ.ph='aim';PZ.call=-1;pzHudAll()}
};
window.pzAuto=function(o){o=o||{};const me=Object.assign({sig:.9,psig:.05,pos:.4,safe:.3,sTry:12,look:5},o.me||{});PZ.speed=o.speed||6;const log={shots:0,offers:0};
 const iv=setInterval(()=>{try{if(!PZ.on||!PZ.st)return;if(PZ.modal&&PZ.ph==='offer'){const b=document.querySelector('#pzmod [data-a=yes]');if(b)b.click();log.offers++;return}
  if(PZ.ph==='aim'&&!PZ.modal){const st=PZ.st;if(PZ.mode==='place'){pzaPlace(st,me);const c=PZ.B[0];const p=pzpNearestPlace(PZ.B,c.x,c.y,st.kitchen||st.brk);pzPlaceCue(p.x,p.y);return}
   if(PZ.mode==='aim'&&!PZ.shotFired){let d;if(st.brk){d=pzaBreak(st,me,Math.random);PZ.B[0].x=d.x||PZ.B[0].x}else d=pzaDecide(st,me,Math.random,{});const n=pzaNoise(d,me,Math.random,1);PZ.aim.ang=PZ.cueAng=n.ang;PZ.aim.pow=n.pow;PZ.aim.a=n.a;PZ.aim.b=n.b;if(pzrOn8(st)&&d.id===8){PZ.call=d.k;PZ.callManual=true}pzFireHuman();log.shots++}}}catch(e){log.err=String(e)}},60);log.stop=()=>clearInterval(iv);return log};0;"""
async def wf(pg,js,n=160,step=250):
    for i in range(n):
        if await pg.evaluate("()=>!!("+js+")"):return True
        await pg.wait_for_timeout(step)
    return False
async def newpage(b,er,url=H):
    pg=await b.new_page(viewport={'width':1600,'height':900})
    pg.on('pageerror',lambda e:er.append(str(e)[:300]));pg.on('console',lambda m:er.append('console:'+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text and 'WebSocket' not in m.text else None)
    await pg.goto(url);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);await pg.evaluate(HELP);return pg
async def start(pg,opp='gloop',stake=200,seed=5,extra=''):
    await pg.evaluate("([o,s,k])=>{casinoOpen();gameOpen('pz');pzStart({opp:o,stake:k,seed:s})}",[opp,seed,stake]);await pg.wait_for_timeout(400);await pg.evaluate("()=>SC.skip()");await pg.evaluate("()=>SC.ready()")
async def main():
    # ------------------------------------------------------------ code hygiene
    mods=sorted(f for f in os.listdir(HERE) if re.match(r'96[a-z]{1,2}\d?_pz_.*\.js$',f))
    src={m:re.sub(r'/\*.*?\*/','',open(os.path.join(HERE,m),encoding='utf8').read(),flags=re.S) for m in mods}
    chk('pool modules present (96a..96za)',len(mods)>=28,mods)
    bad=[]
    for m,s in src.items():
        for pat in [r'\bbackdrop-filter\b',r'\b\d+(\.\d+)?v[wh]\b',r'@media[^{]*(min|max)-(width|height)',r'soft-light',r'mix-blend-mode\s*:\s*screen',r'\.shadowBlur\s*=',r'ctx\.filter',r'\.filter\s*=\s*[\'"`]',r"globalCompositeOperation\s*=\s*['\"]screen"]:
            if re.search(pat,s):bad.append((m,pat))
    chk('no backdrop-filter, vw/vh, viewport media queries, soft-light/screen blends, shadowBlur or ctx.filter in the pool modules',not bad,bad)
    css=''.join(src.values())
    kf=[]
    for m in re.finditer(r'@keyframes\s+([\w-]+)\s*\{',css):
        i=m.end();d=1
        while d and i<len(css):
            d+=(css[i]=='{')-(css[i]=='}');i+=1
        if re.search(r'box-shadow|filter',css[m.end():i]):kf.append(m.group(1))
    chk('no animated box-shadow/filter in the pool CSS',not kf and not re.search(r'transition:[^;}]*(box-shadow|filter)',css),kf)
    chk('no Firebase or Wix in the pool modules',not any(re.search(r'firebase|wix',s,re.I) for s in src.values()),'')
    chk('no model ids in the pool modules',not any(re.search(r'claude-(opus|sonnet|haiku|fable)',s,re.I) for s in src.values()),'')
    bl=open(os.path.join(HERE,'build.sh')).read()
    order=[m for m in mods if m in bl]
    chk('every pool module is in build.sh in order',len(order)==len(mods) and [bl.index(m) for m in mods if not m.startswith('96i')]==sorted(bl.index(m) for m in mods if not m.startswith('96i')),(len(order),len(mods)))
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await newpage(b,er);E=pg.evaluate
        # -------------------------------------------------------- the casino entry and the save
        r=await E("()=>({first:GAMES[0].id,pzi:GAMES.findIndex(g=>g.id==='pz'),tile:!!TA.pz,cap:casCap('pz'),mini:typeof pzFeat})")
        chk('The Crooked Cue is the second casino game (Penalty Kings leads since 9.9c) with a tile and a 5,000 max bet',r['first'] in ('pk','gtt') and r['pzi'] in (1,2) and r['tile'] and r['cap']==5000,r)
        r=await E("()=>{const out=[];for(const bad of['junk',[],{beat:5,cues:null,guide:'x',live:{v:1}},{trick:[1],tut:'a',felt:'nope',cue:'nope'},null]){P.pz=bad;const Z=PZS();out.push([typeof Z.beat,Array.isArray(Z.trick),typeof Z.tut,Z.cue,Z.felt,Z.guide,Z.live])}P.pz=null;return out}")
        chk('a corrupt or old pool save is repaired field by field',all(o[0]=='object' and not o[1] and o[2]=='object' and o[3]=='house' and o[4]=='tavern' and o[5]=='full' and o[6] is None for o in r),r)
        r=await E("()=>{const Z=PZS();Z.rep={vesper:0};const a=pzMult('vesper');Z.rep.vesper=99;const f=pzMult('vesper');Z.rep={};return [a,f,PZ_REG.vesper.mult,PZ_REG.vesper.floor]}")
        chk('"wise to you" lowers the multiplier but never below the floor',r[0]==r[2] and r[1]==r[3],r)
        r=await E("()=>PZ_ORDER.map(k=>[k,PZ_REG[k].stakes.every(s=>s<=5000),PZ_REG[k].mult>1,PZ_REG[k].floor>1])")
        chk('every regular: stakes within the cap and a winning multiplier',len(r)==7 and all(x[1] and x[2] and x[3] for x in r),r)
        # -------------------------------------------------------- physics
        r=await E("()=>{const rnd=pzRng(9),B=pzpRack(rnd);const c=B.find(b=>b.id===0),e8=B.find(b=>b.id===8);return [B.length,Math.round(e8.x),Math.round(e8.y),Math.round(PZ_PHY.W*.75),Math.round(PZ_PHY.H/2),!!c]}")
        chk('a rack has 16 balls with the 8 in the middle of the third row',r[0]==16 and 20<r[1]-r[3]<60 and abs(r[2]-r[4])<8,r)
        r=await E("()=>{let bad=0,pk=0,ke=0,n=0;const rnd=pzRng(3);for(let k=0;k<60;k++){const B=pzpRack(rnd);pzpStrike(B[0],(rnd()-.5)*.5,.5+rnd()*.5,0,0);const e0=B.reduce((a,b)=>a+b.vx*b.vx+b.vy*b.vy,0);const rr=pzpRun(B,16);n++;for(const b of B){if(!isFinite(b.x)||!isFinite(b.y)||!isFinite(b.vx))bad++;if(b.on&&(b.x<-5||b.x>PZ_PHY.W+5||b.y<-5||b.y>PZ_PHY.H+5))bad++}pk+=rr.ev.filter(e=>e.t==='pk').length}return [bad,pk,n]}")
        chk('60 random breaks: no NaN, no ball outside the table, balls do pot',r[0]==0 and r[1]>5,r)
        r=await E("()=>{const B=[{id:0,x:200,y:220,on:true,vx:0,vy:0,ux:0,uy:0,es:0},{id:1,x:400,y:220,on:true,vx:0,vy:0,ux:0,uy:0,es:0}];pzpStrike(B[0],0,.5,0,0);const rr=pzpRun(B,.4);return [Math.round(B[0].x),Math.round(B[1].x),Math.abs(B[1].y-220)<1,rr.ev.some(e=>e.t==='bb')]}")
        chk('a straight shot: the cue ball stops (stun) and the object ball carries on',r[3] and r[2] and r[1]>430 and r[0]>340 and r[0]<400,r)
        r=await E("()=>{const mk=(s)=>{const B=[{id:0,x:200,y:220,on:true,vx:0,vy:0,ux:0,uy:0,es:0},{id:1,x:400,y:220,on:true,vx:0,vy:0,ux:0,uy:0,es:0}];pzpStrike(B[0],0,.2,0,s);pzpRun(B,6);return B[0].x};return [mk(-.8),mk(0),mk(.8)]}")
        chk('draw pulls the cue ball back and follow pushes it on (draw < stun < follow)',r[0]<r[1]-15 and r[2]>r[1]+15,r)
        # -------------------------------------------------------- rules
        J="""(setup)=>{const B=pzpRack(pzRng(4));const st=pzrNew(B,0,{});const ev=[];setup(B,st,ev);return pzrJudge(st,ev)}"""
        r=await E("""()=>{const out={};const run=(f)=>{const B=pzpRack(pzRng(4));for(const b of B)b.on=true;const st=pzrNew(B,0,{});st.brk=false;st.open=true;const ev=[];f(B,st,ev);return pzrJudge(st,ev)};
         out.scratch=run((B,st,ev)=>{ev.push({t:'bb',a:0,b:1,s:300,x:1,y:1,tm:0.1},{t:'pk',a:0,p:2,x:1,y:1,tm:.5});});
         out.none=run((B,st,ev)=>{});
         out.nocush=run((B,st,ev)=>{ev.push({t:'bb',a:0,b:1,s:300,x:1,y:1,tm:.1});});
         out.legalpot=run((B,st,ev)=>{ev.push({t:'bb',a:0,b:1,s:300,x:1,y:1,tm:.1},{t:'pk',a:1,p:2,x:1,y:1,tm:.5});});
         out.early8=run((B,st,ev)=>{ev.push({t:'bb',a:0,b:8,s:300,x:1,y:1,tm:.1},{t:'pk',a:8,p:2,x:1,y:1,tm:.5});});
         return {scratch:[out.scratch.foul,out.scratch.scratch],none:[out.none.foul],nocush:[out.nocush.foul],pot:[out.legalpot.foul,out.legalpot.keep],e8:[!!out.early8.win,out.early8.foul]}}""")
        chk('rules: scratch and no-contact are fouls, a legal pot keeps the turn, no-cushion is a foul',r['scratch'][0] and r['scratch'][1] and r['none'][0] and r['nocush'][0] and (not r['pot'][0]) and r['pot'][1],r)
        r=await E("""()=>{const B=pzpRack(pzRng(4));for(const b of B)b.on=true;for(const b of B)if(b.id>=1&&b.id<=7)b.on=false;const st=pzrNew(B,0,{});st.brk=false;st.open=false;st.grp=['s','t'];st.call=2;
         const win=pzrJudge(st,[{t:'bb',a:0,b:8,s:300,x:1,y:1,tm:.1},{t:'cu',a:8,s:300,x:1,y:1,tm:.2},{t:'pk',a:8,p:2,x:1,y:1,tm:.5}]);
         const B2=pzpRack(pzRng(4));for(const b of B2)b.on=true;for(const b of B2)if(b.id>=1&&b.id<=7)b.on=false;const st2=pzrNew(B2,0,{});st2.brk=false;st2.open=false;st2.grp=['s','t'];st2.call=2;
         const wrong=pzrJudge(st2,[{t:'bb',a:0,b:8,s:300,x:1,y:1,tm:.1},{t:'cu',a:8,s:300,x:1,y:1,tm:.2},{t:'pk',a:8,p:4,x:1,y:1,tm:.5}]);
         return [win.win,wrong.win,wrong.lose||wrong.loss||null,JSON.stringify(Object.keys(win))]}""")
        chk('the 8 in the called pocket wins the rack for you, in another pocket the other player wins',r[0]==0 and r[1]==1,r)
        # -------------------------------------------------------- 9.4 review fixes: contact accuracy, jaw banks, spotting, break variety, guide
        r=await E("""()=>{let worst=0;const R=PZ_PHY.R;for(const cut of[20,45]){for(const pow of[.3,1]){const B=[{id:0,x:200,y:220,on:true,vx:0,vy:0,ux:0,uy:0,es:0},{id:1,x:520,y:220,on:true,vx:0,vy:0,ux:0,uy:0,es:0}];const a=cut*Math.PI/180,gx=520-2*R*Math.cos(a),gy=220-2*R*Math.sin(a);pzpStrike(B[0],Math.atan2(gy-220,gx-200),pow,0,0);let dir=null;for(let i=0;i<4000&&dir===null;i++){const e=[];pzpStep(B,1/120,e,i/120);if(e.some(x=>x.t==='bb'))dir=Math.atan2(B[1].vy,B[1].vx)}worst=Math.max(worst,Math.abs(dir-a)*180/Math.PI)}}return worst}""")
        chk('swept contact: the object ball leaves exactly along the ghost-ball line (error under 0.05 degrees at 20 and 45 degree cuts, slow and fast)',r<.05,r)
        r=await E("""()=>{const mk=(rail)=>{const B=pzpRack(pzRng(4));for(const b of B)b.on=true;const st=pzrNew(B,0,{});st.brk=false;st.open=true;return pzrJudge(st,[{t:'bb',a:0,b:1,s:300,x:1,y:1,tm:.1},{t:'cu',a:1,s:200,x:1,y:1,tm:.2,j:!rail},{t:'pk',a:1,p:2,x:1,y:1,tm:.5}]).banks};return [mk(false),mk(true)]}""")
        chk('a ball rattling a pocket jaw is not a bank shot, a rail first is',r[0]==0 and r[1]==1,r)
        r=await E("""()=>{const B=pzpRack(pzRng(4));for(const b of B)b.on=true;const e=B.find(b=>b.id===8);const fx=PZ_PHY.W*.75,fy=PZ_PHY.H/2;const o=B.find(b=>b.on&&b!==e&&Math.hypot(b.x-fx,b.y-fy)<30);pzrSpot8(B,e);let min=1e9;for(const b of B)if(b!==e&&b.on)min=Math.min(min,Math.hypot(b.x-e.x,b.y-e.y));return [Math.round(min),e.on]}""")
        chk('the respotted 8 never lands on another ball',r[0]>=2*12+1 and r[1],r)
        r=await E("""()=>{const h={};const rnd=pzRng(11);for(let k=0;k<120;k++){const B=pzpRack(rnd);B[0].x=220;B[0].y=220;pzpStrike(B[0],0,1,0,0);const rr=pzpRun(B,16);const n=rr.ev.filter(e=>e.t==='pk'&&e.a>0).length;h[n]=1}return Object.keys(h).length}""")
        chk('breaks differ: at least three different pot counts in 120 full-power breaks',r>=3,r)
        await E("()=>{P.pz=null;P.gold=10000;save();pzHub()}");await pg.wait_for_timeout(300);await start(pg,'moldwick',250,6)
        await E("()=>{const B=PZ.B,st=PZ.st;st.brk=false;st.open=true;for(const b of B)if(b.id>2&&b.id!==8)b.on=false;B[0].x=250;B[0].y=300;B[1].x=520;B[1].y=250;B[2].x=700;B[2].y=120;for(const b of B){b.vx=b.vy=0}PZ.aim.ang=PZ.cueAng=Math.atan2(250-300,520-24-250);PZ.aim.pow=.6}")
        r=await E("""()=>{const B=PZ.B,s=pzGuideSim(B,PZ.cueAng,.6,0,0);const C=B.map(b=>({id:b.id,x:b.x,y:b.y,on:b.on,vx:0,vy:0,ux:0,uy:0,es:0}));pzpStrike(C[0],PZ.cueAng,.6,0,0);const rr=pzpRun(C,12);const pk=rr.ev.filter(e=>e.t==='pk').map(e=>e.a+':'+e.p).sort().join(),sp=s.pots.map(e=>e.id+':'+e.p).concat(s.scratch>=0?['0:'+s.scratch]:[]).sort().join();return {first:s.first,trail:s.obj.length,same:pk===sp,pk,sp}}""")
        chk('the guide simulation matches the real shot (same first ball, same balls potted, a real object-ball path)',r['first']==1 and r['trail']>3 and r['same'],r)
        p0=await E("()=>{const c=PZ.B[0];return [PZ.cv.getBoundingClientRect().left+(c.x+PZ_G.x+160)/1600*PZ.cv.getBoundingClientRect().width,PZ.cv.getBoundingClientRect().top+(c.y+PZ_G.y-60)/900*PZ.cv.getBoundingClientRect().height]}")
        await pg.mouse.move(p0[0],p0[1]);await pg.mouse.move(p0[0]+3,p0[1]+3);a0=await E("()=>PZ.aim.ang")
        await pg.mouse.move(p0[0]+3,p0[1]+30);a1=await E("()=>PZ.aim.ang")
        await pg.mouse.move(p0[0]+3,p0[1]+3);await pg.keyboard.down('Shift');await pg.mouse.move(p0[0]+3,p0[1]+30);a2=await E("()=>PZ.aim.ang");await pg.keyboard.up('Shift')
        d0=a1-a0;d1=a2-a0
        chk('Shift (fine aim): the pointer steers the angle at about 15% speed',abs(d0)>0.01 and abs(d1/d0-.15)<.05,(d0,d1))
        r=await E("""()=>{const cv=PZ.cv,r=cv.getBoundingClientRect(),c=PZ.B[0],x=r.left+(c.x+PZ_G.x+120)/1600*r.width,y=r.top+(c.y+PZ_G.y-80)/900*r.height;const fire=(t,dx,dy)=>cv.dispatchEvent(new PointerEvent(t,{pointerType:'touch',pointerId:7,clientX:x+dx,clientY:y+dy,bubbles:true,button:0}));fire('pointerdown',0,0);const a0=PZ.aim.ang;fire('pointermove',0,100);const a1=PZ.aim.ang;fire('pointerup',0,100);return [a0,a1,PZ.touch,document.getElementById('pzm').classList.contains('touch')]}""")
        chk('touch: dragging a finger turns the aim (and the touch layout switches on)',abs(r[1]-r[0])>.05 and r[2] and r[3],r)
        r=await E("()=>{PZ.ph='roll';PZ.ffHeld=true;const a=pzFF();PZ.ffHeld=false;PZ.ph='aim';return a}")
        chk('holding click or Space fast-forwards (3x)',r==3,r)
        r=await E("()=>{PZ.moved=false;return PZ.aim.pow}")
        chk('each turn opens at a moderate power (about 55%) and Space needs an aim first',abs(r-.55)<.2 or r>=.75,r)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(600)
        # a practice match earns nothing: no stats, no trophies
        await E("()=>{P.pz=null;P.gold=10000;save();pzHub()}");await pg.wait_for_timeout(300)
        await E("()=>{casinoOpen();gameOpen('pz');pzStart({opp:'gloop',practice:true,seed:8});window.__a=pzAuto({speed:8});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},400)}")
        await pg.wait_for_timeout(22000)
        r=await E("()=>({pots:PZS().pots,racks:PZS().racks,gold:P.gold,shots:window.__a.shots,live:PZS().live&&PZS().live.practice})")
        chk('a practice match earns no stats, trophies or gold',r['shots']>3 and r['pots']==0 and r['racks']==0 and r['gold']==10000,r)
        await E("()=>{window.__a.stop();pzForfeit()}");await pg.wait_for_timeout(500)
        # broke players get a free practice game, not a dead button
        await E("()=>{P.pz=null;P.gold=10;save();pzHub()}");await pg.wait_for_timeout(500)
        await pg.click('#pzrackem');await pg.wait_for_timeout(600)
        r=await E("()=>({prac:!!(PZ.M&&PZ.M.practice),gold:P.gold,note:!!document.getElementById('pznote')})")
        chk('with too little gold the main button starts a free practice game',r['prac'] and r['gold']==10,r)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(400)
        # -------------------------------------------------------- the AI
        r=await E("""()=>{let ok=0,err=0,n=0;const t0=performance.now();for(const id of PZ_ORDER){const R=PZ_REG[id],rnd=pzRng(11);const B=pzpRack(rnd);const st=pzrNew(B,0,{});st.brk=false;st.open=true;const B2=B.map(b=>Object.assign({},b));
          try{const g=pzaThink(st,Object.assign({},R.ai),rnd,{sigK:1});let r;for(let i=0;i<4000;i++){r=g.next();if(r.done)break}n++;if(r.done&&r.value&&isFinite(r.value.ang))ok++}catch(e){err++}}return [ok,err,n,Math.round(performance.now()-t0)]}""")
        chk('every regular finds a shot on a fresh table without errors',r[0]==7 and r[1]==0,r)
        # -------------------------------------------------------- hub and cue rack
        await E("()=>{P.pz=null;P.gold=100000;const Z=PZS();Z.beat={gloop:1,moldwick:1,grizzle:1};Z.shade.day=pzDay();save();casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(700)
        r=await E("""()=>{const rows=[...document.querySelectorAll('.pzrow')],bd=document.querySelector('.pzboard').getBoundingClientRect();return {n:rows.length,lock:rows.filter(x=>x.classList.contains('lock')).length,over:rows.some(x=>x.getBoundingClientRect().bottom>bd.bottom-20),opp:!!document.querySelector('#pzopp .pzoppi'),sk:document.querySelectorAll('.pzmtr u').length,stage:document.getElementById('pzh').getBoundingClientRect().width}}""")
        chk('hub: seven tables listed, locked ones are silhouettes, all rows fit the board, spotlight with scouting meters',r['n']==7 and r['lock']==3 and not r['over'] and r['opp'] and r['sk']==20,r)
        r=await E("()=>{const c=document.querySelector('#pzopp #pzoppc').getBoundingClientRect(),p=document.querySelector('#pzopp .pzstage').getBoundingClientRect();return [c.width<=p.width+1,c.height<=p.height+1]}")
        chk('hub: the opponent portrait fits its frame',all(r),r)
        await pg.click('.pzrow[data-k=moldwick]');await pg.wait_for_timeout(300)
        chk('hub: picking another table changes the panel',await E("()=>PZ.sel==='moldwick'&&document.querySelector('.pzoppi .pzh3').textContent.includes('Moldwick')"))
        await pg.click('[data-a=cues]');await pg.wait_for_timeout(500)
        r=await E("()=>({cards:document.querySelectorAll('.pzki').length,lock:document.querySelectorAll('.pzki.lock').length,eq:document.querySelectorAll('.pzki.eq').length})")
        chk('cue rack: 16 cues (13 + the three 10.7 premium cues), one equipped, the rest locked',r['cards']==16 and r['eq']==1 and r['lock']==15,r)
        g0=await E("()=>P.gold");await pg.click('.pzki[data-i=maple]');await pg.wait_for_timeout(300)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(300);await pg.mouse.up();await pg.wait_for_timeout(200)
        chk('cue rack: letting go of the buy button early buys nothing',await E("()=>P.gold")==g0 and not await E("()=>!!PZS().cues.maple"))
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(900);await pg.mouse.up();await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,PZS().cue,!!PZS().cues.maple]")
        chk('cue rack: holding the buy button for 0.7 s charges the price and equips the cue',r[0]==g0-1500 and r[1]=='maple' and r[2],r)
        await pg.click('.pzktabs button[data-t=felts]');await pg.wait_for_timeout(300);await pg.click('.pzktabs button[data-t=balls]');await pg.wait_for_timeout(300)
        chk('cue rack: felts and ball sets tabs render',await E("()=>document.querySelectorAll('.pzki').length>=2"))
        await E("()=>pzHub()");await pg.wait_for_timeout(300);await pg.click('[data-a=rules]');await pg.wait_for_timeout(400)
        chk('How to Play: five tabs, three illustrated lessons, replay and practice buttons',await E("()=>document.querySelectorAll('.pzhtabs button').length==5&&document.querySelectorAll('.pzhcard canvas').length==3&&!!document.getElementById('pzhre')&&!!document.getElementById('pzhpr')"))
        await pg.click('.pzhtabs button[data-h=keys]');await pg.wait_for_timeout(300)
        chk('How to Play: the controls tab lists the keys',await E("()=>document.querySelectorAll('.pzhowk>div').length>=8"))
        # -------------------------------------------------------- 9.5: hub keys, The Regulars, the hub tour
        await E("()=>{P.pz=null;P.gold=100000;const Z=PZS();Z.beat={gloop:2,moldwick:1};Z.shade.day=pzDay();Z.vs={gloop:[2,1]};save();PZ.sel=null;pzHub();0;}");await pg.wait_for_timeout(1300)
        r=await E("()=>({tiles:document.querySelectorAll('.pznav button canvas').length,sel:PZ.sel,chips:document.querySelectorAll('.pzchip2').length,prac:!!document.getElementById('pzprac'),rec:(document.querySelector('.pzfacts')||{}).textContent||''})")
        chk('hub: four menu tiles with icons, the next regular picked, poker-chip stakes, a practice button, your record in the spotlight',r['tiles']==4 and r['sel']=='grizzle' and r['chips']>=3 and r['prac'],r)
        await pg.keyboard.press('1');await pg.wait_for_timeout(400);s0=await E("()=>pzStakeOf('gloop')");await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(400)
        r=await E("()=>[PZ.sel,pzStakeOf('gloop'),(document.querySelector('.pzfacts')||{}).textContent]")
        chk('hub keys: 1 picks Gloop, right arrow raises the stake, the spotlight shows your 2-1 record',r[0]=='gloop' and r[1]>s0 and '2-1' in r[2],[s0,r])
        await pg.keyboard.press('r');await pg.wait_for_timeout(900)
        r=await E("()=>({cards:document.querySelectorAll('.pzrg').length,open:document.querySelectorAll('.pzrg:not(.lock)').length,stats:document.querySelectorAll('.pzrgst>div').length,tro:document.querySelectorAll('.pzrgtr>div').length})")
        chk('The Regulars: seven cards (three open), twelve numbers and the pool trophies',r['cards']==7 and r['open']==3 and r['stats']==12 and r['tro']>=10,r)
        await pg.click('.pzrg[data-k=moldwick]');await pg.wait_for_timeout(900)
        chk('The Regulars: clicking a regular goes back to the bar with them picked',await E("()=>!!document.getElementById('pzh')&&PZ.sel==='moldwick'"))
        await E("()=>{P.pz=null;save();PZ.sel=null;PZ_TUT_OFF=false;pzHub();0;}")
        await wf(pg,"document.querySelector('.pztuc.in')",n=30,step=150)
        n=0
        for i in range(9):
            t=await E("()=>{const e=document.querySelector('.pztu:not(.out) .pztut');return e?e.textContent:null}")
            if not t:break
            n+=1;await pg.click('.pztu:not(.out) .pztun');await pg.wait_for_timeout(480)
        r=await E("()=>[PZS().tut.hub|0,!!document.querySelector('.pztu:not(.out)'),PZ.on,PZ_TUT_OFF,!!document.getElementById('pzh'),PZ.tok]")
        chk('hub tour: seven steps on a first visit, then it is done for good',n==7 and r[0]==1 and not r[1] and not r[2],[n,r])
        await E("()=>{pzHub();0;}");await pg.wait_for_timeout(1200)
        chk('hub tour: it does not come back on the next visit',await E("()=>!document.querySelector('.pztu')"))
        await E("()=>{PZ_TUT_OFF=true;0;}")
        # -------------------------------------------------------- a match: stake, tips, shot, pause menu
        await E("()=>{P.pz=null;P.gold=10000;PZ_TUT_OFF=false;const Z=PZS();Z.tut.hub=1;save()}");await start(pg,'gloop',200,5)
        await wf(pg,"document.querySelector('.pztuc.in')",n=30,step=150)
        r=await E("()=>({gold:P.gold,dayN:PZS().dayN,ph:PZ.ph,mode:PZ.mode,balls:PZ.B.filter(b=>b.on).length,brk:PZ.st.brk,tut:(document.querySelector('.pztut')||{}).textContent,clk:PZ.clockOn})")
        chk('match start: stake taken once, daily counter up, 16 balls, break, the first-match tutorial opens (no clock against Gloop)',r['gold']==9800 and r['dayN']==1 and r['balls']==16 and r['brk'] and r['tut']=='Welcome to the table!' and r['clk']==False,r)
        await pg.click('.pztun');await pg.wait_for_timeout(450)
        r=await E("()=>[(document.querySelector('.pztut')||{}).textContent,!!document.querySelector('.pztu.spot')]")
        chk('tutorial: Next moves on to Aim with a spotlight on the table',r[0]=='Aim' and r[1],r)
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(400)
        r=await E("()=>[!!document.querySelector('.pztu:not(.out)'),PZS().tut.m1|0,PZ.paused]")
        chk('tutorial: Esc skips it for good and does not pause the match',not r[0] and r[1]==1 and not r[2],r)
        await E("()=>{PZ_TUT_OFF=true}")
        r=await E("()=>[PZ.aim.pow,PZ.aim.ang]")
        chk('the break starts at a strong default power',r[0]>=.75,r)
        await E("()=>{pzPauseMenu()}");await pg.wait_for_timeout(300)
        chk('pause menu opens',await E("()=>!!document.querySelector('#pzmod [data-a=resume]')&&PZ.paused"))
        await E("()=>{pzModalClose();0;}");await pg.wait_for_timeout(200)
        await E("()=>{PZ.aim.ang=0;PZ.cueAng=0;PZ.fineOff=0;0;}");await pg.mouse.move(700,300);await pg.mouse.move(800,700,steps=4);a0=await E("()=>PZ.aim.ang");await pg.mouse.move(820,830);await pg.mouse.move(1000,860,steps=6)
        a1=await E("()=>PZ.aim.ang");await pg.mouse.move(700,330,steps=6);a2=await E("()=>PZ.aim.ang")
        chk('aim holds still while the pointer is over the bottom bar, and follows it again over the table',abs(a1-a0)<1e-6 and abs(a2-a1)>0.05,[a0,a1,a2])
        await E("()=>{PZ.aim.ang=0;PZ.cueAng=0;PZ.fineOff=0;0;}");c=await E("()=>[PZ_G.x+PZ.B[0].x,PZ_G.y+PZ.B[0].y]")
        await pg.mouse.move(c[0]+120,c[1]);await E("()=>{PZ.aim.ang=0;PZ.cueAng=0;0;}");await pg.mouse.down();await pg.mouse.move(c[0]+120,c[1]+90,steps=6);await pg.mouse.move(c[0]+110,c[1]+120,steps=4);await pg.mouse.up();await pg.wait_for_timeout(250)
        r=await E("()=>[PZ.ph,(document.getElementById('pzsub')||{}).textContent||'']")
        chk('a sideways flick does not shoot and says to pull straight back',r[0]=='aim' and 'straight back' in r[1],r)
        await E("()=>{pzPauseMenu();0;}");await pg.wait_for_timeout(300)
        await pg.click('[data-a=set]');await pg.wait_for_timeout(250);await pg.click('[data-a=back]');await pg.wait_for_timeout(250)
        chk('pause menu: Settings and Back returns to the pause menu',await E("()=>!!document.querySelector('#pzmod [data-a=rules]')"))
        await pg.click('[data-a=rules]');await pg.wait_for_timeout(250);await pg.click('[data-a=back]');await pg.wait_for_timeout(250)
        chk('pause menu: House rules and Back returns to the pause menu',await E("()=>!!document.querySelector('#pzmod [data-a=forfeit]')"))
        await pg.click('[data-a=forfeit]');await pg.wait_for_timeout(250);await pg.click('[data-a=no]');await pg.wait_for_timeout(250)
        chk('pause menu: Forfeit then Keep playing returns to the pause menu',await E("()=>!!document.querySelector('#pzmod [data-a=resume]')"))
        await pg.click('[data-a=resume]');await pg.wait_for_timeout(250)
        chk('resume closes the menu and the match goes on',await E("()=>!PZ.modal&&!PZ.paused&&PZ.ph==='aim'"))
        await E("()=>{PZ.speed=3;pzFireHuman()}")
        for i in range(60):
            await pg.wait_for_timeout(300)
            if await E("()=>PZ.ph==='ai'||PZ.ph==='aim'&&PZ.st.turn===0&&PZ.st.shots>0||PZ.ph==='endhold'"):break
        r=await E("()=>({ph:PZ.ph,shots:PZ.st.shots,live:!!PZS().live,err:0})")
        chk('a human break plays out, is judged and the match goes on',r['shots']>=1 and r['live'],r)
        # -------------------------------------------------------- forfeit / resume / shot clock
        await E("()=>{PZ.speed=1}")
        await E("()=>{const t=PZ.tok;PZ.tok;}")
        r=await E("()=>{if(PZ.ph==='aim'&&PZ.st.turn===0){PZ.clock=.05;return 1}return 0}");await pg.wait_for_timeout(700)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(800)
        r=await E("()=>({gold:P.gold,live:PZS().live,losses:PZS().losses,res:!!document.querySelector('.pzresc.lose')})")
        chk('forfeit: the stake is gone, no live match is kept, the loss screen shows',r['gold']==9800 and not r['live'] and r['losses']==1 and r['res'],r)
        chk('results: the stats strip shows four tiles',await E("()=>document.querySelectorAll('.pzstat>div').length==4"))
        # reload mid-match then resume
        await E("()=>{pzHub()}");await pg.wait_for_timeout(300);await E("()=>{pzStart({opp:'moldwick',stake:100,seed:8})}");await pg.wait_for_timeout(400);await E("()=>SC.skip()");await E("()=>SC.ready()");await pg.wait_for_timeout(200)
        snap=await E("()=>({B:PZ.B.map(b=>[b.id,Math.round(b.x),Math.round(b.y),b.on?1:0]),gold:P.gold})")
        await pg.reload();await pg.wait_for_timeout(1500);await E(PRE.replace('P.gold=100000;P.pz=null;save()','0'));await E(HELP)
        chk('reload mid-match: the stake stays taken',await E("()=>P.gold")==snap['gold'],(snap['gold']))
        await E("()=>{casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(800)
        chk('reload mid-match: a resume prompt is waiting',await E("()=>!!document.getElementById('pzresume')"))
        await pg.click('#pzrs1');await pg.wait_for_timeout(1200)
        r=await E("()=>PZ.B.map(b=>[b.id,Math.round(b.x),Math.round(b.y),b.on?1:0])")
        chk('resume puts every ball back where it was',json.dumps(r)==json.dumps(snap['B']),(r[:2],snap['B'][:2]))
        await E("()=>SC.ready()");await E("()=>{PZ.clock=.05}");await pg.wait_for_timeout(700)
        r=await E("()=>({bih:PZ.st.bih,turn:PZ.st.turn})")
        chk('shot clock: running out of time is a foul and hands over ball in hand',r['bih'] and r['turn']==1,r)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(600)
        # -------------------------------------------------------- limits
        await E("()=>{P.gold=10000;P.pz=null;save();pzHub()}");await pg.wait_for_timeout(300)
        r=await E("()=>[pzStart({opp:'gloop',stake:6000,seed:1}),P.gold]")
        chk('a stake above the 5,000 cap is refused and nothing is taken',r[0]==False and r[1]==10000,r)
        r=await E("()=>{const o=[];for(const id in PZ_REG){const R=PZ_REG[id];if(R.venue==='hoard')continue;/* 10.7: the Gilded Hoard has its own 50,000 ceiling (t_pzd107) */for(const st of(R.stakes.length?R.stakes:[500,1000,2000,3000,5000]))o.push(Math.round(st*pzMultS(id,st)))}return {mx:Math.max(...o),m5:pzMultS('mortimer',5000),m2:pzMultS('mortimer',2000),lo:pzMultS('gloop',50)}}")
        chk('no payout can pass 15,000 and the multiplier shrinks to fit (Mortimer 5,000 pays x3.0)',r['mx']<=15000 and r['m5']==3 and r['m2']==3.5 and r['lo']>=1.15,r)
        await E("()=>{P.gold=20;pzHub()}");await pg.wait_for_timeout(300)
        r=await E("()=>[pzStart({opp:'gloop',stake:200,seed:1}),P.gold]")
        chk('not enough gold: refused, nothing taken',r[0]==False and r[1]==20,r)
        await E("()=>{P.gold=10000;PZS().dayN=PZ_DAILY;save();pzHub()}");await pg.wait_for_timeout(300)
        await E("()=>{pzStart({opp:'gloop',stake:200,seed:1})}");await pg.wait_for_timeout(400)
        r=await E("()=>({gold:P.gold,practice:PZ.M.practice,stake:PZ.M.stake})")
        chk('after 20 paid matches a day the next one is a free friendly',r['gold']==10000 and r['practice'] and r['stake']==0,r)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(500)
        # -------------------------------------------------------- review fixes
        await E("()=>{P.gold=10000;P.pz=null;save();pzHub()}");await pg.wait_for_timeout(300)
        await E("()=>{PZ.reg=PZ_REG.vesper;pzResults({win:true,opp:'vesper',stake:500,score:[2,1],race:2,practice:false,pay:1000,bonus:0,bnr:0,golden:0,pots:9,banks:0,time:100,unlocks:[],mult:2,forfeit:false,beatN:1});0;}");await pg.wait_for_timeout(300)
        r=await E("()=>{const g=P.gold;window.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',repeat:true}));window.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter'}));return {g0:g,g1:P.gold,live:!!PZS().live,on:PZ.on}}")
        chk('a held (or too early) Enter on the results screen never starts a new paid match',r['g0']==r['g1'] and not r['live'] and not r['on'],r)
        await E("()=>{P.gold=10000;P.pz=null;save();pzHub()}");await pg.wait_for_timeout(200)
        r=await E("()=>{PZ.resAt=0;const Z=PZS();Z.streak=5;Z.losses=0;Z.live={v:PZ_LIVE_V,pre:1,opp:'gloop',stake:0,mult:1,race:1,practice:true,extended:false,score:[0,0],rack:1,breaker:0,bnr:0,golden:0,pots:0,banks:0,racks:[],bonus:0,seed:5,st:null,B:Array.from({length:16},(_,i)=>[i,0,0,1]),pend:null,rattled:0};save();pzHub();const b=document.getElementById('pzrs2');if(!b)return {err:'no resume prompt',live:JSON.stringify(Z.live).slice(0,80)};b.click();b.click();return {streak:Z.streak,losses:Z.losses,live:!!Z.live}}")
        chk('dropping a practice match from the resume prompt is not a loss and keeps the streak',r.get('streak')==5 and r.get('losses')==0 and r.get('live')==False,r)
        r=await E("()=>{PZ.fineBtn=true;window.dispatchEvent(new MouseEvent('pointerup',{button:2}));const a=PZ.fineBtn;PZ.fineBtn=true;window.dispatchEvent(new Event('blur'));return [a,PZ.fineBtn]}")
        chk('right-button fine aim cannot stick after a release outside the table or a blur',r==[False,False],r)
        r=await E("()=>{const Z=PZS();Z.live=null;P.gold=20000;save();pzStart({opp:'mortimer',stake:5000,seed:3});const M=PZ.M;M.bnr=3;M.golden=2;M.score=[3,0];M.race=3;M.over={winner:0,why:'8 ball'};let got=null;const o=window.pzResults;window.pzResults=function(r){got=r;return o.apply(this,arguments)};pzMatchEnd();window.pzResults=o;return {pay:got&&got.pay,bonus:got&&got.bonus,mult:M.mult}}")
        chk('a win with break-and-run and golden bonuses still pays exactly the 15,000 ceiling at most',r['pay']==15000,r)
        await E("()=>{PZS().live=null;PZ.on=false;save();pzHub()}");await pg.wait_for_timeout(300)
        # -------------------------------------------------------- the 8: call, slow motion
        await E("()=>{P.pz=null;P.gold=10000;save();pzHub()}");await pg.wait_for_timeout(300);await start(pg,'vesper',500,6)
        await E("()=>SC.on8()");await pg.wait_for_timeout(500)
        r=await E("()=>({hint:document.getElementById('pzhint').textContent,pk:document.querySelectorAll('#pztip.on').length})")
        chk('the last ball: the hint says how the 8 is called (no stray "?")','the 8' in r['hint'].lower() and 'pocket' in r['hint'] and ('?' not in r['hint']),r)
        await E("()=>{const B=PZ.B;B[0].x=440;B[0].y=300;B[8].x=560;B[8].y=190;const e=B[8],px=PZ_AIM[2][0],py=PZ_AIM[2][1],ux=px-e.x,uy=py-e.y,l=Math.hypot(ux,uy),gx=e.x-ux/l*24,gy=e.y-uy/l*24;PZ.aim.ang=PZ.cueAng=Math.atan2(gy-B[0].y,gx-B[0].x);PZ.aim.pow=.42;PZ.call=2;PZ.callManual=true;PZ.cueAv=0;pzFireHuman()}")
        slow=False
        for i in range(400):
            await pg.wait_for_timeout(60)
            if await E("()=>!!(PZ.slow&&PZ.slow.on)||PZ.slowDone"):slow=True;break
        chk('the deciding 8 rolling at its pocket triggers slow motion',slow)
        for i in range(60):
            await pg.wait_for_timeout(250)
            if await E("()=>PZ.ph==='endhold'||PZ.ph==='ai'||PZ.ph==='over'"):break
        r=await E("()=>({score:PZ.M.score.slice(),ph:PZ.ph})")
        chk('potting the 8 in the called pocket wins the rack',r['score'][0]==1,r)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(500)
        # -------------------------------------------------------- Trick Shots
        await E("()=>{P.pz=null;P.gold=1000;save();pzHub()}");await pg.wait_for_timeout(300)
        r=await E("""()=>PZ_TRICK.map(t=>{const ids=[0,...t.balls.map(b=>b[0])],pts=[t.cue,...t.balls.map(b=>[b[1],b[2]])];let ok=new Set(ids).size===ids.length;for(const [x,y] of pts)if(x<30||x>850||y<30||y>410)ok=false;for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++)if(Math.hypot(pts[i][0]-pts[j][0],pts[i][1]-pts[j][1])<26)ok=false;return ok&&t.goal.pot.every(id=>ids.includes(id))})""")
        chk('ten trick shot layouts, all balls on the cloth and apart, every goal ball exists',len(r)==10 and all(r),r)
        await E("()=>pzTrick()");await pg.wait_for_timeout(500)
        r=await E("()=>({cards:document.querySelectorAll('.pzti').length,imgs:document.querySelectorAll('.pzti .pztf img').length})")
        chk('trick shot list: ten cards with mini tables and balls',r['cards']==10 and r['imgs']>=13,r)
        await pg.click('.pzti[data-i="0"]');await wf(pg,"PZ.ph==='aim'&&PZ.mode==='aim'&&PZ.M.trick")
        chk('a puzzle starts: you aim, one table, the goal line',await E("()=>PZ.ph==='aim'&&PZ.M.trick.n===0&&PZ.B.filter(b=>b.on).length===2&&document.getElementById('pzhint').textContent.startsWith('Goal')"))
        await E("()=>{PZ.aim.ang+=0.7;PZ.aim.pow=.5}");await pg.wait_for_timeout(700);await E("()=>pzFireHuman()")
        await wf(pg,"PZ.ph==='gap'");await wf(pg,"PZ.ph==='aim'&&PZ.M.trick.tries===1")
        r=await E("()=>({ph:PZ.ph,tries:PZ.M.trick.tries,balls:PZ.B.filter(b=>b.on).length})")
        chk('a miss resets the layout and counts a try',r['ph']=='aim' and r['tries']==1 and r['balls']==2,r)
        await E("()=>{PZ.aim.ang=pzDefaultAim();PZ.aim.pow=.6}");await pg.wait_for_timeout(700);await E("()=>pzFireHuman()")
        await wf(pg,"PZ.ph==='trickdone'");await wf(pg,"document.querySelector('#pzmod [data-a=next]')")
        r=await E("()=>({stars:PZS().trick[0],paid:PZS().trick.$0||0,gold:P.gold,modal:!!document.querySelector('#pzmod [data-a=next]')})")
        chk('solving on the second try earns 3 stars and 200 gold, and the done panel offers the next puzzle',r['stars']==3 and r['paid']==1 and r['gold']==1200 and r['modal'],r)
        await pg.click('[data-a=again]');await wf(pg,"PZ.ph==='aim'&&PZ.mode==='aim'&&PZ.M.trick.tries===0")
        await E("()=>{PZ.aim.ang=pzDefaultAim();PZ.aim.pow=.6}");await pg.wait_for_timeout(700);await E("()=>pzFireHuman()")
        await wf(pg,"PZ.ph==='trickdone'");await wf(pg,"document.querySelector('#pzmod [data-a=list]')")
        r=await E("()=>({stars:PZS().trick[0],paid:PZS().trick.$0||0,gold:P.gold})")
        chk('solving it again keeps 3 stars and pays nothing more (the 200 gold is one-time)',r['stars']==3 and r['paid']==1 and r['gold']==1200,r)
        await pg.click('[data-a=list]');await pg.wait_for_timeout(500)
        chk('back to the list: the stars show',await E("()=>document.querySelectorAll('.pzti em.st3').length==1"))
        # -------------------------------------------------------- trophies
        r=await E("()=>['pz1','pz100','pzbnr','pzgold','pzbank','pzall','pzchamp','pzpro','pzshade','pztaunt','pztrick','pzw25'].map(id=>typeof ACH!=='undefined'?!!ACH.find(a=>a.id===id):null)")
        chk('all twelve pool trophies are registered',r.count(True)==12 or r==[None]*12,r)
        # -------------------------------------------------------- frame cost
        await E("()=>{P.pz=null;P.gold=10000;save();pzHub()}");await pg.wait_for_timeout(300);await start(pg,'gloop',100,5);await pg.wait_for_timeout(1500)
        r=await E("""()=>{const t=[];PZ.speed=1;for(let i=0;i<12;i++)pzFrame(PZ.g);for(let i=0;i<90;i++){const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [t[Math.floor(t.length*.5)],t[Math.floor(t.length*.95)]]}""")
        chk('aiming frame cost is small (median under 4 ms, p95 under 12 ms in headless)',r[0]<4 and r[1]<12,r)
        await E("()=>{PZ.aim.pow=.95;pzFireHuman()}");await pg.wait_for_timeout(900)
        r=await E("""()=>{const t=[];for(let i=0;i<3;i++)pzFrame(PZ.g);for(let i=0;i<40;i++){const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [t[Math.floor(t.length*.5)],t[Math.floor(t.length*.9)]]}""")
        chk('break frame cost with 15 balls moving is fine (median under 8 ms, p90 under 18 ms in headless)',r[0]<8 and r[1]<18,r)
        # -------------------------------------------------------- one whole match at accelerated time, with the money checked
        await E("()=>{PZ.speed=1;pzForfeit()}");await pg.wait_for_timeout(400)
        await E("()=>{P.pz=null;P.gold=20000;save();pzHub()}");await pg.wait_for_timeout(300)
        g0=await E("()=>P.gold")
        await E("()=>{casinoOpen();gameOpen('pz');pzStart({opp:'gloop',stake:200,seed:21});window.__a=pzAuto({speed:8});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},400)}")
        done=False
        for i in range(260):
            await pg.wait_for_timeout(1000)
            if await E("()=>!!document.querySelector('.pzresc')"):done=True;break
        r=await E("()=>({res:PZ.result,gold:P.gold,err:__a.err||null,live:!!PZS().live,dayN:PZS().dayN})")
        chk('a whole match runs to a result with no errors',done and not r['err'],r)
        if done:
            res=r['res'];exp=g0-200+(res['pay']+100 if res['win'] else 0)
            chk('the money matches the result (win pays stake x multiplier + bonus + the 100 first-win bonus for Gloop, loss pays nothing)',r['gold']==exp and (not res['win'] or res['pay']>=200*res['mult']-1) and not r['live'],(r,exp))
            q=await E("()=>({why:(document.querySelector('.pzwhy')||{}).textContent||'',strip:document.querySelectorAll('.pzstrip span').length,fb:document.querySelectorAll('.pzun.fb').length,first:(PZS().first||{}).gloop|0})")
            chk('results: how it ended, one strip chip per rack, and the first-win bonus card on a first win',len(q['why'])>8 and q['strip']==sum(res['score']) and (q['fb']==1 and q['first']==1 if res['win'] else q['fb']==0),q)
        chk('no page errors in the whole run',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
