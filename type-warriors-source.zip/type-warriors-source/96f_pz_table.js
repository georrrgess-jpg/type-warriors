/* ===== 9.4 THE CROOKED CUE: the table and the tavern, baked once (96f) =====
   Stage 1600 x 900. The playfield (physics origin) sits at (PZ_G.x, PZ_G.y). The cushions are traced from the exact physics edges
   (PZ_TBL), so what you see is where balls bounce. One baked canvas holds the room and the table; the lamp, bulbs, dust, balls and
   characters are drawn on top each frame. Never use ctx.filter or shadowBlur here: gradients and layered alpha only. */
const PZ_G={x:360,y:214,w:880,h:440,rail:44,trayY:728,trayX0:392,trayX1:1214,lampX:800,lampY:150};
const pzMix=(a,b,t)=>{const p=s=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16));const A=p(a),B=p(b);return'#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')};
const pzNoise=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
const pzCv=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
const pzLin=(g,x0,y0,x1,y1,st)=>{const q=g.createLinearGradient(x0,y0,x1,y1);st.forEach(([o,c])=>q.addColorStop(o,c));return q};
const pzRR=(g,x,y,w,h,r)=>{g.beginPath();g.roundRect(x,y,w,h,r)};
/* a radial light sprite (cached per colour) stamped with 'lighter' */
const PZ_GL={};
function pzGlowS(col){if(PZ_GL[col])return PZ_GL[col];const c=pzCv(64,64),x=c.getContext('2d'),q=x.createRadialGradient(32,32,0,32,32,32);q.addColorStop(0,col);q.addColorStop(.35,col.replace(/[\d.]+\)$/,'.35)'));q.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=q;x.fillRect(0,0,64,64);return PZ_GL[col]=c}
function pzGlow(g,x,y,r,col,a){g.save();g.globalCompositeOperation='lighter';g.globalAlpha=a==null?1:a;g.drawImage(pzGlowS(col),x-r,y-r,r*2,r*2);g.restore()}
/* the physics boundary loop as screen-space points (clockwise from the top-left corner jaw) */
function pzLoop(){const {W:w,H:h,CM,SM}=PZ_PHY,J=17,K=16;return[[CM-J,-J],[CM,0],[w/2-SM,0],[w/2-SM+5,-K],[w/2+SM-5,-K],[w/2+SM,0],[w-CM,0],[w-CM+J,-J],[w+J,CM-J],[w,CM],[w,h-CM],[w+J,h-CM+J],[w-CM+J,h+J],[w-CM,h],[w/2+SM,h],[w/2+SM-5,h+K],[w/2-SM+5,h+K],[w/2-SM,h],[CM,h],[CM-J,h+J],[-J,h-CM+J],[0,h-CM],[0,CM],[-J,CM-J]]}
/* the pockets as drawn: centre, hole radius, rim radius */
const PZ_POCK=[[-3,-3,22,33],[440,-12,19,29],[883,-3,22,33],[-3,443,22,33],[440,452,19,29],[883,443,22,33]];
/* ---------- the room ---------- */
function pzBakeRoom(g,o){o=o||{};const fy=592;
 /* back wall: vertical planks with grain and nail heads */
 g.fillStyle='#2a1610';g.fillRect(0,0,1600,900);
 for(let i=0;i<40;i++){const x=i*40;g.fillStyle=pzMix('#3a2014','#4e2c1a',pzNoise(i));g.fillRect(x,0,38,fy);g.fillStyle='rgba(0,0,0,.4)';g.fillRect(x+38,0,2,fy);g.fillStyle='rgba(255,210,150,.05)';g.fillRect(x+2,0,2,fy);
  for(let k=0;k<4;k++){g.strokeStyle='rgba(20,8,4,.26)';g.lineWidth=1.4;g.beginPath();const yy=pzNoise(i*9+k)*fy;g.moveTo(x+6,yy);g.quadraticCurveTo(x+18,yy+26,x+32,yy+8);g.stroke()}
  for(const ny of[150,330,510]){g.fillStyle='rgba(20,10,6,.7)';g.beginPath();g.arc(x+19,ny+pzNoise(i+ny)*6,1.6,0,TAU);g.fill()}}
 /* wainscot rail */
 g.fillStyle=pzLin(g,0,fy-60,0,fy,[[0,'#5a3418'],[1,'#3a2010']]);g.fillRect(0,fy-60,1600,60);g.fillStyle='#7a4a24';g.fillRect(0,fy-62,1600,6);g.fillStyle='rgba(0,0,0,.4)';g.fillRect(0,fy-4,1600,4);
 for(let i=0;i<14;i++){g.strokeStyle='rgba(0,0,0,.35)';g.lineWidth=3;g.strokeRect(20+i*115,fy-52,100,40)}
 /* shelf of bottles along the top (the HUD sits in front of it) */
 g.fillStyle='#5a3418';g.fillRect(0,118,1600,16);g.fillStyle='#2a140a';g.fillRect(0,134,1600,6);g.fillStyle='rgba(255,210,150,.16)';g.fillRect(0,118,1600,2);
 const bc=['#3aa85a','#c83a3a','#7ad8ff','#d8a03a','#9a5ad8','#ff9a3a','#5ad8b8'];
 for(let i=0;i<46;i++){const x=20+i*35+pzNoise(i)*8,h=40+pzNoise(i+3)*34,w=16+pzNoise(i+7)*8,c=bc[i%7];g.globalAlpha=.88;g.fillStyle=c;pzRR(g,x,118-h,w,h,5);g.fill();pzRR(g,x+w*.3,118-h-14,w*.4,16,3);g.fill();g.globalAlpha=1;
  g.strokeStyle=PZ_O;g.lineWidth=2;pzRR(g,x,118-h,w,h,5);g.stroke();g.fillStyle='rgba(255,255,255,.4)';g.fillRect(x+3,118-h+6,3,h-12);g.fillStyle='rgba(255,240,200,.5)';g.fillRect(x+w*.5-5,118-h*.45,10,12)}
 /* left: a tall night window; right: a dartboard and a wanted poster */
 {const x=36,y=168,w=170,h=300;g.fillStyle='#1a0e08';pzRR(g,x-12,y-12,w+24,h+24,14);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  g.fillStyle=pzLin(g,0,y,0,y+h,[[0,'#0a0a3a'],[1,'#2a2a7a']]);g.fillRect(x,y,w,h);
  for(let i=0;i<30;i++){g.fillStyle=`rgba(255,255,255,${.25+pzNoise(i+40)*.6})`;g.fillRect(x+4+pzNoise(i)*(w-8),y+4+pzNoise(i+9)*(h*.7),2,2)}
  g.fillStyle='#fff4d0';g.beginPath();g.arc(x+w*.68,y+70,26,0,TAU);g.fill();g.fillStyle='#d8c890';g.beginPath();g.arc(x+w*.68-8,y+64,6,0,TAU);g.arc(x+w*.68+9,y+80,4,0,TAU);g.fill();
  g.fillStyle='#0a0a22';g.beginPath();g.moveTo(x,y+h);g.lineTo(x,y+h-70);g.lineTo(x+40,y+h-100);g.lineTo(x+86,y+h-60);g.lineTo(x+120,y+h-110);g.lineTo(x+w,y+h-70);g.lineTo(x+w,y+h);g.fill();
  g.strokeStyle='#2a1408';g.lineWidth=8;g.beginPath();g.moveTo(x+w/2,y);g.lineTo(x+w/2,y+h);g.moveTo(x,y+h*.45);g.lineTo(x+w,y+h*.45);g.stroke();g.strokeStyle='rgba(255,210,150,.18)';g.lineWidth=2;g.beginPath();g.moveTo(x+w/2-3,y);g.lineTo(x+w/2-3,y+h);g.stroke();
  g.fillStyle='rgba(255,255,255,.05)';g.beginPath();g.moveTo(x+10,y+10);g.lineTo(x+60,y+10);g.lineTo(x+20,y+h-10);g.lineTo(x+10,y+h-10);g.fill()}
 {const cx=1490,cy=262,r=64;g.fillStyle='#1a0e08';g.beginPath();g.arc(cx,cy,r+12,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  const rings=[['#e8dcc0',r],['#12081f',r*.88],['#c83a3a',r*.72],['#e8dcc0',r*.58],['#2a8a4a',r*.42],['#e8dcc0',r*.3],['#c83a3a',r*.16]];for(const [c,rr] of rings){g.fillStyle=c;g.beginPath();g.arc(cx,cy,rr,0,TAU);g.fill()}
  g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=1.5;for(let i=0;i<20;i++){const a=i/20*TAU;g.beginPath();g.moveTo(cx+Math.cos(a)*r*.16,cy+Math.sin(a)*r*.16);g.lineTo(cx+Math.cos(a)*r*.9,cy+Math.sin(a)*r*.9);g.stroke()}
  for(const [dx,dy,a] of[[-14,-8,.5],[16,10,-.3],[-30,18,1.1]]){g.strokeStyle='#8a5a2a';g.lineWidth=3;g.beginPath();g.moveTo(cx+dx,cy+dy);g.lineTo(cx+dx-Math.cos(a)*18,cy+dy-Math.sin(a)*18);g.stroke();g.fillStyle='#c83a3a';g.beginPath();g.moveTo(cx+dx-Math.cos(a)*18,cy+dy-Math.sin(a)*18);g.lineTo(cx+dx-Math.cos(a)*28+3,cy+dy-Math.sin(a)*28-6);g.lineTo(cx+dx-Math.cos(a)*28-3,cy+dy-Math.sin(a)*28+6);g.fill()}
  /* poster */
  g.save();g.translate(1390,420);g.rotate(-.04);g.fillStyle='#d8c898';g.strokeStyle=PZ_O;g.lineWidth=3;g.fillRect(-52,-70,104,140);g.strokeRect(-52,-70,104,140);g.fillStyle='#5a3a1a';g.font='400 22px "Pirata One",Georgia,serif';g.textAlign='center';g.fillText('PLAY FOR',0,-44);g.fillText('KEEPS',0,-22);
  g.fillStyle='#2a1a0a';g.beginPath();g.arc(0,16,22,0,TAU);g.fill();g.fillStyle='#d8c898';g.beginPath();g.arc(0,16,13,0,TAU);g.fill();g.fillStyle='#14121a';g.beginPath();g.arc(0,16,7,0,TAU);g.fill();g.fillStyle='#5a3a1a';g.font='700 11px Poppins,sans-serif';g.fillText('8 BALL RULES',0,56);g.restore()}
 /* floor: wide planks in perspective-ish rows */
 g.fillStyle='#34200f';g.fillRect(0,fy,1600,900-fy);
 for(let r=0;r<8;r++){const y=fy+r*40+r*r*1.5,hh=38+r*1.5;g.fillStyle=r%2?'#3e2716':'#331e0e';g.fillRect(0,y,1600,hh);g.fillStyle='rgba(255,210,150,.05)';g.fillRect(0,y,1600,2);g.fillStyle='rgba(0,0,0,.45)';g.fillRect(0,y+hh-2,1600,2);
  for(let k=0;k<10;k++){const x=((k*197+r*113)%1700)-60;g.fillStyle='rgba(0,0,0,.45)';g.fillRect(x,y,2,hh)}}
 g.fillStyle=pzLin(g,0,fy-24,0,fy+36,[[0,'rgba(0,0,0,0)'],[1,'rgba(0,0,0,.55)']]);g.fillRect(0,fy-24,1600,60);
 /* barrels either side of the room */
 for(const bx of[30,1570]){g.fillStyle=pzLin(g,bx-50,0,bx+50,0,[[0,'#3a1e0e'],[.4,'#6a3a1a'],[1,'#2a1408']]);g.beginPath();g.ellipse(bx,780,52,16,0,0,TAU);g.fill();g.fillRect(bx-52,640,104,140);g.beginPath();g.ellipse(bx,640,52,16,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.moveTo(bx-52,640);g.lineTo(bx-52,780);g.moveTo(bx+52,640);g.lineTo(bx+52,780);g.stroke();
  g.fillStyle='#1a1a22';for(const yy of[660,712,764]){g.fillRect(bx-52,yy,104,8)}g.fillStyle='#4a2a14';g.beginPath();g.ellipse(bx,640,44,12,0,0,TAU);g.fill()}
 /* the string-light wire (bulbs are drawn live) */
 g.strokeStyle='#120a06';g.lineWidth=2;g.beginPath();g.moveTo(0,30);for(let x=0;x<=1600;x+=200)g.quadraticCurveTo(x+100,70,x+200,30);g.stroke();
 /* a warm vignette */
 const v=g.createRadialGradient(800,460,300,800,460,1020);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(6,2,12,.8)');g.fillStyle=v;g.fillRect(0,0,1600,900)}
/* ---------- the table ---------- */
function pzBakeTable(g,felt,o){o=o||{};const G=PZ_G,{W:w,H:h}=PZ_PHY,rail=G.rail;g.save();g.translate(G.x,G.y);
 /* floor shadow and legs */
 g.fillStyle='rgba(0,0,0,.5)';g.beginPath();g.ellipse(w/2,h+rail+78,w*.64,64,0,0,TAU);g.fill();
 for(const lx of[-rail+22,w+rail-70]){g.fillStyle=pzLin(g,lx,0,lx+48,0,[[0,'#3a1e0e'],[.5,'#70401a'],[1,'#2a1408']]);pzRR(g,lx,h+rail+8,48,104,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='#d8a03a';g.fillRect(lx+4,h+rail+34,40,6);g.fillRect(lx+4,h+rail+84,40,6)}
 /* apron with the ball-return groove */
 g.fillStyle=pzLin(g,0,h+rail-8,0,h+rail+52,[[0,'#6e3818'],[.55,'#4e2610'],[1,'#2e1408']]);pzRR(g,-rail-8,h+rail-8,w+rail*2+16,58,12);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.fillStyle='rgba(255,220,170,.14)';g.fillRect(-rail,h+rail-6,w+rail*2,2);
 {const ty=G.trayY-G.y,x0=G.trayX0-G.x,x1=G.trayX1-G.x;g.fillStyle='#1a0c06';pzRR(g,x0-14,ty-15,x1-x0+28,30,15);g.fill();g.fillStyle=pzLin(g,0,ty-13,0,ty+13,[[0,'#0e0604'],[1,'#3a1c0c']]);pzRR(g,x0-10,ty-12,x1-x0+20,24,12);g.fill();
  g.strokeStyle='#d8a03a';g.lineWidth=2.5;pzRR(g,x0-14,ty-15,x1-x0+28,30,15);g.stroke();
  /* the ball-return chute: potted balls come out of this brass-ringed mouth */
  g.fillStyle='#0a0504';g.beginPath();g.ellipse(x1+20,ty,11,16,0,0,TAU);g.fill();g.strokeStyle='#d8a03a';g.lineWidth=3;g.stroke();g.strokeStyle='rgba(255,240,200,.4)';g.lineWidth=1.4;g.beginPath();g.arc(x1+20,ty,13,Math.PI*1.1,Math.PI*1.6);g.stroke();g.strokeStyle='rgba(255,240,200,.35)';g.lineWidth=1.2;g.beginPath();g.moveTo(x0-4,ty-14);g.lineTo(x1+4,ty-14);g.stroke()}
 /* wooden rails */
 const wood=pzLin(g,0,-rail,0,h+rail,[[0,'#9a5424'],[.35,'#6e3616'],[.7,'#7e4018'],[1,'#5a2c10']]);
 g.fillStyle=wood;pzRR(g,-rail,-rail,w+rail*2,h+rail*2,28);g.fill();g.strokeStyle=PZ_O;g.lineWidth=5;g.stroke();
 for(let i=0;i<70;i++){const yy=-rail+4+pzNoise(i)*(h+rail*2-8);g.strokeStyle=`rgba(40,16,4,${.14+pzNoise(i+5)*.18})`;g.lineWidth=1+pzNoise(i+9);g.beginPath();g.moveTo(-rail+8,yy);g.bezierCurveTo(w*.3,yy+7*Math.sin(i),w*.7,yy-7*Math.cos(i),w+rail-8,yy+3);g.stroke()}
 g.strokeStyle='rgba(255,220,170,.28)';g.lineWidth=2;pzRR(g,-rail+5,-rail+5,w+rail*2-10,h+rail*2-10,24);g.stroke();
 /* sheen on the top rail */
 g.fillStyle=pzLin(g,0,-rail,0,-rail+18,[[0,'rgba(255,230,190,.28)'],[1,'rgba(255,230,190,0)']]);g.fillRect(-rail+20,-rail+4,w+rail*2-40,18);
 /* diamonds (mother of pearl) */
 const dia=(x,y,vert)=>{g.fillStyle='#f6efd8';g.beginPath();if(vert){g.moveTo(x,y-7);g.lineTo(x+4.5,y);g.lineTo(x,y+7);g.lineTo(x-4.5,y)}else{g.moveTo(x-7,y);g.lineTo(x,y+4.5);g.lineTo(x+7,y);g.lineTo(x,y-4.5)}g.closePath();g.fill();g.strokeStyle='rgba(18,8,31,.8)';g.lineWidth=1.2;g.stroke();g.fillStyle='rgba(255,255,255,.7)';g.fillRect(x-1,y-1,2,2)};
 for(let i=1;i<8;i++){if(i===4)continue;dia(w*i/8,-rail/2-4,true);dia(w*i/8,h+rail/2+4,true)}for(let i=1;i<4;i++){dia(-rail/2-4,h*i/4,false);dia(w+rail/2+4,h*i/4,false)}
 /* the cushion band, then the cloth, both traced from the physics edges */
 const L=pzLoop();g.fillStyle=pzMix(felt.c,'#000000',.15);pzRR(g,-24,-24,w+48,h+48,10);g.fill();
 const loop=()=>{g.beginPath();L.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath()};
 /* the cushion rubber: lighter toward the nose, darker toward the wood */
 g.save();g.beginPath();g.rect(-24,-24,w+48,h+48);L.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.clip('evenodd');g.lineJoin='round';
 for(const [lw,k] of[[56,.0],[40,.10],[28,.18],[18,.26],[9,.34]]){g.strokeStyle=pzMix(pzMix(felt.c,'#000000',.15),felt.a,k);g.lineWidth=lw;g.beginPath();L.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.stroke()}
 g.restore();
 /* cloth */
 g.save();loop();g.clip();
 g.fillStyle=pzLin(g,0,0,0,h,[[0,felt.a],[1,felt.b]]);g.fillRect(-30,-30,w+60,h+60);
 {const tl=pzCv(96,96),tx=tl.getContext('2d'),im=tx.createImageData(96,96);for(let i=0;i<96*96;i++){const n=pzNoise(i*1.7+3),v=n>.5?255:0,a=Math.abs(n-.5)*.16;im.data[i*4]=v;im.data[i*4+1]=v;im.data[i*4+2]=v;im.data[i*4+3]=a*255}
  tx.putImageData(im,0,0);tx.strokeStyle='rgba(255,255,255,.035)';tx.lineWidth=1;for(let i=-96;i<96;i+=3){tx.beginPath();tx.moveTo(i,0);tx.lineTo(i+96,96);tx.stroke()}g.fillStyle=g.createPattern(tl,'repeat');g.fillRect(-30,-30,w+60,h+60)}
 /* faint chalk smudges and wear */
 for(let i=0;i<26;i++){const x=pzNoise(i)*w,y=pzNoise(i+50)*h,r=18+pzNoise(i+80)*38;const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,'rgba(150,190,255,.05)');q.addColorStop(1,'rgba(150,190,255,0)');g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)}
 /* embroidered title in the kitchen */
 g.save();g.translate(w*.115,h/2);g.rotate(-Math.PI/2);g.font='400 30px "Pirata One",Georgia,serif';g.textAlign='center';g.fillStyle='rgba(255,230,160,.10)';g.fillText('THE CROOKED CUE',0,0);g.restore();
 /* head string and spots */
 g.strokeStyle='rgba(255,255,255,.14)';g.lineWidth=2;g.setLineDash([7,9]);g.beginPath();g.moveTo(w/4,8);g.lineTo(w/4,h-8);g.stroke();g.setLineDash([]);
 for(const sx of[w/4,w*3/4]){g.fillStyle='rgba(255,255,255,.34)';g.beginPath();g.arc(sx,h/2,3.2,0,TAU);g.fill()}
 /* lamp light pool over the cloth */
 const lp=g.createRadialGradient(w/2,h*.46,30,w/2,h*.46,w*.66);lp.addColorStop(0,o.dim?'rgba(255,236,190,.12)':'rgba(255,233,168,.20)');lp.addColorStop(.55,'rgba(255,230,170,.06)');lp.addColorStop(1,o.dim?'rgba(0,0,10,.58)':'rgba(0,0,0,.24)');g.fillStyle=lp;g.fillRect(-30,-30,w+60,h+60);
 /* inner shadow along the cushions */
 g.lineJoin='round';for(const [lw,al] of[[30,.06],[20,.09],[11,.13],[5,.18]]){g.strokeStyle=`rgba(0,0,0,${al})`;g.lineWidth=lw;loop();g.stroke()}
 g.restore();
 /* nose highlight and shadow lines on the rail segments */
 g.save();g.lineCap='round';
 const rails=PZ_TBL.S.filter(s=>s[0]===s[2]||s[1]===s[3]);for(const [a,b,c,d] of rails){g.strokeStyle='rgba(0,0,0,.5)';g.lineWidth=3;g.beginPath();g.moveTo(a,b);g.lineTo(c,d);g.stroke();g.strokeStyle=pzMix(felt.a,'#ffffff',.3);g.globalAlpha=.55;g.lineWidth=1.3;g.beginPath();g.moveTo(a+(a===c?(a<w/2?1.5:-1.5):0),b+(b===d?(b<h/2?1.5:-1.5):0));g.lineTo(c+(a===c?(a<w/2?1.5:-1.5):0),d+(b===d?(b<h/2?1.5:-1.5):0));g.stroke();g.globalAlpha=1}
 g.restore();
 /* pockets: brass rim, leather lip, dark throat */
 for(const [px,py,hr,rr] of PZ_POCK){
  g.fillStyle='#24120a';g.beginPath();g.arc(px,py+3,rr+4,0,TAU);g.fill();/* the leather lip */
  g.fillStyle=pzLin(g,px-rr,py-rr,px+rr,py+rr,[[0,'#f0d080'],[.45,'#b88a3a'],[1,'#6a4a14']]);g.beginPath();g.arc(px,py,rr,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.fillStyle='#2a1608';g.beginPath();g.arc(px,py,hr+4,0,TAU);g.fill();
  const q=g.createRadialGradient(px,py,2,px,py,hr);q.addColorStop(0,'#000');q.addColorStop(.72,'#07040a');q.addColorStop(1,'#2a1a14');g.fillStyle=q;g.beginPath();g.arc(px,py,hr,0,TAU);g.fill();
  g.strokeStyle='rgba(255,240,200,.5)';g.lineWidth=1.6;g.beginPath();g.arc(px,py,rr-4,Math.PI*1.05,Math.PI*1.55);g.stroke();g.strokeStyle='rgba(255,220,150,.25)';g.lineWidth=1.2;g.beginPath();g.arc(px,py,hr+1,0,TAU);g.stroke()}
 /* brass studs on the rails near the corners */
 for(const [sx,sy] of[[-30,34],[34,-30],[w+30,34],[w-34,-30],[-30,h-34],[34,h+30],[w+30,h-34],[w-34,h+30]]){g.fillStyle='#d8a03a';g.beginPath();g.arc(sx,sy,3.6,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.4;g.stroke();g.fillStyle='rgba(255,250,220,.8)';g.fillRect(sx-1.5,sy-1.8,1.5,1.5)}
 g.restore()}
/* the whole backdrop for a felt and dimness; returns a 1600 x 900 canvas */
function pzBake(feltId,dim){const f=PZ_FELT.find(x=>x.id===feltId)||PZ_FELT[0],c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';pzBakeRoom(g);pzBakeTable(g,f,{dim});
 /* the lamp's wide warm glow is baked once (it used to be a 940 px additive blit every frame) */
 pzGlow(g,PZ_G.lampX,PZ_G.y+PZ_PHY.H*.5,dim?330:470,dim?'rgba(255,214,150,1)':'rgba(255,224,160,1)',dim?.07:.12);
 if(dim){const G=PZ_G;g.fillStyle='rgba(8,4,28,.34)';g.fillRect(0,0,1600,900);const v=g.createRadialGradient(G.x+G.w/2,G.y+G.h/2,200,G.x+G.w/2,G.y+G.h/2,820);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(4,2,16,.55)');g.fillStyle=v;g.fillRect(0,0,1600,900)}
 return c}
