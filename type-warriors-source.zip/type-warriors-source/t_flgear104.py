# python3 t_flgear104.py [game.html] : 10.4 Harvest Festival, the harvest gear (99n, 99n2, 99n3, 99n4; prefix flg / flb / flgs).
# Data and stat bands against the Halloween relics, every piece drawn (hero, poses, thumbnails that fit), kept out of the everyday
# pools, flgGive, flgBuy / flgBuyBoth with the cheat guard on (TW_AC_TEST) and the gold ledger, the equipped piece and the loadouts
# surviving a reload (the save repair), the Bountiful Harvest meter (flawless 2, slipped 1, boss sentence 2, forced 0), the burst
# (every monster harvested with bounty, projectiles swept, overgrowth slow, the set's heal, bosses partly spared and still typeable),
# practice mode left alone, both abilities at once (HUD panels apart), the armory inspect card, the Hall set goal, the shop window
# and its purchase at 1600x900, 1280x720 and 1024x640 with no overlaps, frame cost and no page errors.
# Screenshots in shots/w104_gear/.
import asyncio,json,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 and not sys.argv[1].startswith('-') else os.path.join(HERE,'out.html'))
SHOTS=os.path.join(HERE,'shots','w104_gear');os.makedirs(SHOTS,exist_ok=True)
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+json.dumps(info)[:1500]),flush=True)
    if not ok:FAIL.append(name)
SEED="{let a=11;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};try{RS_ASK=false}catch(e){}"
# a field of ordinary monsters, spread out, nothing more to come
FIELD="window.__field=(n)=>{S.mode='play';S.ban=null;S.wave=6;S.round=2;S.d=8;S.spawnLeft=30;const n0=S.en.length;for(let i=0;i<n;i++)spawn();S.en=S.en.filter(e=>!e.boss&&!e.sh);S.en.slice(n0).forEach((e,i)=>{e.x=560+i*150;e.shd=0});S.spawnLeft=60;S.spawnT=1e9};\
window.__type=(e)=>{S.tgt=e;for(const ch of e.w.slice(e.i))key(ch)};window.__run=(s)=>{for(let i=0;i<s*60;i++)update(1/60)};"
async def page(b,vw=1600,vh=900,er=None):
    pg=await b.new_page(viewport={'width':vw,'height':vh})
    if er is not None:pg.on('pageerror',lambda e:er.append(str(e)[:300]))
    await pg.goto(H);await pg.wait_for_function("()=>typeof title==='function'&&typeof P==='object'");await pg.wait_for_timeout(700)
    await pg.evaluate(SEED+FIELD);await pg.evaluate(OVL);return pg
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[];pg=await page(b,er=er);E=pg.evaluate
        # ---------- data ----------
        r=await E("""()=>{const o={};const A=FL.gear.a,Wp=FL.gear.w,R=FL.rar;
          o.ids=A.every(id=>AR[id]&&AR[id].fl&&AR[id].hw&&AR[id].n===FL.gearN[id])&&Wp.every(id=>WP[id]&&WP[id].fl&&WP[id].hw&&WP[id].n===FL.gearN[id]);
          o.rar=A.every((id,i)=>AR[id].r===R[i])&&Wp.every((id,i)=>WP[id].r===R[i]);
          o.kits=A.every(id=>AK[id]&&(HWH[AK[id].helm]||AK[id].helm));o.col=[...A.map(i=>AR[i].col),...Wp.map(i=>WP[i].col)].every(c=>/^#[0-9a-f]{6}$/i.test(c));
          o.paths=Wp.every(id=>PATHS[WP[id].p]&&WNEW[id]);
          /* armor bands: the same rarity of the Halloween set; weapon power within 35% of the Halloween weapon of the rarity */
          const HA=['hwscare','hwgrave','hwwitch','hwvamp','hwpump','hwreap'],HW=['hw_jack','hw_spade','hw_bat','hw_katana','hw_fang','hw_scythe'];
          const pa=a=>(a.hp||0)*1+(a.sh||0)*1+((a.sc||1)-1)*20+(1-(a.sl||1))*20,pw=w=>((w.sc||1)-1)*2+(1-(w.sl||1))*3+((w.fu||1)-1)*1.2+(w.cr||0)*2.5+(w.gm||0)*1+(w.cq?.25:0)+(w.ch||0)*3;
          o.band=A.map((id,i)=>[id,+pa(AR[id]).toFixed(2),+pa(AR[HA[i]]).toFixed(2)]).concat(Wp.map((id,i)=>[id,+pw(WP[id]).toFixed(2),+pw(WP[HW[i]]).toFixed(2)]));
          o.bandOk=o.band.every(([id,a,h],i)=>i<6?Math.abs(a-h)<=1.01:Math.abs(a-h)<=Math.max(.06,h*.35));
          o.mono=[0,1].every(k=>{const L=o.band.slice(k*6,k*6+6).map(x=>x[1]);return L.every((v,i)=>!i||v>=L[i-1]-.001)});
          o.ab=AR.flfeast.ab==='bounty'&&WP.fl_horn.ab==='bounty'&&!!GAB.bounty&&/Bountiful Harvest/.test(AR.flfeast.d);
          o.my=AR.flfeast.mythic===2;
          return o}""")
        chk('data: twelve harvest relics with the shared ids and names, fl and hw flags, colours, kits, paths and builders',r['ids'] and r['col'] and r['kits'] and r['paths'],r)
        chk('data: one per rarity, Common to Mythic',r['rar'],r)
        chk('data: stats in the Halloween bands (armor within 1 point, weapons within 35%) and rising with rarity',r['bandOk'] and r['mono'],r['band'])
        chk('data: the two Mythics carry Bountiful Harvest; the armor keeps its own golden palette',r['ab'] and r['my'],r)
        # ---------- art ----------
        r=await E("""()=>{const o={bad:[],edge:[],hero:[]};const c=document.createElement('canvas');
          const blank=(g,w,h)=>{const d=g.getImageData(0,0,w,h).data;for(let i=3;i<d.length;i+=4)if(d[i]>8)return false;return true};
          for(const [k,L] of[['a',FL.gear.a],['w',FL.gear.w]])for(const id of L)for(const [w,h] of[[236,150],[150,186],[200,250],[68,84]]){c.width=w;c.height=h;const g=c.getContext('2d');
            for(const t of[0,1.7]){try{art(c,k,id,t);if(blank(g,w,h))o.bad.push(id+' blank '+w)}catch(e){o.bad.push(id+': '+e.message)}}
            if(k==='w'){const d=g.getImageData(0,0,w,h).data;let n=0;for(let x=0;x<w;x++)for(const y of[0,h-1])if(d[(y*w+x)*4+3]>235)n++;for(let y=0;y<h;y++)for(const x of[0,w-1])if(d[(y*w+x)*4+3]>235)n++;if(n>Math.max(4,(w+h)*.06))o.edge.push(id+' '+w+'x'+h+': '+n)}}
          c.width=c.height=420;const g=c.getContext('2d');
          for(const a of FL.gear.a)for(const w of FL.gear.w)for(const pose of[null,'victory','dead']){try{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,420,420);g.save();g.translate(210,360);drawHero(g,{arm:a,wp:w,col:3,t:1.3,pose,pu:.6,lg:.4,walk:1});g.restore()}catch(e){o.hero.push(a+'/'+w+'/'+pose+': '+e.message)}}
          return o}""")
        chk('art: every relic draws a thumbnail at four menu sizes and two times',not r['bad'],r['bad'])
        chk('art: the weapon thumbnails are not cut off at the edges',not r['edge'],r['edge'])
        chk('art: the hero draws in every harvest armor with every harvest weapon, standing, in victory and defeated',not r['hero'],r['hero'])
        # ---------- pools ----------
        r=await E("""()=>{const f=new Set([...FL.gear.a,...FL.gear.w]),o={};P.xp=lvx(30);syncPaths();
          let hit=0;for(let i=0;i<400;i++){const x=premRoll();if(x&&f.has(x.id))hit++}o.prem=hit;
          hit=0;for(let i=0;i<400;i++){const x=cxRoll();if(x&&f.has(x.id))hit++}o.cx=hit;
          o.shop=['a','w','s','p','c'].some(k=>{try{return shItems(k).some(q=>f.has(Array.isArray(q)?q[1]:q))}catch(e){return false}});return o}""")
        chk('pools: never in the Eclipse or Celestial rolls or the shop crate lists',r['prem']==0 and r['cx']==0 and not r['shop'],r)
        # ---------- give / buy ----------
        r=await E("""()=>{const o={};delete P.ownA.flcorn;o.g1=flgGive('a','flcorn');o.g2=flgGive('a','flcorn');o.own=!!P.ownA.flcorn;o.bad=flgGive('a','plate')===false&&flgGive('w','nope')===false&&flgGive('x','flcorn')===false;
          o.w=flgGive('w','fl_acorn')&&!!P.own.fl_acorn;o.count=flgCount();return o}""")
        chk('flgGive: grants once (true, then false), only harvest ids',r['g1'] is True and r['g2'] is False and r['own'] and r['bad'] and r['w'],r)
        r=await E("""async()=>{const o={};window.FL_FORCE=1;delete P.ownA.flfeast;delete P.own.fl_horn;if(P.armor==='flfeast')P.armor='rags';
          P.gold=99999;o.poor=flgBuy('a')===false&&P.gold===99999&&!P.ownA.flfeast;
          P.gold=100000;o.a=flgBuy('a')===true&&P.gold===0&&!!P.ownA.flfeast;o.again=flgBuy('a')===false;
          P.gold=500000;o.part=flgBuyBoth()===false&&P.gold===500000;o.w=flgBuy('w')===true&&P.gold===400000&&!!P.own.fl_horn;
          delete P.ownA.flfeast;delete P.own.fl_horn;P.gold=175000;o.both=flgBuyBoth()===true&&P.gold===0&&!!P.ownA.flfeast&&!!P.own.fl_horn;
          window.FL_FORCE=-1;delete P.own.fl_horn;P.gold=200000;o.ended=flgBuy('w')===false&&P.gold===200000;window.FL_FORCE=1;
          const L=ledgerRecent(10);o.ldg=L.some(e=>e.d===-175000&&/harvest relic/.test(e.src));P.own.fl_horn=1;P.ownA.flfeast=1;return o}""")
        chk('flgBuy / flgBuyBoth: price, owned and part-owned refusals, the festival window, the gold ledger',all(r.get(k) for k in['poor','a','again','part','w','both','ended','ldg']),r)
        # ---------- save repair and loadouts across a reload ----------
        await E("""()=>{P.xp=lvx(30);P.ownA.flfeast=1;P.own.fl_horn=1;P.own.fl_glaive=1;P.ownA.flmoon=1;P.armor='flfeast';setWeapon('fl_horn');const L=loNorm();loStore(0);
          P.armor='flmoon';setWeapon('fl_glaive');loStore(1);P.armor='flfeast';setWeapon('fl_horn');save()}""")
        await pg.reload();await pg.wait_for_function("()=>typeof title==='function'&&typeof P==='object'");await pg.wait_for_timeout(800);await E(SEED+FIELD);await E(OVL)
        r=await E("""()=>{const L=loNorm();return{a:P.armor,w:P.weapon,p:P.path,l0:[L.s[0].a,L.s[0].w],l1:[L.s[1].a,L.s[1].w],ap:(loApply(1),[P.armor,P.weapon,P.path])}}""")
        chk('save repair: the equipped harvest armor and weapon survive a reload',r['a']=='flfeast' and r['w']=='fl_horn' and r['p']=='knight',r)
        chk('loadouts: harvest presets survive a reload and apply (weapon class follows)',r['l0']==['flfeast','fl_horn'] and r['l1']==['flmoon','fl_glaive'] and r['ap']==['flmoon','fl_glaive','rogue'],r)
        r=await E("""()=>{P.eqK={a:'flcorn',w:'fl_acorn',p:'knight'};delete P.ownA.flcorn;delete P.own.fl_acorn;P.armor='rags';P.weapon='rusty';const n=flgEqFix();return{n,a:P.armor,w:P.weapon}}""")
        chk('save repair: an unowned piece is never put back',r['n']==0 and r['a']=='rags' and r['w']=='rusty',r)
        await E("()=>{P.ownA.flcorn=1;P.own.fl_acorn=1;P.armor='flfeast';setWeapon('fl_horn');save()}")
        # ---------- the ability ----------
        r=await E("""()=>{const o={};for(const k of['flfeast','flcorn','hwreap'])P.ownA[k]=1;for(const k of['fl_horn','fl_acorn'])P.own[k]=1;P.xp=lvx(30);P.armor='flfeast';setWeapon('fl_horn');start(0);o.set=S.fbN;title();P.armor='flcorn';start(0);o.one=S.fbN;title();P.armor='hwreap';P.ownA.hwreap=1;start(0);o.both=[S.hvN,S.fbN];title();
          setWeapon('fl_acorn');start(0);o.none=S.fbN;title();setWeapon('fl_horn');P.armor='flfeast';start(0,'prac');o.prac=S.fbN;title();return o}""")
        chk('ability: counted at the start of a run (set 2, one piece 1, none 0), off in practice mode',r['set']==2 and r['one']==1 and r['none']==0 and r['prac']==0,r)
        chk('ability: Soul Harvest and Bountiful Harvest can run together (Reaper\'s Shroud + Horn of Plenty)',r['both']==[1,1],r)
        r=await E("""()=>{const o={};start(0);__field(5);const e=S.en[0];__type(e);o.flaw=S.fbm;const f=S.en[0];S.tgt=f;key(f.w[0]==='q'?'z':'q');key(f.w[0]==='q'?'z':'q');for(const ch of f.w.slice(f.i))key(ch);o.slip=S.fbm-o.flaw;
          const g=S.en[0],m0=S.fbm;kill(g,true);o.forced=S.fbm-m0;S.mode='title';title();return o}""")
        chk('meter: a flawless word adds 2 grains, a slipped word 1, a forced kill 0 (a boss sentence 1, checked below)',r['flaw']==2 and r['slip']==1 and r['forced']==0,r)
        r=await E("""()=>{const o={};start(0);__field(6);__run(.5);S.hp=2;const n0=S.en.length,s0=S.score;S.pj=[{x:900,y:600,v:200,k:'orb',src:'x'}];S.fbm=flbNeed()-1;const e=S.en.slice().sort((a,b)=>a.x-b.x)[0];__type(e);
          o.burst=!!S.fbB;o.reset=S.fbm===0;o.pj=S.pj.length;o.slow=S.fbS;o.hp=S.hp;o.uses=S.fbU;__run(1.8);o.left=S.en.filter(q=>q.x<W-10).length;o.harv=S.fbK;o.n0=n0;o.gain=S.score-s0;
          /* the overgrowth slows: compare one second of walking with and without it */
          __field(1);const m=S.en[0];m.x=1200;const x0=m.x;__run(1);const slowd=x0-m.x;S.fbS=0;const x1=m.x;__run(1);const fast=x1-m.x;o.ratio=+(slowd/Math.max(1,fast)).toFixed(2);S.mode='title';title();return o}""")
        chk('burst: at the set threshold the cornucopia bursts, the meter resets, projectiles are swept, the set heals 1',r['burst'] and r['reset'] and r['pj']==0 and r['hp']==3 and r['uses']==1 and abs(r['slow']-9)<.01,r)
        chk('burst: every monster on the field is harvested within 1.8 s, with bounty score',r['left']==0 and r['harv']>=r['n0']-1 and r['gain']>0,r)
        chk('overgrowth: monsters walk at about 70% speed while it lasts',.6<=r['ratio']<=.8,r)
        r=await E("""()=>{const o={};P.armor='flcorn';start(0);o.need=flbNeed();__field(3);S.fbm=o.need-2;__type(S.en.slice().sort((a,b)=>a.x-b.x)[0]);o.slow=S.fbS;S.mode='title';title();P.armor='flfeast';return o}""")
        chk('one piece: 30 grains, 6 s of overgrowth',r['need']==30 and abs(r['slow']-6)<.01,r)
        r=await E("""()=>{const o={};start(0);S.ban=null;S.wave=5;S.round=5;S.spawnLeft=1;spawn();const e=S.en.find(q=>q.boss);if(!e)return{err:'no boss'};e.x=W-340;e.state='fight';newBossLine(e);
          o.w0=e.w;const i0=3;S.tgt=e;for(const ch of e.w.slice(0,i0))key(ch);e.tm=e.tmax*.4;const tm0=e.tm;flbBurst();S.fbm=0;__run(1.7);
          o.w1=e.w;o.alive=S.en.includes(e);o.cut=e.w.length<o.w0.length&&o.w0.startsWith(e.w);o.third=+(1-(e.w.length-i0)/(o.w0.length-i0)).toFixed(2);o.tm=true;o.endsWord=o.w0.length===e.w.length||o.w0[e.w.length]===' ';
          S.tgt=e;const m0=S.fbm;for(const ch of e.w.slice(e.i))key(ch);o.vul=e.vul>0;o.bossGrain=S.fbm-m0;S.mode='title';title();return o}""")
        chk('bosses partly spared: only the last quarter of the sentence falls away, at a word break; the boss lives',r.get('alive') and r.get('cut') and r.get('endsWord') and .1<=r.get('third',0)<=.36,r)
        chk('bosses: the shortened sentence can still be typed to the end, and it adds 1 grain',r.get('vul') and r.get('bossGrain')==1,r)
        r=await E("""()=>RS_SKIP.has('fbB')&&RS_SKIP.has('fbG')""")
        chk('resume: the burst and the flying grain are not saved in the run snapshot',r)
        # ---------- HUD, screenshots and frame cost ----------
        r=await E("""async()=>{P.armor='hwreap';start(0);__field(4);S.fbm=9;S.soul=5;__run(.3);draw();const o={both:[S.hvN,S.fbN]};S.mode='title';title();P.armor='flfeast';return o}""")
        await E("()=>{start(0);__field(5);__run(.4);S.fbm=13;const e=S.en.slice().sort((a,b)=>a.x-b.x)[0];__type(e);__run(.25);draw()}")
        await pg.screenshot(path=os.path.join(SHOTS,'hud_meter_1600.png'))
        await E("()=>{S.fbm=flbNeed()-1;const e=S.en.slice().sort((a,b)=>a.x-b.x)[0];if(e)__type(e);__run(.85);draw()}")
        await pg.screenshot(path=os.path.join(SHOTS,'burst_pour_1600.png'))
        await E("()=>{__run(1.1);__field(4);__run(.6);draw()}")
        await pg.screenshot(path=os.path.join(SHOTS,'overgrowth_1600.png'))
        r=await E("""()=>{const t=[];for(let k=0;k<3;k++){S.fbm=flbNeed()-1;__field(5);__run(.2);const e=S.en.slice().sort((a,b)=>a.x-b.x)[0];if(e)__type(e);for(let i=0;i<120;i++){update(1/60);const a=performance.now();drawWorld();drawHUD();t.push(performance.now()-a)}}
          const base=[];S.fbB=null;S.fbS=0;S.fbN=0;__field(5);for(let i=0;i<120;i++){update(1/60);const a=performance.now();drawWorld();drawHUD();base.push(performance.now()-a)}
          const q=(a,p)=>{const s=a.slice().sort((x,y)=>x-y);return+s[Math.floor(s.length*p)].toFixed(2)};S.mode='title';title();return{med:q(t,.5),p75:q(t,.75),base:q(base,.5),base75:q(base,.75)}}""")
        chk('frame cost: the burst adds under 2 ms a frame to the field and HUD draw (median; p75 under 5 ms more)',r['med']-r['base']<2 and r['p75']-r['base75']<5,r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=600;c.height=600;const g=c.getContext('2d',{willReadFrequently:true});const L=[['flfeast','fl_horn'],['hwreap','hw_scythe'],['flmoon','fl_glaive'],['hwpump','hw_fang'],['flcorn','fl_acorn'],['hwvamp','hw_katana'],['flmaple','fl_maple'],['hwwitch','hw_bat']],T={};
          for(const [a,w] of L){T[a]=[];for(let i=0;i<6;i++)drawHero(g,{arm:a,wp:w,col:0,t:i/60})}
          /* a software canvas (no GPU flushes), interleaved short batches, the best batch per hero: steady even when other work shares the machine */
          for(let k=0;k<15;k++)for(const [a,w] of L){const t0=performance.now();for(let i=0;i<6;i++){g.setTransform(1.95,0,0,1.95,300,560);drawHero(g,{arm:a,wp:w,col:0,t:(k*6+i)/60})}T[a].push((performance.now()-t0)/6)}
          const o={};for(const a in T)o[a]=+Math.min(...T[a]).toFixed(2);return o}""")
        ok=r['flfeast']<=r['hwreap']*1.6+.3 and all(r[a]<=r[h]*2.2+.3 for a,h in [('flmoon','hwpump'),('flcorn','hwvamp'),('flmaple','hwwitch')])
        chk('frame cost: the Feastlord draws within 1.6x the Reaper, the others within 2.2x the Halloween relic of their rarity (best batch, software canvas, ms at battle scale)',ok,r)
        r=await E("""async()=>{const fr=async(a,w)=>{P.ownA[a]=1;P.own[w]=1;P.armor=a;setWeapon(w);start(0);__field(5);S.fbm=0;await new Promise(r=>setTimeout(r,500));const ts=[];let last=performance.now();await new Promise(res=>{let n=0;const f=t=>{ts.push(t-last);last=t;if(++n<90)requestAnimationFrame(f);else res()};requestAnimationFrame(f)});S.mode='title';title();ts.sort((x,y)=>x-y);return+ts[Math.floor(ts.length/2)].toFixed(1)};
          return{harvest:await fr('flfeast','fl_horn'),halloween:await fr('hwreap','hw_scythe')}}""")
        chk('frame cost: a fight in the game loop with the harvest Mythics runs at the frame time of the Halloween Mythics (median rAF)',r['harvest']<=r['halloween']*1.25+2,r)
        # ---------- menus: armory inspect, Hall goal, shop window ----------
        r=await E("""async()=>{P.ownA.flfeast=1;P.own.fl_horn=1;P.armor='flfeast';setWeapon('fl_horn');save();armory('Armor');await new Promise(r=>setTimeout(r,400));const card=ov.querySelector('[data-k="flfeast"]');if(card)card.click();await new Promise(r=>setTimeout(r,400));
          const t=(ov.textContent||'');const pv=ov.querySelector('.gab');const o={card:!!card,ab:/Bountiful Harvest/.test(t),active:!!ov.querySelector('.gab em.on'),ovl:pv?__rpuOvl(pv.parentElement):['no panel']};return o}""")
        await pg.screenshot(path=os.path.join(SHOTS,'armory_inspect_1600.png'))
        chk('armory: Feastlord\'s Aegis has a card; inspecting it shows Bountiful Harvest with the set marked Active, no overlaps in the panel',r['card'] and r['ab'] and r['active'] and not r['ovl'],r)
        r=await E("""()=>{delete P.own.fl_horn;const g1=hlGoals().find(g=>g.key==='s:bounty');P.own.fl_horn=1;const g2=hlGoals().find(g=>g.key==='s:bounty');return{one:!!g1&&g1.have===1&&g1.tot===2,both:!g2}}""")
        chk('Hall: the Bountiful Harvest set appears in "Almost complete" while half owned',r['one'] and r['both'],r)
        MERGED=await E("()=>typeof flcCollection==='function'")
        r=await E("""async()=>{window.FL_FORCE=1;delete P.own.fl_horn;P.colg={k:'s:bounty'};catHall();await new Promise(r=>setTimeout(r,500));const b=ov.querySelector('[data-gs]');if(!b)return{err:'no button'};b.click();await new Promise(r=>setTimeout(r,900));const w=!!document.getElementById(typeof flcCollection==='function'?'flcwin':'flgsw');shClose();P.own.fl_horn=1;return{w}}""")
        chk('Hall: "Find it in the Shop" on the half-owned set opens the shop window for the Mythics (the Harvest Collection when the chest part is there, else the Harvest Relics window)',r.get('w'),r)
        for vw,vh in [(1600,900),(1280,720),(1024,640)]:
            q=await page(b,vw,vh,er);Q=q.evaluate
            if MERGED:
                # merged build: the chest part's Harvest Collection is the shop face for the two Mythics; its buttons are flgWhyNot's, its purchase flgBuy's
                r=await Q("""async()=>{window.FL_FORCE=1;P.gold=150000;delete P.ownA.flfeast;delete P.own.fl_horn;P.ownA.flsmock=1;P.own.fl_pin=1;P.ownA.flmaple=1;shop();await new Promise(r=>setTimeout(r,500));
                  const o={btn:!!document.getElementById('flcshbt'),hdr:__rpuOvl(ov.querySelector('.shh')),noOwn:!document.getElementById('flgsp')};document.getElementById('flcshbt').click();await new Promise(r=>setTimeout(r,900));
                  const w=document.getElementById('flcwin');o.win=!!w;o.ovl=__rpuOvl(w);const R=w.getBoundingClientRect(),Wr=document.getElementById('wrap').getBoundingClientRect();o.inside=R.left>=Wr.left-1&&R.right<=Wr.right+1;
                  o.cards=w.querySelectorAll('.flcc').length;o.dis=[...w.querySelectorAll('[data-fb]')].map(b=>b.disabled);o.why=['a','w','b'].map(flgWhyNot);return o}""")
                await q.screenshot(path=os.path.join(SHOTS,f'shop_window_{vw}.png'))
                chk(f'shop {vw}x{vh}: the Harvest Collection banner opens the Collection (no second Harvest Relics button), three cards whose buttons follow flgWhyNot, no overlaps, on the stage',r['btn'] and r['noOwn'] and r['win'] and r['cards']==3 and not r['ovl'] and not r['hdr'] and r['inside'] and r['dis']==[False,False,True] and r['why']==['','','gold'],r)
                if vw==1600:
                    r=await Q("""async()=>{const g0=P.gold;{const bb=document.querySelector('[data-fb="a"]');bb.click();await new Promise(r=>setTimeout(r,400));bb.click()}await new Promise(r=>setTimeout(r,1500));const w=document.getElementById('flcwin');
                      const L=ledgerRecent(5);return{own:!!P.ownA.flfeast,gold:g0-P.gold,note:!!(w&&w.querySelector('.flcnote')),ownCard:!!(w&&w.querySelector('.flcc.own[data-w="a"]')),bundle:!!(w&&w.querySelector('[data-fb="b"]').disabled),ldg:L.some(e=>e.d===-100000&&/harvest relic/.test(e.src))}}""")
                    await q.screenshot(path=os.path.join(SHOTS,'shop_bought_1600.png'))
                    chk('shop: buying the armor from its Collection card goes through flgBuy: charges 100,000 once (gold ledger "harvest relic"), marks it owned and leaves the bundle part-owned',r['own'] and r['gold']==100000 and r['note'] and r['ownCard'] and r['bundle'] and r['ldg'],r)
                    r=await Q("""async()=>{shClose();const e0=FL.end,f0=window.FL_FORCE;delete P.own.fl_horn;P.gold=120000;window.FL_FORCE=undefined;FL.end=Date.now()-864e5;shop();await new Promise(r=>setTimeout(r,300));
                      const ban=!!document.getElementById('flcshbt');flcCollection();await new Promise(r=>setTimeout(r,500));const w=document.getElementById('flcwin');const o={ban,grace:flShopOn()&&!flOn(),btnW:!w.querySelector('[data-fb="w"]').disabled,txt:/sold until/.test(w.textContent)};
                      shClose();FL.end=Date.now()-FL.grace-1e6;shop();await new Promise(r=>setTimeout(r,300));o.ownerBan=!!document.getElementById('flcshbt');flcCollection();await new Promise(r=>setTimeout(r,400));o.off=[...document.querySelectorAll('#flcwin [data-fb]')].every(b=>b.disabled);
                      const g1=P.gold;flcBuyM('w');o.noBuy=P.gold===g1&&!P.own.fl_horn;shClose();FL.end=e0;window.FL_FORCE=f0;return o}""")
                    chk('shop: the grace week after the festival still sells the Mythics (flgWhyNot\'s rule, banner and buttons on); after it the banner stays for owners, the buttons are off and nothing is charged',all(r.values()),r)
            else:
                r=await Q("""async()=>{window.FL_FORCE=1;P.gold=150000;delete P.ownA.flfeast;delete P.own.fl_horn;P.ownA.flsmock=1;P.own.fl_pin=1;P.ownA.flmaple=1;shop();await new Promise(r=>setTimeout(r,500));
                  const o={btn:!!document.getElementById('flgsp'),hdr:__rpuOvl(ov.querySelector('.shh'))};document.getElementById('flgsp').click();await new Promise(r=>setTimeout(r,900));
                  const w=document.getElementById('flgsw');o.win=!!w;o.ovl=__rpuOvl(w);const R=w.getBoundingClientRect(),Wr=document.getElementById('wrap').getBoundingClientRect();o.inside=R.left>=Wr.left-1&&R.right<=Wr.right+1;
                  o.cards=w.querySelectorAll('.flgsc').length;o.dis=[...w.querySelectorAll('[data-flgb]')].map(b=>b.disabled);return o}""")
                await q.screenshot(path=os.path.join(SHOTS,f'shop_window_{vw}.png'))
                chk(f'shop {vw}x{vh}: the header button and the Harvest Relics window, three cards, no overlaps, on the stage',r['btn'] and r['win'] and r['cards']==3 and not r['ovl'] and not r['hdr'] and r['inside'] and r['dis']==[False,False,True],r)
                if vw==1600:
                    r=await Q("""async()=>{const g0=P.gold;document.querySelector('[data-flgb="a"]').click();await new Promise(r=>setTimeout(r,1500));const w=document.getElementById('flgsw');
                      return{own:!!P.ownA.flfeast,gold:g0-P.gold,note:!!(w&&w.querySelector('.flgsnote')),ownCard:!!(w&&w.querySelector('.flgsc.own[data-k="a"]')),bundle:!!(w&&w.querySelector('[data-flgb="b"]').disabled)}}""")
                    await q.screenshot(path=os.path.join(SHOTS,'shop_bought_1600.png'))
                    chk('shop: buying the armor from its card charges 100,000, marks it owned and leaves the bundle part-owned',r['own'] and r['gold']==100000 and r['note'] and r['ownCard'] and r['bundle'],r)
                    r=await Q("""async()=>{shClose();window.flcOpenUI=()=>{};shop();await new Promise(r=>setTimeout(r,300));const o=!document.getElementById('flgsp');delete window.flcOpenUI;
                      window.FL_FORCE=-1;FL.end=Date.now()-FL.grace-1e6;shop();await new Promise(r=>setTimeout(r,300));return{hid:o,ended:!!document.getElementById('flgsp')}}""")
                    chk('shop: the header button gives way to the chest part\'s own window (flcOpenUI) and stays for owners after the festival',r['hid'] and r['ended'],r)
            await q.close()
        r=await E("""()=>{const o={};for(const [a,w] of[['flsmock','fl_fork'],['florch','fl_pin'],['flmaple','fl_maple']]){P.ownA[a]=1;P.own[w]=1}P.xp=lvx(30);const c=document.createElement('canvas');c.width=1600;c.height=380;const g=c.getContext('2d');g.fillStyle='#1a1430';g.fillRect(0,0,1600,380);
          FL.gear.a.forEach((a,i)=>{g.save();g.translate(130+i*265,350);g.scale(1.75,1.75);drawHero(g,{arm:a,wp:FL.gear.w[i],col:0,t:1.3+i*.4});g.restore()});return c.toDataURL()}""")
        import base64;open(os.path.join(SHOTS,'sheet_all.png'),'wb').write(base64.b64decode(r.split(',')[1]))
        # ---------- the cheat guard on (TW_AC_TEST): a purchase by click stands across a reload ----------
        ctx=await b.new_context(viewport={'width':1600,'height':900});await ctx.add_init_script('window.FL_FORCE=1')
        q=await ctx.new_page();q.on('pageerror',lambda e:er.append(str(e)[:300]));await q.goto(H);await q.wait_for_function("()=>typeof title==='function'&&typeof P==='object'");await q.wait_for_timeout(800)
        await q.evaluate("()=>{P.gold=160000;delete P.own.fl_horn;save()}");await q.wait_for_timeout(600)
        await ctx.add_init_script('window.TW_AC_TEST=1');await q.reload();await q.wait_for_function("()=>typeof title==='function'&&typeof P==='object'");await q.wait_for_timeout(1500)
        r0=await q.evaluate("()=>({on:!!(TWAC.stat().enforced),gold:P.gold})")
        await q.evaluate("()=>{P.gold=9e9}");await q.evaluate("()=>{shop()}");await q.wait_for_timeout(500)
        if MERGED:await q.click('#flcshbt');await q.wait_for_timeout(900);await q.click('[data-fb="w"]');await q.wait_for_timeout(400);await q.click('[data-fb="w"]');await q.wait_for_timeout(2500)
        else:await q.click('#flgsp');await q.wait_for_timeout(900);await q.click('[data-flgb="w"]');await q.wait_for_timeout(2500)
        r1=await q.evaluate("()=>({gold:P.gold,own:!!P.own.fl_horn})")
        await q.reload();await q.wait_for_function("()=>typeof title==='function'&&typeof P==='object'");await q.wait_for_timeout(1500)
        r2=await q.evaluate("()=>({gold:P.gold,own:!!P.own.fl_horn,stored:JSON.parse(sgGet(KEY)).gold})")
        chk('cheat guard on (TW_AC_TEST): a console write is refused, a purchase by click is paid and stands across a reload',r0['on'] and r0['gold']==160000 and r1=={'gold':60000,'own':True} and r2=={'gold':60000,'own':True,'stored':60000},[r0,r1,r2])
        await ctx.close()
        # ---------- 10.4c art polish: every piece draws something at several sizes, the Mythic pieces stay cheap ----------
        r=await E("""()=>{const o={bad:[],cost:{}};const px=c=>{const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>40)n++;return n};
          for(const [kind,ids] of[['a',FL.gear.a],['w',FL.gear.w]])for(const id of ids)for(const sz of[36,64,128]){const c=document.createElement('canvas');c.width=c.height=sz;art(c,kind,id,1.3);const n=px(c);if(n<sz*sz*.04)o.bad.push([id,sz,n])}
          const c=document.createElement('canvas');c.width=c.height=400;const g=c.getContext('2d');
          const run=(f,n)=>{for(let i=0;i<15;i++)f(i*.03);const ts=[];for(let k=0;k<5;k++){const t0=performance.now();for(let i=0;i<n;i++)f(1+i*.033);ts.push((performance.now()-t0)/n)}ts.sort((a,b)=>a-b);return +ts[2].toFixed(2)};
          o.cost.base=run(t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,400,400);g.translate(200,300);g.scale(1.5,1.5);drawHero(g,{arm:'flsmock',wp:null,col:0,t})},60);
          o.cost.feast=run(t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,400,400);g.translate(200,300);g.scale(1.5,1.5);drawHero(g,{arm:'flfeast',wp:'fl_horn',col:0,t})},60);
          o.cost.moon=run(t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,400,400);g.translate(200,300);g.scale(1.5,1.5);drawHero(g,{arm:'flmoon',wp:'fl_glaive',col:0,t})},60);
          o.cost.horn=run(t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,400,400);g.translate(100,300);g.scale(2,2);drawW(g,'fl_horn',70,t)},60);
          return o}""")
        chk('10.4c: every harvest armor and weapon draws a clear shape at 36, 64 and 128 px',not r['bad'],r['bad'])
        chk('10.4c: the Mythic hero (armor + Horn of Plenty) draws in under 12 ms and the Horn alone under 4 ms (software rendering)',r['cost']['feast']<12 and r['cost']['horn']<4 and r['cost']['moon']<10,r['cost'])
        chk('no page errors',not er,er)
        await b.close()
    print(f'\n{N[0]-len(FAIL)}/{N[0]} passed'+('' if not FAIL else '  FAILED: '+', '.join(FAIL)))
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
