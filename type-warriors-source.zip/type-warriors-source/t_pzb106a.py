# python3 t_pzb106a.py [out.html] : 10.6 ball agent A: Harvest Amber (amber) and Glacier Crystal (glacier) in 97b7_pz_balls_amber_ice.js.
# Registration, the owner's ball rule measured for just these two sets (same measuring code as t_pzb102.py, read from it so the two cannot drift),
# the two sets differ from every older set and from each other, paint cost against Starfall (galaxy) and Ember Core (lava), no page errors.
import asyncio,os,sys,re
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
SRC=open(os.path.join(HERE,'t_pzb102.py')).read()
MEASURE=re.search(r'MEASURE=r"""(.*?)"""',SRC,re.S).group(1).replace("PZ_BALLS.map(b=>b.id)","['amber','glacier']")
SETS={'amber':('Harvest Amber',15000),'glacier':('Glacier Crystal',25000)}
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:700]),flush=True)
    if not ok:FAIL.append(name)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900});pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true}");await E("()=>document.fonts.ready")
        # registration
        r=await E("""()=>({a:PZ_BALLS.find(b=>b.id==='amber'),g:PZ_BALLS.find(b=>b.id==='glacier'),pa:PZ_BPAL.amber,pg:PZ_BPAL.glacier,ta:PZ_TAG97.amber,tg:PZ_TAG97.glacier,
          cnt:PZ_BALLS.filter(b=>b.id==='amber'||b.id==='glacier').length})""")
        for k,(nm,pr) in SETS.items():
            x=r[k[0]]
            chk(f'{k}: registered with the right name and price',x and x['n']==nm and x['price']==pr and x.get('prem')==1 and str(pr) and 'Cue Rack' in x['how'],x)
            pal=r['p'+k[0]]
            chk(f'{k}: palette has kind {k}, eight colours, white, cap, disc, num, disc8, num8, ring8',pal and pal['kind']==k and all(str(i) in pal['col'] for i in range(1,9)) and all(pal.get(q) for q in ['white','cap','disc','num','disc8','num8','ring8']),pal)
            chk(f'{k}: has a tag line',bool(r['t'+k[0]]) and len(r['t'+k[0]])>10,r)
        chk('both sets are listed exactly once',r['cnt']==2,r)
        # the rule
        R=await E(MEASURE)
        keys=['stripeLight','capMin','solidLight','pairGap','solidCol','stripeCol','y8','yMin','ratio8','disc8','num8','numMin','cueY','cueS']
        for s,v in R.items():print('  %-8s'%s+''.join('%11s'%v[k] for k in keys))
        for s,v in R.items():
            chk(f'{s}: stripes have light caps above and below a coloured band (light area >= 0.22, caps >= 0.2, band coloured)',v['stripeLight']>=.22 and v['capMin']>=.2 and v['stripeCol']>=.2,v)
            chk(f'{s}: solids are coloured all over (light area <= 0.08, coloured >= 0.5)',v['solidLight']<=.08 and v['solidCol']>=.5,v)
            chk(f'{s}: solids and stripes told apart by the light area (gap >= 0.18)',v['pairGap']>=.18 and v['stripeLight']-v['solidLight']>=.18,v)
            chk(f'{s}: the 8 is the darkest ball (<= 0.62 of the darkest other, <= 60) with a high-contrast disc and number (>= 4.5)',v['ratio8']<=.62 and v['y8']<=60 and v['disc8']>=4.5 and v['num8']>=4.5,v)
            chk(f'{s}: every number reads (>= 4:1); the cue ball is white',v['numMin']>=4 and v['cueY']>=150 and v['cueS']<=.12,v)
        # differ from each other and from the older sets: compare a mid-ball render pixel by pixel
        r=await E("""()=>{const sets=['gem','moon','marble','neon','lava','galaxy','royal','amber','glacier'],M=pzbRot(pzbRot(pzbI(),0,1,0,.5),1,0,0,-.3),im={};
          for(const s of sets){pzbSetup(52,s);const row=[];for(const n of [1,2,3,9,10]){pzbPaint(15,n,M);const d=PZ_BS.ax.getImageData(15*52,0,52,52).data;row.push(d)}im[s]=row}
          const dist=(a,b)=>{let t=0,k=0;for(let i=0;i<a.length;i++){for(let j=0;j<a[i].length;j+=4){if(a[i][j+3]<250)continue;t+=Math.abs(a[i][j]-b[i][j])+Math.abs(a[i][j+1]-b[i][j+1])+Math.abs(a[i][j+2]-b[i][j+2]);k++}}return t/k/3};
          const out={};for(const s of ['amber','glacier'])for(const o of sets)if(o!==s)out[s+'-'+o]=+dist(im[s],im[o]).toFixed(1);pzbSetup(52,'classic');return out}""")
        print('  mean per-channel difference:',r)
        chk('amber and glacier differ clearly from each other and from every older set (mean per-channel difference >= 18)',min(r.values())>=18,{k:v for k,v in r.items() if v<18})
        # paint cost: ms per 64 px ball paint, 200 paints, against Starfall and Ember Core
        r=await E("""()=>{const R={};for(const s of ['galaxy','lava','amber','glacier']){pzbSetup(64,s);let best=1e9;for(let w=0;w<30;w++)pzbPaint(15,1+w%15,pzbRot(pzbI(),1,0,0,w*.1));
          for(let tr=0;tr<7;tr++){const t0=performance.now();for(let k=0;k<200;k++)pzbPaint(15,1+k%15,pzbRot(pzbRot(pzbI(),0,1,0,k*.07),1,0,0,tr));best=Math.min(best,(performance.now()-t0)/200)}R[s]=+best.toFixed(3)}pzbSetup(52,'classic');return R}""")
        print('  ms per 64 px paint:',r)
        lim=max(r['galaxy'],r['lava'])*1.5
        chk('paint cost per 64 px ball stays within 1.5x of the dearer of Starfall and Ember Core',r['amber']<=lim and r['glacier']<=lim,{**r,'limit':round(lim,3)})
        # paints are stable: no NaN, an animated roll changes the picture, orientation matters (the pattern rolls with the ball)
        r=await E("""()=>{const o={};for(const s of ['amber','glacier']){pzbSetup(52,s);const a=[],bd=[];for(const M of [pzbI(),pzbRot(pzbI(),0,1,0,1.2)]){pzbPaint(15,2,M);bd.push(PZ_BS.ax.getImageData(15*52,0,52,52).data)}
          let df=0;for(let i=0;i<bd[0].length;i+=4)df+=Math.abs(bd[0][i]-bd[1][i]);let bad=0;for(const n of [0,1,8,9,15]){pzbPaint(15,n,pzbI());const d=PZ_BS.ax.getImageData(15*52,0,52,52).data;for(let i=0;i<d.length;i++)if(!(d[i]>=0&&d[i]<=255))bad++}o[s]={rollDiff:Math.round(df/(52*52)),bad}}pzbSetup(52,'classic');return o}""")
        chk('the pattern rolls with the ball (a turned ball paints differently) and every pixel is valid',all(v['rollDiff']>6 and v['bad']==0 for v in r.values()),r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
