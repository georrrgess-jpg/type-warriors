/* ---------- Graveyard crate: the midnight ritual ----------
   A full Halloween opening sequence used only for the Graveyard crate. The crate claws its way out of a fresh grave, skeletal hands
   grip the ground, one jack-o'-lantern lights per rarity tier with a church-bell toll, ghosts circle, lightning strikes, and at
   Mythic the Reaper rises and cuts the lock. Every sound is synthesized live (pipe organ, bells, theremin, ghosts, bats, thunder,
   creaking wood, a witch's cackle and a music box), timed to the same clock as the picture. */
const HXT={O:[3.6,3.6,4.0,4.8,6.6,10.6],D:[1.8,1.8,2.0,2.4,3.2,7.0]};
const HX_FIRE=['#ffb040','#ffb040','#7ab8ff','#c86bff','#ff7a1a','#5affb0'];/* pumpkin flame colour by tier */
const hxTC=q=>q.tier>=5?'#5affb0':q.tier===4?'#ff9a30':q.it.col;/* theme colour of the reveal */
const hxA=n=>Math.round(Math.max(0,Math.min(1,n))*255).toString(16).padStart(2,'0');
/* pumpkins sit in a front arc, left to right; they light centre-out */
const HX_PK=[[-560,48],[-395,70],[-235,84],[235,84],[395,70],[560,48]],HX_ORD=[2,3,1,4,0,5];
function hxTimes(q){const T=q.tier,O=q.O,L=T+1,pt=[];for(let i=0;i<L;i++)pt.push(L===1?2.0+(O-2.7)*.5:2.0+(O-2.7)*(i/(L-1)));
 const lt=T<3?[]:T===3?[O-1.5]:T===4?[2.5,O-1.1]:[2.3,3.9,5.6,7.3,O-.75];return{pt,lt}}
function hxPrep(q){q.hw=1;const T=q.tier;q.O=HXT.O[T];q.E=q.O+HXT.D[T];const tm=hxTimes(q);q.pt=tm.pt;q.lt=tm.lt;q.lit=[0,0,0,0,0,0];q.litT=[0,0,0,0,0,0];
 q.gh=[];const N=[3,4,6,8,12,18][T];for(let i=0;i<N;i++)q.gh.push({a:i/N*TAU+Math.random()*.5,r:200+Math.random()*130,sp:.6+Math.random()*.5,ph:Math.random()*6,s:3.4+Math.random()*1.8,t0:2.0+(q.O-2.4)*(i/N)*.7});
 q.rel=[];q.bats=[];q.cf=[];q.dirt=[];q.bolt=null;q.boltF=0;q.cut=0;q.last=performance.now();
 q.amb=[];for(let i=0;i<5;i++)q.amb.push({x:Math.random()*W,y:120+Math.random()*260,ph:Math.random()*6,v:40+Math.random()*60,s:1.6+Math.random()*1.2})}
/* ======================= sound ======================= */
function hxOrgan(o,t,f,d,v){for(const [m,a] of[[.5,.45],[1,1],[2,.55],[3,.22],[4,.16],[6,.07]])cTone(o,t,f*m,d,'sine',v*a,{a:.05,hold:1,r:.35});cTone(o,t,f,d,'triangle',v*.28,{det:7,a:.06,hold:1,r:.35,lp:2400})}
const hxChord=(o,t,ms,d,v)=>ms.forEach(m=>hxOrgan(o,t,nf(m),d,v));
function hxToccata(o,t,v){let tt=t;for(const [n,d] of[[81,.09],[79,.09],[81,.75],[0,.25],[79,.13],[77,.13],[76,.13],[74,.13],[73,.3],[74,.9]]){if(n){hxOrgan(o,tt,nf(n),d+.12,v);hxOrgan(o,tt,nf(n-12),d+.12,v*.75)}tt+=d}
 hxChord(o,tt,[38,45,50,53,57],2.8,v*.7);cTone(o,tt,nf(26),2.8,'sine',v*2.2,{a:.15,hold:1,r:.9})}
function hxToll(o,t,f,v){cBell(o,t,f,v,3.2);cTone(o,t,f*.5,2.6,'sine',v*.6,{a:.01})}
function hxTheremin(o,t,d,pts,v){try{const os=ac.createOscillator(),lf=ac.createOscillator(),lg=ac.createGain(),g=ac.createGain(),b=ac.createBiquadFilter();os.type='sine';os.frequency.setValueAtTime(pts[0],t);os.frequency.setValueCurveAtTime(new Float32Array(pts),t,d);
 lf.frequency.value=6.2;lg.gain.value=pts[0]*.018;lf.connect(lg);lg.connect(os.frequency);b.type='lowpass';b.frequency.value=2600;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+d*.25);g.gain.setValueAtTime(v,t+d*.8);g.gain.exponentialRampToValueAtTime(.0001,t+d);
 os.connect(b);b.connect(g);g.connect(o);os.start(t);lf.start(t);os.stop(t+d+.05);lf.stop(t+d+.05)}catch(e){}}
function hxVoice(o,t,d,f0,f1,v,fm,vib){try{const os=ac.createOscillator(),lf=ac.createOscillator(),lg=ac.createGain(),g=ac.createGain();os.type='sawtooth';os.frequency.setValueAtTime(f0,t);os.frequency.exponentialRampToValueAtTime(f1,t+d);lf.frequency.value=vib||4.6;lg.gain.value=f0*.02;lf.connect(lg);lg.connect(os.frequency);
 g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+d*.35);g.gain.exponentialRampToValueAtTime(.0001,t+d);
 for(const [ff,qq,a] of fm){const b=ac.createBiquadFilter(),gg=ac.createGain();b.type='bandpass';b.frequency.value=ff;b.Q.value=qq;gg.gain.value=a;os.connect(b);b.connect(gg);gg.connect(g)}
 g.connect(o);os.start(t);lf.start(t);os.stop(t+d+.05);lf.stop(t+d+.05)}catch(e){}}
function hxGhost(o,t,d,f,v){hxVoice(o,t,d,f,f*.72,v,[[430,6,1],[880,8,.7]],4.2);cNoise(o,t,d,v*.35,{type:'bandpass',f1:700,f2:500,q:2,a:d*.4})}
function hxThunder(o,t,v){cNoise(o,t,.2,v*1.3,{type:'highpass',f1:3200,f2:1500,a:.003});cNoise(o,t+.04,3.4,v,{f1:1400,f2:50,a:.06});cTone(o,t,50,2.6,'sine',v*.9,{f2:28,a:.08});cNoise(o,t+.7,2.6,v*.6,{f1:320,f2:60,a:.3})}
function hxCreak(o,t,d,v){try{const os=ac.createOscillator(),g=ac.createGain(),b=ac.createBiquadFilter();os.type='sawtooth';const n=24,pts=new Float32Array(n);for(let i=0;i<n;i++)pts[i]=85+Math.random()*70+i*2;os.frequency.setValueAtTime(pts[0],t);os.frequency.setValueCurveAtTime(pts,t,d);
 b.type='bandpass';b.frequency.value=1150;b.Q.value=9;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+d*.3);g.gain.setValueAtTime(v,t+d*.85);g.gain.exponentialRampToValueAtTime(.0001,t+d);os.connect(b);b.connect(g);g.connect(o);os.start(t);os.stop(t+d+.05)}catch(e){}
 for(let k=0;k<d*26;k++)cNoise(o,t+k/26+Math.random()*.01,.025,v*.5,{type:'bandpass',f1:2200+Math.random()*1500,q:6,a:.003})}
function hxDirt(o,t,d,v){cNoise(o,t,d,v,{f1:380,f2:110,a:.25});cTone(o,t,46,d,'sine',v*.8,{a:.2,hold:1,r:.3});for(let k=0;k<d*24;k++)cNoise(o,t+Math.random()*d,.035,v*.55,{type:'bandpass',f1:1200+Math.random()*2800,q:4,a:.002})}
function hxWhoomph(o,t,v){cNoise(o,t,.65,v,{f1:2000,f2:140,a:.04});cTone(o,t,95,.55,'sine',v*.8,{f2:42,a:.015})}
function hxBats(o,t,d,v){for(let k=0;k<d*28;k++)cNoise(o,t+k/28+Math.random()*.01,.024,v*(.4+Math.random()*.6),{type:'bandpass',f1:2400+Math.random()*3200,q:2.5,a:.002});for(let k=0;k<Math.max(2,d*4);k++)cTone(o,t+Math.random()*d,7200+Math.random()*2400,.05,'sine',v*.22,{f2:5000,a:.003})}
function hxHeart(o,t,v){cKick(o,t,v,72,34,.26);cKick(o,t+.17,v*.65,66,32,.22)}
function hxCackle(o,t,v){for(let i=0;i<10;i++){const tt=t+i*.1+(i>6?(i-6)*.02:0),f=820-i*30+Math.random()*30;hxVoice(o,tt,.085,f*1.18,f,v*(1-i*.05),[[1250,3,1],[2600,5,.6]],9)}}
function hxSwish(o,t,v){cNoise(o,t,.38,v,{type:'bandpass',f1:500,f2:7500,q:1.6,a:.28});cBell(o,t+.32,nf(98),v*.35,1.6);cBell(o,t+.32,nf(97)+7,v*.25,1.4);cNoise(o,t+.32,.12,v*.6,{type:'highpass',f1:6000,f2:6000})}
function hxXylo(o,t,ms,gap,v){ms.forEach((m,i)=>{const tt=t+i*gap;cTone(o,tt,nf(m),.22,'sine',v,{a:.002});cTone(o,tt,nf(m)*3.93,.07,'sine',v*.35,{a:.001});cNoise(o,tt,.025,v*.5,{type:'bandpass',f1:3200,q:3,a:.001})})}
function hxMusicBox(o,t,v){let tt=t;for(const [m,d] of[[76,.36],[83,.18],[82,.18],[83,.36],[79,.18],[78,.18],[79,.36],[76,.18],[75,.18],[76,.36],[78,.18],[71,.54],[72,.36],[76,.18],[79,.18],[84,.36],[83,.18],[79,.18],[76,.9]]){cTone(o,tt,nf(m),1.3,'sine',v,{a:.002});cTone(o,tt,nf(m+12),.6,'triangle',v*.25,{a:.002});tt+=d}}
function hxReveal(o,t,tier,full){
 cKick(o,t,.5+tier*.07,100,30,1+tier*.15);cNoise(o,t,1+tier*.35,.2+tier*.02,{f1:4200+tier*800,f2:150});cNoise(o,t,.16,.28,{type:'bandpass',f1:900,f2:400,q:1.5});hxWhoomph(o,t+.02,.26+tier*.03);
 if(tier<=1){hxXylo(o,t+.06,tier?[64,67,71,76,79]:[72,71,70,69,68,67],tier?.07:.06,.11);cTone(o,t+.5,nf(52),.9,'triangle',.08,{a:.005});cTone(o,t+.5,nf(59),.9,'triangle',.06,{a:.005});hxToll(o,t+.45,nf(64),.05)}
 else if(tier===2){hxXylo(o,t+.05,[64,67,71,76,79,83],.06,.1);hxChord(o,t+.4,[52,59,64,67,71],1.6,.02);hxBats(o,t+.1,.7,.06)}
 else if(tier===3){hxChord(o,t+.05,[40,52,59,64,67,71],2.6,.022);[64,67,71].forEach(m=>cChoir(o,t+.2,nf(m),2.4,.02));hxGhost(o,t+.4,1.8,520,.05);hxBats(o,t+.05,1,.07)}
 else if(tier===4){const P=[[[38,50,57,62,65],.75],[[45,52,57,61,64],.75],[[38,50,57,62,65,69],2.3]];let tt=t+.05;for(const [ms,d] of P){hxChord(o,tt,ms,d+.1,.022);tt+=d}
  cTimp(o,t+.05,8,.07,.18);hxCackle(o,t+.45,.06);hxBats(o,t+.05,1.4,.08);cTone(o,t,nf(26),3,'sine',.22,{a:.05,hold:1,r:1});if(full)hxMusicBox(o,t+2.1,.05)}
 else{hxThunder(o,t,.24);cTone(o,t,nf(26),6,'sine',.26,{a:.08,hold:1,r:2});
  const P=full?[[[38,50,57,62,65],.95],[[34,46,53,58,62],.95],[[31,43,50,55,58],.95],[[33,45,52,57,61,64],.95],[[38,50,57,62,66,69,74],3.6]]:[[[38,50,57,62,66,69,74],2.8]];let tt=t+.1;
  for(const [ms,d] of P){hxChord(o,tt,ms,d+.12,.02);ms.slice(-3).forEach(m=>cChoir(o,tt,nf(m+12),d+.3,.014));tt+=d}
  [45,45,38].forEach((m,i)=>hxToll(o,t+.2+i*1.1,nf(m),.09));hxCackle(o,t+.7,.065);hxBats(o,t+.05,2,.09);
  hxTheremin(o,t+.25,2.2,[300,340,420,520,640,760,880,990,1100],.06);if(full){hxMusicBox(o,t+5,.05);cSpark(o,t+1.4,20,4,86,.025)}}}
function hxAudio(q){if(!axOn())return;const T0=ac.currentTime+.06,o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;q.aT=T0;const tier=q.tier,O=q.O;
 try{if(mg&&!ST.mute)mg.gain.setTargetAtTime(ST.mvol*.6*.12,ac.currentTime,.25)}catch(e){}
 cNoise(o,T0,O+2.5,.045,{type:'bandpass',f1:450,f2:1100,q:3,a:1.2});/* wind */
 hxToll(o,T0+.05,nf(45),.11);hxToccata(o,T0+.2,.018);
 hxDirt(o,T0+.45,1.2,.16);cKick(o,T0+1.62,.45,90,36,.5);cNoise(o,T0+1.62,.4,.18,{f1:900,f2:120});
 for(let i=0;i<5;i++)cNoise(o,T0+1.05+i*.11,.03,.12,{type:'bandpass',f1:3600,q:5,a:.001});/* bony knuckles */
 q.pt.forEach((tt,i)=>{hxWhoomph(o,T0+tt,.2);hxToll(o,T0+tt+.02,nf(45+[0,3,5,7,10,12][i]),.075)});
 if(tier>=1){let tb=T0+2.0,k=0;while(tb<T0+O-.15&&k<40){const u=(tb-T0-2)/Math.max(.5,O-2);hxHeart(o,tb,.18+.3*u);tb+=.9-.5*Math.min(1,u);k++}}
 if(tier>=2){const d=O-2.4,n=24,pts=[];for(let i=0;i<n;i++)pts.push(330+i*(tier>=4?28:18)+Math.sin(i*1.3)*60);hxTheremin(o,T0+2.1,d,pts,.035+tier*.006);
  for(let tt=2.3;tt<O-.6;tt+=1.4)hxGhost(o,T0+tt,1.3,380+Math.random()*220,.04);hxBats(o,T0+2.4,.8,.05);if(tier>=4)hxBats(o,T0+O-2,1,.06)}
 for(const tt of q.lt)hxThunder(o,T0+tt,.16+tier*.02);
 if(tier>=3)cNoise(o,T0+2,O-2,.12,{rev:1,type:'bandpass',f1:280,f2:5200,q:1.2});
 if(tier>=5){[50,57,62,65].forEach(m=>cChoir(o,T0+O-4.6,nf(m),4.6,.018));cTone(o,T0+5,36,O-5,'sawtooth',.05,{swell:1,lp:160,lp2:900});hxSwish(o,T0+O-.32,.22)}
 hxCreak(o,T0+O-.95,.9,.09);
 hxReveal(o,T0+O,tier,true)}
/* ======================= picture ======================= */
function hxStone(c,x,y,w,h,gc,ga,t){c.save();c.translate(x,y);
 const g=c.createLinearGradient(0,-h,0,0);g.addColorStop(0,'#5c6670');g.addColorStop(1,'#262c33');c.fillStyle=g;c.beginPath();c.moveTo(-w/2,0);c.lineTo(-w/2,-h+w/2);c.arc(0,-h+w/2,w/2,Math.PI,0);c.lineTo(w/2,0);c.closePath();c.fill();
 c.strokeStyle='#14181d';c.lineWidth=3;c.stroke();c.strokeStyle='#ffffff14';c.lineWidth=2;c.beginPath();c.arc(0,-h+w/2,w/2-14,Math.PI*1.05,Math.PI*1.95);c.stroke();
 c.strokeStyle='#0c0f12aa';c.lineWidth=2;c.beginPath();c.moveTo(w*.28,-h*.62);c.lineTo(w*.18,-h*.5);c.lineTo(w*.24,-h*.4);c.lineTo(w*.12,-h*.28);c.stroke();
 c.fillStyle='#3e6a3a';for(let i=0;i<9;i++){c.beginPath();c.ellipse(-w/2+8+i*w/9,-4,14,8+((i*7)%5),0,Math.PI,0);c.fill()}
 c.textAlign='center';c.textBaseline='middle';c.font='400 64px "Pirata One",Georgia,serif';c.fillStyle='#1a1f24';c.fillText('R.I.P.',2,-h+w/2+8);
 if(ga>0){c.save();c.globalAlpha=Math.min(1,ga);c.shadowColor=gc;c.shadowBlur=26;c.fillStyle=gc;c.fillText('R.I.P.',0,-h+w/2+6);c.restore()}
 c.fillStyle='#ffffff10';c.fillText('R.I.P.',0,-h+w/2+4);
 c.strokeStyle=ga>0?gc+hxA(ga*.8):'#1a1f24';c.lineWidth=3;c.beginPath();c.moveTo(-w*.28,-h+w/2+52);c.lineTo(w*.28,-h+w/2+52);c.stroke();c.restore()}
function hxHand(c,x,y,s,up,grip,flip){if(up<=0)return;c.save();c.translate(x,y);c.scale(flip?-s:s,s);c.beginPath();c.rect(-60,-200,120,200);c.clip();c.translate(0,(1-up)*150);
 c.lineCap='round';c.lineJoin='round';const bone='#e8e2cc',ol='#3a3428';
 const L=(a,b,cc,dd,w)=>{c.strokeStyle=ol;c.lineWidth=w+3;c.beginPath();c.moveTo(a,b);c.lineTo(cc,dd);c.stroke();c.strokeStyle=bone;c.lineWidth=w;c.beginPath();c.moveTo(a,b);c.lineTo(cc,dd);c.stroke()};
 L(-4,0,-6,-78,7);L(5,0,4,-78,6);c.fillStyle=bone;c.strokeStyle=ol;c.lineWidth=2;c.beginPath();c.ellipse(-1,-88,15,12,-.15,0,TAU);c.fill();c.stroke();
 for(let i=0;i<4;i++){const bx=-12+i*8,a0=-Math.PI/2-.35+i*.24,k1=.25+grip*1.05,k2=.3+grip*1.2;let px=bx,py=-96,a=a0;const l1=20-Math.abs(i-1.5)*2,l2=15-Math.abs(i-1.5)*2;
  let nx=px+Math.cos(a)*l1,ny=py+Math.sin(a)*l1;L(px,py,nx,ny,4.6);px=nx;py=ny;a+=k1;nx=px+Math.cos(a)*l2;ny=py+Math.sin(a)*l2;L(px,py,nx,ny,4);px=nx;py=ny;a+=k2;nx=px+Math.cos(a)*10;ny=py+Math.sin(a)*10;L(px,py,nx,ny,3.4)}
 L(12,-86,24,-100,4.6);L(24,-100,26-grip*8,-114+grip*4,4);c.restore()}
function hxReaper(c,x,y,s,al,sw,t){if(al<=0)return;c.save();c.globalAlpha=al;c.translate(x,y);c.scale(s,s);
 const rb='#0a0710',ed='#1c1530';const wv=Math.sin(t*1.6)*6;
 c.fillStyle=rb;c.beginPath();c.moveTo(-170,0);for(let i=0;i<=10;i++){const xx=-170+i*34;c.lineTo(xx,i%2?-22-wv*.3:4)}c.lineTo(170,0);c.bezierCurveTo(150,-160,120,-300,70,-400);c.bezierCurveTo(50,-470,-50,-470,-70,-400);c.bezierCurveTo(-120,-300,-150,-160,-170,0);c.fill();
 c.strokeStyle=ed;c.lineWidth=3;c.stroke();
 c.beginPath();c.moveTo(-82,-372);c.bezierCurveTo(-90,-500,90,-500,82,-372);c.bezierCurveTo(60,-350,-60,-350,-82,-372);c.fillStyle='#120c1c';c.fill();c.stroke();
 c.fillStyle='#000';c.beginPath();c.ellipse(0,-392,46,40,0,0,TAU);c.fill();
 const ef=.75+.25*Math.sin(t*4);for(const ex of[-16,16]){glow(c,ex,-398,26,'#5affb0'+hxA(.8*ef));ell(c,ex,-398,6,4,'#c8ffe6')}
 /* scythe: pivot at the bony hand */
 c.save();c.translate(118,-250);c.rotate(-1.15+sw*2.05);c.strokeStyle='#2a1c12';c.lineWidth=9;c.lineCap='round';c.beginPath();c.moveTo(0,90);c.lineTo(0,-300);c.stroke();
 c.fillStyle='#c8d0d8';c.strokeStyle='#5affb0';c.lineWidth=2;c.beginPath();c.moveTo(0,-290);c.quadraticCurveTo(-170,-330,-250,-210);c.quadraticCurveTo(-150,-268,-6,-262);c.closePath();c.fill();c.shadowColor='#5affb0';c.shadowBlur=18;c.stroke();c.shadowBlur=0;c.restore();
 c.fillStyle='#e8e2cc';c.beginPath();c.ellipse(118,-250,14,11,0,0,TAU);c.fill();c.restore()}
function hxCandy(c,p){c.save();c.translate(p.x,p.y);c.rotate(p.r);c.globalAlpha=Math.min(1,p.l*1.5);const s=p.s;
 if(p.k===0){c.fillStyle='#ffd23a';c.beginPath();c.moveTo(-s,s*.9);c.lineTo(s,s*.9);c.lineTo(0,-s*1.4);c.closePath();c.fill();c.fillStyle='#ff8a1a';c.beginPath();c.moveTo(-s*.7,s*.15);c.lineTo(s*.7,s*.15);c.lineTo(0,-s*1.4);c.closePath();c.fill();c.fillStyle='#fff8e8';c.beginPath();c.moveTo(-s*.32,-s*.55);c.lineTo(s*.32,-s*.55);c.lineTo(0,-s*1.4);c.closePath();c.fill()}
 else if(p.k===1){c.fillStyle=p.c;c.beginPath();c.arc(0,0,s*.8,0,TAU);c.fill();c.beginPath();c.moveTo(-s*.7,0);c.lineTo(-s*1.6,-s*.6);c.lineTo(-s*1.6,s*.6);c.closePath();c.moveTo(s*.7,0);c.lineTo(s*1.6,-s*.6);c.lineTo(s*1.6,s*.6);c.closePath();c.fill();c.fillStyle='#ffffff55';c.beginPath();c.arc(-s*.25,-s*.25,s*.25,0,TAU);c.fill()}
 else{c.fillStyle='#e8e2cc';c.beginPath();c.arc(0,-s*.2,s*.8,0,TAU);c.fill();c.fillRect(-s*.45,s*.3,s*.9,s*.5);c.fillStyle='#120a18';c.beginPath();c.arc(-s*.3,-s*.25,s*.2,0,TAU);c.arc(s*.3,-s*.25,s*.2,0,TAU);c.fill()}
 c.restore()}
function hxBolt(x0,x1,y1){const pts=[[x0,-30]];let x=x0,y=-30;const n=14;for(let i=1;i<=n;i++){y=-30+(y1+30)*i/n;x=lerp(x0,x1,i/n)+(i<n?(Math.random()-.5)*90:0);pts.push([x,y])}
 const br=[];for(let k=0;k<3;k++){const i=3+Math.floor(Math.random()*8),p=pts[i];let bx=p[0],by=p[1];const b=[[bx,by]];const dir=Math.random()<.5?-1:1;for(let j=0;j<5;j++){bx+=dir*(20+Math.random()*40);by+=30+Math.random()*30;b.push([bx,by])}br.push(b)}return{pts,br}}
function hxDrip(c,word,cx,ty,size,col,post,start,tier){c.save();c.font='400 '+size+'px "Pirata One",Georgia,serif';c.textAlign='center';c.textBaseline='middle';const sp=size*.18,ws=[...word].map(g=>c.measureText(g).width+sp),tot=ws.reduce((a,b)=>a+b,0);let x=cx-tot/2;
 for(let i=0;i<word.length;i++){const u=sstep(start+i*.08,start+i*.08+.3,post);if(u>0){const xx=x+ws[i]/2,yy=ty+(1-u)*-40;c.save();c.globalAlpha=u;c.translate(xx,yy);
   const dl=sstep(start+.4+i*.08,start+2.4+i*.08,post);c.fillStyle=col;for(let k=0;k<2;k++){const h=((i*7+k*13)%5),dx=(k?.22:-.18)*ws[i]+h,len=(size*.18+h*size*.06)*dl;if(len>1){c.beginPath();c.roundRect(dx-3,size*.18,6,len,3);c.fill();c.beginPath();c.arc(dx,size*.18+len,5,0,TAU);c.fill()}}
   c.shadowColor=col;c.shadowBlur=30;c.lineWidth=tier>=4?9:6;c.strokeStyle='#000d';c.lineJoin='round';c.strokeText(word[i],0,0);c.fillStyle=col;c.fillText(word[i],0,0);c.shadowBlur=0;c.fillStyle='#ffffff40';c.fillText(word[i],0,-2);c.restore()}x+=ws[i]}c.restore()}
function hxUpdate(){const q=S.cr2;if(!q)return;const now=performance.now(),dt=Math.min(.1,Math.max(0,(now-q.last)/1000));q.last=now;q.t+=dt;const t=q.t,O=q.O,T=q.tier,cx=W/2,by=GY-30,tc=hxTC(q);
 q.shk=Math.max(0,q.shk-dt*46);q.fl=Math.max(0,q.fl-dt*(T>=5?.9:1.6));q.boltF=Math.max(0,q.boltF-dt*3);
 if(t>.45&&t<1.65&&Math.random()<dt*40){for(let k=0;k<3;k++)q.dirt.push({x:cx+(Math.random()-.5)*300,y:by,vx:(Math.random()-.5)*380,vy:-260-Math.random()*420,l:1.4,s:3+Math.random()*6,c:Math.random()<.5?'#3a2a1c':'#5a4430'})}
 if(t>.45&&t<1.6)q.shk=Math.max(q.shk,5);
 if(t>1.6&&!q.fired.land){q.fired.land=1;q.shk=14;for(let k=0;k<40;k++)q.dirt.push({x:cx+(Math.random()-.5)*320,y:by,vx:(Math.random()-.5)*600,vy:-200-Math.random()*380,l:1.6,s:3+Math.random()*7,c:Math.random()<.5?'#3a2a1c':'#5a4430'})}
 q.pt.forEach((pt,i)=>{if(t>=pt&&!q.lit[i]){q.lit[i]=1;q.litT[i]=t;const p=HX_PK[HX_ORD[i]],x=cx+p[0],y=by+p[1];for(let k=0;k<26;k++){const a=-Math.PI/2+(Math.random()-.5)*1.4,v=120+Math.random()*320;fxAdd(q,{x,y:y-30,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.6+Math.random()*.7,g:-60,s:2+Math.random()*3,c:HX_FIRE[T],ty:'dot'})}q.shk=Math.max(q.shk,4)}});
 q.lt.forEach((lt,i)=>{const k='b'+i;if(t>=lt&&!q.fired[k]){q.fired[k]=1;const last=i===q.lt.length-1&&T>=4,x1=last?cx:cx+(Math.random()<.5?-1:1)*(300+Math.random()*400);q.bolt=hxBolt(x1+(Math.random()-.5)*200,x1,last?by-220:GY+20);q.bolt.t0=t;q.boltF=1;q.shk=Math.max(q.shk,T>=5?22:16);
   for(let j=0;j<40;j++){const a=Math.random()*TAU,v=200+Math.random()*500;fxAdd(q,{x:x1,y:last?by-220:GY,vx:Math.cos(a)*v,vy:Math.sin(a)*v-200,l:.5+Math.random()*.6,g:600,s:2+Math.random()*3,c:'#e8fff4',ty:'dot'})}}});
 if(t>2&&t<O&&T>=2&&Math.random()<dt*(1+T*.8)){q.bats.push({x:Math.random()<.5?-40:W+40,y:150+Math.random()*350,vx:0,vy:0,l:3,s:1.6+Math.random()*1.4,ph:Math.random()*6,orb:1,a:Math.random()*TAU})}
 if(t>1.9&&t<O){const ch=sstep(1.9,O,t);q.shk=Math.max(q.shk,T>=3?ch*(3+T*1.6):0)}
 if(T>=5&&t>=O-.3&&!q.fired.cut){q.fired.cut=1;q.cut=t;q.fl=Math.max(q.fl,.35);q.shk=Math.max(q.shk,20)}
 if(t>=O&&!q.fired.open){q.fired.open=1;q.fl=1;q.shk=[14,14,18,24,36,52][T];
  const n=[60,80,110,170,300,480][T];for(let i=0;i<n;i++){const a=-Math.PI/2+(Math.random()-.5)*Math.PI*1.6,v=200+Math.random()*(T>=4?1100:700);fxAdd(q,{x:cx,y:by-180,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1+Math.random()*(T>=4?2.2:1.1),g:420,dr:.5,s:2+Math.random()*(T>=4?6:4),c:Math.random()<.55?tc:Math.random()<.5?'#e8fff4':HX_FIRE[T],ty:Math.random()<.3?'star':'dot'})}
  for(const g of q.gh){const x=cx+Math.cos(g.a)*g.r*1.25,y=by-170+Math.sin(g.a)*g.r*.32;q.rel.push({x,y,vx:Math.cos(g.a)*(300+Math.random()*300),vy:-260-Math.random()*300,l:2.4,s:g.s,ph:g.ph})}
  for(let i=0;i<[2,3,4,6,10,16][T];i++)q.rel.push({x:cx+(Math.random()-.5)*120,y:by-200,vx:(Math.random()-.5)*700,vy:-400-Math.random()*400,l:2.6,s:3+Math.random()*2.5,ph:Math.random()*6});
  for(let i=0;i<[10,14,22,32,52,84][T];i++){const a=-Math.PI/2+(Math.random()-.5)*2.4,v=300+Math.random()*700;q.bats.push({x:cx+(Math.random()-.5)*80,y:by-200,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:2.6,s:1.8+Math.random()*1.8,ph:Math.random()*6})}
  for(let i=0;i<[20,30,40,60,90,140][T];i++){const a=-Math.PI/2+(Math.random()-.5)*2,v=300+Math.random()*800;q.cf.push({x:cx+(Math.random()-.5)*80,y:by-200,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:3+Math.random()*2,g:700,r:Math.random()*6,vr:(Math.random()-.5)*12,s:7+Math.random()*6,k:Math.random()<.5?0:Math.random()<.7?1:2,c:['#c86bff','#ff8a1a','#5affb0','#ff4d94'][Math.random()*4|0]})}
  if(T>=5)for(let i=0;i<80;i++)q.cf.push({x:Math.random()*W,y:-20-Math.random()*300,vx:(Math.random()-.5)*80,vy:60+Math.random()*120,l:7,g:40,r:Math.random()*6,vr:(Math.random()-.5)*6,s:7+Math.random()*5,k:Math.random()<.6?0:1,c:['#c86bff','#ff8a1a','#5affb0'][Math.random()*3|0]})}
 if(t>O&&T>=4&&t<O+(T>=5?7:2.5)&&Math.random()<dt*20){q.cf.push({x:Math.random()*W,y:-20,vx:(Math.random()-.5)*60,vy:80+Math.random()*100,l:7,g:30,r:Math.random()*6,vr:(Math.random()-.5)*6,s:7+Math.random()*5,k:Math.random()<.6?0:1,c:['#c86bff','#ff8a1a','#5affb0'][Math.random()*3|0]})}
 fxStep(q,dt);
 for(const d of q.dirt){d.l-=dt;d.x+=d.vx*dt;d.y+=d.vy*dt;d.vy+=1300*dt;if(d.y>by+30)d.l=0}q.dirt=q.dirt.filter(d=>d.l>0);
 for(const g of q.rel){g.l-=dt;g.x+=g.vx*dt;g.y+=g.vy*dt;g.vy-=60*dt;g.vx*=1-dt*.4}q.rel=q.rel.filter(g=>g.l>0);
 for(const b of q.bats){b.l-=dt;if(b.orb&&t<O){b.a+=dt*1.6;const tx=cx+Math.cos(b.a)*520,ty=by-330+Math.sin(b.a*1.3)*120;b.x+=(tx-b.x)*dt*1.6;b.y+=(ty-b.y)*dt*1.6;b.l=Math.max(b.l,.5)}else{if(b.orb){b.orb=0;const a=Math.atan2(b.y-(by-200),b.x-cx);b.vx=Math.cos(a)*600;b.vy=Math.sin(a)*600-200}b.x+=b.vx*dt;b.y+=b.vy*dt;b.vy-=40*dt}}q.bats=q.bats.filter(b=>b.l>0&&b.y>-80&&b.x>-120&&b.x<W+120);
 for(const p of q.cf){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.g*dt;p.vx*=1-dt*.6;p.r+=p.vr*dt;if(p.y>GY+60){p.y=GY+60;p.vy*=-.3;p.vx*=.6;p.vr*=.5}}q.cf=q.cf.filter(p=>p.l>0);
 if(t>=q.E&&!q.done){q.done=true;crateResult()}}
function hxDraw(){const q=S.cr2,t=Math.max(0,q.t),c=ctx,cx=W/2,by=GY-30,T=q.tier,O=q.O,tc=hxTC(q),ch=sstep(1.9,O,t),post=Math.max(0,t-O),fire=HX_FIRE[T];
 c.save();if(q.shk>0&&ST.shake)c.translate((Math.random()-.5)*q.shk,(Math.random()-.5)*q.shk);
 /* night deepens with the tier */
 c.fillStyle=`rgba(2,4,10,${(.38+ch*.08*T*(1-sstep(O,O+.4,t)*.5)).toFixed(3)})`;c.fillRect(-60,-60,W+120,H+120);
 /* the moon reacts: violet at Epic, blood-orange at Legendary, an eclipse with a witch-fire corona at Mythic */
 {const mx=W*.22,my=190,mr=74;if(T===3){c.save();c.globalCompositeOperation='lighter';glow(c,mx,my,200,'#c86bff'+hxA(ch*.5));c.restore()}
  if(T===4){c.save();c.globalAlpha=ch;c.fillStyle='#ff5a1a';c.beginPath();c.arc(mx,my,mr,0,TAU);c.fill();c.globalAlpha=ch*.6;c.fillStyle='#8a1a0a';c.beginPath();c.arc(mx-18,my-12,20,0,TAU);c.arc(mx+20,my+14,26,0,TAU);c.fill();c.restore();c.save();c.globalCompositeOperation='lighter';glow(c,mx,my,240,'#ff6a1a'+hxA(ch*.45));c.restore()}
  if(T===5){const e=sstep(2.2,O-1,t),ox=lerp(150,0,e);c.save();c.globalCompositeOperation='lighter';glow(c,mx,my,90+e*260,'#5affb0'+hxA(e*.6));c.strokeStyle='#5affb0'+hxA(e);c.lineWidth=4;c.shadowColor='#5affb0';c.shadowBlur=30;c.beginPath();c.arc(mx,my,mr+3,0,TAU);c.stroke();c.restore();c.fillStyle='#04060a';c.beginPath();c.arc(mx+ox,my,mr+1,0,TAU);c.fill()}}
 /* lightning */
 if(q.bolt&&t-q.bolt.t0<.45){const a=1-(t-q.bolt.t0)/.45;c.save();c.globalCompositeOperation='lighter';c.lineJoin='round';const dr=(pts,w)=>{c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.strokeStyle=(T>=5?'#5affb0':'#b8d8ff')+hxA(a*.5);c.lineWidth=w*3;c.stroke();c.strokeStyle='#ffffff'+hxA(a);c.lineWidth=w;c.stroke()};dr(q.bolt.pts,3.4);for(const b of q.bolt.br)dr(b,1.6);c.restore()}
 if(q.boltF>0){c.fillStyle=(T>=5?'rgba(200,255,230,':'rgba(220,235,255,')+(q.boltF*.35).toFixed(3)+')';c.fillRect(0,0,W,H)}
 /* the Reaper rises behind the stone */
 if(T>=5){const up=sstep(4.6,8.4,t),al=up*(t<O?1:Math.max(0,1-post/3.2));const sw=t<O-.32?0:sstep(O-.32,O-.08,t);hxReaper(c,cx+20,by-40+(1-up)*360,1.05,al,sw,t)}
 /* stone and open grave */
 const rise=sstep(.45,1.6,t),lev=T>=4?ch*(T>=5?26:14)*(t<O?1:Math.max(0,1-post*3)):0;
 hxStone(c,cx,by-36,310,400,tc,ch*.9+(t>O?.6:0),t);
 c.fillStyle='#07050a';c.beginPath();c.ellipse(cx,by+6,190*Math.min(1,t*2.5),26,0,0,TAU);c.fill();
 /* ghosts behind */
 const ghost=(front)=>{for(const g of q.gh){if(t<g.t0||t>=O)continue;const ap=Math.min(1,(t-g.t0)*1.8);g.a+=0;const a=g.a+(t-g.t0)*g.sp*(1+ch*2.4),sa=Math.sin(a);if((sa>0)!==front)continue;const x=cx+Math.cos(a)*g.r*1.25,y=by-170+sa*g.r*.32+Math.sin(t*2+g.ph)*14;hwGhost(c,x,y,g.s*(front?1.05:.85),t+g.ph,'#e8fff0',ap*(front?.72:.42))}};
 ghost(false);
 /* the crate claws its way up */
 const shx=t>1.9&&t<O?Math.sin(t*70)*(2+ch*(5+T*3)):0,open=sstep(O,O+.5,t),os=open>0?1+Math.sin(open*Math.PI)*.07:1;
 if(t>1.9){c.save();c.globalCompositeOperation='lighter';glow(c,cx,by-120,(220+ch*240)*(open>0?1.6:1),tc+hxA(.25+ch*.25));c.restore()}
 c.save();c.beginPath();c.rect(0,0,W,by+4);c.clip();hwChest(c,cx+shx,by+(1-rise)*300-lev,2.1*os,open,t);c.restore();
 /* mounds of dirt either side */
 for(const s of[-1,1]){c.fillStyle='#2a1e14';c.beginPath();c.ellipse(cx+s*215,by+14,110,30*Math.min(1,t*2),0,Math.PI,0);c.fill();c.fillStyle='#3a2a1c';for(let k=0;k<6;k++){c.beginPath();c.arc(cx+s*(150+k*24),by+4-((k*13)%9),7+(k%3)*3,0,TAU);c.fill()}}
 /* skeletal hands grip the ground */
 {const up=sstep(1.0,1.8,t)*(t<O+.4?1:Math.max(0,1-(post-.4)*1.5)),gr=sstep(1.5,2.1,t)*(1-sstep(O-.2,O+.2,t)*.6)+(t>1.9&&t<O?Math.sin(t*9)*.08:0);hxHand(c,cx-268,by+22,1,up,gr,false);hxHand(c,cx+268,by+22,1,up,gr,true)}
 ghost(true);
 /* jack-o'-lanterns: one wakes per tier */
 for(let i=0;i<6;i++){const p=HX_PK[i],x=cx+p[0],y=by+p[1],oi=HX_ORD.indexOf(i),lit=q.lit[oi],r=26+Math.abs(p[0])/60;
  if(!lit){hwPumpkin(c,x,y,r,t,{lit:false,c:'#9a4a14'});c.save();c.translate(x,y);c.scale(r/12,r/12);c.fillStyle='#1a0a04';c.beginPath();c.moveTo(-6.4,-1.6);c.lineTo(-1.6,-1.2);c.lineTo(-4.2,-6);c.closePath();c.moveTo(1.6,-1.2);c.lineTo(6.4,-1.6);c.lineTo(4.2,-6);c.closePath();c.fill();c.beginPath();c.moveTo(-6.6,4.6);c.lineTo(6.6,4.6);c.lineTo(5.2,9.2);c.quadraticCurveTo(0,11.6,-5.2,9.2);c.closePath();c.fill();c.restore()}
  else{const k=Math.min(1,(t-q.litT[oi])*3);hwPumpkin(c,x,y,r*(1+(1-k)*.25),t,{});if(T>=2){c.save();c.globalCompositeOperation='lighter';glow(c,x,y,r*2.6,fire+hxA(.55));c.restore()}
   c.save();c.globalCompositeOperation='lighter';const fh=r*(.95+.18*Math.sin(t*11+i)+.08*Math.sin(t*27+i*3))*k,fw=r*.26,sw=Math.sin(t*7+i)*r*.12,fy=y-r*.82;
    for(const [sc,c0,c1] of[[1.35,fire+'00',fire+'55'],[1,fire+'22',fire+'dd'],[.55,'#ffe9a800','#fff6d0ee']]){const h2=fh*sc,w2=fw*sc,g=c.createRadialGradient(x,fy-h2*.15,1,x,fy-h2*.25,h2*.9);g.addColorStop(0,c1);g.addColorStop(1,c0);c.fillStyle=g;
     c.beginPath();c.moveTo(x-w2,fy);c.bezierCurveTo(x-w2*1.1,fy-h2*.45,x+sw-w2*.25,fy-h2*.7,x+sw*1.4,fy-h2);c.bezierCurveTo(x+sw+w2*.25,fy-h2*.7,x+w2*1.1,fy-h2*.45,x+w2,fy);c.quadraticCurveTo(x,fy+w2*.5,x-w2,fy);c.fill()}
    glow(c,x,fy-fh*.4,r*1.2,fire+'55');c.restore()}}
 /* dirt clods */
 for(const d of q.dirt){c.globalAlpha=Math.min(1,d.l*2);c.fillStyle=d.c;c.fillRect(d.x-d.s/2,d.y-d.s/2,d.s,d.s)}c.globalAlpha=1;
 /* soul-fire column */
 if(open>0){const dur=T>=5?3.6:T>=4?2.4:1.6,u=post/dur;if(u<1){const e=sstep(0,.15,u)*(1-sstep(.6,1,u)),w=(60+T*30)*e*(1+.08*Math.sin(t*30));c.save();c.globalCompositeOperation='lighter';const g=c.createLinearGradient(cx-w,0,cx+w,0);g.addColorStop(0,tc+'00');g.addColorStop(.35,tc+'aa');g.addColorStop(.5,'#ffffffee');g.addColorStop(.65,tc+'aa');g.addColorStop(1,tc+'00');c.fillStyle=g;c.fillRect(cx-w,-20,w*2,by-150);
  for(let k=0;k<8;k++){const yy=((t*700+k*120)%(by-150)),xx=cx+Math.sin(t*9+k)*w*.6;glow(c,xx,by-150-yy,24+T*4,tc+'88')}c.restore()}}
 /* released ghosts */
 for(const g of q.rel)hwGhost(c,g.x,g.y,g.s,t+g.ph,'#e8fff0',Math.min(.8,g.l*.5));
 /* bats */
 for(const b of q.bats)hwBatShape(c,b.x,b.y,b.s,Math.sin(t*22+b.ph),'#120a18',T>=5?'#5affb0':'#ff3030');
 /* sparks */
 c.save();c.globalCompositeOperation='lighter';for(const p of q.fx){c.globalAlpha=Math.max(0,Math.min(1,p.l*1.3));c.fillStyle=p.c;if(p.ty==='star')cStar(c,p.x,p.y,p.s*2.2,p.l*3);else c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}c.restore();
 /* the prize rises out of the witch-fire */
 if(t>O+.25){const hot=T>=4,u=sstep(O+.3,O+.3+(hot?1.6:1.1),t),y=lerp(by-170,by-430,u)+Math.sin(S.t*2)*(u>.98?8:0),sc=lerp(.4,1.3,u);if(T>=3){try{art(q.img,q.k==='a'?'a':'w',q.id,S.t)}catch(e){}}
  c.save();c.translate(cx,y);c.scale(sc,sc);c.save();c.globalCompositeOperation='lighter';glow(c,0,0,hot?310:230,tc+'77');c.restore();
  c.save();c.rotate(S.t*.5);c.strokeStyle=tc;c.shadowColor=tc;c.shadowBlur=22;c.lineWidth=4;c.beginPath();c.arc(0,0,150,0,TAU);c.stroke();c.lineWidth=2;c.beginPath();c.arc(0,0,166,0,TAU);c.stroke();
   for(let i=0;i<16;i++){c.rotate(TAU/16);c.beginPath();c.moveTo(0,-150);c.lineTo(0,-166);c.moveTo(-5,-158);c.lineTo(5,-158);c.stroke()}c.restore();
  if(T>=3){c.save();c.rotate(-S.t*.8);c.globalAlpha=.85;c.strokeStyle=fire;c.lineWidth=2;c.setLineDash([10,14]);c.beginPath();c.arc(0,0,188,0,TAU);c.stroke();c.restore()}
  c.shadowBlur=0;c.drawImage(q.img,-130,-130,260,260);
  if(T>=4){const n=T>=5?8:5;for(let i=0;i<n;i++){const a=S.t*(T>=5?1.1:.8)+i*TAU/n,ox=Math.cos(a)*225,oy=Math.sin(a)*70;if(T>=5&&i%2)hwGhost(c,ox,oy,3.2,S.t+i,'#e8fff0',.75);else hwPumpkin(c,ox,oy,16,S.t+i,{})}}
  c.restore()}
 /* candy and skull confetti */
 for(const p of q.cf)hxCandy(c,p);
 /* rolling ground fog */
 c.save();for(let k=0;k<4;k++){const yy=GY+40+k*26,sp=(k%2?-1:1)*(20+k*10);for(let i=-1;i<7;i++){const xx=((i*300+t*sp)%(W+600)+W+600)%(W+600)-300;const g=c.createRadialGradient(xx,yy,10,xx,yy,240);g.addColorStop(0,(T>=5?'#5affb0':'#b8d8c8')+hxA(.13+ch*.05));g.addColorStop(1,'#b8d8c800');c.fillStyle=g;c.fillRect(xx-240,yy-120,480,240)}}c.restore();
 c.restore();
 /* letterbox for the big pulls */
 if(T>=4){const bu=sstep(2.2,O-.6,t)*(1-sstep(O+1.4,O+2.6,t)),bar=74*bu;if(bar>.5){c.fillStyle='#000';c.fillRect(0,0,W,bar);c.fillRect(0,H-bar,W,bar)}}
 /* dripping rarity title */
 if(post>0){const size=[52,58,72,88,112,138][T];hxDrip(c,q.it.r.toUpperCase(),cx,98,size,T>=5?hsx(S.t*120,100,66):tc,post,T>=5?1.0:T>=4?.7:.45,T)}
 /* witch-fire flash */
 if(q.fl>0){c.fillStyle=(T>=4?'rgba(220,255,236,':'rgba(255,255,255,')+Math.min(1,q.fl*.85).toFixed(3)+')';c.fillRect(0,0,W,H)}
 if(T>=5&&post>0&&post<4.5){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=(1-post/4.5)*.35;const g=c.createRadialGradient(cx,CCY-40,0,cx,CCY-40,1100);g.addColorStop(0,'#5affb0');g.addColorStop(.5,'#c86bff');g.addColorStop(1,'#ff9a3000');c.fillStyle=g;c.fillRect(0,0,W,H);c.restore()}}
/* ---------- hooks: only the Graveyard crate takes this path ---------- */
{const ca=crateAudio;crateAudio=function(q){if(q&&q.ck==='h'){hxPrep(q);return hxAudio(q)}return ca(q)}}
{const cu=crateUpdate;crateUpdate=function(dt){if(S.cr2&&S.cr2.hw)return hxUpdate();return cu(dt)}}
{const dc=drawCrateScene;drawCrateScene=function(){if(S.cr2&&S.cr2.hw){hxDraw();const q=S.cr2;
  /* once the result text is up, fade the chest's lower half so the item name and description read cleanly */
  if(q.done&&!q.fadeOut){const a=Math.min(1,(q.t-q.E)/.6);const c=ctx,g=c.createLinearGradient(0,590,0,780);g.addColorStop(0,'rgba(4,2,12,0)');g.addColorStop(.55,'rgba(4,2,12,'+(.82*a).toFixed(3)+')');g.addColorStop(1,'rgba(4,2,12,'+(.92*a).toFixed(3)+')');c.save();c.fillStyle=g;c.fillRect(0,590,W,H-590);c.restore()}
  return}return dc()}}
/* trophy pop-ups sit in the top-right corner during a crate opening so they never cover the rarity title */
{const nt0=nextToast;nextToast=function(){nt0();const el=document.getElementById('toast');if(el&&S.mode==='crate')el.classList.add('cr')}}
{const sk=crateSkip;crateSkip=function(){const q=S.cr2;if(!q||!q.hw)return sk();if(q.done)return;
  if(q.t<q.O-.05){crateFade(q,.05);if(axOn()){const o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;hxReveal(o,ac.currentTime+.05,q.tier,false)}const tm=q.O-.05;q.pt.forEach((pt,i)=>{if(!q.lit[i]){q.lit[i]=1;q.litT[i]=tm-.4}});q.t=tm;q.skipped=1}
  else if(q.t<q.E)q.t=q.E}}
{const ce=crateEnd;crateEnd=function(){const hw=S.cr2&&S.cr2.hw;ce();if(hw)try{if(mg)mg.gain.setTargetAtTime(ST.mute?0:ST.mvol*.6,ac.currentTime,.4)}catch(e){}}}
