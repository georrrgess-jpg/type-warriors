/* ===== RUNESTONE RAMPARTS (Update 8.8b): data =====
   A strategy tower-defense mode: no typing. Monsters walk the roads toward the castle; towers on stone pads fire on their own; three
   abilities (Overcharge, Slow Field, Repair) recharge on cooldowns. Supply builds and upgrades towers during a run; coins are earned per
   monster, per wave and for a win, with no ceiling (Freeplay keeps paying).
   Maps fill the whole 1600x900 stage. Each map has its own twist: Mossgate Hollow one long road over a river bridge; Frostfang Pass two
   entrances that merge and icy patches that speed monsters up; Ember Crown a road that splits and rejoins, and lava vents that scorch
   monsters walking past. Code prefix rp, state RPX (95e), save P.rp via RPP(). */
const RPT={HP:20,SELL:.7,EARLY:3,BUILD_T:15,BUILD_ANIM:.9,UP_ANIM:.7,FIRSTDAY:1.5,
 AB:{over:{cd:45,dur:10,k:2.4,n:'Overcharge',key:'1',desc:'A tower fires 2.4x faster for 10 s.'},slow:{cd:40,dur:7,k:.45,r:100,n:'Slow Field',key:'2',desc:'Freezes a stretch of road for 7 s: monsters there move at half speed.'},
  repair:{cd:70,heal:4,n:'Repair',key:'3',desc:'Restores 4 health to the castle.'}},
 ICE_K:1.45,VENT_T:9,VENT_R:78,VENT_K:.1,
 UI:{top:108,bottom:772,castleX:1325},ASC_ANIM:1.4};
/* towers: arrays are per tier 1..5 (tiers 4 and 5 only in the endless Wonderland). cost[0] builds, cost[k] upgrades to tier k+1.
   cd = seconds between shots. ap = armor it ignores. The Celestial Prism fires continuous beams instead (dps per beam, ramping up). */
const RP_TW={
 ballista:{cost:[100,150,280,600,1000],range:[230,250,280,300,320],dmg:[24,44,84,150,250],cd:[.95,.8,.62,.55,.48],ap:[3,6,99,99,99],pierce:[0,0,1,2,3],air:1,ground:1,
  desc:'Strong single shots. Hits flyers and pierces armor.',up:['Heavier bow: more damage and range.','Twin-rune bolts: armor no longer matters, and each bolt passes through to a second foe.','Mythic arbalest: bolts pierce two more foes and hit far harder.','Celestial arbalest: starlit bolts pierce three more foes.']},
 brazier:{cost:[120,170,300,640,1050],range:[175,190,210,225,240],dmg:[20,34,60,100,165],cd:[1.3,1.15,1.0,.92,.84],splash:[62,74,92,106,120],burn:[0,0,10,18,30],air:0,ground:1,
  desc:'Blazing embers that splash every foe nearby. Cannot hit flyers.',up:['Wider, hotter blasts.','Triple vents: blasts leave burning ground.','Mythic furnace: violet fire, wider blasts, hotter burning ground.','Celestial sunfire: huge blasts that leave searing starfire.']},
 frost:{cost:[90,130,240,520,900],range:[160,178,198,215,232],dmg:[6,10,16,26,40],cd:[1.05,.95,.85,.8,.72],slow:[.36,.46,.58,.64,.7],slowT:[1.6,1.9,2.3,2.6,3],air:0,ground:1,
  desc:'Frost pulses chill and slow every ground foe in range.',up:['Colder pulse: slows harder and longer.','Frost crown: chilled foes take double damage from the pulse.','Mythic glacier: the pulse reaches flyers too.','Celestial winter: every pulse freezes monsters solid for a moment.']},
 bell:{cost:[110,160,290,620,1000],range:[220,238,265,285,305],dmg:[24,40,70,115,180],cd:[1.15,1.0,.85,.76,.68],chain:[2,3,5,7,9],airK:2,air:1,ground:1,
  desc:'Lightning that chains between foes. Double damage to flyers.',up:['A second bell: longer chains.','Storm crown: five-foe chains that stun flyers.','Mythic carillon: seven-foe chains.','Celestial tempest: nine-foe chains.']},
 prism:{cost:[400,450,700,1300,2200],range:[240,255,275,295,320],dps:[72,100,135,205,320],beams:[1,2,3,4,5],ap:[0,0,99,99,99],ramp:1.8,rampK:1.35,nova:[0,0,0,0,240],novaR:175,novaT:4,air:1,ground:1,
  desc:'A radiant beam that burns hotter the longer it holds a target. Hits flyers. The costliest tower, and the brightest.',up:['Refracts into a second beam.','Three beams that melt armor.','Mythic prism: four beams.','Celestial prism: five beams and a supernova every few seconds.']}};
const RP_TWORDER=['ballista','brazier','frost','bell','prism'];
const RP_MAXT=m=>m&&m.endless?5:3;/* the top tier on a map */
/* foes: hp at wave 1 of the first map, speed px/s, bounty = supply, coin = coins paid for the kill, dmg = health lost when it gets through */
const RP_FOE={
 scamp:{hp:30,sp:96,bounty:5,coin:2,dmg:1,armor:0},
 bulwark:{hp:72,sp:54,bounty:7,coin:3,dmg:1,armor:4},
 golem:{hp:280,sp:36,bounty:18,coin:8,dmg:3,armor:9},
 gloom:{hp:44,sp:78,bounty:7,coin:3,dmg:1,armor:0,air:1},
 ooze:{hp:120,sp:48,bounty:8,coin:4,dmg:2,armor:0,split:'oozelet',splitN:2},
 oozelet:{hp:32,sp:74,bounty:2,coin:1,dmg:1,armor:0},
 shaman:{hp:96,sp:50,bounty:12,coin:5,dmg:2,armor:0,heal:.08,healR:105,healT:2.4},
 behemoth:{hp:2600,sp:24,bounty:150,coin:90,dmg:10,armor:10,boss:1}};
const RP_FOETIP={scamp:'Fast runners. Cover the road early.',bulwark:'Shielded squads. Splash from the Ember Blazer breaks them.',golem:'Heavy armor. Rune Ballista bolts pierce it.',
 gloom:'Flies over everything. Only the Rune Ballista and the Storm Bell can hit it.',ooze:'Splits in two when it pops.',oozelet:'Small, quick and squishy.',
 shaman:'Heals nearby monsters. Take it down first.',behemoth:'The boss. Slow it, focus it, and keep Repair ready.'};
/* maps. paths: every road from an entrance to the castle gate (shared stretches repeat the same points). pads are chosen from the roads. */
const RP_MAPS=[
 {id:'moss',n:'Mossgate Hollow',sub:'One long forest road',waves:10,start:300,hpk:1.15,spk:1.05,coinK:1,bonus:400,late:.2,lateW:4,lateC:.1,xp:120,pal:'moss',pads:12,
  twist:'A single winding road crosses the river on an old bridge.',
  paths:[[[-60,330],[120,322],[250,380],[330,500],[300,620],[400,712],[600,722],[720,640],[740,500],[690,380],[760,250],[930,190],[1080,240],[1130,380],[1080,520],[1150,660],[1300,690],[1450,628]]],
  river:[[842,-30],[876,170],[856,380],[924,560],[896,760],[958,930]]},
 {id:'frost',n:'Frostfang Pass',sub:'Two entrances, icy road',waves:15,start:340,hpk:1.45,spk:1.04,coinK:.55,bonus:600,late:.85,lateW:5,lateC:.35,xp:200,pal:'frost',pads:13,
  twist:'Monsters come from two caves at once, and icy patches speed them up.',
  paths:[[[-60,200],[150,210],[300,282],[400,400],[470,470],[620,470],[720,360],[700,232],[820,162],[1000,172],[1080,282],[1010,410],[1060,560],[1180,642],[1320,648],[1450,628]],
         [[-60,700],[160,690],[310,620],[420,520],[470,470],[620,470],[720,360],[700,232],[820,162],[1000,172],[1080,282],[1010,410],[1060,560],[1180,642],[1320,648],[1450,628]]],
  ice:[[690,300,46],[1040,350,46],[1250,646,48],[560,470,40]]},
 {id:'ember',n:'Ember Crown',sub:'A split road through fire',waves:20,start:380,hpk:2.05,spk:1.08,coinK:.45,bonus:900,late:.5,lateW:6,lateC:.25,xp:300,pal:'ember',pads:13,
  twist:'The road forks around a lava lake and rejoins; lava vents erupt and scorch any monster nearby.',
  paths:[[[-60,470],[140,470],[300,440],[380,430],[470,300],[640,212],[840,232],[960,330],[1040,430],[1150,400],[1260,470],[1310,590],[1450,628]],
         [[-60,470],[140,470],[300,440],[380,430],[480,560],[660,690],[860,662],[980,560],[1040,430],[1150,400],[1260,470],[1310,590],[1450,628]]],
  vents:[[560,262],[780,700],[1185,452]],lake:[700,450,170,110]},
 {id:'wonder',n:'Wonderland',sub:'Endless waves',endless:1,waves:15,start:520,hpk:2,spk:1.08,coinK:.45,bonus:0,late:.45,lateW:6,lateC:.2,xp:30,pal:'wonder',pads:14,
  twist:'An endless siege on the crystal palace. Monsters pour out of two portals; after wave 15 every wave is harder than the last. Only here can towers reach tiers 4 and 5.',
  paths:[[[-60,190],[140,196],[290,262],[380,370],[520,430],[680,420],[800,330],[770,206],[900,150],[1060,196],[1120,318],[1010,452],[1010,600],[1120,700],[1300,700],[1450,628]],
         [[-60,712],[160,700],[300,640],[420,540],[520,430],[680,420],[800,330],[770,206],[900,150],[1060,196],[1120,318],[1010,452],[1010,600],[1120,700],[1300,700],[1450,628]]],
  river:[[1236,-30],[1196,200],[1256,420],[1206,640],[1250,930]]}];
const RP_MAP=id=>RP_MAPS.find(m=>m.id===id)||RP_MAPS[0];
/* the endless Wonderland always starts at Ember Crown's difficulty */
{const e=RP_MAP('ember'),w=RP_MAP('wonder');for(const k of['hpk','spk','late','lateW','lateC'])w[k]=e[k]}
const RP_MAPOPEN=m=>{const i=RP_MAPS.indexOf(m);return i<=0||(RPP().stars[RP_MAPS[i-1].id]||0)>0};
/* reward track: stars across all maps unlock tower skins only found here, then the title */
const RP_SKINS=[{tw:'ballista',k:'gilded',n:'Gilded Ballista',need:2},{tw:'brazier',k:'azure',n:'Azure Blazer',need:4},{tw:'frost',k:'aurora',n:'Aurora Spire',need:6},{tw:'bell',k:'thunderking',n:'Thunderking Bell',need:8}];
const RP_TITLE_NEED=9;
/* the save */
function RPP(){let r=P.rp;const D={stars:{},best:{},wins:0,runs:0,kills:0,gold:0,skin:{},own:{},seen:0,intro:0,day:'',dayDone:{},hint:{},fp:{},tut:{},asc:{},ebest:0};
 if(!r||typeof r!=='object'||Array.isArray(r))r=P.rp={};
 for(const k in D)if(r[k]===undefined||typeof r[k]!==typeof D[k]||Array.isArray(r[k])!==Array.isArray(D[k]))r[k]=D[k];
 for(const m of RP_MAPS){const v=r.stars[m.id];if(v!==undefined&&!(v>=0&&v<=3))delete r.stars[m.id]}
 for(const t of RP_TWORDER){if(r.skin[t]&&r.skin[t]!=='base'&&!r.own[t+':'+r.skin[t]])r.skin[t]='base'}
 return r}
const rpStarN=()=>{const r=RPP();return RP_MAPS.reduce((a,m)=>a+(r.stars[m.id]||0),0)};
function rpSkinOf(tw){const r=RPP(),k=r.skin[tw];return k&&k!=='base'&&r.own[tw+':'+k]?k:'base'}
function rpDay(){const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()}
/* waves: groups {id,n,gap,at}; map 1 is hand-made; later maps and Freeplay are generated */
/* map 1's hand-made waves (8.8b: harder - more monsters, mixed earlier) */
const RP_W1=[
 [{id:'scamp',n:12,gap:.9,at:0}],
 [{id:'scamp',n:14,gap:.75,at:0},{id:'bulwark',n:5,gap:1.3,at:5}],
 [{id:'bulwark',n:10,gap:.85,at:0},{id:'scamp',n:10,gap:.6,at:6},{id:'gloom',n:3,gap:1.2,at:10}],
 [{id:'gloom',n:8,gap:1.1,at:0},{id:'scamp',n:14,gap:.55,at:3},{id:'bulwark',n:5,gap:1,at:9}],
 [{id:'golem',n:3,gap:3.2,at:0},{id:'scamp',n:16,gap:.5,at:2},{id:'gloom',n:5,gap:1,at:8}],
 [{id:'ooze',n:5,gap:2,at:0},{id:'bulwark',n:12,gap:.75,at:4},{id:'gloom',n:6,gap:.9,at:9}],
 [{id:'shaman',n:3,gap:2.6,at:2},{id:'bulwark',n:14,gap:.65,at:0},{id:'gloom',n:9,gap:.8,at:6},{id:'golem',n:2,gap:3,at:10}],
 [{id:'golem',n:6,gap:2.4,at:0},{id:'scamp',n:20,gap:.4,at:3},{id:'gloom',n:9,gap:.75,at:8},{id:'shaman',n:2,gap:3,at:6}],
 [{id:'ooze',n:7,gap:1.6,at:0},{id:'shaman',n:4,gap:2.2,at:3},{id:'bulwark',n:16,gap:.55,at:5},{id:'golem',n:4,gap:2.5,at:9}],
 [{id:'behemoth',n:1,gap:1,at:3},{id:'bulwark',n:12,gap:.65,at:0},{id:'scamp',n:16,gap:.4,at:8},{id:'gloom',n:10,gap:.8,at:12},{id:'golem',n:3,gap:3,at:15}]];
/* difficulty: the base hit-point curve, a late ramp per map (map.late = extra hit points by the last wave, ramping from wave map.lateW;
   map.lateC = extra monsters), bosses get only a quarter of the late boost. The endless Wonderland plays like Ember Crown up to wave 15;
   after that every wave adds hit points (+5% compounding on top of the curve) and monsters. */
const rpRamp=(map,w)=>{if(!map.late)return 0;const end=map.endless?RP_MAP('ember').waves:map.waves,v=(w-map.lateW)/Math.max(1,end-map.lateW);return v<0?0:v>1?1:v};
function rpHpK(map,w,boss){let k=map.hpk*(1+.12*(w-1)+.007*(w-1)*(w-1))*(1+(map.late||0)*(boss?.25:1)*rpRamp(map,w));
 if(map.endless&&w>15)k*=Math.pow(boss?1.03:1.05,w-15);return k}
function rpWave(map,w){const W=map.waves;if(map.id==='moss'&&w<=W)return RP_W1[w-1];
 const free=!map.endless&&w>W,f=free?w-W:0,ex=map.endless&&w>15?w-15:0,pool=[['scamp',1,1],['bulwark',2,2],['gloom',2,3],['ooze',4,5],['golem',7,6],['shaman',6,7]].filter(p=>w>=p[2]);
 const groups=[];let at=0,bud=(14+w*7.5)*(map.id==='ember'||map.endless?1.1:1)*(1+f*.12)*(1+(map.lateC||0)*rpRamp(map,w))*(1+ex*.05);
 const last=map.endless?w%10===0:(w===W||(free&&f%5===0));
 if(last){groups.push({id:'behemoth',n:map.endless?1+Math.floor(w/30):free?1+Math.floor(f/10):1,gap:6,at:3});bud*=.55}
 const ng=4+Math.min(3,Math.floor(ex/8)),cap=ex>10?24:18;
 let i=0;while(bud>2&&i<ng){const p=pool[(w*7+i*3)%pool.length],cost=p[1],n=Math.max(2,Math.min(cap,Math.round(bud/cost/(i<1?1.4:2))));
  groups.push({id:p[0],n,gap:p[0]==='golem'?2.6:p[0]==='ooze'?1.8:p[0]==='shaman'?2.2:Math.max(.36,1-w*.02),at});at+=n*.45+2;bud-=n*cost;i++}
 return groups}
const rpBountyK=w=>1+.015*(w-1);
const rpWaveBonus=w=>30+6*w;
/* coins (the game's money, no ceiling): every kill, every wave cleared, and a win bonus */
const rpWaveCoins=(map,w)=>Math.round((12+4*w)*map.coinK);
const rpWinCoins=(map,stars)=>Math.round(map.bonus*(.6+.2*stars));
