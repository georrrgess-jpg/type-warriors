/* ===== RUNESTONE TOWER DEFENSE 10.0: Three Worlds - the rules (98b, after 98a and the art modules 98d-98k) =====
   Spec: TD_WORLDS_PLAN.md. Data and art hooks: 98a.
   - Unlocks: rpWorldOpen(w) (World 2 = a star on Ember Crown, World 3 = a star on Kraken's Maw), rpMapOpen2(m) (inside a world the map
     before it needs a star). Since 10.1 the Clockwork Hive and the Singularity Engine are open from the start on every map (RPW_TWNEED
     is empty; rpwTwLocked / rpwTwOnly stay as harmless no-ops for older callers).
   - Tier caps: map.maxT (4 in World 2, 5 in World 3). RP_MAXT (a const in 95a) only knows the Wonderland, so while an upgrade or the
     tower panel runs on such a map, map.endless reads 1 below the cap and 0 at it. Upgrades past tier 3 there play the ascension effect
     but never count for the Wonderland's Ascended collection.
   - Waves: generated from the world's pool (map.pool) with its boss (map.boss) on the last wave and in Freeplay.
   - Monster abilities (TD_WORLDS_PLAN.md section 2), applied before the engine moves the monsters: speed changes go through
     e.sp (as a ratio, e._spm, so other modules' changes survive), "cannot be hit" (e.hide) makes the monster invisible to rpTarget and
     immune in rpHurt, shields / guard / wading change the damage in rpHurt.
   - Map twists: tide (coral), fog + cannon (wreck), whirlpools + glowcaps (abyss), bridges + gales (meadow), the switch track +
     conveyors + furnace vents (foundry), the thunderstorm + lightning rods (storm). State for the art: R.tide, R.fog, R.cannon, R.gust,
     R.sw/R.swK, R.bolts, R.rodK.
   - Jams: tw.jam seconds, tw.jamBy 'ink'|'emp'|'bolt'; a jammed tower does not fire.
   - Placeholder art for any new monster whose art module is missing, and fallback twist visuals when a map has no RPW.twist. */
const RPWK={jamImm:4,inkFly:.45,boltD:.55,cannonFly:.6,gustRamp:.4,tideRamp:1.6};
function rpWorldOpen(w){if(!w||w<=1)return true;const W=RP_WORLD(w);try{return (RPP().stars[W.need]||0)>0}catch(e){return false}}
function rpMapOpen2(m){if(!m)return false;if(rpWorldOf(m)===1)return RP_MAPOPEN(m);if(!rpWorldOpen(m.world))return false;const L=RP_WORLD(m.world).maps,i=L.indexOf(m.id);return i<=0||(RPP().stars[L[i-1]]||0)>0}
/* 10.1: no tower is world-locked any more; the names stay for callers (tests, Tower Skins, 98m) */
const RPW_TWNEED={};
const rpwTwLocked=t=>false;
const rpwTwMsg=t=>'';
function rpwTwOnly(fn){return fn()}
/* ---------- tier caps ---------- */
function rpwCap(tw,fn){const R=RPX,m=R&&R.map;if(!m||!m.maxT||!tw)return fn();const e0=m.endless;m.endless=tw.tier<m.maxT?1:0;try{return fn()}finally{m.endless=e0}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const t=this;return rpwCap(tw,()=>u0.call(t,tw))}}
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const t=this,a=arguments;return rpwCap(tw,()=>i0.apply(t,a))}}
{const i0=rpHudInfo;rpHudInfo=function(R,C){const t=this,a=arguments;return rpwCap(R&&R.sel,()=>i0.apply(t,a))}}
{const a0=rpAscendFx;rpAscendFx=function(R,tw){if(!(R&&R.map&&R.map.world>1))return a0.apply(this,arguments);const r=RPP(),old=r.asc[tw.type];try{return a0.apply(this,arguments)}finally{if(old===undefined)delete r.asc[tw.type];else r.asc[tw.type]=old}}}
/* ---------- waves ---------- */
{const w0=rpWave;rpWave=function(map,w){if(!map||!map.pool)return w0.apply(this,arguments);const W=map.waves,free=w>W,f=free?w-W:0,pool=map.pool.filter(p=>w>=p[2]);
 const groups=[];let at=0,bud=(16+w*7.8)*1.12*(1+f*.12)*(1+(map.lateC||0)*rpRamp(map,w))*(w<4?.5+.15*w:1);const last=w===W||(free&&f%5===0);
 if(last){groups.push({id:map.boss,n:free?1+Math.floor(f/10):1,gap:6,at:3});bud*=.55}
 const ng=4+(map.world>2?1:0),used=new Set();let i=0;while(bud>2&&i<ng){let j=(w*7+i*3)%pool.length,k=0;while(used.has(pool[j][0])&&k++<pool.length)j=(j+1)%pool.length;const p=pool[j],cost=p[1];used.add(p[0]);const n=Math.max(2,Math.min(RPW_DISRUPT[p[0]]?4:RPW_ARMOR[p[0]]?12:20,Math.round(bud/cost/(i<1?1.4:2))));
  groups.push({id:p[0],n,gap:cost>=6?2.4:cost>=3?1.2:Math.max(.34,.95-w*.02),at});at+=n*.45+2;bud-=n*cost;i++}
 return groups}}
const RPW_DISRUPT={squid:1,siren:1,tinker:1,jammer:1};/* at most four of these per group */
const RPW_ARMOR={shell:1,knight:1};/* at most twelve of these per group */
/* the switch track: the whole wave takes the line the switch shows */
{const s0=rpSpawn;rpSpawn=function(id,pi){const R=RPX;if(R&&R.map&&R.map.sw&&pi==null)pi=R.sw||0;const e=s0.call(this,id,pi);if(e)rpwInitFoe(R,e);return e}}
function rpwInitFoe(R,e){const F=RP_FOE[e.id];if(!F)return;e.arm0=e.armor;
 if(F.scut)e.scT=F.scut[0]*Math.random();if(F.shellT)e.shT=F.shellT*(.5+Math.random()*.5);if(F.glimT)e.glT=F.glimT*(.4+Math.random()*.6);
 if(F.songT)e.sgT=F.songT*.5;if(F.leapT)e.lpT=F.leapT*(.5+Math.random()*.5);if(F.stompT)e.stT=F.stompT;if(F.dive)e.dvI=0;if(F.shedAt)e.shI=0;if(F.ventAt)e.vtH=1;if(F.empR)e.emp=new Set()}
/* ---------- the battle starts: twist state ---------- */
{const s0=rpStart;rpStart=function(id){const r=s0.apply(this,arguments);try{const R=RPX;if(R&&R.map&&R.map.world>1)rpwTwistInit(R)}catch(e){console.error(e)}return r}}
function rpwTwistInit(R){const m=R.map;R.inks=[];R.emps=[];R.bolts=[];
 if(m.tide)R.tide={t:0,k:0,high:false};
 if(m.fog){R.fog=[];for(let i=0;i<m.fog;i++)R.fog.push({x:200+i*520+Math.random()*120,y:230+((i*197)%380),rx:150+Math.random()*50,ry:78+Math.random()*24,v:14+Math.random()*10})}
 if(m.cannon)R.cannon={t:m.cannonT*.6,x:m.cannon[0],y:m.cannon[1],fire:0,tx:0,ty:0,fly:-1};
 if(m.gustT)R.gust={t:m.gustT*.7,k:0,on:0};
 if(m.sw){R.sw=0;R.swK=1}
 if(m.rods){R.rodK=m.rods.map(()=>0);R.boltT=m.boltT*.6;R.boltTwT=m.boltTwT*.8}
 for(const p of R.pads)p.rod=m.rods?m.rods.some(r=>Math.hypot(p.x-r[0],(p.y-r[1])/.8)<m.rodR):false;
 if(m.glow)for(const p of R.pads)p.glow=m.glow.some(g=>Math.hypot(p.x-g[0],p.y-g[1])<m.glowR)}
/* a tower on a glowcap / rod pad carries it */
{const b0=rpBuild;rpBuild=function(pad,type){const r=b0.apply(this,arguments);try{if(r!==false&&pad&&pad.tw){pad.tw.glowK=pad.glow?1.15:0;pad.tw.rodK=pad.rod?1:0}}catch(e){}return r}}
/* the switch flips at every new wave */
{const w0=rpWaveStart;rpWaveStart=function(){const R=RPX,was=R&&R.wst;const r=w0.apply(this,arguments);try{if(R&&R.map.sw&&was==='build'&&R.wst==='run'){const n=R.wave%2?0:1;if(n!==R.sw){R.sw=n;R.swK=0;rpToast(n?'The switch flips: monsters take the south line!':'The switch flips: monsters take the north line!',2.2,'#ffb84a')}}}catch(e){}return r}}
/* ---------- targeting and damage ---------- */
{const t0=rpTarget;rpTarget=function(R,tw,rg){const H=[],fn=R&&R.map&&R.map.fogNear;
 for(const e of R.foes){if(e.dead||e.s<0)continue;if(e.hide||(fn&&e.fogd&&tw&&rpD2(rpPos(R,e).x,rpPos(R,e).y,tw.x,tw.y)>fn*fn)){H.push(e)}}
 if(tw&&tw.glowK)arguments[2]=rg*tw.glowK;for(const e of H){e._hs=e.s;e.s=-1}try{return t0.apply(this,arguments)}finally{for(const e of H)e.s=e._hs}}}
{const h0=rpHurt;rpHurt=function(e,dmg,ap,src){if(!e||e.dead)return h0.apply(this,arguments);if(e.hide)return;let k=1;
 if(e.guardK)k*=1-e.guardK;if(e.wade)k*=src&&src.type==='tide'?1.5:.8;if(src&&src.rodK)k*=1.1;dmg*=k;
 if(e.shield>0){const a=Math.min(e.shield,dmg);e.shield-=a;dmg-=a;if(dmg<=.001){e.fl=.1;return}}return h0.call(this,e,dmg,ap,src)}}
/* ---------- jams: a jammed tower does not fire ---------- */
function rpwJam(R,tw,d,by){if(!tw||tw.build<1||tw.jamImm>0)return;tw.jam=Math.max(tw.jam||0,d);tw.jamBy=by;tw.jamT=0;try{rpSfx(by==='ink'?'no':'boom')}catch(e){}}
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.jamImm>0)tw.jamImm-=dt;if(tw.jam>0){tw.jam=Math.max(0,tw.jam-dt);if(tw.jam===0)tw.jamImm=RPWK.jamImm;tw.jamT=(tw.jamT||0)+dt;tw.over=Math.max(0,tw.over-dt);tw.fire=Math.max(0,(tw.fire||0)-dt*3);return}return f0.apply(this,arguments)}}
/* ---------- each step: twists and abilities, before the engine moves the monsters ---------- */
{const s0=rpStep;rpStep=function(R,dt){if(R&&R.map&&R.map.world>1)try{rpwPre(R,dt)}catch(e){console.error(e)}return s0.apply(this,arguments)}}
const rpwNearTw=(R,x,y,r)=>{let best=null,bd=r*r;for(const p of R.pads){const tw=p.tw;if(!tw||tw.build<1)continue;const d=rpD2(tw.x,tw.y,x,y);if(d<bd){bd=d;best=tw}}return best};
function rpwPre(R,dt){const m=R.map,run=R.wst==='run';
 /* twists */
 if(R.tide){const T=R.tide;T.t+=run?dt:0;const c=T.t%m.tideT,hi=m.tideHi,ramp=RPWK.tideRamp;T.k=c<ramp?c/ramp:c<hi?1:c<hi+ramp?1-(c-hi)/ramp:0;if(!run)T.k=Math.max(0,T.k-dt);const was=T.high;T.high=T.k>.5;if(T.high&&!was&&run)rpToast('The tide rises!',1.6,'#7ae8ff')}
 if(R.fog)for(const f of R.fog){f.x+=f.v*dt;if(f.x-f.rx>1650){f.x=-f.rx-40;f.y=200+Math.random()*420}}
 if(R.cannon&&run){const C=R.cannon;if(C.fire>0){C.fire+=dt/1.4;if(C.fire>=1)C.fire=0}C.t-=dt;
  if(C.fly>=0){C.fly+=dt;if(C.fly>=RPWK.cannonFly){C.fly=-1;const e=C.e;if(e&&!e.dead){const was=e.hide;e.hide=0;rpHurt(e,e.mx*(e.boss?.03:.08),99,null);e.hide=was;rpRing(C.tx,C.ty,'#ffb84a',70,5);try{ptBurst(R.fx,C.tx,C.ty-10,14,['#ffd27a','#ff8a2a','#3a2a2a'],{v:240,s:4,up:1,g:380})}catch(x){}}}}
  if(C.t<=0){C.t=m.cannonT;let best=null,bv=-1;for(const e of R.foes){if(e.dead||e.s<0||e.hide)continue;const v=e.s/rpLen(R,e);if(v>bv){bv=v;best=e}}
   if(best){const q=rpPos(R,best);C.e=best;C.tx=q.x;C.ty=q.y;C.fire=.001;C.fly=0;try{rpSfx('boom')}catch(x){}}}}
 if(R.gust){const G=R.gust;if(run){G.t-=dt;if(G.t<=0){G.on=m.gustD;G.t=m.gustT;rpToast('A gale sweeps the islands!',1.4,'#d8f4ff')}}if(G.on>0){G.on=Math.max(0,G.on-dt);G.k=Math.min(1,G.k+dt/RPWK.gustRamp)}else G.k=Math.max(0,G.k-dt/RPWK.gustRamp)}
 if(R.sw!=null)R.swK=Math.min(1,(R.swK||0)+dt*1.6);
 if(R.rodK){for(let i=0;i<R.rodK.length;i++)R.rodK[i]=Math.max(0,R.rodK[i]-dt*1.5);
  if(run){R.boltT-=dt;R.boltTwT-=dt;
   if(R.boltT<=0){R.boltT=m.boltT;let best=null,bv=-1;for(const e of R.foes){if(e.dead||e.s<0||e.hide)continue;const v=e.s/rpLen(R,e);if(v>bv){bv=v;best=e}}
    if(best){const q=rpPos(R,best);rpHurt(best,best.mx*(best.boss?.04:.1),99,null);R.bolts.push({x:q.x,y:q.y-10,t:0,d:RPWK.boltD,tw:0});R.flash=1;try{rpSfx('boom')}catch(x){}}}
   if(R.boltTwT<=0){R.boltTwT=m.boltTwT;const tws=R.pads.filter(p=>p.tw&&p.tw.build>=1);if(tws.length){const p=tws[Math.floor(Math.random()*tws.length)];
     if(p.rod){let bi=0,bd=1e9;m.rods.forEach((r,i)=>{const d=Math.hypot(p.x-r[0],p.y-r[1]);if(d<bd){bd=d;bi=i}});R.rodK[bi]=1;R.bolts.push({x:m.rods[bi][0],y:m.rods[bi][1]-70,t:0,d:RPWK.boltD,tw:0,rod:1})}
     else{rpwJam(R,p.tw,2,'bolt');R.bolts.push({x:p.x,y:p.y-60,t:0,d:RPWK.boltD,tw:1})}R.flash=1}}}}
 if(R.bolts.length){for(const b of R.bolts)b.t+=dt;R.bolts=R.bolts.filter(b=>b.t<b.d)}
 if(R.flash>0)R.flash=Math.max(0,R.flash-dt*3);
 for(const k of R.inks){k.t+=dt;if(!k.hit&&k.t>=RPWK.inkFly){k.hit=1;rpwJam(R,k.tw,k.d,'ink')}}R.inks=R.inks.filter(k=>k.t<RPWK.inkFly+.3);
 for(const k of R.emps)k.t+=dt;R.emps=R.emps.filter(k=>k.t<k.d);
 /* support auras (recomputed each step; the strongest counts, never stacked) */
 const live=R.foes.filter(e=>!e.dead&&e.s>=0);for(const e of live){e.guardK=0;e.hasteK=0}
 for(const s of live){const F=RP_FOE[s.id];if(!F)continue;
  if(F.guardR&&!s.hide){for(const e of live)if(e!==s&&e.id!==s.id&&e.pi===s.pi&&e.s<s.s&&s.s-e.s<F.guardR)e.guardK=Math.max(e.guardK,F.guardK)}
  if(F.hasteR){const p=rpPos(R,s);for(const e of live)if(e!==s){const q=rpPos(R,e);if(rpD2(p.x,p.y,q.x,q.y)<F.hasteR*F.hasteR)e.hasteK=Math.max(e.hasteK,F.hasteK)}}}
 /* each monster */
 for(const e of R.foes){if(e.dead)continue;const F=RP_FOE[e.id];if(!F)continue;let mult=1;
  if(e.s<0){rpwSp(e,1);continue}
  e.hide=0;if(e.shieldT>0){e.shieldT-=dt;if(e.shieldT<=0)e.shield=0}
  if(F.scut){e.scT-=dt;if(e.scT<=0)e.scT=F.scut[0];if(e.scT>F.scut[0]-F.scut[1])mult*=F.scut[2]}
  if(F.shellT){if(e.shIn>0){e.shIn-=dt;mult*=.02;if(e.shIn<=0){e.armor=e.arm0;e.shT=F.shellT}}else{e.shT-=dt;if(e.shT<=0&&!e.stun){e.shIn=F.shellD;e.armor=e.arm0+F.shellA}}}
  if(F.puffAt&&!e.puff&&e.hp<e.mx*F.puffAt){e.puff=1;e.arm0+=F.puffA;e.armor+=F.puffA;try{ptBurst(R.fx,rpPos(R,e).x,rpPos(R,e).y-24,8,['#ffffff','#bff8ff'],{v:120,s:3})}catch(x){}}
  if(e.puff)mult*=F.puffSp;
  if(F.glimT){e.glT-=dt;if(e.glT<=-F.glimD)e.glT=F.glimT;if(e.glT<=0)e.hide=1}
  if(F.shed)e.armor=Math.round(e.arm0*Math.max(0,e.hp/e.mx));
  if(F.songT){e.sgT-=dt;if(e.sgT<=0){e.sgT=F.songT;const p=rpPos(R,e);let n=0;for(const f of R.foes){if(f.dead||f.s<0)continue;const q=rpPos(R,f);if(rpD2(p.x,p.y,q.x,q.y)<F.songR*F.songR){f.shield=Math.max(f.shield||0,f.mx*F.songK);f.shieldT=F.songD;n++}}
    R.rings.push({x:p.x,y:p.y,t:0,d:.7,max:F.songR,c:'#7ae8ff',w:3});e.sing=.8}}
  if(e.sing>0)e.sing-=dt;
  if(F.inkAt&&!e.inked&&e.hp<e.mx*F.inkAt){e.inked=1;const p=rpPos(R,e),tw=rpwNearTw(R,p.x,p.y,F.inkR);if(tw)R.inks.push({x0:p.x,y0:p.y-30,tw,t:0,d:F.inkD})}
  if(F.dive){if(e.dive>0){e.dive-=dt;e.hide=1;mult*=F.diveSp;if(e.dive<=0){const k=e.dvI;for(let i=0;i<F.diveN;i++){const c=rpSpawn('crab',e.pi);if(c){c.s=Math.max(0,e.s-20-i*14)}}rpRing(rpPos(R,e).x,rpPos(R,e).y,'#7ae8ff',120,6);rpToast(`The ${rpMobName(e.id,m.pal)} surfaces!`,1.4,'#7ae8ff')}}
   else if(e.dvI<F.dive.length&&e.hp<e.mx*F.dive[e.dvI]){e.dvI++;e.dive=F.diveD;rpToast(`The ${rpMobName(e.id,m.pal)} dives!`,1.4,'#7ae8ff')}}
  if(F.ventAt){if(e.vent>0){e.vent-=dt;mult*=F.ventSp;e.slowT=0;e.slowK=0}else if(e.hp/e.mx<e.vtH-F.ventAt){e.vtH-=F.ventAt;e.vent=F.ventD}}
  if(e.hasteK)mult*=1+e.hasteK;
  if(F.leapT){if(e.leap>0){const u=Math.min(dt,e.leap);e.s+=F.leapS*u/F.leapD;e.leap-=dt;e.hide=1;mult*=.02}else{e.lpT-=dt;if(e.lpT<=0&&!e.stun){e.lpT=F.leapT;e.leap=F.leapD}}}
  if(F.empR){const p=rpPos(R,e);for(const pd of R.pads){const tw=pd.tw;if(!tw||tw.build<1||e.emp.has(tw))continue;if(rpD2(p.x,p.y,tw.x,tw.y)<F.empR*F.empR){e.emp.add(tw);rpwJam(R,tw,F.empD,'emp');R.emps.push({x:p.x,y:p.y-20,t:0,d:.5,r:F.empR})}}}
  if(F.stompT){e.stT-=dt;if(e.stT<=0){e.stT=F.stompT;const p=rpPos(R,e);for(const pd of R.pads){const tw=pd.tw;if(tw&&tw.build>=1&&rpD2(p.x,p.y,tw.x,tw.y)<F.stompR*F.stompR)rpwJam(R,tw,F.stompD,'emp')}
    R.emps.push({x:p.x,y:p.y,t:0,d:.8,r:F.stompR,big:1});rpRing(p.x,p.y,'#ffd45a',F.stompR,8);try{rpSfx('boom')}catch(x){}}
   if(e.shI<F.shedAt.length&&e.hp<e.mx*F.shedAt[e.shI]){e.shI++;e.arm0=Math.max(0,e.arm0-F.shedA);e.armor=e.arm0;e.spB=(e.spB||1)*(1+F.shedSp);const p=rpPos(R,e);try{ptBurst(R.fx,p.x,p.y-60,18,['#c8a050','#8a6a3a','#ffd45a'],{v:300,s:5,up:1,g:420})}catch(x){}rpToast(`The ${rpMobName(e.id,m.pal)} sheds its armor!`,1.4,'#ffd45a')}}
  if(e.spB)mult*=e.spB;
  /* ground zones */
  e.wade=0;if(!e.air){const p=rpPos(R,e);
   if(m.tide&&R.tide&&R.tide.k>.5)for(const z of m.tide)if((p.x-z[0])**2+((p.y-z[1])/.8)**2<z[2]*z[2]){e.wade=1;mult*=.75;break}
   if(m.whirl)for(const z of m.whirl)if(rpD2(p.x,p.y,z[0],z[1])<z[2]*z[2]){mult*=1.4;break}
   if(m.bridge)for(const z of m.bridge)if(rpD2(p.x,p.y,z[0],z[1])<z[2]*z[2]){mult*=.85;break}
   if(m.conv)for(const z of m.conv)if(rpD2(p.x,p.y,z[0],z[1])<z[2]*z[2]){mult*=1.3;break}}
  else if(R.gust&&R.gust.k>0)mult*=1+.8*R.gust.k;
  if(R.fog){const p=rpPos(R,e);e.fogd=R.fog.some(f=>((p.x-f.x)/f.rx)**2+((p.y-f.y)/f.ry)**2<1)?1:0}
  rpwSp(e,mult)}}
function rpwSp(e,mult){mult=Math.max(.02,mult);const o=e._spm||1;if(Math.abs(o-mult)<1e-6)return;e.sp=e.sp/o*mult;e._spm=mult}
/* ---------- drawing: poses, hidden monsters, leaps, shields; ink, EMP and bolt effects; jammed towers ---------- */
{const d0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){const id=e.id;let pose=null;if(e.shIn>0&&RPMD.shell_in)pose='shell_in';else if(e.puff&&RPMD.puffer_big)pose='puffer_big';
  else if(id==='titan'&&e.shI>=2&&RPMD.titan_p3)pose='titan_p3';else if(id==='titan'&&e.shI>=1&&RPMD.titan_p2)pose='titan_p2';
  const lift=e.leap>0?Math.sin(Math.PI*(1-e.leap/((RP_FOE[id]||{}).leapD||.45)))*46:0,hid=e.hide&&!(e.leap>0);
  c.save();if(lift){q={x:q.x,y:q.y-lift,a:q.a,ice:q.ice}}
  if(hid)c.globalAlpha*=e.dive>0?.18:.35;if(pose)e.id=pose;try{d0.call(this,c,R,e,q)}finally{e.id=id;c.restore()}
  if(e.dead)return;if(e.dive>0&&!R.rm){c.save();c.globalAlpha=.6;c.strokeStyle='#bff8ff';c.lineWidth=3;const r=26+8*Math.sin(R.t*6);c.beginPath();c.ellipse(q.x,q.y,r*2,r*.6,0,0,TAU);c.stroke();c.restore()}
  if(e.shield>0){c.save();c.globalAlpha=.35+.15*Math.sin(R.t*5);c.strokeStyle='#7ae8ff';c.fillStyle='rgba(122,232,255,.12)';c.lineWidth=2.5;const h=((RPMOB[id]||{}).h||50)*.6;c.beginPath();c.ellipse(q.x,q.y-h,h*.9,h,0,0,TAU);c.fill();c.stroke();c.restore()}
  if(e.guardK>0&&!R.rm){c.save();c.globalAlpha=.55;c.fillStyle='#ffd45a';c.font='700 13px Poppins,sans-serif';c.textAlign='center';c.fillText('⛨',q.x,q.y-((RPMOB[id]||{}).h||40)-10);c.restore()}
  if(e.vent>0&&!R.rm&&Math.random()<.4)try{ptBurst(R.fx,q.x,q.y-40,1,['#e8f0ff','#c8d0e0'],{v:60,s:5,up:1})}catch(x){}
  if(e.sing>0&&!R.rm&&Math.random()<.25)try{ptBurst(R.fx,q.x+8,q.y-50,1,['#7ae8ff','#ffffff'],{v:50,s:3,up:1,k:'star'})}catch(x){}}}
{const a0=rpTowerAt;rpTowerAt=function(c,R,tw){const r=a0.apply(this,arguments);if(tw.jam>0)try{rpwJamDraw(c,R,tw)}catch(e){}return r}}
function rpwJamDraw(c,R,tw){const k=Math.min(1,tw.jam*2),t=R.t,top=(typeof rpTowerTop==='function'?rpTowerTop(tw.type,tw.tier):100)||100;c.save();c.globalAlpha=k;
 if(tw.jamBy==='ink'){c.fillStyle='#2a1440';c.strokeStyle='#12081f';c.lineWidth=2;for(let i=0;i<5;i++){const a=i*1.3+tw.x*.01,x=tw.x+Math.cos(a)*18,y=tw.y-top*.55+Math.sin(a)*22;c.beginPath();c.ellipse(x,y,9+(i%2)*5,7+(i%3)*3,a,0,TAU);c.fill();c.stroke()}
  c.fillStyle='rgba(180,120,255,.5)';for(let i=0;i<3;i++){c.beginPath();c.arc(tw.x-12+i*12,tw.y-top*.5+((t*40+i*13)%30),3,0,TAU);c.fill()}}
 else{c.strokeStyle=tw.jamBy==='bolt'?'#fff2b0':'#9fe8ff';c.lineWidth=2.4;c.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const a=t*9+i*2.1,r=24;c.beginPath();let x=tw.x+Math.cos(a)*r,y=tw.y-top*.55+Math.sin(a)*r*.8;c.moveTo(x,y);
   for(let j=0;j<4;j++){x+=(Math.sin(t*31+i*7+j*3)*10);y+=8;c.lineTo(x,y)}c.stroke()}}
 c.globalCompositeOperation='source-over';c.globalAlpha=k*.9;c.fillStyle='#12081fd0';c.beginPath();c.roundRect(tw.x-26,tw.y-top-30,52,18,9);c.fill();c.fillStyle=tw.jamBy==='ink'?'#d0a8ff':'#9fe8ff';c.font='800 11px Poppins,sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText('JAMMED',tw.x,tw.y-top-21);c.restore()}
/* ink shots, EMP rings, bolts and the fallback twist visuals; drawn with the other rings */
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){const r=b0.apply(this,arguments);if(R.map&&R.map.world>1)try{rpwFx(c,R)}catch(e){}return r}}
function rpwFx(c,R){const t=R.t;
 for(const k of R.inks||[]){const u=Math.min(1,k.t/RPWK.inkFly),x=k.x0+(k.tw.x-k.x0)*u,y=k.y0+(k.tw.y-60-k.y0)*u-Math.sin(u*Math.PI)*80;c.save();c.fillStyle='#2a1440';c.strokeStyle='#12081f';c.lineWidth=2;c.beginPath();c.arc(x,y,7,0,TAU);c.fill();c.stroke();c.restore()}
 for(const k of R.emps||[]){const u=k.t/k.d;c.save();c.globalAlpha=(1-u)*.8;c.strokeStyle=k.big?'#ffd45a':'#9fe8ff';c.lineWidth=k.big?6:3;c.setLineDash([12,8]);c.beginPath();c.ellipse(k.x,k.y,k.r*u,k.r*u*RPFX.sq,0,0,TAU);c.stroke();c.restore()}
 const id=R.map.id;if(RPW.twist[id])return;
 /* fallback twist visuals (the art modules replace these) */
 const m=R.map;c.save();
 if(R.tide&&R.tide.k>0){c.globalAlpha=.35*R.tide.k;c.fillStyle='#4ad8f0';for(const z of m.tide){c.beginPath();c.ellipse(z[0],z[1],z[2],z[2]*.8,0,0,TAU);c.fill()}}
 if(m.whirl){c.globalAlpha=.5;c.strokeStyle='#8affff';c.lineWidth=3;for(const z of m.whirl){c.beginPath();c.arc(z[0],z[1],z[2]*.7,t*3,t*3+4);c.stroke()}}
 if(m.conv){c.globalAlpha=.3;c.fillStyle='#ffb84a';for(const z of m.conv){c.beginPath();c.ellipse(z[0],z[1],z[2],z[2]*.4,0,0,TAU);c.fill()}}
 if(R.gust&&R.gust.k>0){c.globalAlpha=.4*R.gust.k;c.strokeStyle='#ffffff';c.lineWidth=2;for(let i=0;i<14;i++){const y=(i*67)%900,x=((t*900+i*211)%1800)-100;c.beginPath();c.moveTo(x,y);c.lineTo(x+90,y);c.stroke()}}
 if(R.fog){c.globalAlpha=.55;c.fillStyle='#c8d4dc';for(const f of R.fog){c.beginPath();c.ellipse(f.x,f.y,f.rx,f.ry,0,0,TAU);c.fill()}}
 if(R.cannon&&R.cannon.fly>=0){const C=R.cannon,u=Math.min(1,C.fly/RPWK.cannonFly),x=C.x+(C.tx-C.x)*u,y=C.y+(C.ty-C.y)*u-Math.sin(u*Math.PI)*160;c.globalAlpha=1;c.fillStyle='#2a2a2a';c.beginPath();c.arc(x,y,8,0,TAU);c.fill()}
 if(m.rods){c.globalAlpha=1;m.rods.forEach((r,i)=>{c.fillStyle='#ffd45a';c.fillRect(r[0]-3,r[1]-70,6,70);if(R.rodK[i]>0){c.globalAlpha=R.rodK[i];c.fillStyle='#fff2b0';c.beginPath();c.arc(r[0],r[1]-72,10,0,TAU);c.fill();c.globalAlpha=1}})}
 for(const b of R.bolts||[]){const u=b.t/b.d;c.globalAlpha=1-u;c.strokeStyle='#fff8d0';c.lineWidth=4;c.beginPath();let x=b.x,y=0;c.moveTo(x+(Math.random()-.5)*30,0);for(let j=1;j<=8;j++){y=b.y*j/8;c.lineTo(b.x+(Math.random()-.5)*40*(1-j/8),y)}c.stroke()}
 if(m.sw){const [x,y]=m.sw;c.globalAlpha=1;c.fillStyle='#3a2a20';c.fillRect(x-6,y-60,12,60);c.save();c.translate(x,y-56);c.rotate((R.sw?.6:-.6)*Math.min(1,R.swK||1));c.fillStyle='#ffb84a';c.fillRect(-4,-40,8,40);c.restore()}
 c.restore()}
/* a lightning flash over the whole battle (Storm Citadel) when the art module has none */
{const d0=rpBannerDraw;rpBannerDraw=function(c,R){if(R&&R.flash>0&&R.map&&!RPW.ambTop[R.map.id]){c.save();c.globalAlpha=R.flash*.35;c.fillStyle='#e8f4ff';c.fillRect(0,0,1600,900);c.restore()}return d0.apply(this,arguments)}}
/* ---------- placeholder monster art (only for monsters whose art module is not loaded) ---------- */
{const PH={crab:['#ff7a5a',30,18],shell:['#5aa86a',40,30],puffer:['#ffd45a',34,30],jelly:['#d89aff',26,30],brute:['#8a7a6a',56,48],siren:['#4ad8c8',22,46],squid:['#c87aff',24,36],leviathan:['#3a8ab8',90,80],
  cog:['#c8a050',24,26],knight:['#d8b060',26,44],steam:['#8a8a9a',50,60],gyro:['#d8c890',30,20],tinker:['#c89a6a',22,42],spring:['#e86a4a',22,40],jammer:['#7a9ad8',26,36],titan:['#a88a5a',90,100]};
 for(const id in PH){if(RPMD[id])continue;const [col,w,h]=PH[id];RPMD[id]=function(g,ph){const b=Math.sin(ph*TAU)*2;g.fillStyle=col;g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.ellipse(0,-h/2+b,w/2,h/2,0,0,TAU);g.fill();g.stroke();
   g.fillStyle='#fff';g.beginPath();g.arc(w*.18,-h*.62+b,4,0,TAU);g.fill();g.fillStyle='#12081f';g.beginPath();g.arc(w*.2,-h*.62+b,2,0,TAU);g.fill()};
  RPMD[id].rpwPH=1;RPMB[id]=[-w/2-4,-h-8,w/2+4,4,w*.5];RPMK[id]=1;if(!RPMDX[id])RPMDX[id]=RPMDX.scamp}}
{const d0=rpvDraw;rpvDraw=function(g,id,ph,v){if(RPMD[id]&&RPMD[id].rpwPH){const f=RPMD[id];g.save();g.lineJoin='round';g.lineCap='round';try{f(g,ph,{v})}finally{g.restore()}return}return d0.apply(this,arguments)}}
/* ---------- results: the next map stays inside the world ---------- */
{const r0=rpResult;rpResult=function(){const R=RPX,m=R&&R.map;if(!m||!m.world||m.world<2)return r0.apply(this,arguments);const t=this,a=arguments;return rpwOnly(m.world,()=>r0.apply(t,a))}}
/* ---------- the boss of a new map: the engine names, shows and announces 'behemoth'; on these maps it means the map's boss ---------- */
const rpwBossOfPal=v=>{const m=RP_MAPS.find(x=>x.pal===v&&x.boss);return m?m.boss:null};
{const n0=rpMobName;rpMobName=function(id,v){if(id==='behemoth'){const b=rpwBossOfPal(v);if(b)return n0.call(this,b,v)}return n0.apply(this,arguments)}}
{const u0=rpMobURL;rpMobURL=function(id,size,v){if(id==='behemoth'){const b=rpwBossOfPal(v);if(b)return u0.call(this,b,size,v)}return u0.apply(this,arguments)}}
{const w0=rpWaveStart;rpWaveStart=function(){const R=RPX,was=R&&R.wst;const r=w0.apply(this,arguments);try{if(R&&R.map.boss&&was==='build'&&R.wst==='run'&&R.q.some(q=>q.id===R.map.boss)&&!R.free){
  R.banner={txt:`${rpName('behemoth',R)}!`,sub:R.map.boss==='leviathan'?'The boss is coming. It dives out of reach: keep damage further down the road.':'The boss is coming. Its stomp jams towers: spread your defense.',t:0,d:2.2,boss:true};rpSfx('boss')}}catch(e){}return r}}
/* ---------- the hub: one world at a time, with tabs ----------
   RPW_VIEW is the world on show (98a trims RP_MAPS to it while the hub is laid out). It follows the selected map (RPSEL), so the hub
   opens on the world of the last map played; the tabs switch worlds (each world remembers its selected map in P.rp.wsel).
   A locked world shows its painting under a card that says how to reach it. Worlds 2 and 3 get their own armory bar: the world's
   stars (/9) open coin chests at 3, 6 and 9 stars (P.rp.wchest) and a title at 9. */
Object.assign(RPWORLD.nodes,{coral:{x:300,y:560},wreck:{x:740,y:300},abyss:{x:1030,y:600},meadow:{x:300,y:430},foundry:{x:720,y:620},storm:{x:1060,y:300}});
const RPW_CHEST={2:[[3,3000],[6,6000],[9,10000]],3:[[3,5000],[6,10000],[9,16000]]},RPW_TITLE={2:'Tide Warden',3:'Sky Warden'};
let RPW_FORCE=0;const RPW_WA={};
function rpwSave(){const r=RPP();for(const k of['wsel','wchest'])if(!r[k]||typeof r[k]!=='object'||Array.isArray(r[k]))r[k]={};return r}
const rpwStars=w=>{const r=RPP();return RP_WORLD(w).maps.reduce((a,id)=>a+(r.stars[id]||0),0)};
function rpwWorldArt(w){if(RPW_WA[w])return RPW_WA[w];let A=null;const f=RPW.world[w];if(f)try{A=f()}catch(e){console.error(e);A=null}
 if(!A||!A.c)A=rpwWorldFallback(w);if(A.nodes)Object.assign(RPWORLD.nodes,A.nodes);return RPW_WA[w]=A}
function rpwWorldFallback(w){const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d'),sea=w===2;
 let q=g.createLinearGradient(0,0,0,900);q.addColorStop(0,sea?'#1a8ab8':'#f0a868');q.addColorStop(1,sea?'#0a3a6a':'#5a4a9a');g.fillStyle=q;g.fillRect(0,0,1600,900);
 for(const id of RP_WORLD(w).maps){const n=RPWORLD.nodes[id];g.fillStyle=sea?'#e8d090':'#6ac454';g.strokeStyle='#12081f';g.lineWidth=4;g.beginPath();g.ellipse(n.x,n.y-60,170,110,0,0,TAU);g.fill();g.stroke()}
 return{c,nodes:null}}
{const b0=rpHubBG;rpHubBG=function(){if(RPW_VIEW<=1)return b0.apply(this,arguments);const cv2=$('rphbg');if(!cv2)return;const g=cv2.getContext('2d'),A=rpwWorldArt(RPW_VIEW);
 const draw=t=>{g.setTransform(1,0,0,1,0,0);g.drawImage(A.c,0,0,1600,900);if(A.anim)try{A.anim(g,t)}catch(e){}};draw(1);if(!rpRM()&&A.anim)LIVE.push({cv:cv2,fn:draw,slow:2})}}
{const m0=rampartsMenu;rampartsMenu=function(back){const r=rpwSave();let w=RPW_FORCE||rpWorldOf(RP_MAP(RPSEL));RPW_FORCE=0;RPW_VIEW=w;
 if(w>1){rpwWorldArt(w);const W=RP_WORLD(w);if(!W.maps.includes(RPSEL))RPSEL=r.wsel[w]&&W.maps.includes(r.wsel[w])?r.wsel[w]:W.maps[0];
  if(!rpMapOpen2(RP_MAP(RPSEL))){const o=W.maps.filter(id=>rpMapOpen2(RP_MAP(id)));RPSEL=o.length?o[o.length-1]:W.maps[0]}}
 const out=m0.apply(this,arguments);try{rpwHubPost(back)}catch(e){console.error(e)}return out}}
const RPW_ROMAN=['','I','II','III','IV','V'];
function rpwHubPost(back){const hub=ov.querySelector('.rphub');if(!hub)return;const r=rpwSave(),w=RPW_VIEW,hb=back||title;r.wsel[w]=RPSEL;hub.classList.add('rpw'+w);
 const go=wid=>{const W=RP_WORLD(wid);RPW_FORCE=wid;RPSEL=r.wsel[wid]&&W.maps.includes(r.wsel[wid])?r.wsel[wid]:W.maps[0];try{rpSfx('key',2)}catch(e){}rampartsMenu(back)};
 /* the tabs */
 const tabs=document.createElement('div');tabs.className='rpwtabs';tabs.innerHTML=RP_WORLDS.map(W=>{const op=rpWorldOpen(W.id),st=W.id===1?RP_WORLD(1).maps.reduce((a,id)=>a+(r.stars[id]||0),0):rpwStars(W.id);
  return `<button class="rpwt${W.id===w?' on':''}${op?'':' lock'}" data-w="${W.id}" style="--c:${W.col}"><i>${RPW_ROMAN[W.id]}</i><span><b>${esc(W.n)}</b><small>${op?`${st} / 9 stars`:'Locked'}</small></span>${op?'':`<em>${RPI.lock}</em>`}</button>`}).join('');
 hub.appendChild(tabs);tabs.querySelectorAll('.rpwt').forEach(b=>b.onclick=()=>{const wid=+b.dataset.w;if(wid!==w)go(wid)});
 if(w===1)return;
 const W=RP_WORLD(w),wop=rpWorldOpen(w);
 /* nodes: open / locked by the world's own rule */
 hub.querySelectorAll('.rpnode[data-m]').forEach(b=>{const m=RP_MAP(b.dataset.m),op=rpMapOpen2(m);b.classList.toggle('lock',!op);if(!op&&!b.querySelector('.rpnlk'))b.insertAdjacentHTML('afterbegin',`<span class="rpnlk">${RPI.lock}</span>`);if(op){const l=b.querySelector('.rpnlk');if(l)l.remove()}
  b.onclick=()=>{if(!op){rpSfx('no');const L=W.maps,i=L.indexOf(m.id);try{toast(i>0?`Earn 1 star in ${RP_MAP(L[i-1]).n} to unlock ${m.n}`:`Earn 1 star in ${RP_MAP(W.need).n} to reach ${W.n}`)}catch(e){}return}if(RPSEL===m.id){rpStart(RPSEL);return}RPSEL=m.id;rpSfx('key',2);rampartsMenu(back)}});
 const m=RP_MAP(RPSEL),df=$('rpdef');if(df&&!rpMapOpen2(m)){df.classList.add('lock');df.onclick=()=>{rpSfx('no')}}
 /* the side panel: the tier cap, and the next world after the last map */
 const side=hub.querySelector('.rpside');if(side){const cm=[...side.querySelectorAll('.rpcm')].pop();if(cm)cm.insertAdjacentHTML('afterend',`<p class="rpcm rpwtier"><i class="rpwtic">${RPW_ROMAN[m.maxT]}</i><span>Towers reach tier ${RPW_ROMAN[m.maxT]} here</span></p>`);
  const L=W.maps,last=L.indexOf(m.id)===L.length-1,NW=RP_WORLDS.find(x=>x.id===w+1);if(last&&NW&&!side.querySelector('.rpnr')){side.insertAdjacentHTML('beforeend',`<div class="rpcrule"><i></i></div><div class="rpnr"><small>NEXT WORLD</small><div class="rpcnr" id="rpwnx"><span class="rpnri rpwnri" style="--c:${NW.col}">${RPW_ROMAN[NW.id]}</span><span><b>${esc(NW.n)}</b><em>${rpWorldOpen(NW.id)?esc(NW.sub):'Earn a star here to reach it'}</em></span><i class="rpcnrgo">›</i></div></div>`);$('rpwnx').onclick=()=>go(NW.id)}}
 /* the world's armory */
 const arm=hub.querySelector('.rparm');if(arm){const sn=rpwStars(w),C=RPW_CHEST[w],got=r.wchest[w]||0;let paid=0,n=got;C.forEach(([need,coins],i)=>{if(sn>=need&&!(got&(1<<i))){n|=1<<i;paid+=coins}});
  if(paid){r.wchest[w]=n;P.gold=Math.min(1e12,P.gold+paid);try{stat('gold',paid,'add')}catch(e){}save();setTimeout(()=>{try{toast(`${W.n} chest opened: +${cmn(paid)} coins`)}catch(e){}},400)}
  const h=arm.querySelector('.rparmh');if(h){const b=h.querySelector('b'),sp=h.querySelector('span'),bar=h.querySelector('em i');if(b)b.textContent=w===2?'Tidebreak Armory':'Skyforge Armory';if(sp)sp.innerHTML=`${RPI.star(1,20)} ${sn} / 9 stars`;if(bar)bar.style.transform=`scaleX(${sn/9})`}
  const trk=arm.querySelector('.rptrk');if(trk)trk.innerHTML=`<i class="rptrl"><s style="transform:scaleX(${Math.min(1,Math.max(0,(sn-1)/8))})"></s></i>`+C.map(([need,coins],i)=>`<span class="rptk rpwck${sn>=need?' own':''}" style="left:${(need-1)/8*100}%"><span class="rptki rpwchest">${RPI.coin}<b>${cmn(coins)}</b></span><em>${need}</em></span>`).join('')
   ;
  const nu=arm.querySelector('.rpnu');if(nu){const nx=C.find(([need])=>sn<need);const s=nu.querySelector('small'),b=nu.querySelector('b');if(s)s.textContent=nx?'Next chest':`Title: ${RPW_TITLE[w]}`;if(b)b.textContent=nx?`${nx[0]} stars`:'All earned';nu.querySelectorAll('span:not(.rptki)').forEach(x=>x.remove());const vr=$('rpvr');if(vr)vr.hidden=true}}
 /* a locked world */
 if(!wop){const need=RP_MAP(W.need),c=document.createElement('div');c.className='rpwlk';c.innerHTML=`<div><span class="rpwlki" style="--c:${W.col}">${RPW_ROMAN[w]}</span><p class="rpkick">WORLD ${RPW_ROMAN[w]} · LOCKED</p><h2>${esc(W.n)}</h2><p>${esc(W.sub)}. Earn a star on <b>${esc(need.n)}</b> to reach it.</p><p class="rpwlkn">New here: ${w===2?'sea monsters, the tide, fog, whirlpools and glowcaps':'clockwork monsters, gales, a switch track, conveyors and a thunderstorm'}. Towers reach tier ${RPW_ROMAN[w===2?4:5]}.</p><button id="rpwlkgo">Play ${esc(need.n)} ›</button></div>`;
  hub.appendChild(c);$('rpwlkgo').onclick=()=>{RPSEL=need.id;go(rpWorldOf(need))}}}
{const st=document.createElement('style');st.textContent=`
.rpwtabs{position:absolute;left:26px;top:80px;display:flex;gap:8px;z-index:4}
#ov .rpwt{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:9px;height:52px;padding:0 14px 0 6px;border-radius:16px;background:linear-gradient(180deg,#241a5cf0,#120c34f4);border:2px solid #4a3a90;box-shadow:0 0 0 2px #12081f;transition:transform .15s;position:relative}
#ov .rpwt:hover{transform:translateY(-2px)}#ov .rpwt.on{border-color:var(--c);background:linear-gradient(180deg,#30247af4,#160e40f8)}
.rpwt>i{display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:#12081f;border:2px solid var(--c);font:400 20px/1 'Pirata One',Georgia,serif;font-style:normal;color:var(--c)}
.rpwt span{display:flex;flex-direction:column;text-align:left}.rpwt b{font:800 14px var(--ui);color:#fff8e8;white-space:nowrap}.rpwt small{font:700 11.5px var(--ui);color:#a99be0}
.rpwt.on small{color:var(--c)}.rpwt.lock{opacity:.78}.rpwt.lock b{color:#cfc6f0}.rpwt em{display:grid;place-items:center;width:20px;height:20px}.rpwt em svg{width:16px;height:16px}
.rpwlk{position:absolute;inset:140px 0 0 0;z-index:6;display:grid;place-items:center;background:radial-gradient(ellipse at 40% 50%,#08051c99,#08051cd8);pointer-events:auto}
.rpwlk>div{position:relative;width:620px;padding:30px 34px 28px;border-radius:26px;text-align:center;background:linear-gradient(180deg,#241a5cfa,#100a30fc);border:2px solid #c99a3a;box-shadow:0 0 0 3px #12081f,0 30px 80px #000c}
.rpwlki{display:inline-grid;place-items:center;width:64px;height:64px;border-radius:20px;background:#12081f;border:3px solid var(--c);font:400 34px/1 'Pirata One',Georgia,serif;color:var(--c)}
.rpwlk h2{margin:4px 0 6px;font:400 46px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f}.rpwlk p{margin:6px 0;font:500 15px/1.45 var(--ui);color:#e8e0ff}.rpwlk b{color:#ffd45a}
.rpwlk .rpwlkn{font-size:13.5px;color:#c4badf}#ov .rpwlk button{margin-top:14px;padding:12px 26px;border-radius:16px;border:none;background:linear-gradient(180deg,#ffe27a,#f2b92a);color:#3a1a04;font:800 18px var(--ui);box-shadow:0 0 0 2px #12081f,0 5px 0 #8a4a0a;cursor:pointer}
.rpwlk .rpkick{margin:10px 0 0;font:800 12px var(--ui);letter-spacing:.24em;color:#7ad8ff}
.rpwtier .rpwtic{display:inline-grid;place-items:center;min-width:22px;height:22px;padding:0 4px;border-radius:7px;background:#ffd45a;color:#3a1a04;font:800 12px var(--ui);font-style:normal}.rpwtier span{color:#ffd45a}
.rpwnri{display:grid!important;place-items:center;width:56px;height:56px;background:#12081f;color:var(--c);font:400 30px/1 'Pirata One',Georgia,serif;box-shadow:0 0 0 2px var(--c)!important}
.rpwchest{display:grid!important;place-items:center;background:radial-gradient(circle at 50% 40%,#5a4ab0,#1a1240)!important;border-radius:14px;border:2px solid #c99a3a}.rpwchest svg{width:30px;height:30px}.rpwchest b{font:800 11px var(--ui);color:#ffd45a}
.rpwck:not(.own) .rptki{opacity:.55}
#ov .rpdef.lock,#ov #rpdef.lock{filter:grayscale(.7);opacity:.6;cursor:default}`;document.head.appendChild(st)}
/* ---------- a new world opens: the results card says so, with a button to sail there ---------- */
{const r0=rpResult;rpResult=function(){const R=RPX,res=R&&R.result,m=R&&R.map;const out=r0.apply(this,arguments);
 try{if(res&&m&&res.won&&!(res.old>0)&&res.stars>0){const W=RP_WORLDS.find(x=>x.need===m.id);const box=ov.querySelector('.rpres');if(W&&box&&!box.querySelector('.rpwnew')){
   const d=document.createElement('div');d.className='rpwnew';d.style.setProperty('--c',W.col);
   d.innerHTML=`<span class="rpwlki" style="--c:${W.col}">${RPW_ROMAN[W.id]}</span><span><small>NEW WORLD UNLOCKED</small><b>${esc(W.n)}</b><em>${esc(W.sub)} · new monsters and twists · towers reach tier ${RPW_ROMAN[W.id===2?4:5]}</em></span><button id="rpwgo">Sail there ›</button>`;
   const row=box.querySelector('.row');if(row)row.before(d);else box.appendChild(d);$('rpwgo').onclick=()=>{RPSEL=W.maps[0];try{rpSfx('key',2)}catch(e){}rampartsMenu(title)};try{rpSfx('up')}catch(e){}}}}catch(e){console.error(e)}return out}}
{const st=document.createElement('style');st.textContent=`.rpwnew{display:flex;align-items:center;gap:14px;margin:10px 0 4px;padding:10px 14px;border-radius:16px;text-align:left;background:linear-gradient(90deg,#2a1f6a,#12081f);border:2px solid var(--c);box-shadow:0 0 0 2px #12081f}
.rpwnew .rpwlki{width:48px;height:48px;font-size:26px;flex:none}.rpwnew>span:nth-child(2){flex:1;display:flex;flex-direction:column}.rpwnew small{font:800 11px var(--ui);letter-spacing:.2em;color:var(--c)}.rpwnew b{font:400 28px/1.05 'Pirata One',Georgia,serif;color:#ffd45a}.rpwnew em{font:600 12.5px var(--ui);font-style:normal;color:#e8e0ff}
#ov .rpwnew button{flex:none;padding:10px 16px;border-radius:14px;border:none;background:linear-gradient(180deg,#ffe27a,#f2b92a);color:#3a1a04;font:800 15px var(--ui);box-shadow:0 0 0 2px #12081f,0 4px 0 #8a4a0a;cursor:pointer}`;document.head.appendChild(st)}
