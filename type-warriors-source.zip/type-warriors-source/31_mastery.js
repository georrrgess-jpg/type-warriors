/* ---------- weapon mastery: use a weapon to level it. Five tiers, three perks per weapon, cosmetic glow. Stored in P.wxp, which Prestige never touches. ---------- */
const WT=[200,900,2400,5200,9500],WTN=['Unproven','Novice','Adept','Expert','Master','Grandmaster'],WROM=['0','I','II','III','IV','V'];
const WLA=[0,1,2,3,3.5,4],WLB=[0,0,1,1,2,2],WLC=[0,0,0,0,1,2];
const wf1=x=>+x.toFixed(1);
/* mastery power by weapon rarity: low rarities barely benefit, top rarities are a little below full strength because their base stats are already strong */
const WPW={Common:.08,Uncommon:.16,Rare:.28,Epic:.8,Legendary:.75,Mythic:.7},wPow=id=>{const v=WPW[WP[id].r];return v==null?.8:v};
const MB=[
 {n:'Keen Edge',d:l=>`+${wf1(4*l)}% score`,f:(S,t)=>{S.sc*=1+.04*t}},
 {n:'Fury Kindling',d:l=>`+${wf1(8*l)}% Fury gain`,f:(S,t)=>{S.furyMul*=1+.08*t}},
 {n:'Steady Stance',d:l=>`Foes ${wf1(3*l)}% slower`,f:(S,t)=>{S.slow=Math.max(.6,S.slow*(1-.03*t))}},
 {n:'Deadeye',d:l=>`+${wf1(3*l)}% crit chance`,f:(S,t)=>{S.crit+=.03*t}},
 {n:'Gilded Grip',d:l=>`+${wf1(6*l)}% gold`,f:(S,t)=>{S.gm+=.06*t}},
 {n:'Warded Hilt',d:l=>`+${wf1(Math.min(l,1)*5)}% Fury gain${l>=2?' and a starting shield':''}`,f:(S,t)=>{S.furyMul*=1+.05*Math.min(t,1);if(t>=2)S.shield++}},
 {n:'Vital Steel',d:l=>`+${wf1(Math.min(l,1)*4)}% score${l>=2?' and +1 max HP':''}`,f:(S,t)=>{S.sc*=1+.04*Math.min(t,1);if(t>=2){S.max++;S.hp++}}},
 {n:'Calm Breath',d:l=>`Slips cost ${wf1(3*l)}% less streak`,f:(S,t)=>{S.keep=Math.min(.9,S.keep+.03*t)}},
 {n:'Quick Study',d:l=>`+${wf1(4*l)}% XP`,f:(S,t)=>{S.xpm=(S.xpm||0)+.04*t}},
 {n:'Long Reach',d:l=>`Boss weak window +${wf1(.25*l)}s`,f:(S,t)=>{S.vm+=.25*t}},
 {n:'Lucky Find',d:l=>`+${wf1(.6*l)}% crate drop chance`,f:(S,t)=>{S.cl+=.006*t}},
 {n:'Sure Footing',d:l=>`${wf1(.05*l)}s longer safety after a hit`,f:(S,t)=>{S.invT+=.05*t}},
 {n:'Deep Reservoir',d:l=>`Fury meter holds ${wf1(4*l)} more`,f:(S,t)=>{S.fm+=4*t}},
 {n:'Quick Recovery',d:l=>`Parry ready ${wf1(.02*l)}s sooner`,f:(S,t)=>{S.pcdT=Math.max(.2,S.pcdT-.02*t)}},
 {n:'Stormcaller',d:l=>`+${wf1(l)}% chance a kill chains to another foe`,f:(S,t)=>{S.chain=(S.chain||0)+.01*t}}];
const wHash=id=>{let h=2166136261;for(const c of id)h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0};
/* the first two perks are the original pair (unchanged for existing saves); the third comes from the newer perks */
const mbTrio=id=>{const h=wHash(id),a=h%10,b=(a+1+((h>>>8)%9))%10,c=10+((h>>>16)%5);return[a,b,c]};
const mbPair=id=>mbTrio(id).slice(0,2);
const wxp=id=>(P.wxp&&P.wxp[id])||0,wTier=id=>{const x=wxp(id);let t=0;while(t<5&&x>=WT[t])t++;return t};
/* progress inside the current tier, 0 to 1 */
const wProg=id=>{const x=wxp(id),t=wTier(id);if(t>=5)return 1;const lo=t?WT[t-1]:0;return Math.max(0,Math.min(1,(x-lo)/(WT[t]-lo)))};
/* perk lines gained at tier t (what reaching that tier grants) */
function tierLines(id,t){const [a,b,c]=mbTrio(id),o=[],p=wPow(id);if(WLA[t]>WLA[t-1]||t===1)o.push(`${MB[a].n}: ${MB[a].d(WLA[t]*p)}`);if(WLB[t]>(WLB[t-1]||0))o.push(`${MB[b].n}: ${MB[b].d(WLB[t]*p)}`);if(WLC[t]>(WLC[t-1]||0))o.push(`${MB[c].n}: ${MB[c].d(WLC[t]*p)}`);return o}
function applyMastery(){const id=P.weapon,t=wTier(id);if(!t)return;const [a,b,c]=mbTrio(id),p=wPow(id);MB[a].f(S,WLA[t]*p);if(WLB[t])MB[b].f(S,WLB[t]*p);if(WLC[t])MB[c].f(S,WLC[t]*p)}
/* the big mastery card used in the armory */
function mastHTML(id){const x=wxp(id),t=wTier(id),col=WP[id].col,nx=t>=5?null:WT[t],segs=[0,1,2,3,4].map(i=>`<s><i style="width:${t>i?100:t===i?Math.round(wProg(id)*100):0}%"></i></s>`).join('');
 const rows=[1,2,3,4,5].map(i=>`<li class="${t>=i?'on':i===t+1?'nx':''}"><b>${WROM[i]}</b><em>${WTN[i]}</em><span>${tierLines(id,i).join('<br>')}</span></li>`).join('');
 return `<div class="wmc t${t}" style="--c:${col}"><div class="wmh"><span>Mastery</span><b>${t?WTN[t]:'Unproven'}</b><u>${WROM[t]}</u></div><div class="wmb">${segs}</div>
 <div class="wmx">${nx?`<b>${x.toLocaleString()}</b> / ${nx.toLocaleString()} XP <small>${(nx-x).toLocaleString()} to ${WTN[t+1]}</small>`:`<b>${x.toLocaleString()}</b> XP <small>Fully mastered</small>`}</div>
 <ul class="wml">${rows}</ul><div class="wmp2">Mastery power for ${WP[id].r} weapons: <b>${Math.round(wPow(id)*100)}%</b></div><div class="wmf">Mastery is permanent. It is kept through every Prestige.</div></div>`}
/* small bar for grid cards */
const wmMini=id=>{const t=wTier(id);return `<span class="wmm t${t}"><span class="wmp">${[1,2,3,4,5].map(i=>`<i class="${t>=i?'on':''}"></i>`).join('')}</span><span class="wmt"><i style="width:${Math.round(wProg(id)*100)}%"></i></span><small>${t?WTN[t]:'Unproven'} · ${wxp(id).toLocaleString()} XP</small></span>`};
const wxpGain=()=>{if(S.prac)return 0;const k=S.rift?RFT.wk:2;return Math.round((S.wk||0)*k+(S.rift?RFT.wb+(S.surges||0)*RFT.wS:0))};
function wxpEnd(){const id=S.wpn||P.weapon,gain=wxpGain();if(S.prac||gain<=0)return'';P.wxp=P.wxp||{};const t0=wTier(id),x0=wxp(id),p0=wProg(id);P.wxp[id]=x0+gain;const t1=wTier(id);save();setTimeout(achCheck,30);
 const col=WP[id].col,nx=t1>=5?null:WT[t1],lo=t1?WT[t1-1]:0,a=t1>t0?0:Math.round(p0*100),b=Math.round(wProg(id)*100);
 const up=t1>t0?tierLines(id,t1).map(l=>`<span>${l}</span>`).join(''):'';
 return `<span class="wxr" style="--c:${col}"><span class="wxh"><b>${WP[id].n}</b><span>+${gain.toLocaleString()} weapon XP</span></span><span class="wxb"><i class="o" style="width:${a}%"></i><i class="n" style="width:${b}%"></i></span><span class="wxs">${t1?WTN[t1]:'Unproven'}${nx?` · ${(nx-wxp(id)).toLocaleString()} XP to ${WTN[t1+1]}`:' · fully mastered'}</span>${t1>t0?`<span class="wxu"><b>Mastery ${WROM[t1]}: ${WTN[t1]}!</b>${up}</span>`:''}</span>`}
const wmCount=t=>Object.keys(P.wxp||{}).filter(k=>WP[k]&&wTier(k)>=t).length;
/* cosmetic glow: a soft halo at tier I, a halo plus orbiting sparks at tier II */
function wGlow(g,id,L,t){const tr=wTier(id);if(!tr)return;const c=WP[id].col;if(!/^#[0-9a-f]{6}/i.test(c))return;t=t||0;g.save();g.globalCompositeOperation='lighter';
 glow(g,L*.55,0,L*(.72+.12*tr),c+(tr>2?'77':tr>1?'66':'3a'));
 if(tr>1){g.fillStyle=c;const ns=4+2*tr;for(let i=0;i<ns;i++){const u=(t*.55+i/ns)%1,x=L*.08+u*L*.95,y=Math.sin(t*5+i*2)*6*(.4+u);g.globalAlpha=Math.sin(u*Math.PI)*.95;ell(g,x,y,2.2,2.2,'#ffffff');glow(g,x,y,5,c+'aa')}}
 g.restore()}
const mastTag=id=>{const t=wTier(id);return `<u class="mt${Math.min(2,t)}">Mastery ${WROM[t]}</u>`};
