/* ===== WILDCARD: the tavern card game (8.2) — rules engine, bots and economy =====
   Pure game logic with no DOM, so it runs the same for Solo, for a room host and in tests.
   Deck (108): four elements Ember, Tide, Grove, Spark, each with one 0, two of 1-9, two Stun (skip), two Turnabout
   (reverse) and two +2 Curse; plus four Wild Rune and four +4 Hex. Match the element or the face; first to empty
   their hand wins. Call WILD! when you are down to one card or you can be caught for 2 cards.
   Every action pushes events onto G.ev ({k,...,n:seq}); the table replays them as animations. */
const WCS=['e','t','g','s'],WCN={e:'Ember',t:'Tide',g:'Grove',s:'Spark',w:'Wild'},WCC={e:'#ff4a1f',t:'#1f8cff',g:'#22c55e',s:'#ffc21a',w:'#9a5cff'};
const WCV={stun:'Stun',turn:'Turnabout',d2:'+2 Curse',wild:'Wild Rune',d4:'+4 Hex'};
const wcRng=seed=>{let a=(seed>>>0)||1;return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}};
function wcShuf(a,r){for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));const x=a[i];a[i]=a[j];a[j]=x}return a}
function wcDeck(r){const d=[];let id=0;for(const s of WCS){d.push({id:id++,s,v:'0'});for(let n=1;n<=9;n++)for(let k=0;k<2;k++)d.push({id:id++,s,v:String(n)});for(const v of['stun','turn','d2'])for(let k=0;k<2;k++)d.push({id:id++,s,v})}
 for(let k=0;k<4;k++){d.push({id:id++,s:'w',v:'wild'});d.push({id:id++,s:'w',v:'d4'})}return wcShuf(d,r)}
const wcIsNum=c=>/^\d$/.test(c.v),wcPts=c=>c.s==='w'?50:wcIsNum(c)?+c.v:20;
const wcName=c=>c.s==='w'?WCV[c.v]:(WCN[c.s]+' '+(WCV[c.v]||c.v));
const wcTop=G=>G.disc[G.disc.length-1];
function wcEmit(G,e){e.n=++G.seq;G.ev.push(e);if(G.ev.length>120)G.ev.splice(0,G.ev.length-120);return e}
/* o: {players:[{id,name,kind:'you'|'bot'|'net',diff,av}], hand, rules:{stack,until,seven}, seed} */
function wcNew(o){const r=wcRng(o.seed||Date.now()),G={r,seed:o.seed,draw:wcDeck(r),disc:[],color:'e',turn:0,dir:1,stack:0,phase:'play',pend:-1,one:null,rules:Object.assign({stack:1,until:0,seven:0},o.rules||{}),ev:[],seq:0,turns:0,win:-1,big:0,
 P:o.players.map(p=>Object.assign({},p,{hand:[],called:0,played:0,drawn:0,lack:{},caught:0,catches:0,d4:0,ones:0}))};
 const hn=o.hand||7;for(let k=0;k<hn;k++)for(const p of G.P)p.hand.push(G.draw.pop());
 let i=G.draw.findIndex(c=>wcIsNum(c));const first=G.draw.splice(i,1)[0];G.disc.push(first);G.color=first.s;
 G.turn=Math.floor(r()*G.P.length);wcEmit(G,{k:'deal',hand:hn});wcEmit(G,{k:'turn',p:G.turn});return G}
function wcCan(G,c){if(G.stack>0){if(!G.rules.stack)return false;const t=wcTop(G);return c.v==='d4'||(c.v==='d2'&&t.v==='d2')}return c.s==='w'||c.s===G.color||c.v===wcTop(G).v}
function wcLegal(G,pi){const p=G.P[pi];if(G.phase==='drawn')return G.pend>=0?p.hand.map((c,i)=>c.id===G.pend&&wcCan(G,c)?i:-1).filter(i=>i>=0):[];return p.hand.map((c,i)=>wcCan(G,c)?i:-1).filter(i=>i>=0)}
const wcNext=(G,k)=>((G.turn+G.dir*(k||1))%G.P.length+G.P.length)%G.P.length;
function wcGive(G,pi,n){const p=G.P[pi],got=[];for(let k=0;k<n;k++){if(!G.draw.length){if(G.disc.length<2)break;const top=G.disc.pop();G.draw=wcShuf(G.disc,G.r);G.disc=[top];wcEmit(G,{k:'shuffle'})}const c=G.draw.pop();p.hand.push(c);got.push(c)}
 p.drawn+=got.length;if(p.hand.length>1)p.called=0;return got}
function wcAdvance(G,skip){G.phase='play';G.pend=-1;G.turn=wcNext(G,skip?2:1);wcTurnStart(G)}
function wcTurnStart(G){if(G.phase==='over')return;G.turns++;wcEmit(G,{k:'turn',p:G.turn});const p=G.P[G.turn];
 if(G.stack>0&&!(G.rules.stack&&p.hand.some(c=>wcCan(G,c)))){const n=G.stack;G.stack=0;const got=wcGive(G,G.turn,n);wcEmit(G,{k:'draw',p:G.turn,c:got.map(c=>c.id),stack:n});wcEmit(G,{k:'skip',p:G.turn});G.turn=wcNext(G);wcTurnStart(G)}}
/* actions: each returns true if it did something */
function wcPlay(G,pi,idx,col){if(G.phase==='over'||G.turn!==pi)return false;const p=G.P[pi],c=p.hand[idx];if(!c)return false;
 if(G.phase==='drawn'&&c.id!==G.pend)return false;if(!wcCan(G,c))return false;if(c.s==='w'&&!WCS.includes(col))return false;
 p.hand.splice(idx,1);G.disc.push(c);G.color=c.s==='w'?col:c.s;p.played++;if(c.v==='d4')p.d4++;
 wcEmit(G,{k:'play',p:pi,c,col:G.color});G.one=null;
 if(p.hand.length===0){G.phase='over';G.win=pi;wcEmit(G,{k:'win',p:pi});return true}
 if(p.hand.length===1){if(p.called){p.ones++}else G.one={p:pi,n:G.seq}}else p.called=0;
 let skip=false;
 if(c.v==='d2'||c.v==='d4'){G.stack+=c.v==='d2'?2:4;G.big=Math.max(G.big,G.stack);wcEmit(G,{k:'stack',n:G.stack})}
 else if(c.v==='stun'){skip=true;wcEmit(G,{k:'skip',p:wcNext(G)})}
 else if(c.v==='turn'){if(G.P.length===2){skip=true;wcEmit(G,{k:'skip',p:wcNext(G)})}else{G.dir*=-1;wcEmit(G,{k:'rev',dir:G.dir})}}
 else if(c.v==='7'&&G.rules.seven&&p.hand.length){let t=-1,m=99;G.P.forEach((q,i)=>{if(i!==pi&&q.hand.length<m){m=q.hand.length;t=i}});if(t>=0){const h=p.hand;p.hand=G.P[t].hand;G.P[t].hand=h;p.called=0;G.P[t].called=G.P[t].hand.length===1?1:0;wcEmit(G,{k:'swap',a:pi,b:t})}}
 wcAdvance(G,skip);return true}
function wcDrawAct(G,pi){if(G.phase==='over'||G.turn!==pi||G.phase==='drawn')return false;const p=G.P[pi];G.one=null;
 if(G.stack>0){const n=G.stack;G.stack=0;const got=wcGive(G,pi,n);wcEmit(G,{k:'draw',p:pi,c:got.map(c=>c.id),stack:n});wcEmit(G,{k:'skip',p:pi});wcAdvance(G,false);return true}
 p.lack[G.color]=1;const got=[];let last=null;
 do{const g=wcGive(G,pi,1);if(!g.length)break;got.push(g[0]);last=g[0]}while(G.rules.until&&!wcCan(G,last)&&got.length<12);
 wcEmit(G,{k:'draw',p:pi,c:got.map(c=>c.id)});
 if(last&&wcCan(G,last)){G.phase='drawn';G.pend=last.id;return true}
 wcAdvance(G,false);return true}
function wcPass(G,pi){if(G.turn!==pi||G.phase!=='drawn')return false;wcEmit(G,{k:'pass',p:pi});wcAdvance(G,false);return true}
function wcCall(G,pi){const p=G.P[pi];if(G.phase==='over'||p.called||p.hand.length>2)return false;if(p.hand.length===2&&G.turn!==pi)return false;
 p.called=1;if(G.one&&G.one.p===pi){G.one=null;p.ones++}wcEmit(G,{k:'call',p:pi});return true}
function wcCatch(G,by,t){if(!G.one||G.one.p!==t||by===t||G.phase==='over')return false;const q=G.P[t];if(q.hand.length!==1||q.called){G.one=null;return false}
 G.one=null;const got=wcGive(G,t,2);G.P[by].catches++;q.caught++;wcEmit(G,{k:'catch',by,p:t,c:got.map(c=>c.id)});return true}
/* final standings: winner, then fewest cards, then fewest points */
function wcRank(G){return G.P.map((p,i)=>({i,n:p.hand.length,pts:p.hand.reduce((a,c)=>a+wcPts(c),0)})).sort((a,b)=>(a.i===G.win?-1:b.i===G.win?1:0)||a.n-b.n||a.pts-b.pts).map(x=>x.i)}

/* ---------- bots: they only see their own hand, the table and what everyone has drawn on ---------- */
const WCB={e:{forget:.35,catch:.25,react:[1500,2600]},m:{forget:.15,catch:.55,react:[900,1900]},h:{forget:.04,catch:.9,react:[450,1200]}};
function wcBestCol(G,pi,hard){const p=G.P[pi],cnt={e:0,t:0,g:0,s:0};for(const c of p.hand)if(c.s!=='w')cnt[c.s]+=1+(hard&&!wcIsNum(c)?.5:0);
 let best=WCS[0];for(const s of WCS)if(cnt[s]>cnt[best])best=s;
 if(hard){const nx=G.P[wcNext(G)];const hurt=WCS.filter(s=>nx.lack[s]&&cnt[s]>0);if(hurt.length&&nx.hand.length<=4)best=hurt.sort((a,b)=>cnt[b]-cnt[a])[0]}
 if(!cnt[best])best=WCS[Math.floor(G.r()*4)];return best}
function wcBot(G,pi){const p=G.P[pi],d=p.diff||'m',L=wcLegal(G,pi);
 if(G.phase==='drawn'){if(!L.length)return{t:'pass'};const c=p.hand[L[0]];if(d==='h'&&c.s==='w'&&p.hand.length>3&&G.P[wcNext(G)].hand.length>2)return{t:'pass'};if(d==='e'&&G.r()<.15)return{t:'pass'};return{t:'play',i:L[0],col:c.s==='w'?wcBestCol(G,pi,d==='h'):null}}
 if(!L.length)return{t:'draw'};
 let pick;
 if(d==='e'){pick=L[Math.floor(G.r()*L.length)];const nums=L.filter(i=>wcIsNum(p.hand[i]));if(nums.length&&G.r()<.35)pick=nums[Math.floor(G.r()*nums.length)];
  const c=p.hand[pick];return{t:'play',i:pick,col:c.s==='w'?(G.r()<.5?WCS[Math.floor(G.r()*4)]:wcBestCol(G,pi)):null}}
 const nx=G.P[wcNext(G)],danger=nx.hand.length<=2,mine=p.hand.length,cnt={};for(const c of p.hand)cnt[c.s]=(cnt[c.s]||0)+1;
 let best=-1e9;for(const i of L){const c=p.hand[i];let s=0;
  if(c.s==='w'){s=c.v==='d4'?-9:-6;if(mine<=2)s+=12;if(danger&&d==='h')s+=c.v==='d4'?16:4}
  else{s+=(cnt[c.s]||0)*1.2;if(wcIsNum(c))s+=+c.v*.25;else s+=1;if(c.s===G.color)s+=1;
   if(danger&&(c.v==='d2'||c.v==='stun'||(c.v==='turn'&&G.P.length>2)))s+=d==='h'?14:6;
   if(d==='h'&&!danger&&!wcIsNum(c)&&mine>3)s-=1.5}
  if(G.stack>0)s+=5;s+=G.r()*(d==='h'?.6:2);if(s>best){best=s;pick=i}}
 const c=p.hand[pick];return{t:'play',i:pick,col:c.s==='w'?wcBestCol(G,pi,d==='h'):null}}
/* apply a bot or remote decision */
function wcDo(G,pi,a){if(!a)return false;if(a.t==='play'){let i=a.i;if(a.id!=null)i=G.P[pi].hand.findIndex(c=>c.id===a.id);return i>=0&&wcPlay(G,pi,i,a.col)}if(a.t==='draw')return wcDrawAct(G,pi);if(a.t==='pass')return wcPass(G,pi);if(a.t==='call')return wcCall(G,pi);if(a.t==='catch')return wcCatch(G,pi,a.p);return false}

/* ---------- economy (tuned with 3,000-game simulations, see HANDOFF) ----------
   Four tables that differ only in their denomination (the buy-in); every table seats the same lounge regulars.
   Everyone buys in, the winner takes the pot less a 12% house cut, and second place gets 40% of their buy-in back.
   Gold returned per gold staked: a careless player about 0.52, a typical player 0.98, a sharp player 1.12, and even a
   sharp player wins only about 29% of games, so nobody profits every time and nobody always loses.
   Staked games are capped per day (after that, games are free practice that still count for stats), and the first
   win each day pays a small bonus. */
const WCT={c50:{n:'Copper Corner',lab:'50',stake:50,chip:'#d0743a',chip2:'#7a3412'},c250:{n:'Silver Salon',lab:'250',stake:250,chip:'#5aa8e8',chip2:'#1a4a8a'},
 c1k:{n:'Gold Room',lab:'1K',stake:1000,chip:'#ffc94a',chip2:'#9a5a10'},c2k5:{n:"Dragon's Hoard",lab:'2.5K',stake:2500,chip:'#e8384a',chip2:'#6a0a18'}};
const WCTK=['c50','c250','c1k','c2k5'],WCFEE=.12;
const WCE={SECOND:.4,DAILY:15,FIRSTWIN:150,MPFEE:.1};
function wcPayout(stake,players,place,fee){const pot=stake*players;if(place===0)return Math.round(pot*(1-fee));if(place===1)return Math.round(stake*WCE.SECOND);return 0}
