/* ===== 9.4 THE CROOKED CUE: the balls (96e) =====
   Each ball is painted per pixel into one slot of an atlas canvas. For every pixel of the visible hemisphere the surface normal is
   rotated into the ball's own frame (orientation matrix M, 3x3 row-major), which decides stripe, number discs (on both poles) and glyph;
   a fixed lamp (diffuse, a sharp specular, a window reflection, and a green bounce light from the felt) is applied in screen space,
   so the highlight stays put while the stripe and numbers roll underneath it. Only balls that moved are repainted
   (16 balls at 52 px cost about 0.7 ms in software rendering; drawing finished balls from the atlas is almost free).
   Prototype: pool_plan/pzball.js. */
const PZ_BS={D:0,set:'classic',pal:null,glyph:{},img:null,atlas:null,ax:null,n:0,idx:null,nx:null,ny:null,nz:null,dif:null,spe:null,al:null,bou:null,win:null,shadow:null,icon:{}};
const PZ_BPAL={
 classic:{col:{1:[242,194,27],2:[30,79,216],3:[224,38,46],4:[106,42,168],5:[242,122,27],6:[23,138,62],7:[138,26,26],8:[20,18,26]},white:[246,241,230],disc:[250,247,238],num:[20,16,24],spec:1,win:.10,dots:1},
 gem:{col:{1:[255,205,60],2:[40,100,255],3:[255,50,80],4:[150,60,230],5:[255,140,40],6:[20,190,110],7:[200,40,70],8:[30,26,44]},white:[255,248,236],disc:[255,238,170],num:[90,50,0],spec:1.5,win:.18,dots:1},
 moon:{col:{1:[255,238,170],2:[150,190,255],3:[255,170,190],4:[200,170,255],5:[255,200,150],6:[160,240,200],7:[220,150,170],8:[70,70,110]},white:[236,240,255],disc:[255,255,255],num:[60,70,150],spec:1.2,win:.16,dots:1,glow:1}};
/* number glyph masks (64 x 64 alpha), rebuilt once if the web font arrives late */
function pzbGlyph(n){if(PZ_BS.glyph[n])return PZ_BS.glyph[n];const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');
 x.font=`800 ${n>9?33:42}px Poppins,sans-serif`;x.textAlign='center';x.textBaseline='middle';x.fillStyle='#000';x.fillText(String(n),32,35);
 const d=x.getImageData(0,0,64,64).data,m=new Uint8Array(4096);for(let i=0;i<4096;i++)m[i]=d[i*4+3];return PZ_BS.glyph[n]=m}
function pzbFontWatch(){if(PZ_BS.fw||!document.fonts)return;PZ_BS.fw=1;try{document.fonts.addEventListener('loadingdone',()=>{if(!PZ_BS.glyphOK&&document.fonts.check('800 40px Poppins')){PZ_BS.glyphOK=1;PZ_BS.glyph={};PZ_BS.gm={};for(let k=1;k<16;k++)PZ_BS.gm[k]=pzbGlyph(k);PZ_BS.dirtyAll=1}})}catch(e){}}
/* one-time setup for a pixel diameter D and a ball set */
function pzbSetup(D,setId){const same=PZ_BS.D===D&&PZ_BS.atlas;PZ_BS.set=setId||PZ_BS.set;PZ_BS.pal=PZ_BPAL[PZ_BS.set]||PZ_BPAL.classic;pzbFontWatch();
 if(!same){PZ_BS.D=D;const N=D*D,S={nx:new Float32Array(N),ny:new Float32Array(N),nz:new Float32Array(N),dif:new Float32Array(N),spe:new Float32Array(N),al:new Float32Array(N),bou:new Float32Array(N),win:new Float32Array(N)};
  const L=[-.42,-.58,.7],ll=Math.hypot(...L);L[0]/=ll;L[1]/=ll;L[2]/=ll;const H=[L[0],L[1],L[2]+1],hl=Math.hypot(...H);H[0]/=hl;H[1]/=hl;H[2]/=hl;const r=D/2,idx=[];
  for(let y=0;y<D;y++)for(let x=0;x<D;x++){const i=y*D+x,px=(x+.5-r)/r,py=(y+.5-r)/r,q=px*px+py*py,d=Math.sqrt(q);S.al[i]=Math.max(0,Math.min(1,(1-d)*r+.5));if(S.al[i]<=0)continue;idx.push(i);
   const qq=Math.min(q,1),nz=Math.sqrt(1-qq);S.nx[i]=px;S.ny[i]=py;S.nz[i]=nz;const nd=px*L[0]+py*L[1]+nz*L[2];S.dif[i]=.30+.80*Math.max(0,nd)*(.72+.28*nz);
   const hs=Math.max(0,px*H[0]+py*H[1]+nz*H[2]);S.spe[i]=Math.pow(hs,62)*1.1+Math.pow(hs,9)*.07;
   /* the felt bounces a little green light up into the lower edge */
   S.bou[i]=Math.pow(Math.max(0,py*.8+(1-nz)*.4-.2),2.2)*.55;
   /* a soft window reflection (a rounded rectangle upper left) */
   const wx=(px+.42)/.36,wy=(py+.5)/.24;S.win[i]=Math.max(0,1-Math.max(Math.abs(wx),Math.abs(wy))*1.1)*Math.min(1,nz*1.6)}
  const n=idx.length,f=k=>{const a=new Float32Array(n);for(let j=0;j<n;j++)a[j]=S[k][idx[j]];return a};
  Object.assign(PZ_BS,{n,idx:Int32Array.from(idx),nx:f('nx'),ny:f('ny'),nz:f('nz'),dif:f('dif'),spe:f('spe'),al:f('al'),bou:f('bou'),win:f('win')});
  PZ_BS.atlas=document.createElement('canvas');PZ_BS.atlas.width=D*16;PZ_BS.atlas.height=D;PZ_BS.ax=PZ_BS.atlas.getContext('2d');PZ_BS.img=PZ_BS.ax.createImageData(D,D);
  /* a baked soft contact shadow */
  const sc=document.createElement('canvas');sc.width=96;sc.height=64;const sx=sc.getContext('2d'),g=sx.createRadialGradient(48,32,2,48,32,30);g.addColorStop(0,'rgba(0,0,0,.62)');g.addColorStop(.55,'rgba(0,0,0,.34)');g.addColorStop(1,'rgba(0,0,0,0)');
  sx.setTransform(1.2,0,0,.8,-9.6,6.4);sx.fillStyle=g;sx.fillRect(0,0,96,64);PZ_BS.shadow=sc}
 PZ_BS.gm={};for(let k=1;k<16;k++)PZ_BS.gm[k]=pzbGlyph(k);PZ_BS.dirtyAll=1;PZ_BS.icon={}}
/* paint ball n (0 = cue) with orientation M into atlas slot */
function pzbPaint(slot,n,M){const P=PZ_BS,pal=P.pal,d=P.img.data,stripe=n>8,C=n===0?pal.white:pal.col[stripe?n-8:n],W=pal.white,DS=pal.disc,NM=pal.num,gl=n>0?P.gm[n]:null,
 cr=C[0],cg=C[1],cb=C[2],wr=W[0],wg=W[1],wb=W[2],m0=M[0],m1=M[1],m2=M[2],m3=M[3],m4=M[4],m5=M[5],m6=M[6],m7=M[7],m8=M[8],sk=pal.spec,wk=pal.win;
 for(let j=0;j<P.n;j++){const wx=P.nx[j],wy=P.ny[j],wz=P.nz[j];
  const lx=m0*wx+m3*wy+m6*wz,ly=m1*wx+m4*wy+m7*wz,lz=m2*wx+m5*wy+m8*wz;
  let r=cr,g2=cg,b=cb;
  if(stripe){const ay=ly<0?-ly:ly,t=Math.max(0,Math.min(1,(ay-.56)/.035+.5));r=cr+(wr-cr)*t;g2=cg+(wg-cg)*t;b=cb+(wb-cb)*t}
  const az=lz<0?-lz:lz;
  if(n>0){if(az>.84){const u=lx*2,v=ly*2,q=u*u+v*v;if(q<1.15){const dk=Math.max(0,Math.min(1,(1-q)/.1+.2));
    const s=lz>0?1:-1,gx=((u*s*.5+.5)*64)|0,gy=((v*.5+.5)*64)|0;let gm=0;if(gx>=0&&gx<64&&gy>=0&&gy<64)gm=gl[gy*64+gx]/255;
    const dr=DS[0]+(NM[0]-DS[0])*gm,dg=DS[1]+(NM[1]-DS[1])*gm,db=DS[2]+(NM[2]-DS[2])*gm;const fade=Math.min(1,(az-.84)/.03);const t=dk*fade;r+=(dr-r)*t;g2+=(dg-g2)*t;b+=(db-b)*t}}}
  else{/* the cue ball: red practice dots on all six poles show every roll and every bit of side spin */
   let dm=0;if(az>.93){const q=lx*lx+ly*ly;if(q<.026)dm=Math.min(1,(.026-q)/.006)}
   else{const ax=lx<0?-lx:lx,ay=ly<0?-ly:ly;if(ax>.95){const q=ly*ly+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}else if(ay>.95){const q=lx*lx+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}}
   if(dm>0){r+=(210-r)*dm;g2+=(48-g2)*dm;b+=(52-b)*dm}}
  const f=P.dif[j],sp=P.spe[j]*255*sk,o=P.idx[j]*4,bo=P.bou[j]*38,wn=P.win[j]*255*wk;
  let rr=r*f+sp+wn,gg=g2*f+sp+wn+bo,bb=b*f+sp+wn+bo*.4;d[o]=rr>255?255:rr;d[o+1]=gg>255?255:gg;d[o+2]=bb>255?255:bb;d[o+3]=P.al[j]*255}
 P.ax.putImageData(P.img,slot*P.D,0)}
function pzbBlit(g,slot,cx,cy,s){const D=PZ_BS.D,w=s||D;g.drawImage(PZ_BS.atlas,slot*D,0,D,D,cx-w/2,cy-w/2,w,w)}
/* a soft ball shadow: lamp at (lx,ly) in stage px; the shadow slides away from it */
function pzbShadow(g,x,y,lx,ly,k,a){const dx=x-lx,dy=y-ly,d=Math.hypot(dx,dy)||1,off=Math.min(9,3+d*.012),sx=x+dx/d*off*.7+2,sy=y+dy/d*off*.5+6.5;g.globalAlpha=a==null?.9:a;
 const w=(k||1)*38;g.drawImage(PZ_BS.shadow,sx-w*.5,sy-w*.34,w,w*.66);g.globalAlpha=1}
/* orientation helpers */
const pzbI=()=>[1,0,0,0,1,0,0,0,1];
function pzbRot(M,ax,ay,az,ang){const c=Math.cos(ang),s=Math.sin(ang),t=1-c;
 const R0=t*ax*ax+c,R1=t*ax*ay-s*az,R2=t*ax*az+s*ay,R3=t*ax*ay+s*az,R4=t*ay*ay+c,R5=t*ay*az-s*ax,R6=t*ax*az-s*ay,R7=t*ay*az+s*ax,R8=t*az*az+c;
 return [R0*M[0]+R1*M[3]+R2*M[6],R0*M[1]+R1*M[4]+R2*M[7],R0*M[2]+R1*M[5]+R2*M[8],R3*M[0]+R4*M[3]+R5*M[6],R3*M[1]+R4*M[4]+R5*M[7],R3*M[2]+R4*M[5]+R5*M[8],R6*M[0]+R7*M[3]+R8*M[6],R6*M[1]+R7*M[4]+R8*M[7],R6*M[2]+R7*M[5]+R8*M[8]]}
/* rolling: the surface moves at roll velocity (ux,uy); the ball turns about the axis (-uy,ux,0) by |u| dt / R. Side spin turns it about z. */
function pzbRoll(b,dt){const R=PZ_PHY.R,v=Math.hypot(b.ux,b.uy);let M=b.M;let ch=false;
 if(v>.5){M=pzbRot(M,-b.uy/v,b.ux/v,0,v*dt/R);ch=true}
 if(b.es&&Math.abs(b.es)>1){M=pzbRot(M,0,0,1,Math.max(-.25,Math.min(.25,b.es*dt/R*.45)));ch=true}
 if(ch){b.M=M;b.dirty=1;if((b.rc=(b.rc||0)+1)>48){b.rc=0;pzbOrtho(b)}}return ch}
/* re-orthonormalise (Gram-Schmidt) so many small rotations do not drift */
function pzbOrtho(b){const M=b.M;let x0=M[0],x1=M[1],x2=M[2],l=Math.hypot(x0,x1,x2)||1;x0/=l;x1/=l;x2/=l;let d=M[3]*x0+M[4]*x1+M[5]*x2,y0=M[3]-d*x0,y1=M[4]-d*x1,y2=M[5]-d*x2;l=Math.hypot(y0,y1,y2)||1;y0/=l;y1/=l;y2/=l;
 b.M=[x0,x1,x2,y0,y1,y2,x1*y2-x2*y1,x2*y0-x0*y2,x0*y1-x1*y0]}
/* a random orientation (racks: numbers face every which way) */
function pzbRandM(rng){let M=pzbI();const a=rng()*TAU,z=rng()*2-1,r=Math.sqrt(1-z*z);return pzbRot(M,r*Math.cos(a),r*Math.sin(a),z,rng()*TAU)}
/* make sure every ball object has an orientation */
/* a fresh rack: every number is turned toward you (a spin in the picture plane and a small tilt) */
function pzbRackM(rng){let M=pzbRot(pzbI(),0,0,1,rng()*TAU);M=pzbRot(M,1,0,0,(rng()-.5)*.8);return pzbRot(M,0,1,0,(rng()-.5)*.8)}
function pzbInitBalls(B,rng){for(const b of B){b.M=pzbRackM(rng);b.dirty=1;b.rc=0}
 /* the cue ball starts with its red dot toward you */
 B[0].M=pzbRot(pzbI(),1,0,0,.35)}
/* repaint what moved (or everything after a font load / ball-set change) */
function pzbSync(B){const all=PZ_BS.dirtyAll;PZ_BS.dirtyAll=0;let n=0;for(const b of B){if(all||b.dirty){pzbPaint(b.id,b.id,b.M);b.dirty=0;n++}}return n}
/* a small icon of ball n as a data URL (HUD cards, tray labels), cached per set and size */
function pzbIcon(n,px){const key=PZ_BS.set+n+'_'+px;if(PZ_BS.icon[key])return PZ_BS.icon[key];
 const D=PZ_BS.D;if(!D)return '';const M=n===0?pzbRot(pzbI(),1,0,0,.35):pzbRot(pzbRot(pzbI(),0,1,0,.28),1,0,0,-.22);pzbPaint(15,n,M);const c=document.createElement('canvas');c.width=c.height=px*2;const x=c.getContext('2d');x.imageSmoothingQuality='high';x.drawImage(PZ_BS.atlas,15*D,0,D,D,0,0,px*2,px*2);
 PZ_BS.dirtyAll=1;return PZ_BS.icon[key]=c.toDataURL('image/png')}
