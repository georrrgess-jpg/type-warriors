/* ===== RUNESTONE TOWER DEFENSE 9.2: a gentler endless Wonderland (95o, after 95n) =====
   The owner wants strong players to reach waves 60-70. Up to wave 15 nothing changes (it still plays like Ember Crown). After wave
   15 monster hit points used to compound by 5% a wave (bosses 3%) and the monster count by 5% a wave; now RPE.hp / RPE.boss / RPE.n,
   with a softer climb (RPE.soft) after wave RPE.w2. Tuned with the bot (see HANDOFF 9.2). */
const RPE={hp:1.02,boss:1.012,n:.015,w2:50,soft:1.014};
const rpEndK=(w,boss)=>{if(w<=15)return 1;const a=Math.min(w,RPE.w2)-15,b=Math.max(0,w-RPE.w2);return Math.pow(boss?RPE.boss:RPE.hp,a)*Math.pow(boss?RPE.boss:RPE.soft,b)};
{const h0=rpHpK;rpHpK=function(map,w,boss){if(!map||!map.endless||w<=15)return h0.apply(this,arguments);/* the base curve, without the old compounding */
  const k=map.hpk*(1+.12*(w-1)+.007*(w-1)*(w-1))*(1+(map.late||0)*(boss?.25:1)*rpRamp(map,w));return k*rpEndK(w,boss)}}
{const w0=rpWave;rpWave=function(map,w){const W=w0.apply(this,arguments);if(!map||!map.endless||w<=15)return W;const ex=w-15,f=(1+ex*RPE.n)/(1+ex*.05);
  return W.map(g=>g.id==='behemoth'?g:Object.assign({},g,{n:Math.max(2,Math.round(g.n*f))}))}}
/* Ember Crown: the 9.2 pads keep every tower off the road edge and out of the lava, so they sit a little farther from the road than
   before and cover slightly less of it. The bot that used to win map 3 three times in four then lost it at the wave-10 boss every time.
   A bigger starting supply (380 -> 440) gives the first towers back; with it the bot wins four in four. Monster stats are untouched, so
   the Wonderland (which copies Ember's monsters for its first 15 waves) and the championship do not change. */
RP_MAP('ember').start=440;
