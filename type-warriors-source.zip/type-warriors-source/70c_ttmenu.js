/* ---------- Trick-or-Treat landing: the redesigned menu ----------
   A top bar, a painted hero scene (it takes on the colours of the street you pick), a street picker panel,
   and a row of event rewards. Everything is drawn with the game's own Halloween art. */
let TVSEL=0;
const TV_DESC=['Pumpkins, lanterns & autumn leaves','Witches, spellbooks & enchanted mist','Vampires, velvet capes & crimson skies'];
const TV_KIND=[['porch','jackpot','porch','haunted','porch'],['witch','haunted','witch','porch','witch'],['jackpot','horse','jackpot','haunted','horse']];
function tvCrescent(g,x,y,r,col){g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();g.fillStyle=col;g.beginPath();g.arc(x,y,r,0,TAU);g.arc(x+r*.46,y-r*.12,r*.86,0,TAU);g.fill('evenodd');g.restore();glow(g,x,y,r*2.6,col+'22')}
function tvBunting(g,x1,y1,x2,y2,sag,n,cols,t){g.strokeStyle='#1a1226';g.lineWidth=2;g.beginPath();for(let i=0;i<=24;i++){const u=i/24,x=x1+(x2-x1)*u,y=y1+(y2-y1)*u+Math.sin(u*Math.PI)*sag;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();
 for(let i=1;i<n;i++){const u=i/n,x=x1+(x2-x1)*u,y=y1+(y2-y1)*u+Math.sin(u*Math.PI)*sag,sw=Math.sin(t*1.6+i)*1.6;poly(g,[x-9,y,x+9,y,x+sw,y+22],cols[i%cols.length])}}
function tvLights(g,x1,y1,x2,y2,sag,n,t){const cs=['#ffb04a','#ff7ab0','#9ce9c4','#ffe07a'];g.strokeStyle='#120c1c';g.lineWidth=2;g.beginPath();for(let i=0;i<=30;i++){const u=i/30,x=x1+(x2-x1)*u,y=y1+(y2-y1)*u+Math.sin(u*Math.PI)*sag;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();
 for(let i=1;i<n;i++){const u=i/n,x=x1+(x2-x1)*u,y=y1+(y2-y1)*u+Math.sin(u*Math.PI)*sag+8,f=.6+.4*Math.sin(t*3+i*1.7),c=cs[i%4];glow(g,x,y,22*f,c+'55');ell(g,x,y,4,5.5,c)}}
function tvHeroPaint(g,c,t){
 const w=c.width,h=c.height,st=TT_STREETS[TVSEL],kinds=TV_KIND[TVSEL],motion=!matchMedia('(prefers-reduced-motion: reduce)').matches;t=motion?t:0;
 const gy=h-70,doorX=w*.47,doorW=96,doorH=176;g.clearRect(0,0,w,h);
 g.fillStyle=vgr(g,0,h,st.sky,'#0a0714');g.fillRect(0,0,w,h);
 glow(g,w*.34,90,300,st.c+'22');glow(g,w*.7,170,340,'#ffae4618');
 for(let i=0;i<80;i++){const a=.35+.65*Math.abs(Math.sin(t*1.3+i*2.1));g.globalAlpha=a;ell(g,(i*181+23)%w,6+(i*61)%250,i%9?1:1.7,i%9?1:1.7,'#fff3d0')}g.globalAlpha=1;
 tvCrescent(g,w*.335,92,34,'#ffd98a');tvCrescent(g,w*.1,232,20,'#ffe2a8');
 /* far street, hazed */
 for(let j=0;j<7;j++)ttThemedHouse(g,40+j*200,gy-8,.62+(j%3)*.07,j,t,st.c,kinds[(j+1)%5]);
 g.fillStyle=vgr(g,gy-260,gy,'#0a071400','#0a0714d0');g.fillRect(0,gy-260,w,270);
 /* the doorstep house */
 glow(g,doorX,gy-90,340,'#ffa83c'+hwA(.2+.04*Math.sin(t*5)));
 ttThemedHouse(g,doorX,gy,2.05,2,t,st.c,kinds[0]);
 ttDoor(g,doorX-doorW/2,gy-doorH,doorW,doorH,1,t,'gyjack',true);
 tvBunting(g,doorX-150,gy-doorH-34,doorX+150,gy-doorH-34,16,9,['#ff8a2a','#fff1d0','#ff5a8a','#9ce9c4'],t);
 /* iron lantern post with a lit jack-o'-lantern */
 {const px=doorX-190;g.strokeStyle='#150d1c';g.lineWidth=6;g.beginPath();g.moveTo(px,gy);g.lineTo(px,gy-290);g.quadraticCurveTo(px,gy-318,px+34,gy-318);g.stroke();g.lineWidth=3;g.beginPath();g.moveTo(px+34,gy-318);g.lineTo(px+34,gy-296);g.stroke();
  glow(g,px+34,gy-268,86,'#ffae4666');hwPumpkin(g,px+34,gy-270,19,t)}
 tvLights(g,w*.36,-8,w*.66,-8,92,13,t);tvLights(g,-10,120,w*.27,96,46,9,t);
 /* ground, cobbled path, fence */
 g.fillStyle=vgr(g,gy-16,h,'#2b1d3c','#0c0716');g.fillRect(0,gy-16,w,h-gy+16);
 for(let r=0;r<4;r++){const y=gy+10+r*17,half=140+r*120,sz=24+r*10;for(let x=doorX-half;x<doorX+half;x+=sz*1.5){const o=(r%2)*sz*.7;ell(g,x+o,y,sz*.62,6+r*1.5,'#46335c');ell(g,x+o,y-1.5,sz*.5,4+r,'#5a4574')}}
 g.fillStyle='#120b1c';for(let x=6;x<330;x+=26){g.fillRect(x,gy-58,12,64);poly(g,[x-1,gy-58,x+6,gy-74,x+13,gy-58],'#120b1c')}g.fillRect(0,gy-44,340,6);g.fillRect(0,gy-22,340,6);
 /* the trick-or-treater, holding a pumpkin pail */
 g.save();g.translate(doorX-doorW/2-128,gy+16);g.fillStyle='#00000066';g.beginPath();g.ellipse(0,2,64,13,0,0,TAU);g.fill();g.scale(1.95,1.95);const bob=Math.sin(t*2)*.8;g.translate(0,bob);
 try{drawHero(g,{arm:P.armor,wp:null,col:P.col,t,lg:0,walk:false})}catch(e){}ttBucket(g,31,-28,t,false);g.restore();
 /* pumpkins and drifting fireflies */
 hwPumpkin(g,doorX+236,gy+30,38,t);hwPumpkin(g,doorX+176,gy+40,24,t+1);hwPumpkin(g,34,gy+44,28,t+2);hwPumpkin(g,doorX-42,gy+52,20,t+3);
 for(let i=0;i<16;i++){const u=(t*.05+i/16)%1,x=(i*173)%w+Math.sin(t*.9+i)*26,y=h-30-u*h*.62;g.globalAlpha=Math.sin(u*Math.PI)*.8;ell(g,x,y,2,2,i%2?'#ffd070':'#ffb04a')}g.globalAlpha=1;
 g.fillStyle=hgr(g,0,w,'#0a071488','#0a071400');g.fillRect(0,0,w*.5,h);g.fillStyle=vgr(g,h-90,h,'#00000000','#000000aa');g.fillRect(0,h-90,w,90)}
function tvThumb(g,c,i){const w=c.width,h=c.height,st=TT_STREETS[i],k=TV_KIND[i],gy=h-12;g.fillStyle=vgr(g,0,h,st.sky,'#0a0714');g.fillRect(0,0,w,h);glow(g,w*.72,26,70,st.c+'33');
 for(let n=0;n<26;n++)ell(g,(n*67+11)%w,3+(n*29)%(h*.5),.9,.9,'#fff3d0');tvCrescent(g,w*.8,24,12,'#ffd98a');
 ttThemedHouse(g,w*.2,gy,.34,0,1.2,st.c,k[1]);ttThemedHouse(g,w*.82,gy,.36,3,1.2,st.c,k[3]);ttThemedHouse(g,w*.52,gy+2,.5,2,1.2,st.c,k[0]);
 g.fillStyle='#120a1c';g.fillRect(0,gy,w,h-gy);hwPumpkin(g,w*.3,gy+3,8,1);hwPumpkin(g,w*.7,gy+4,7,2)}
function tvRewardArt(g,c,kind,t){const w=c.width,h=c.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 if(kind==='crate'){g.setTransform(w/200,0,0,h/160,0,0);glow(g,100,92,70,'#ff9a3a44');chest(g,100,146,1.05,0,'h',t);return}
 const id=kind==='fang'?'hw_fang':'hw_scythe',tc=c._tc||(c._tc=document.createElement('canvas'));tc.width=w;tc.height=h;art(tc,'w',id,t);const k=.96;g.drawImage(tc,w*(1-k)/2,h*.02,w*k,h*k)}
function tvStallArt(g,c,t){const w=c.width,h=c.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);g.setTransform(w/200,0,0,h/160,0,0);
 glow(g,100,86,90,'#ffb04a33');g.fillStyle='#2a1a10';g.fillRect(34,34,7,110);g.fillRect(159,34,7,110);
 g.save();g.beginPath();g.moveTo(24,34);g.lineTo(176,34);g.lineTo(176,62);for(let i=0;i<8;i++)g.arc(176-9.5-i*19,62,9.5,0,Math.PI);g.closePath();g.clip();for(let i=0;i<8;i++){g.fillStyle=i%2?'#f1e2c0':'#e8762a';g.fillRect(24+i*19,30,20,40)}g.restore();
 g.fillStyle='#4a2c18';g.fillRect(26,112,148,36);g.fillStyle='#6a4228';g.fillRect(22,108,156,8);
 for(const [x,s] of [[56,1],[92,.8],[148,1]]){g.save();g.translate(x,108);g.scale(s,s);g.fillStyle='#ffffff1c';g.strokeStyle='#e8f4ffaa';g.lineWidth=1.6;g.beginPath();g.roundRect(-13,-36,26,36,5);g.fill();g.stroke();for(let i=0;i<8;i++){g.save();g.translate(-7+(i%3)*7,-5-Math.floor(i/3)*10);g.rotate(Math.sin(i*5)*.6);poly(g,[-3,4,3,4,0,-5],'#f2a43a');poly(g,[-2.4,0,2.4,0,3,4,-3,4],'#ff7a22');poly(g,[-1.2,-2.4,1.2,-2.4,0,-5],'#fff6dc');g.restore()}g.fillStyle='#4a2c18';g.fillRect(-14,-41,28,6);g.restore()}
 hwPumpkin(g,122,106,12,t)}
const TV_ICON={snd:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9.5v5h3.6L12 18.5v-13L7.6 9.5z" fill="currentColor"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/></svg>',
 mute:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9.5v5h3.6L12 18.5v-13L7.6 9.5z" fill="currentColor"/><path d="M16 9.5l5 5M21 9.5l-5 5"/></svg>',
 fs:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
 back:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
 home:'<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11l9-7.5 9 7.5M5.5 9.5V20h13V9.5M10 20v-6h4v6"/></svg>',
 help:'<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M9.2 9.4a2.9 2.9 0 1 1 4.3 2.5c-.9.5-1.5 1.1-1.5 2.1M12 17.3v.2"/></svg>',
 arrow:'<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
 check:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>'};
function tvHow(){
 if($('tvhow'))return;const m=document.createElement('div');m.id='tvhow';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','How to play Trick-or-Treat');
 m.innerHTML=`<div class="tvhb"><h3>How to play</h3><ol><li>${ttIcon('door')}<div><b>Choose a door</b><small>Every stop offers two doorsteps. Pick the house you want to visit.</small></div></li><li>${ttIcon('clock')}<div><b>Type when the light glows</b><small>Type the glowing words before the timer runs out. Clean words earn bonus time.</small></div></li><li>${ttCorn()}<div><b>Collect your treats</b><small>Candy corn is yours to keep, even if the route ends early.</small></div></li></ol><p>11 doorsteps &bull; Three missed houses end the route &bull; Escape pauses</p><button class="tvhx" id="tvhx">Got it</button></div>`;
 document.body.appendChild(m);const close=()=>{document.removeEventListener('keydown',ek,true);m.remove()};
 const ek=e=>{if(!$('tvhow')){document.removeEventListener('keydown',ek,true);return}if(e.key==='Escape'||e.key==='Enter'){e.preventDefault();e.stopPropagation();close()}};
 document.addEventListener('keydown',ek,true);$('tvhx').onclick=close;m.addEventListener('pointerdown',e=>{if(e.target===m)close()});setTimeout(()=>$('tvhx')&&$('tvhx').focus(),30)}
function ttMenu(){ttNormalize();S.mode='title';S.view='menu';TRT.run=null;
 const saved=P.treatData.active,goal=P.treatData.target,on=hwOn()&&ttWritable();if(saved)TVSEL=ttInt(saved.street,2);else if(!(TVSEL>=0&&TVSEL<3))TVSEL=0;
 const items=[{k:'crate',n:'Graveyard Crate',d:'One Halloween relic',p:TT_PRICE.crate},{k:'fang',id:'hw_fang',n:WP.hw_fang.n,d:WP.hw_fang.r+' · exclusive weapon',p:TT_PRICE.fang},{k:'soul',id:'hw_scythe',n:WP.hw_scythe.n,d:WP.hw_scythe.r+' · ultimate scythe',p:TT_PRICE.soul}];
 const tile=it=>{const owned=it.id&&P.own[it.id],can=!owned&&on&&P.candyCorn>=it.p,isGoal=it.id&&goal===it.k,pc=Math.min(100,P.candyCorn/it.p*100),col=it.id?RC[WP[it.id].r]:'#ff9a3a';
  return `<button class="tvtile${can?' can':''}${owned?' own':''}${isGoal?' goal':''}" data-tvr="${it.k}" style="--tc:${col}"><canvas id="tvra-${it.k}" width="240" height="190" aria-hidden="true"></canvas><div><b>${esc(it.n)}</b><small>${esc(it.d)}</small>${owned?`<span class="tvown">${TV_ICON.check} Owned</span>`:`<span class="tvpr">${ttCorn()} ${it.p.toLocaleString()}</span>`}${!owned&&it.id?`<i class="tvbar" title="${Math.floor(pc)}% there"><u style="width:${pc}%"></u></i>`:''}</div>${can?'<em>Ready</em>':isGoal?'<em class="g">★ Saving</em>':''}</button>`};
 const streets=TT_STREETS.map((q,i)=>`<button class="tvstreet${TVSEL===i?' on':''}" role="radio" aria-checked="${TVSEL===i}" data-tvs="${i}" style="--sc:${q.c}"><canvas id="tvth${i}" width="260" height="170" aria-hidden="true"></canvas><div><b>${q.n}</b><small>${TV_DESC[i]}</small></div><i class="tvck">${TV_ICON.check}</i></button>`).join('');
 const panel=saved?`<h3>Your saved adventure</h3><p>${TT_STREETS[saved.street].n} &bull; ${saved.stop===10?'at the mansion':'door '+(saved.stop+1)+' of 11'} &bull; ${saved.bag} candy collected</p><div class="tvsaved"><canvas id="tvth${ttInt(saved.street,2)}s" width="260" height="170" aria-hidden="true"></canvas></div><button class="tvgo" id="ttresume">${ttCorn()}<span>${saved.phase==='done'?'View your results':'Continue your night'}</span>${TV_ICON.arrow}</button>`
  :`<h3>Your next adventure</h3><p>Choose a street to trick-or-treat.</p><div class="tvstreets" role="radiogroup" aria-label="Street">${streets}</div><button class="tvgo" id="tvgo" ${on?'':'disabled'}>${ttCorn()}<span>${on?'Start adventure':'Event closed'}</span>${TV_ICON.arrow}</button>`;
 show(`<section class="ttroot tvroot"><header class="tvtop"><button class="tvback" id="ttback">${TV_ICON.back}<span>Back</span></button><span class="tvev">${ttIcon('pumpkin')}<b>HALLOWEEN &bull; ${hwOn()?esc(hwLeft()):'EVENT CLOSED'}</b></span><span class="tvsp"></span><span class="tvwal">${ttCorn()}<b>${P.candyCorn.toLocaleString()}</b><span>candy corn</span></span><button class="tvic" id="tvsnd" aria-label="Toggle music"></button><button class="tvic" id="tvfs" aria-label="Toggle fullscreen" title="Fullscreen">${TV_ICON.fs}</button></header>
<div class="tvmain"><canvas id="ttscene" width="1300" height="580" aria-label="A knight in a night street, trick-or-treating at a decorated doorstep"></canvas><div class="tvhero"><div class="tvkick"><span>TYPE WARRIORS</span><em class="hwlt s">LIMITED TIME</em></div><h2>Trick-or-Treat</h2><p>Knock on doors, type the glowing words, and collect sweet rewards!</p><div class="tvstats"><span><b>${P.treatData.completed}</b> routes</span><span><b>${P.treatData.houses}</b> houses</span><span>Best haul <b>${P.treatData.best}</b></span><button class="tvmash" id="ttmash">Monster Mash</button></div></div>
<aside class="tvpanel">${panel}<div class="tvfoot"><span>${TV_ICON.home}11 houses &bull; Keep every candy reward</span><button id="tvhowb">${TV_ICON.help}How to play</button></div></aside></div>
<div class="tvrew"><div class="tvrl"><h4>Event Rewards</h4><p>Collect candy to unlock exclusive rewards!</p></div>${items.map(tile).join('')}<button class="tvtile tvstall" id="ttshop"><canvas id="tvra-stall" width="240" height="190" aria-hidden="true"></canvas><div><b>Candy Stall</b><small>Spend candy on cosmetics</small></div><span class="tvarr">${TV_ICON.arrow}</span></button></div></section>`,'m');
 S.back=title;$('ttback').onclick=title;$('ttmash').onclick=()=>gyMenu(ttMenu);$('tvhowb').onclick=tvHow;
 const snd=()=>{$('tvsnd').innerHTML=ST.mute?TV_ICON.mute:TV_ICON.snd;$('tvsnd').setAttribute('aria-pressed',ST.mute?'false':'true')};snd();
 $('tvsnd').onclick=()=>{try{$('mt').click()}catch(e){}snd()};$('tvfs').onclick=()=>{try{$('fs').click()}catch(e){}};
 $('ttshop').onclick=()=>{ensureAudio();ttShop()};ov.querySelectorAll('[data-tvr]').forEach(b=>b.onclick=()=>{ensureAudio();ttShop()});
 if($('ttresume'))$('ttresume').onclick=()=>{ensureAudio();ttResume()};
 if($('tvgo')){$('tvgo').onclick=()=>{ensureAudio();ttNewRun(TVSEL)};const pick=i=>{TVSEL=i;ov.querySelectorAll('[data-tvs]').forEach(b=>{const o=+b.dataset.tvs===i;b.classList.toggle('on',o);b.setAttribute('aria-checked',o)});try{beep(520+i*110,.05,'triangle',.3)}catch(e){}};
  ov.querySelectorAll('[data-tvs]').forEach(b=>{b.onclick=()=>pick(+b.dataset.tvs);b.onkeydown=e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'||e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();e.stopPropagation();const n=(TVSEL+(e.key==='ArrowDown'||e.key==='ArrowRight'?1:2))%3;pick(n);const nb=ov.querySelector('[data-tvs="'+n+'"]');if(nb)nb.focus()}}})}
 live('ttscene',c=>{const g=c.getContext('2d');return t=>tvHeroPaint(g,c,t)});
 for(let i=0;i<3;i++){const ids=['tvth'+i,'tvth'+i+'s'];for(const id of ids)live(id,c=>{const g=c.getContext('2d');let d=0;return t=>{if(d)return;d=1;tvThumb(g,c,i)}})}
 for(const it of items)live('tvra-'+it.k,c=>{const g=c.getContext('2d');return t=>tvRewardArt(g,c,it.k,t)});
 live('tvra-stall',c=>{const g=c.getContext('2d');return t=>tvStallArt(g,c,t)})}
{const s=document.createElement('style');s.textContent=`
.ttroot.tvroot{max-width:1320px;gap:14px;text-align:left;padding:2px 0 70px;font-family:var(--ui,'Poppins',sans-serif);margin:0 auto}
.tvtop{display:flex;align-items:center;gap:12px;min-height:54px}.tvsp{flex:1}
.tvback{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:8px;height:48px;padding:0 20px 0 16px;border-radius:14px;background:#181240;border:1.5px solid #4c3f8e;color:#f1ecff;font:600 17px var(--ui,Poppins,sans-serif)}
.tvback:hover,.tvic:hover{background:#241a5c;border-color:#7a6ad0}.tvback:focus-visible,.tvic:focus-visible,.tvgo:focus-visible,.tvstreet:focus-visible,.tvtile:focus-visible,.tvfoot button:focus-visible,.tvmash:focus-visible{outline:3px solid #fff;outline-offset:2px}
.tvev{display:flex;align-items:center;gap:10px;color:#ffc65a}.tvev .tticon{width:34px;height:34px;color:#ff9a3a}.tvev b{font:700 15px var(--ui,Poppins,sans-serif);letter-spacing:.14em}
.tvwal{display:flex;align-items:center;gap:10px;height:52px;padding:0 24px 0 18px;border-radius:99px;background:#150f35;border:2px solid #b8862c;color:#e9e2ff;font:500 18px var(--ui,Poppins,sans-serif);box-shadow:0 0 18px #ffb04a22}.tvwal b{font:700 28px var(--ui,Poppins,sans-serif);color:#fff}.tvwal .ttcorn{width:26px;height:30px}
.tvic{all:unset;box-sizing:border-box;cursor:pointer;display:grid;place-items:center;width:52px;height:52px;border-radius:14px;background:#181240;border:1.5px solid #4c3f8e;color:#f1ecff}
.tvmain{position:relative;display:grid;grid-template-columns:1fr minmax(400px,480px);gap:24px;min-height:clamp(430px,calc(100vh - 330px),600px);border-radius:24px;overflow:hidden;border:1.5px solid #3d2f70;box-shadow:0 18px 50px #000a;background:#0a0714}
.tvmain>canvas{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:18% 50%}
.tvhero{position:relative;z-index:1;display:flex;flex-direction:column;justify-content:flex-start;padding:30px 0 26px 40px;min-width:0;pointer-events:none}.tvhero>*{pointer-events:auto}
.tvkick{display:flex;align-items:center;gap:12px;margin-left:44px}.tvkick span{font:700 22px var(--ui,Poppins,sans-serif);letter-spacing:.32em;color:#b4a8ff}
.tvhero h2{margin:0;font:400 clamp(56px,6.2vw,104px)/.95 'Pirata One',Georgia,serif;color:#ffc92e;text-shadow:0 4px 0 #8a4a06,0 6px 0 #4a2403,0 0 26px #ffae3c88;letter-spacing:.01em}
.tvhero p{margin:14px 0 0;max-width:470px;font:400 clamp(18px,1.6vw,24px)/1.3 Georgia,serif;color:#f6ecff;text-shadow:0 2px 8px #000}
.tvstats{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:auto;padding-top:18px}.tvstats span{padding:7px 14px;border-radius:99px;background:#0a0716cc;border:1px solid #4a3d86;color:#cfc6f2;font:500 14px var(--ui,Poppins,sans-serif)}.tvstats b{color:#ffd76a}
.tvmash{all:unset;box-sizing:border-box;cursor:pointer;height:38px;padding:0 18px;line-height:38px;border-radius:99px;background:#7a2f8f;border:1.5px solid #c58cf0;color:#fff;font:700 14px var(--ui,Poppins,sans-serif)}.tvmash:hover{background:#9a3fb4}
.tvpanel{position:relative;z-index:1;margin:16px 16px 16px 0;padding:18px 20px 14px;border-radius:20px;background:linear-gradient(180deg,#171038f0,#0e0a28f2);border:1.5px solid #4a3c86;box-shadow:0 12px 40px #000a;backdrop-filter:blur(6px);display:flex;flex-direction:column;gap:9px}
.tvpanel h3{margin:0;font:400 clamp(32px,2.6vw,42px)/1 'Pirata One',Georgia,serif;color:#ffd24a;text-shadow:0 2px 0 #5a2c04}.tvpanel>p{margin:0 0 4px;font:400 16px Georgia,serif;color:#d8cff5}
.tvstreets{display:flex;flex-direction:column;gap:11px}
.tvstreet{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:16px;height:84px;padding:6px 16px 6px 6px;border-radius:16px;background:#150f35;border:2px solid #3a2f68;transition:transform .15s,border-color .15s,background .15s;position:relative}
.tvstreet canvas{width:112px;height:70px;border-radius:11px;object-fit:cover;flex-shrink:0;border:1px solid #ffffff22}.tvstreet>div{flex:1;min-width:0}
.tvstreet b{display:block;font:400 clamp(22px,1.8vw,28px)/1.05 'Pirata One',Georgia,serif;color:#fff1d6}.tvstreet small{display:block;margin-top:2px;font:400 13px/1.25 Georgia,serif;color:#c9c0ea}
.tvck{width:30px;height:30px;border-radius:50%;border:2px solid #7a6fb0;display:grid;place-items:center;flex-shrink:0;color:transparent}
.tvstreet:hover{transform:translateX(-3px);border-color:var(--sc)}
.tvstreet.on{border-color:#ffc83a;background:linear-gradient(90deg,#3a2a18,#1d1438);box-shadow:0 0 22px #ffc83a33,inset 0 0 0 1px #ffd76a55}.tvstreet.on .tvck{background:#ffc83a;border-color:#ffc83a;color:#2a1700}
.tvgo{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:14px;height:60px;border-radius:16px;background:linear-gradient(180deg,#ffe07a,#f7b21f 55%,#eb9810);color:#2a1700;box-shadow:0 6px 0 #8a5a08,0 10px 24px #ffb04a33;margin-top:6px;transition:transform .12s,filter .12s}
.tvgo span{font:400 34px/1 'Pirata One',Georgia,serif}.tvgo .ttcorn{width:30px;height:34px}.tvgo:hover:not([disabled]){filter:brightness(1.08);transform:translateY(-2px)}.tvgo:active:not([disabled]){transform:translateY(4px);box-shadow:0 2px 0 #8a5a08}.tvgo[disabled]{filter:grayscale(.8) brightness(.7);cursor:not-allowed}
.tvsaved canvas{display:block;width:100%;height:150px;border-radius:14px;object-fit:cover;border:1px solid #ffffff22}
.tvfoot{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:6px;padding-top:12px;color:#ddd5f6;font:500 15px var(--ui,Poppins,sans-serif)}.tvfoot>span{display:flex;align-items:center;gap:10px}.tvfoot svg{color:#ffb86a}
.tvfoot button{all:unset;cursor:pointer;display:flex;align-items:center;gap:8px;padding:6px 10px;border-radius:10px;color:#e6defb;font:500 15px var(--ui,Poppins,sans-serif)}.tvfoot button:hover{background:#ffffff14}
.tvrew{display:grid;grid-template-columns:minmax(190px,.9fr) repeat(3,minmax(0,1.5fr)) minmax(0,1.5fr);gap:12px;align-items:stretch}
.tvrl{display:flex;flex-direction:column;justify-content:center;padding:14px 18px;border-radius:18px;background:#120d2f;border:1.5px solid #3a2f68}.tvrl h4{margin:0 0 4px;font:400 28px/1 'Pirata One',Georgia,serif;color:#ffb83a}.tvrl p{margin:0;font:400 14px/1.3 Georgia,serif;color:#e4dcfa;max-width:none}
.tvtile{all:unset;box-sizing:border-box;cursor:pointer;position:relative;display:flex;align-items:center;gap:12px;min-height:104px;padding:8px 12px 8px 6px;border-radius:18px;background:linear-gradient(180deg,#171040,#0f0a2a);border:1.5px solid #3a2f68;transition:transform .15s,border-color .15s,box-shadow .15s;overflow:hidden}
.tvtile canvas{width:88px;height:74px;flex-shrink:0;object-fit:contain}.tvtile>div{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.tvtile b{font:400 21px/1.05 'Pirata One',Georgia,serif;color:#fff1d6}.tvtile small{font:400 12px/1.25 Georgia,serif;color:#c9c0ea}
.tvpr,.tvown{display:flex;align-items:center;gap:8px;margin-top:4px;font:700 20px var(--ui,Poppins,sans-serif);color:#fff}.tvpr .ttcorn{width:22px;height:25px}.tvown{font-size:18px;color:#7dff9a}
.tvbar{display:block;height:5px;border-radius:9px;background:#ffffff1c;overflow:hidden;margin-top:2px}.tvbar u{display:block;height:100%;background:linear-gradient(90deg,#ff9a3a,#ffd24a);border-radius:9px}
.tvtile:hover{transform:translateY(-3px);border-color:var(--tc,#ffb83a)}.tvtile.can{border-color:#ffc83a;box-shadow:0 0 22px #ffc83a33}.tvtile.goal{border-color:#e08aff}
.tvtile em{position:absolute;bottom:9px;right:10px;font:700 11px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.1em;color:#2a1700;background:#ffc83a;padding:3px 9px;border-radius:99px;text-transform:uppercase}.tvtile em.g{background:#e08aff;color:#2a0a3a}
.tvstall{border-color:#d89a2e;background:linear-gradient(180deg,#2a1a30,#150f2c);box-shadow:0 0 20px #ffb04a22}.tvstall .tvarr{color:#ffd76a;display:flex}.tvstall b{font-size:24px}
#tvhow{position:fixed;inset:0;z-index:99990;display:flex;align-items:center;justify-content:center;background:#05030ccc;backdrop-filter:blur(3px)}
.tvhb{width:min(520px,92vw);padding:26px 28px 22px;border-radius:20px;background:linear-gradient(180deg,#1f1752,#0e0c34);border:2px solid #c8902a;box-shadow:0 24px 60px #000;animation:ccin .22s ease-out;text-align:left}
.tvhb h3{margin:0 0 14px;font:400 44px 'Pirata One',Georgia,serif;color:#ffd76a}.tvhb ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:14px}.tvhb li{display:flex;gap:14px;align-items:center}.tvhb li>svg{flex-shrink:0;width:36px;height:36px;color:#ffcf83}.tvhb li b{display:block;font:600 18px var(--ui,Poppins,sans-serif);color:#fff}.tvhb li small{display:block;font:400 16px/1.35 Georgia,serif;color:#cfc6f0}
.tvhb p{margin:16px 0 0;padding-top:12px;border-top:1px solid #ffffff22;font:500 14px var(--ui,Poppins,sans-serif);color:#b9b0dc;max-width:none}.tvhx{all:unset;cursor:pointer;display:block;margin:16px 0 0 auto;height:44px;line-height:44px;padding:0 28px;border-radius:12px;background:linear-gradient(180deg,#ffd76a,#e8a820);color:#2a1700;font:700 16px var(--ui,Poppins,sans-serif)}.tvhx:focus-visible{outline:3px solid #fff}
@media(max-width:1100px){.tvmain{grid-template-columns:1fr;min-height:0}.tvhero{padding:24px 22px 220px}.tvmain>canvas{height:340px;bottom:auto;position:relative;grid-row:1}.tvpanel{margin:0 14px 14px}.tvrew{grid-template-columns:1fr 1fr}.tvrl{grid-column:1/-1}.tvwal span:last-child{display:none}}
`;document.head.appendChild(s)}
