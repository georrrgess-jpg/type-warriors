/* ===== RUNESTONE TOWER DEFENSE 10.3: Potions, art (99i, after 99h; prefix rppt) =====
   Baked once, drawn cheaply (no shadowBlur, no ctx.filter, additive glows only as small baked sprites):
   - rpptPaint(g,k)          a potion bottle in a 100 x 100 box (chunky #12081f outline, dark indigo glass, the potion's liquid with
                             a surface and bubbles, a darker right half, a white highlight stroke, the potion's mark, its stopper)
   - rpptCv(k,px) / rpptURL(k,px)   the bottle baked at px (cached canvas / data URL for the DOM)
   - rpptIco(k,px)           <img> markup for the DOM
   - battle sprites (rpptSpr): frost ground, ice block, scorch, flame, glow; drawn by 99j
   - rpptRoom()              the Apothecary room (1600 x 900, baked once): stone wall, arched night window, shelves of bottles,
                             hanging herbs, a workbench, the cauldron on its fire; rpptRoomLive(g,t,st) draws the moving parts
                             (candle flames, the fire, bubbles and steam over the cauldron, drifting motes) on a small canvas. */
const RPPTO='#12081f';
const RPPTC=new Map();
/* ---------- the bottle ---------- */
function rpptShape(k){const P=a=>{const p=new Path2D();a(p);return p};
 const neck=(x0,x1,y0,y1)=>P(p=>p.roundRect(x0,y0,x1-x0,y1-y0,3));
 switch(k){
  case'fury':return{parts:[neck(42,58,22,40),P(p=>p.arc(50,63,27,0,TAU))],body:1,lvl:50,cx:50,cy:63,r:27,mk:[50,68]};
  case'quick':return{parts:[neck(44,56,20,36),P(p=>p.roundRect(35,32,30,60,12))],body:1,lvl:46,cx:50,cy:62,r:15,mk:[50,64]};
  case'frost':return{parts:[neck(42,58,24,40),P(p=>p.ellipse(50,65,31,26,0,0,TAU)),P(p=>p.roundRect(36,84,28,8,3))],body:1,lvl:52,cx:50,cy:65,r:30,mk:[50,68]};
  case'fire':return{parts:[P(p=>p.roundRect(41,24,18,12,3)),P(p=>p.arc(50,62,29,0,TAU))],body:1,lvl:46,cx:50,cy:62,r:29,mk:[50,66]};
  case'mend':return{parts:[neck(43,57,22,40),P(p=>{p.moveTo(50,90);p.bezierCurveTo(18,70,18,40,36,40);p.bezierCurveTo(44,40,48,44,50,50);p.bezierCurveTo(52,44,56,40,64,40);p.bezierCurveTo(82,40,82,70,50,90);p.closePath()})],body:1,lvl:52,cx:50,cy:62,r:26,mk:[50,64]};
  case'hour':return{parts:[neck(44,56,20,34),P(p=>{p.moveTo(30,32);p.lineTo(70,32);p.bezierCurveTo(72,48,58,56,54,62);p.bezierCurveTo(58,68,74,76,72,92);p.lineTo(28,92);p.bezierCurveTo(26,76,42,68,46,62);p.bezierCurveTo(42,56,28,48,30,32);p.closePath()})],body:1,lvl:44,cx:50,cy:62,r:22,mk:[50,80],hour:1};
  case'gild':return{parts:[neck(43,57,22,36),P(p=>{p.moveTo(36,36);p.lineTo(64,36);p.quadraticCurveTo(74,38,74,50);p.lineTo(74,82);p.quadraticCurveTo(74,92,64,92);p.lineTo(36,92);p.quadraticCurveTo(26,92,26,82);p.lineTo(26,50);p.quadraticCurveTo(26,38,36,36);p.closePath()})],body:1,lvl:50,cx:50,cy:64,r:24,mk:[50,68]};
  case'seer':return{parts:[neck(44,56,18,34),P(p=>{p.moveTo(50,30);p.bezierCurveTo(60,42,78,50,78,68);p.bezierCurveTo(78,84,66,93,50,93);p.bezierCurveTo(34,93,22,84,22,68);p.bezierCurveTo(22,50,40,42,50,30);p.closePath()})],body:1,lvl:54,cx:50,cy:68,r:26,mk:[50,70]}}
 return rpptShape('fury')}
const rpptHex=(c,a)=>{const n=parseInt(c.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`};
const rpptMix=(c1,c2,u)=>{const a=parseInt(c1.slice(1),16),b=parseInt(c2.slice(1),16),m=(s)=>Math.round(((a>>s)&255)*(1-u)+((b>>s)&255)*u);return '#'+((1<<24)|(m(16)<<16)|(m(8)<<8)|m(0)).toString(16).slice(1)};
/* the potion's mark on its glass */
function rpptMark(g,k,x,y,s){s=s||1;g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';const o=RPPTO;
 const sh=(p,f,w)=>{g.lineWidth=w||2.4;g.strokeStyle=o;g.stroke(p);g.fillStyle=f;g.fill(p)};
 if(k==='fury'){/* a sword */const b=new Path2D('M-3.4 6L-3.4 -9L0 -15L3.4 -9L3.4 6Z');sh(b,'#f4f6ff',2.2);g.strokeStyle='#9aa8d0';g.lineWidth=1.4;g.beginPath();g.moveTo(0,-11);g.lineTo(0,4);g.stroke();
  const gd=new Path2D();gd.roundRect(-10,5,20,5,2.5);sh(gd,'#ffd45a',2.2);const gp=new Path2D();gp.roundRect(-2.2,10,4.4,6,1.5);sh(gp,'#8a4a22',2);const pm=new Path2D();pm.arc(0,17.5,2.8,0,TAU);sh(pm,'#ffd45a',1.8)}
 else if(k==='fire'){const p=new Path2D('M0 -13C5 -7 9 -4 9 3C9 9 5 13 0 13C-5 13 -9 9 -9 3C-9 -2 -6 -4 -5 -9C-3 -5 -2 -4 -1 -3C0 -7 -1 -10 0 -13Z');sh(p,'#fff2a8');
  const q=new Path2D('M0 -2C3 1 4 3 4 6C4 9 2 10 0 10C-2 10 -4 9 -4 6C-4 3 -2 2 0 -2Z');g.fillStyle='#ff8a2a';g.fill(q)}
 else if(k==='quick'){const p=new Path2D('M3 -15L-7 2H-1L-4 15L8 -3H1L5 -15Z');sh(p,'#ffe27a')}
 else if(k==='frost'){g.strokeStyle=o;g.lineWidth=5;for(let i=0;i<3;i++){g.save();g.rotate(i*Math.PI/3);g.beginPath();g.moveTo(0,-12);g.lineTo(0,12);g.stroke();g.restore()}
  g.strokeStyle='#ffffff';g.lineWidth=2.4;for(let i=0;i<3;i++){g.save();g.rotate(i*Math.PI/3);g.beginPath();g.moveTo(0,-12);g.lineTo(0,12);g.moveTo(-4,-9);g.lineTo(0,-6);g.lineTo(4,-9);g.moveTo(-4,9);g.lineTo(0,6);g.lineTo(4,9);g.stroke();g.restore()}}
 else if(k==='mend'){const p=new Path2D('M-4 -11H4V-4H11V4H4V11H-4V4H-11V-4H-4Z');sh(p,'#ffffff')}
 else if(k==='hour'){const p=new Path2D('M0 -8L2.4 -2.4L8 0L2.4 2.4L0 8L-2.4 2.4L-8 0L-2.4 -2.4Z');sh(p,'#fff4c0',2)}
 else if(k==='gild'){const p=new Path2D();p.arc(0,0,11,0,TAU);sh(p,'#ffe9a0');g.strokeStyle='#c98a1a';g.lineWidth=2;g.beginPath();g.arc(0,0,7,0,TAU);g.stroke();
  const q=new Path2D('M0 -5L1.5 -1.5L5 0L1.5 1.5L0 5L-1.5 1.5L-5 0L-1.5 -1.5Z');g.fillStyle='#c98a1a';g.fill(q)}
 else if(k==='seer'){const p=new Path2D('M-13 0C-7 -9 7 -9 13 0C7 9 -7 9 -13 0Z');sh(p,'#f4fffd');const q=new Path2D();q.arc(0,0,5.4,0,TAU);g.lineWidth=2;g.strokeStyle=o;g.fillStyle='#16a894';g.fill(q);g.stroke(q);g.fillStyle=o;g.beginPath();g.arc(0,0,2.2,0,TAU);g.fill();g.fillStyle='#fff';g.beginPath();g.arc(-1.8,-2,1.3,0,TAU);g.fill()}
 g.restore()}
/* the stopper on top of each bottle */
function rpptCork(g,k,o){const L=(p,f,w)=>{g.lineWidth=w||3;g.strokeStyle=RPPTO;g.stroke(p);g.fillStyle=f;g.fill(p)};g.lineJoin='round';
 if(k==='fire'){/* a fuse with a spark (the spark is drawn live in battle; baked here as a glint) */
  g.lineCap='round';g.strokeStyle=RPPTO;g.lineWidth=6;g.beginPath();g.moveTo(50,25);g.quadraticCurveTo(52,14,60,11);g.stroke();g.strokeStyle='#d8b07a';g.lineWidth=2.6;g.stroke();
  if(!(o&&o.nospark)){const gl=g.createRadialGradient(61,10,0,61,10,9);gl.addColorStop(0,'#fff8c0');gl.addColorStop(.4,'#ffb04acc');gl.addColorStop(1,'#ff6a1a00');g.fillStyle=gl;g.fillRect(52,1,18,18);
   g.fillStyle='#fff';g.beginPath();g.arc(61,10,2.2,0,TAU);g.fill()}
  /* the metal collar */
  const c=new Path2D();c.roundRect(39,24,22,9,3);L(c,'#8a7aa8',2.6);g.fillStyle='#c8bce8';g.fillRect(41,26,6,2);return}
 const cols={fury:['#a8703a','#7a4a22'],quick:['#c8d4e8','#8a98b8'],frost:['#a8703a','#7a4a22'],mend:['#7ac85a','#4a8a3a'],hour:['#8a5ac8','#5a3a90'],gild:['#ffd45a','#c98a1a'],seer:['#8affea','#2ab8a4']}[k]||['#a8703a','#7a4a22'];
 if(k==='seer'){const p=new Path2D('M50 4L58 13L50 22L42 13Z');L(p,cols[0],2.8);g.fillStyle='#ffffffaa';g.beginPath();g.moveTo(47,10);g.lineTo(50,6);g.lineTo(52,9);g.fill()}
 else if(k==='gild'||k==='hour'||k==='quick'){const p=new Path2D();p.roundRect(43,13,14,10,3);L(p,cols[0],2.8);const q=new Path2D();q.arc(50,11,5.2,0,TAU);L(q,cols[0],2.6);g.fillStyle=cols[1];g.fillRect(52,15,4,6);g.fillStyle='#ffffffaa';g.fillRect(45,15,2.4,5)}
 else{const p=new Path2D();p.roundRect(42.5,11,15,15,[5,5,2,2]);L(p,cols[0],2.8);g.fillStyle=cols[1];g.fillRect(52,14,4,10);g.strokeStyle='#ffffff88';g.lineWidth=1.6;g.beginPath();g.moveTo(45.5,14);g.lineTo(45.5,22);g.stroke();
  if(k==='frost'){const f=new Path2D('M41 13Q50 7 59 13L58 16Q50 12 42 16Z');L(f,'#e8f8ff',2)}
  if(k==='mend'){const f=new Path2D('M56 12Q66 4 70 10Q64 16 56 14Z');L(f,'#8ae06a',2)}}}
function rpptPaint(g,k,o){o=o||{};const D=RPPD[k]||RPPD.fury,S=rpptShape(k),col=D.col,lt=D.c2;g.save();g.lineJoin='round';g.lineCap='round';
 /* the outline: every part stroked double width, then filled, so the parts read as one shape */
 g.strokeStyle=RPPTO;g.lineWidth=7;for(const p of S.parts)g.stroke(p);
 g.fillStyle='#2a2260';for(const p of S.parts)g.fill(p);
 const body=S.parts[S.body];
 g.save();g.clip(body);
 /* glass: dark indigo with a soft lighter top */
 let gr=g.createLinearGradient(0,20,0,95);gr.addColorStop(0,'#4a4090');gr.addColorStop(1,'#241c58');g.fillStyle=gr;g.fillRect(0,0,100,100);
 /* the liquid */
 const lv=S.lvl+(o.level||0);gr=g.createLinearGradient(20,lv,80,96);gr.addColorStop(0,rpptMix(col,'#ffffff',.25));gr.addColorStop(.55,col);gr.addColorStop(1,rpptMix(col,'#12081f',.35));
 g.fillStyle=gr;g.fillRect(0,lv,100,100-lv);
 if(S.hour){/* the hourglass: golden sand gathered in the lower bulb, a thread of it falling */g.fillStyle='#ffd45a';g.beginPath();g.ellipse(50,92,24,14,0,Math.PI,TAU);g.fill();g.fillStyle='#fff2b0';g.fillRect(49,60,2,22)}
 g.fillStyle=rpptHex('#ffffff',.35);g.beginPath();g.ellipse(50,lv,40,4.2,0,0,TAU);g.fill();g.strokeStyle=rpptHex(lt,.9);g.lineWidth=2;g.beginPath();g.ellipse(50,lv,40,4.2,0,0,Math.PI);g.stroke();
 /* the darker right half */
 g.fillStyle='rgba(18,8,31,.24)';g.beginPath();g.ellipse(S.cx+S.r*1.15,S.cy+4,S.r*.95,S.r*1.6,0,0,TAU);g.fill();
 /* bubbles */
 g.fillStyle=rpptHex('#ffffff',.55);for(const [bx,by,br] of[[42,lv+12,2.6],[56,lv+20,1.8],[46,lv+26,1.4],[60,lv+8,1.2]]){if(by<94){g.beginPath();g.arc(bx,by,br,0,TAU);g.fill()}}
 g.restore();
 /* the mark */
 rpptMark(g,k,S.mk[0],S.mk[1],k==='quick'?.9:1);
 /* highlight (upper left) */
 g.save();g.clip(body);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=4;g.beginPath();
 if(k==='quick'||k==='gild'){const x=k==='quick'?40.5:32;g.moveTo(x,48);g.lineTo(x,72)}else{g.arc(S.cx,S.cy,S.r-7,Math.PI*1.08,Math.PI*1.42)}g.stroke();
 g.fillStyle='rgba(255,255,255,.9)';g.beginPath();g.arc(k==='quick'?41:S.cx-S.r*.38,k==='quick'?78:S.cy+S.r*.05,2.2,0,TAU);g.fill();g.restore();
 /* the neck ring */
 if(k!=='fire'){const nr=new Path2D();const y=k==='seer'?31:k==='hour'||k==='quick'?31:k==='gild'?33:36;nr.roundRect(40,y,20,5,2.5);g.lineWidth=2.4;g.strokeStyle=RPPTO;g.stroke(nr);g.fillStyle='#ffd45a';g.fill(nr)}
 rpptCork(g,k,o);
 /* a sparkle */
 if(!o.plain){g.fillStyle='#ffffff';const s=new Path2D('M78 26L80 31L85 33L80 35L78 40L76 35L71 33L76 31Z');g.globalAlpha=.9;g.fill(s);g.globalAlpha=1}
 g.restore()}
function rpptCv(k,px,o){const key=k+'|'+px+'|'+(o&&o.plain?1:0)+(o&&o.nospark?1:0);let c=RPPTC.get(key);if(c)return c;c=document.createElement('canvas');c.width=c.height=px;const g=c.getContext('2d');g.scale(px/100,px/100);try{rpptPaint(g,k,o)}catch(e){console.error(e)}RPPTC.set(key,c);return c}
const RPPTU=new Map();
function rpptURL(k,px){const key=k+'|'+px;let u=RPPTU.get(key);if(u)return u;try{u=rpptCv(k,px).toDataURL()}catch(e){u=''}RPPTU.set(key,u);return u}
const rpptIco=(k,px,cls)=>`<img alt="" class="${cls||''}" src="${rpptURL(k,px||64)}" width="${px||64}" height="${px||64}" draggable="false">`;
/* the satchel (an icon for the hub button, the results and the board) */
const RPPT_SATCHEL='<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M8 11c0-5 3-8 8-8s8 3 8 8" fill="none" stroke="#12081f" stroke-width="4.4"/><path d="M8 11c0-5 3-8 8-8s8 3 8 8" fill="none" stroke="#c98a4a" stroke-width="2"/><path d="M4 12h24l-2 15c-.3 2-2 3-4 3H10c-2 0-3.7-1-4-3z" fill="#a8683a" stroke="#12081f" stroke-width="2.4" stroke-linejoin="round"/><path d="M4 12h24l-1 6H5z" fill="#c88a4a" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><circle cx="16" cy="18" r="3" fill="#ffd45a" stroke="#12081f" stroke-width="1.8"/><path d="M8 22c2 4 4 5 8 5" stroke="#7a4a22" stroke-width="1.6" fill="none"/></svg>';
/* ---------- battle sprites (baked) ---------- */
function rpptSpr(key,w,h,fn){let c=RPPTC.get('S:'+key);if(c)return c;c=document.createElement('canvas');c.width=Math.ceil(w);c.height=Math.ceil(h);const g=c.getContext('2d');try{fn(g,w,h)}catch(e){console.error(e)}RPPTC.set('S:'+key,c);return c}
/* frost on the ground where a Frostbite Flask shattered (r = 110 px, squashed like the map's ground) */
const rpptFrostG=r=>rpptSpr('frostg'+r,r*2+40,r*RPFX.sq*2+60,(g,w,h)=>{const cx=w/2,cy=h/2+10,ry=r*RPFX.sq;
 let gr=g.createRadialGradient(cx,cy,0,cx,cy,r);gr.addColorStop(0,'rgba(232,248,255,.55)');gr.addColorStop(.7,'rgba(160,220,255,.32)');gr.addColorStop(1,'rgba(120,200,255,0)');g.save();g.translate(cx,cy);g.scale(1,RPFX.sq);g.fillStyle=gr;g.beginPath();g.arc(0,0,r,0,TAU);g.fill();g.restore();
 g.strokeStyle='rgba(232,248,255,.85)';g.lineWidth=2.5;g.setLineDash([12,9]);g.beginPath();g.ellipse(cx,cy,r*.92,ry*.92,0,0,TAU);g.stroke();g.setLineDash([]);
 /* ice crystals around the rim */
 for(let i=0;i<11;i++){const a=i/11*TAU+.3,x=cx+Math.cos(a)*r*.78,y=cy+Math.sin(a)*ry*.78,s=7+((i*37)%9);g.save();g.translate(x,y);
  const p=new Path2D(`M0 ${-s*1.6}L${s*.5} 0L0 ${s*.3}L${-s*.5} 0Z`);g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=RPPTO;g.stroke(p);g.fillStyle=i%2?'#d8f4ff':'#9fdcff';g.fill(p);g.fillStyle='#ffffffcc';g.fillRect(-1,-s*1.1,1.6,s*.8);g.restore()}});
/* an ice block over a frozen monster (w x h around its body) */
const rpptIce=()=>rpptSpr('ice',96,110,(g,w,h)=>{const p=new Path2D();p.roundRect(6,6,w-12,h-12,16);g.lineJoin='round';g.lineWidth=4;g.strokeStyle=RPPTO;g.stroke(p);
 let gr=g.createLinearGradient(0,0,w,h);gr.addColorStop(0,'rgba(232,248,255,.62)');gr.addColorStop(.5,'rgba(150,215,255,.4)');gr.addColorStop(1,'rgba(90,160,240,.5)');g.fillStyle=gr;g.fill(p);
 g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=4;g.beginPath();g.moveTo(18,24);g.lineTo(18,58);g.moveTo(26,18);g.lineTo(44,18);g.stroke();
 g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=2;g.beginPath();g.moveTo(w-24,h-30);g.lineTo(w-38,h-50);g.lineTo(w-30,h-62);g.moveTo(w-38,h-50);g.lineTo(w-52,h-46);g.stroke();
 g.fillStyle='rgba(18,8,31,.14)';g.fillRect(w*.58,10,w*.32,h-20)});
/* a scorch for the Dragonfire Bomb's burning ground */
const rpptScorch=r=>rpptSpr('scorch'+r,r*2+20,r*RPFX.sq*2+20,(g,w,h)=>{const cx=w/2,cy=h/2;g.save();g.translate(cx,cy);g.scale(1,RPFX.sq);
 let gr=g.createRadialGradient(0,0,0,0,0,r);gr.addColorStop(0,'rgba(40,10,6,.62)');gr.addColorStop(.6,'rgba(70,20,8,.42)');gr.addColorStop(1,'rgba(70,20,8,0)');g.fillStyle=gr;g.beginPath();g.arc(0,0,r,0,TAU);g.fill();
 for(let i=0;i<26;i++){const a=i*2.4,d=r*(.15+((i*53)%70)/100);g.fillStyle=i%3?'rgba(255,138,42,.85)':'rgba(255,214,120,.9)';g.beginPath();g.arc(Math.cos(a)*d,Math.sin(a)*d,1.6+(i%3),0,TAU);g.fill()}g.restore()});
/* one flame tongue (drawn several times, flickering, over a scorch) */
const rpptFlame=()=>rpptSpr('flame',40,60,(g,w,h)=>{g.lineJoin='round';const p=new Path2D('M20 4C28 16 36 24 36 38C36 50 29 57 20 57C11 57 4 50 4 38C4 30 9 25 11 18C14 24 16 26 17 27C17 18 18 10 20 4Z');
 g.lineWidth=3;g.strokeStyle=RPPTO;g.stroke(p);let gr=g.createLinearGradient(0,4,0,57);gr.addColorStop(0,'#ffd27a');gr.addColorStop(.5,'#ff8a2a');gr.addColorStop(1,'#d8401a');g.fillStyle=gr;g.fill(p);
 const q=new Path2D('M20 26C25 34 28 38 28 44C28 50 24 53 20 53C16 53 12 50 12 44C12 38 16 34 20 26Z');g.fillStyle='#fff2a8';g.fill(q)});
/* a soft round glow in a colour (additive) */
const rpptGlow=col=>rpptSpr('glow'+col,128,128,(g)=>{const gr=g.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,rpptHex(col,.75));gr.addColorStop(.4,rpptHex(col,.3));gr.addColorStop(1,rpptHex(col,0));g.fillStyle=gr;g.fillRect(0,0,128,128)});
/* the shards of a shattered bottle (one sprite per potion) */
const rpptShard=k=>rpptSpr('shard'+k,16,16,(g)=>{const p=new Path2D('M3 3L13 6L8 13Z');g.lineJoin='round';g.lineWidth=2;g.strokeStyle=RPPTO;g.stroke(p);g.fillStyle=rpptMix((RPPD[k]||RPPD.fury).col,'#ffffff',.45);g.fill(p)});
/* ---------- the Apothecary room ---------- */
const RPPTR={x:0,y:0,cx:300,cy:648,cw:600,ch:780};
function rpptRoom(){return rpptSpr('room',1600,900,(g)=>{g.lineJoin='round';g.lineCap='round';const O=RPPTO;
 const L=(p,f,w)=>{g.lineWidth=w||3;g.strokeStyle=O;g.stroke(p);if(f){g.fillStyle=f;g.fill(p)}};
 /* the wall: warm dark stone */
 let gr=g.createLinearGradient(0,0,0,900);gr.addColorStop(0,'#1d1230');gr.addColorStop(.6,'#2a1a38');gr.addColorStop(1,'#1a0f22');g.fillStyle=gr;g.fillRect(0,0,1600,900);
 let seed=7;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};
 for(let row=0;row<14;row++){const y=row*56-10,off=row%2?40:0;for(let x=-80+off;x<1640;x+=118){const w=104+rnd()*10,h=48;const p=new Path2D();p.roundRect(x+rnd()*4,y+rnd()*3,w,h,10);
   g.fillStyle=`rgba(${70+rnd()*30|0},${48+rnd()*20|0},${80+rnd()*26|0},.42)`;g.fill(p);g.lineWidth=2.4;g.strokeStyle='rgba(12,6,22,.55)';g.stroke(p);g.strokeStyle='rgba(255,220,180,.06)';g.beginPath();g.moveTo(x+10,y+6);g.lineTo(x+w-12,y+6);g.stroke()}}
 /* warm candle light pooling in the room */
 const pool=(x,y,r,c,a)=>{const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,rpptHex(c,a));q.addColorStop(1,rpptHex(c,0));g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)};
 pool(300,600,520,'#ff9a3a',.28);pool(120,280,260,'#ffb04a',.16);pool(520,330,230,'#ffb04a',.14);pool(1500,200,300,'#ffb04a',.1);
 /* the arched window: night sky, moon, stars, a mullion */
 {const x=58,y=96,w=220,h=300;const arch=new Path2D();arch.moveTo(x,y+h);arch.lineTo(x,y+w/2);arch.arc(x+w/2,y+w/2,w/2,Math.PI,0);arch.lineTo(x+w,y+h);arch.closePath();
  const fr=new Path2D();fr.moveTo(x-18,y+h+16);fr.lineTo(x-18,y+w/2);fr.arc(x+w/2,y+w/2,w/2+18,Math.PI,0);fr.lineTo(x+w+18,y+h+16);fr.closePath();L(fr,'#4a3a5a',4);
  g.fillStyle='rgba(255,255,255,.08)';g.fill(fr);
  gr=g.createLinearGradient(0,y,0,y+h);gr.addColorStop(0,'#0e1a4a');gr.addColorStop(1,'#3a2a7a');L(arch,gr,4);
  g.save();g.clip(arch);for(let i=0;i<40;i++){g.fillStyle=`rgba(255,248,232,${.4+rnd()*.6})`;g.fillRect(x+rnd()*w,y+rnd()*h*.8,1.6+rnd()*1.6,1.6+rnd()*1.6)}
  pool(x+150,y+86,90,'#fff4c0',.35);const m=new Path2D();m.arc(x+150,y+86,30,0,TAU);L(m,'#fff4d0',3);g.fillStyle='#e8dcb0';for(const [a,b,r] of[[-8,-6,6],[9,8,4],[4,-12,3]]){g.beginPath();g.arc(x+150+a,y+86+b,r,0,TAU);g.fill()}
  /* distant hills and a tower */
  const hl=new Path2D();hl.moveTo(x,y+h);hl.lineTo(x,y+h-50);hl.quadraticCurveTo(x+70,y+h-96,x+130,y+h-60);hl.quadraticCurveTo(x+180,y+h-90,x+w,y+h-66);hl.lineTo(x+w,y+h);hl.closePath();g.fillStyle='#1a1440';g.fill(hl);
  g.fillStyle='#120c30';g.fillRect(x+40,y+h-120,18,70);g.beginPath();g.moveTo(x+34,y+h-120);g.lineTo(x+49,y+h-148);g.lineTo(x+64,y+h-120);g.fill();g.fillStyle='#ffd45a';g.fillRect(x+46,y+h-108,5,7);g.restore();
  g.lineWidth=7;g.strokeStyle='#4a3a5a';g.beginPath();g.moveTo(x+w/2,y);g.lineTo(x+w/2,y+h);g.moveTo(x,y+h*.52);g.lineTo(x+w,y+h*.52);g.stroke();g.lineWidth=2.4;g.strokeStyle=O;g.stroke();
  /* the sill with a pot of herbs */
  const sl=new Path2D();sl.roundRect(x-30,y+h+8,w+60,20,6);L(sl,'#6a4a5a',3);g.fillStyle='rgba(255,255,255,.12)';g.fillRect(x-26,y+h+11,w+52,4);
  const pt=new Path2D();pt.moveTo(x+164,y+h+8);pt.lineTo(x+168,y+h-18);pt.lineTo(x+200,y+h-18);pt.lineTo(x+204,y+h+8);pt.closePath();L(pt,'#b8603a',2.6);
  for(let i=0;i<6;i++){const lf=new Path2D();const bx=x+184+(i-2.5)*5;lf.moveTo(bx,y+h-18);lf.quadraticCurveTo(bx+(i-2.5)*6,y+h-46,bx+(i-2.5)*9,y+h-56-((i*7)%10));g.lineWidth=5;g.strokeStyle=O;g.stroke(lf);g.lineWidth=3;g.strokeStyle=i%2?'#5aeb8a':'#3ab86a';g.stroke(lf)}}
 /* the shelves with bottles */
 const shelf=(x,y,w)=>{const s=new Path2D();s.roundRect(x,y,w,16,4);L(s,'#7a4a2a',3);g.fillStyle='#a8683a';g.fillRect(x+3,y+3,w-6,4);
  for(const bx of[x+18,x+w-30]){const b=new Path2D();b.moveTo(bx,y+16);b.lineTo(bx+12,y+16);b.lineTo(bx+6,y+40);b.closePath();L(b,'#5a3420',2.4)}};
 const jars=(x,y,w,n,s)=>{for(let i=0;i<n;i++){const k=RPPT_ORDER[(i*5+Math.floor(y))%8],sz=(s||46)*(.82+((i*31+Math.floor(x))%5)*.06),bx=x+48+i*(w-96)/Math.max(1,n-1)-sz/2;g.drawImage(rpptCv(k,Math.round(sz),{plain:1,nospark:1}),bx,y-sz*.92)}};
 shelf(330,210,250);jars(330,210,250,5,48);shelf(330,380,250);jars(330,380,250,4,58);
 shelf(1370,150,210);jars(1370,150,210,4,46);
 /* books and a skull on the low shelf */
 for(let i=0;i<4;i++){const b=new Path2D();b.roundRect(1380+i*16,64+(i%2)*6,14,86-(i%2)*6,3);L(b,['#7a3a5a','#3a5a8a','#5a8a3a','#8a5a2a'][i],2.4);g.fillStyle='#ffd45a';g.fillRect(1382+i*16,80,10,3)}
 /* hanging herbs from a beam */
 {const bm=new Path2D();bm.roundRect(300,52,1300,22,6);L(bm,'#5a3420',3);g.fillStyle='#7a4a2a';g.fillRect(304,56,1292,5);
  for(let i=0;i<5;i++){const x=340+i*56;g.strokeStyle=O;g.lineWidth=3;g.beginPath();g.moveTo(x,74);g.lineTo(x,96+(i%2)*14);g.stroke();
   for(let j=0;j<7;j++){const lf=new Path2D();const a=(j-3)*.32,ly=96+(i%2)*14;lf.moveTo(x,ly);lf.quadraticCurveTo(x+Math.sin(a)*14,ly+14,x+Math.sin(a)*22,ly+36+(j%3)*6);g.lineWidth=6;g.strokeStyle=O;g.stroke(lf);g.lineWidth=3.4;g.strokeStyle=['#6ab84a','#8a7ac8','#c8a04a','#5ab87a','#b86a8a'][i];g.stroke(lf)}
   const tie=new Path2D();tie.roundRect(x-6,92+(i%2)*14,12,7,3);L(tie,'#c84a3a',2)}}
 /* the floor: wooden planks */
 {gr=g.createLinearGradient(0,720,0,900);gr.addColorStop(0,'#4a2a1a');gr.addColorStop(1,'#2a160c');g.fillStyle=gr;g.fillRect(0,720,1600,180);
  g.strokeStyle='rgba(12,6,10,.6)';g.lineWidth=3;g.beginPath();g.moveTo(0,720);g.lineTo(1600,720);for(let y=752;y<900;y+=36){g.moveTo(0,y);g.lineTo(1600,y)}g.stroke();
  g.lineWidth=2;for(let y=720,r=0;y<900;y+=36,r++)for(let x=(r%2)*90;x<1600;x+=180){g.beginPath();g.moveTo(x,y);g.lineTo(x,y+36);g.stroke()}
  g.fillStyle='rgba(255,180,90,.06)';g.fillRect(0,722,1600,6);pool(300,760,360,'#ff8a2a',.22)}
 /* the workbench at the left with a mortar, a book, scrolls */
 {const tb=new Path2D();tb.roundRect(20,590,150,22,6);L(tb,'#8a5a32',3);g.fillStyle='#b8783a';g.fillRect(24,594,142,5);
  for(const lx of[32,148]){const l=new Path2D();l.roundRect(lx,610,12,110,3);L(l,'#6a3e22',2.6)}
  const bk=new Path2D();bk.moveTo(40,590);bk.lineTo(44,566);bk.lineTo(98,560);bk.lineTo(102,586);bk.closePath();L(bk,'#7a3a5a',2.6);g.fillStyle='#f4ecd8';g.beginPath();g.moveTo(48,584);g.lineTo(51,568);g.lineTo(96,563);g.lineTo(98,582);g.closePath();g.fill();
  g.strokeStyle='#8a7a6a';g.lineWidth=1.4;for(let i=0;i<4;i++){g.beginPath();g.moveTo(55,572+i*3.4);g.lineTo(92,568+i*3.4);g.stroke()}
  const mt=new Path2D();mt.moveTo(116,568);mt.quadraticCurveTo(118,592,136,592);mt.quadraticCurveTo(154,592,156,568);mt.closePath();L(mt,'#a8a0b8',2.6);g.lineWidth=7;g.strokeStyle=O;g.beginPath();g.moveTo(140,572);g.lineTo(160,546);g.stroke();g.lineWidth=4;g.strokeStyle='#c8b89a';g.stroke()}
 /* the cauldron on its fire (the liquid, fire and bubbles are live) */
 {const cx=RPPTR.cx,cy=RPPTR.cy;
  /* stones of the fire pit */
  for(let i=0;i<9;i++){const a=Math.PI*(.05+i*.11),x=cx+Math.cos(a)*150,y=cy+92+Math.sin(a)*22;const s=new Path2D();s.ellipse(x,y,22,13,0,0,TAU);L(s,i%2?'#6a6078':'#584e66',2.6)}
  /* legs */
  for(const lx of[-92,86]){const l=new Path2D();l.moveTo(cx+lx,cy+40);l.lineTo(cx+lx-6*Math.sign(lx),cy+104);l.lineTo(cx+lx+12*Math.sign(lx),cy+104);l.closePath();L(l,'#2a2440',3)}
  /* the pot */
  const pot=new Path2D();pot.moveTo(cx-136,cy-52);pot.bezierCurveTo(cx-150,cy+40,cx-90,cy+96,cx,cy+96);pot.bezierCurveTo(cx+90,cy+96,cx+150,cy+40,cx+136,cy-52);pot.closePath();
  gr=g.createLinearGradient(cx-140,0,cx+140,0);gr.addColorStop(0,'#4a4466');gr.addColorStop(.4,'#2e2a48');gr.addColorStop(1,'#16122a');L(pot,gr,4);
  g.save();g.clip(pot);g.strokeStyle='rgba(255,255,255,.22)';g.lineWidth=7;g.beginPath();g.arc(cx-30,cy-20,104,Math.PI*.62,Math.PI*.95);g.stroke();
  g.fillStyle='rgba(255,140,60,.18)';g.beginPath();g.ellipse(cx,cy+110,150,60,0,0,TAU);g.fill();g.restore();
  /* rivets and a band */
  g.lineWidth=3;g.strokeStyle=O;g.beginPath();g.moveTo(cx-142,cy-4);g.quadraticCurveTo(cx,cy+18,cx+142,cy-4);g.stroke();g.strokeStyle='#6a6488';g.lineWidth=1.6;g.stroke();
  for(let i=-3;i<=3;i++){g.fillStyle='#8a84a8';g.beginPath();g.arc(cx+i*38,cy+8-Math.abs(i)*3,3.2,0,TAU);g.fill();g.lineWidth=1.4;g.strokeStyle=O;g.stroke()}
  /* handles */
  for(const s of[-1,1]){g.lineWidth=9;g.strokeStyle=O;g.beginPath();g.arc(cx+s*146,cy-26,16,s<0?Math.PI*.5:-Math.PI*.5,s<0?Math.PI*1.5:Math.PI*.5);g.stroke();g.lineWidth=4.5;g.strokeStyle='#5a5478';g.stroke()}
  /* the rim (front lip drawn live over the liquid) */
  const rim=new Path2D();rim.ellipse(cx,cy-52,146,30,0,0,TAU);L(rim,'#3a3458',4)}
 /* a candle cluster on the floor right of the cauldron and on the shelves (flames live) */
 const candle=(x,y,h,w)=>{const c=new Path2D();c.roundRect(x-w/2,y-h,w,h,[w/2,w/2,3,3]);L(c,'#f4ecd8',2.6);g.fillStyle='#d8ccb0';g.fillRect(x+w*.12,y-h+4,w*.3,h-6);g.strokeStyle=O;g.lineWidth=2;g.beginPath();g.moveTo(x,y-h);g.lineTo(x,y-h-6);g.stroke();
  const d=new Path2D();d.moveTo(x-w/2,y-h+6);d.quadraticCurveTo(x-w/2-3,y-h+14,x-w/2+1,y-h+16);g.lineWidth=3;g.strokeStyle='#f4ecd8';g.stroke(d)};
 for(const c of RPPTR_C)candle(c[0],c[1],c[2],c[3]);
 /* a rug under the cauldron */
 {const rg=new Path2D();rg.ellipse(300,800,250,52,0,0,TAU);g.fillStyle='rgba(122,42,58,.55)';g.fill(rg);g.setLineDash([10,8]);g.lineWidth=3;g.strokeStyle='rgba(255,212,90,.45)';g.beginPath();g.ellipse(300,800,226,44,0,0,TAU);g.stroke();g.setLineDash([])}
 /* a soft vignette */
 gr=g.createRadialGradient(800,450,300,800,450,980);gr.addColorStop(0,'rgba(8,4,16,0)');gr.addColorStop(1,'rgba(8,4,16,.55)');g.fillStyle=gr;g.fillRect(0,0,1600,900)})}
/* candles: x, y (base), height, width */
const RPPTR_C=[[470,640,46,16],[500,650,30,14],[530,646,38,14],[352,210,26,12],[556,210,34,12],[1388,150,24,12],[80,590,30,13]];
/* the moving parts of the room: drawn on a canvas covering x 0..600, y 0..780 of the stage */
function rpptRoomLive(g,t,st){const cx=RPPTR.cx,cy=RPPTR.cy,col=st&&st.col||'#7aff9a',u=st&&st.u||0,rm=st&&st.rm,lite=st&&st.lite;g.clearRect(0,0,RPPTR.cw,RPPTR.ch);
 g.save();g.lineJoin='round';
 /* the fire under the pot */
 for(let i=0;i<7;i++){const x=cx-80+i*27,s=.9+.35*Math.sin(t*(7+i)+i*2)+(u>0?.35:0),fl=rpptFlame();g.save();g.translate(x,cy+108);g.scale(s*.9,s*(1+.12*Math.sin(t*11+i)));g.drawImage(fl,-20,-56);g.restore()}
 g.globalCompositeOperation='lighter';g.globalAlpha=.55+.15*Math.sin(t*5);g.drawImage(rpptGlow('#ff8a2a'),cx-130,cy+40,260,130);g.globalAlpha=1;g.globalCompositeOperation='source-over';
 /* the liquid */
 const lq=new Path2D();lq.ellipse(cx,cy-50,132,24,0,0,TAU);const base=u>0?rpptMix('#5aeb8a',col,Math.min(1,u*1.6)):col;
 let gr=g.createLinearGradient(0,cy-74,0,cy-26);gr.addColorStop(0,rpptMix(base,'#ffffff',.35));gr.addColorStop(1,rpptMix(base,'#12081f',.25));g.fillStyle=gr;g.fill(lq);
 g.save();g.clip(lq);const nb=rm?3:lite?6:10+Math.round(u*14);for(let i=0;i<nb;i++){const ph=(t*(.5+u*1.6)+i*.37)%1,x=cx-110+((i*67)%220),y=cy-46-ph*10,r=(4+(i%4)*2.4)*(1-ph*.4)*(1+u*.5);
   g.globalAlpha=1-ph;g.strokeStyle=RPPTO;g.lineWidth=2;g.fillStyle=rpptMix(base,'#ffffff',.55);g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.stroke()}g.globalAlpha=1;
  g.fillStyle='rgba(255,255,255,.28)';g.beginPath();g.ellipse(cx-40,cy-58,46,6,-.05,0,TAU);g.fill();g.restore();
 /* the front lip of the rim over the liquid */
 g.lineWidth=11;g.strokeStyle=RPPTO;g.beginPath();g.ellipse(cx,cy-52,146,30,0,.06,Math.PI-.06);g.stroke();g.lineWidth=6;g.strokeStyle='#4a4466';g.stroke();g.lineWidth=2;g.strokeStyle='rgba(255,255,255,.25)';g.beginPath();g.ellipse(cx,cy-50,146,30,0,.5,1.2);g.stroke();
 /* glow and steam */
 g.globalCompositeOperation='lighter';g.globalAlpha=.4+u*.5;g.drawImage(rpptGlow(base),cx-170,cy-150,340,180);g.globalAlpha=1;g.globalCompositeOperation='source-over';
 if(!rm){const ns=lite?3:6;for(let i=0;i<ns;i++){const ph=(t*.22+i/ns)%1,x=cx-60+i*24+Math.sin(t+i)*16,y=cy-70-ph*190,r=18+ph*30;g.globalAlpha=(1-ph)*.22;g.fillStyle='#e8e0ff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1}
 /* sparkles rising while brewing */
 if(u>0&&!rm){for(let i=0;i<10;i++){const ph=(t*1.4+i*.13)%1,x=cx-90+((i*41)%180)+Math.sin(t*3+i)*10,y=cy-60-ph*160;g.globalAlpha=1-ph;g.fillStyle=i%2?'#ffffff':rpptMix(col,'#ffffff',.4);g.save();g.translate(x,y);g.rotate(t*2+i);g.fillRect(-3,-3,6,6);g.restore()}g.globalAlpha=1}
 /* candle flames */
 for(const [x,y,h] of RPPTR_C){if(x>RPPTR.cw||y>RPPTR.ch)continue;const fy=y-h-6,s=1+.12*Math.sin(t*9+x)+(rm?0:.06*Math.sin(t*23+y));
  g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpptGlow('#ffb04a'),x-36,fy-44,72,72);g.globalCompositeOperation='source-over';g.globalAlpha=1;
  g.save();g.translate(x,fy);g.scale(.42*s,.42*s*(1+.1*Math.sin(t*13+x)));g.drawImage(rpptFlame(),-20,-56);g.restore()}
 /* drifting motes */
 if(!rm&&!lite)for(let i=0;i<9;i++){const ph=(t*.05+i*.111)%1,x=40+((i*137)%520)+Math.sin(t*.7+i)*20,y=720-ph*640;g.globalAlpha=Math.sin(ph*Math.PI)*.7;g.fillStyle='#ffd27a';g.fillRect(x,y,2.4,2.4)}
 g.globalAlpha=1;g.restore()}
