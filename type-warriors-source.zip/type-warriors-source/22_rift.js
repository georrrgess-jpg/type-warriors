/* ---------- Starfall Rift monsters, words and the training dummy ---------- */
const starPts=(r0,r1,n,rot)=>{const p=[];for(let i=0;i<n*2;i++){const a=rot+i*Math.PI/n,r=i%2?r0:r1;p.push(Math.cos(a)*r,Math.sin(a)*r)}return p};
function sparkle(g,x,y,s,a,c){g.save();g.globalAlpha=a;g.fillStyle=c||'#fff';g.fillRect(x-s*.15,y-s,s*.3,s*2);g.fillRect(x-s,y-s*.15,s*2,s*.3);g.restore()}
function wisp(g,t,o){const cy=-44+Math.sin(t*5)*5;glow(g,0,cy,78,'#8ae8ff99');
 for(let i=0;i<8;i++){const u=i/8,x=20+u*66,y=cy+Math.sin(t*9-i*.9)*6*u;g.globalAlpha=(1-u)*.75;ell(g,x,y,11*(1-u)+2,7*(1-u)+1.4,i%2?'#ffffff':'#6ad0ff')}g.globalAlpha=1;
 g.save();g.translate(0,cy);g.rotate(t*2.2);poly(g,starPts(9,24,5,0),rgr(g,0,0,1,26,'#ffffff','#5ac8ff'));g.restore();
 ell(g,0,cy,9,9,'#ffffff');eye(g,-3,cy-1,2.6,'#2a6aff');eye(g,4,cy-1,2.6,'#2a6aff');
 for(let i=0;i<4;i++)sparkle(g,Math.sin(t*3+i*1.7)*34,cy+Math.cos(t*2.6+i*2.1)*26,4,.5+.5*Math.sin(t*6+i))}
function crawler(g,t,o){const b=Math.sin(t*10)*2;glow(g,0,-34,68,'#ff9a4a66');
 for(let i=0;i<8;i++){const u=i/8,y=-32+Math.sin(t*12-i)*4*u;g.globalAlpha=(1-u)*.8;ell(g,26+u*70,y,14*(1-u)+2,9*(1-u)+2,i%2?'#ffd08a':'#ff7a3a')}g.globalAlpha=1;
 for(const [x,ph] of[[-18,0],[-6,2],[8,4],[20,1]]){const a=Math.sin(t*12+ph)*8;limb(g,x,-18,x+a,-3,4.4,'#2a1a3a');ell(g,x+a,-2.6,4.6,2.4,'#14081e')}
 g.beginPath();g.ellipse(0,-36+b,34,25,0,0,TAU);g.fillStyle=rgr(g,-10,-50,3,44,'#8a6ad0','#2a1a5a');g.fill();g.strokeStyle='#0008';g.lineWidth=1.6;g.stroke();
 for(const [x,y,r] of[[-14,-48,4],[2,-56,5],[16,-46,3.6],[-2,-40,3]]){poly(g,[x,y-r*1.6,x+r,y,x,y+r*1.6,x-r,y],'#ffd08a');}
 ell(g,-26,-36+b,13,12,vgr(g,-48,-24,'#b090f0','#4a2a8a'));eye(g,-31,-40+b,3.4,'#ffef7a');eye(g,-21,-40+b,3.4,'#ffef7a');
 poly(g,[-30,-46,-36,-58,-24,-50],'#d8c0ff')}
function prism(g,t,o){const cy=-52+Math.sin(t*3.4)*6,h=t*60;glow(g,0,cy,86,hsx(h,90,62)+'88');
 for(let i=0;i<3;i++){const a=t*1.6+i*TAU/3;const x=Math.cos(a)*38,y=cy+Math.sin(a)*14;poly(g,[x,y-8,x+6,y,x,y+8,x-6,y],hsx(h+i*80,90,68))}
 g.save();g.translate(0,cy);poly(g,[0,-34,22,0,0,34,-22,0],vgr(g,-34,34,hsx(h,80,84),hsx(h+120,80,48)),'#fff9',1.6);
 poly(g,[0,-34,0,34,-22,0],'#ffffff30');poly(g,[0,-34,22,0,0,0],hsx(h+200,90,75)+'aa');poly(g,[0,0,22,0,0,34],hsx(h+60,90,60)+'88');g.restore();
 eye(g,-6,cy-2,3.4,'#ffffff');eye(g,7,cy-2,3.4,'#ffffff');sparkle(g,-26,cy-28,6,.5+.5*Math.sin(t*7),'#fff');sparkle(g,28,cy+22,5,.5+.5*Math.sin(t*5+2),'#fff')}
function novaBomb(g,t,o){const pul=.5+.5*Math.sin(t*9),r=26+pul*4;glow(g,0,-40,86+pul*12,'#ff7ad8'+(pul>.5?'aa':'77'));
 for(const [x,ph] of[[-12,0],[12,Math.PI]]){const a=Math.sin(t*9+ph)*8;limb(g,x,-16,x+a*.5,-4,6,'#2a1040');ell(g,x+a,-3,8,3.6,'#14081e')}
 g.save();g.translate(0,-42);g.rotate(Math.sin(t*2)*.12);poly(g,starPts(r*.72,r*1.25,8,t*.8),rgr(g,-6,-6,2,r*1.3,'#ffe0f8','#b02a9a'),'#2a0a30',1.5);ell(g,0,0,r*.6,r*.6,rgr(g,-4,-4,1,r*.7,'#ffffff',pul>.5?'#ff5ad0':'#a03a90'));
 eye(g,-6,-2,3.6,'#2a0a30');eye(g,6,-2,3.6,'#2a0a30');g.restore();
 for(let i=0;i<4;i++){const u=(t*.9+i/4)%1;g.globalAlpha=1-u;ell(g,Math.sin(i*4+t)*12,-76-u*30,2.6,2.6,'#ffd0f8');g.globalAlpha=1}}
function shardling(g,t,o){const b=Math.sin(t*9)*2;glow(g,0,-30,62,'#7ad8ff66');
 for(const [x,ph] of[[-14,0],[0,2],[14,4]]){const a=Math.sin(t*10+ph)*6;poly(g,[x-3,-16,x+a,-2,x+4,-16],'#3a78c0')}
 for(const [x,h,w,c1,c2] of[[-18,34,11,'#9ae0ff','#2a7ab8'],[16,30,10,'#b8f0ff','#3a8ac8'],[0,50,15,'#e0faff','#4a9ad8']]){g.save();g.translate(x,-14+b);poly(g,[-w,0,-w*.55,-h*.75,0,-h,w*.6,-h*.72,w,0],vgr(g,-h,0,c1,c2),'#0a2a4a',1.4);poly(g,[0,-h,0,0,w,0,w*.6,-h*.72],'#ffffff26');g.restore()}
 eye(g,-5,-26+b,3.2,'#0a2a4a');eye(g,5,-26+b,3.2,'#0a2a4a');sparkle(g,18,-56,5,.5+.5*Math.sin(t*6),'#fff')}
function comet(g,t,o){const cy=-44+Math.sin(t*7)*7;glow(g,0,cy,96,'#ffd24aaa');
 for(let i=0;i<14;i++){const u=i/14,y=cy+Math.sin(t*10-i*.7)*7*u;g.globalAlpha=(1-u)*.85;ell(g,18+u*96,y,15*(1-u)+2,10*(1-u)+1.6,i%3===0?'#fff6c0':i%3===1?'#ffd24a':'#ff9a2a')}g.globalAlpha=1;
 for(let i=0;i<5;i++){const u=(t*1.4+i/5)%1;g.globalAlpha=1-u;coin(g,30+u*90,cy+Math.sin(i*3+t*4)*16,5);g.globalAlpha=1}
 g.save();g.translate(0,cy);g.rotate(t*1.6);poly(g,starPts(13,30,6,0),rgr(g,-3,-3,2,32,'#fffbe0','#e8a010'),'#7a4a0a',1.6);g.restore();
 ell(g,0,cy,12,12,rgr(g,-3,-3,1,14,'#ffffff','#ffc040'));eye(g,-4,cy-1,2.8,'#7a3a00');eye(g,4,cy-1,2.8,'#7a3a00');sparkle(g,-20,cy-22,7,.5+.5*Math.sin(t*8),'#fff')}
function dummy(g,t,o){const w=Math.sin(t*1.6)*.6+((o&&o.lg)||0)*4;
 ell(g,0,-2,28,5,'#0006');g.fillStyle=vgr(g,-96,0,'#8a6030','#4a2e14');g.fillRect(-5,-96,10,94);g.fillStyle='#6a4622';g.fillRect(-42,-74,84,9);
 g.save();g.translate(0,-88);g.rotate(w*.02);g.beginPath();g.ellipse(0,-14,17,19,0,0,TAU);g.fillStyle=rgr(g,-5,-20,2,24,'#e8cf96','#a8884a');g.fill();g.strokeStyle='#5a4220';g.lineWidth=1.6;g.stroke();
 g.strokeStyle='#5a4220';g.beginPath();g.moveTo(-14,-22);g.lineTo(14,-2);g.moveTo(14,-22);g.lineTo(-14,-2);g.globalAlpha=.25;g.stroke();g.globalAlpha=1;ell(g,-6,-16,3,3,'#2a1a0a');ell(g,7,-16,3,3,'#2a1a0a');g.beginPath();g.moveTo(-6,-7);g.quadraticCurveTo(0,-3,7,-7);g.stroke();
 for(let i=0;i<5;i++){poly(g,[-12+i*6,-30,-10+i*6,-42-(i%2)*4,-7+i*6,-30],'#d8b860')}g.restore();
 g.save();g.translate(0,-50);g.beginPath();g.moveTo(-18,-26);g.lineTo(18,-26);g.lineTo(14,22);g.lineTo(-14,22);g.closePath();g.fillStyle=vgr(g,-26,22,'#d8c080','#9a7a38');g.fill();g.strokeStyle='#5a4220';g.lineWidth=1.6;g.stroke();
 g.strokeStyle='#7a5a2a';for(let i=0;i<4;i++){g.beginPath();g.moveTo(-14,-18+i*10);g.lineTo(14,-18+i*10);g.stroke()}poly(g,[-18,-26,-34,-18,-30,-10],'#d8b860');poly(g,[18,-26,34,-18,30,-10],'#d8b860');g.restore();
 ell(g,0,-44,7,7,'#c83a3a');ell(g,0,-44,3,3,'#ffd0d0')}
Object.assign(MON,{
 wisp:{n:'Star Wisp',h:84,sp:160,th:64,fly:1,ds:'Darts across the rift on a comet tail. Short words, big speed.'},
 crawler:{n:'Comet Crawler',h:104,sp:68,th:70,tr:'charge'},
 prism:{n:'Prism Sprite',h:116,sp:96,th:84,fly:1,bonus:'time',ds:'Slay it to bank 3 extra seconds on the rift clock.'},
 agolem:{n:'Astral Golem',h:238,sp:30,th:118,tr:'shield'},
 nova:{n:'Nova Bomb',h:116,sp:50,th:84,tr:'bomb'},
 stalker:{n:'Rift Stalker',h:166,sp:58,th:98,tr:'blink'},
 shard:{n:'Shardling',h:96,sp:70,th:64,tr:'split',ds:'Shatters into two Star Wisps when slain.'},
 comet:{n:'Treasure Comet',h:100,sp:200,th:70,fly:1,bonus:'jackpot',ds:'Rare and blazing fast. Worth a huge bonus of time and score.'},
 dummy:{n:'Training Dummy',h:150,sp:40,th:110,nx:1}});
Object.assign(DR,{wisp,crawler,prism,nova:novaBomb,shard:shardling,comet,dummy,
 agolem:(g,t,o)=>{hum(g,t,{lg:o.lg,sk:'#3a3a8a',dk:'#14143a',hl:'#8a8aff',top:'#2a2a6a',hd:14,eye:'#ffffff',bulk:1.95,lw:13,reach:10,hunch:.6,legH:34,aura:'#8a9aff',pad:'#b8c0ff',padspike:1,wp:'club',wsc:1.3,belly:1});for(let i=0;i<7;i++)sparkle(g,Math.sin(i*2.3)*26-4,-70-((i*37)%70)+10,3.4,.45+.45*Math.sin(t*4+i*1.3),'#dfe6ff')},
 stalker:(g,t,o)=>{hum(g,t,{lg:o.lg,sk:'#241a48',dk:'#0a0620',eye:'#ff9aff',cl:'#0a0620',cape:'#2a1a5a',bulk:1.05,hd:13,legH:34,wp:'gsword',bl:'#d8b8ff',top:'#1a1240',pad:'#3a2a78',aura:'#c88aff',hunch:.5,walk:.8});for(let i=0;i<5;i++)sparkle(g,Math.sin(i*3.1)*20+4,-50-((i*29)%70),3,.4+.5*Math.sin(t*5+i),'#f0d8ff')}});
for(const k of['wisp','crawler','prism','agolem','nova','stalker','shard','comet','dummy'])MON[k].d=DR[k];
const RZR=[['crawler','stalker','nova'],['wisp','prism','shard'],['agolem','nova']],RIFT_IDS=['wisp','crawler','prism','agolem','nova','stalker','shard','comet'];
const RIFTW=[...new Set(`star nova orbit comet quasar pulsar galaxy nebula cosmos lunar solar eclipse meteor aurora zenith apogee void rift flux warp plasma photon proton neutron quark gravity horizon vortex cluster stellar radiant cosmic asteroid equinox solstice twilight zodiac nadir orion lyra vega sirius rigel altair polaris draco cygnus andromeda pegasus phoenix aquila hydra corona umbra penumbra transit eccentric parallax ecliptic equator axis arc beam blaze bright burst flare flash gleam glint glow halo shine spark streak shimmer twinkle dazzle ember stardust moonlit sunrise dusk dawn night midnight skyward starlit starfall starlight stargaze celestial heavens infinite ethereal radiance luminous aether spectrum prism shard crystal orbital rocket thrust launch lander probe comet module ionize fusion fission magnet tether beacon signal sector portal gateway rupture fracture tremor surge pulse wave crest tide drift glide soar dart swoop dash streaming`.split(/\s+/))].filter(w=>/^[a-z]{3,10}$/.test(w));
const PSENT=['the quick brown fox jumps','pack my box with jugs','slow and steady wins','a stitch in time','practice makes perfect','keep your eyes on the screen','type with calm and rhythm','fingers light and fast','never stop never slow','every word is a strike','the night is dark and deep','a knight rises at dawn','fortune favors the bold','steel bends but never breaks','quiet hands win the day','sharp blade and sharper mind','breathe then type again','one key at a time','speed comes from accuracy','the dragon sleeps beneath the hill','stars fall over the silent keep','hold the line at the gate','courage is a quiet word','after the storm comes light','forge your name in fire','wind over the old stone bridge','an ember glows in the dark','the last bell rings at midnight'];
