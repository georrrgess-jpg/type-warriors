/* ===== RUNESTONE TOWER DEFENSE 10.3b: the potion belt moves off the map's build pads (99k, after 99j; prefix rpptf, config RPPTFIT) =====
   Owner request: the potions and the potion bar in battle must not overlap anything or poke through other boxes.
   t_potui103.py audits the belt on all ten maps at three sizes. It found that the belt above the abilities (bottom left) and its row of
   buff chips covered build pads and towers on several maps (Coral Shallows pad 1, Cloudspire Meadows pad 1, Storm Citadel pad 3, ...)
   and touched a tower's info panel. The right-hand column above the Next Wave panel has no pad on any map (every pad's edge stays left
   of x 1290), so the belt now sits there, right-aligned with the wave panel. The chip row is gone: a drink's countdown shows on its
   own bottle instead (seconds on its face and a bar that empties; the names under the bottles live in their tooltips, so the belt sits just above the wave panel), so nothing grows above the belt. The bottle tooltips open to the
   left, the Next Wave card opens above the belt, the first-time potion tip points at the new place, the ability tip goes back to its
   own spot, and with Rune Typing on the belt rises so the potion words fit between it and the wave panel. */
const RPPTFIT={beltB:157,beltBty:157};
{const st=document.createElement('style');st.textContent=`
.rph .rpptb{left:auto;right:14px;bottom:${RPPTFIT.beltB}px;align-items:flex-end}
.rph.rptyon .rpptb{bottom:${RPPTFIT.beltBty}px}
.rph .rpptb .rpptbelt{margin-top:0}
.rph .rpptb .rppts{transform-origin:50% 100%}
.rph .rpptb .rpptch{display:none}
.rph .rppts .rptip{left:auto;right:-12px;bottom:calc(100% + 18px)}
.rph .rpptb .rppts em{display:none}
.rph .rpptb .rpptyw{top:auto;bottom:calc(100% + 4px)}
.rph .rppts .rpptlt{position:absolute;inset:0;display:grid;place-items:center;z-index:3;font:800 17px var(--ui);color:#fff8e8;text-shadow:0 2px 0 #12081f,0 0 6px #12081f;pointer-events:none}
.rph .rppts .rpptlv{position:absolute;left:11px;right:auto;width:36px;max-width:36px;bottom:5px;height:4px;border-radius:2px;background:#12081fcc;overflow:hidden;z-index:3;pointer-events:none;opacity:0;transition:opacity .2s}
.rph .rppts .rpptlv u{position:absolute;inset:0;background:var(--c);transform-origin:0 50%;text-decoration:none}
.rph .rppts.live .rpptlv{opacity:1}
.rph .rppts.live.used{border-color:var(--c)}.rph .rppts.live.used .rpptsi{opacity:.55}.rph .rppts.live.used em{color:#fff8e8;background:#2a1f6a}
#rphud.rpq.rpptOn .rpqnc{bottom:calc(100% + 96px)}
#rphud.rpq.rpptOn.rptyon .rpqnc{bottom:calc(100% + 126px)}
.rph.rpptOn .rptut.at-abil{bottom:126px}
.rph.rpptOn.rptyon .rptut.at-abil{bottom:186px}
.rph .rptut.at-pot{left:auto;right:16px;bottom:${RPPTFIT.beltB+86}px}.rph .rptut.at-pot::after{left:auto;right:100px}
.rph.rptyon .rptut.at-pot{bottom:${RPPTFIT.beltBty+86}px}
`;document.head.appendChild(st)}
/* a drink's countdown on its own bottle (the chips are hidden) */
{const t0=rpptTick;rpptTick=function(force){const r=t0.apply(this,arguments);try{const R=RPX,b=$('rpptb');if(!R||!R.pt||!b)return r;const T=R.pt;
  b.querySelectorAll('.rppts:not(.empty)').forEach(x=>{const i=+x.dataset.i,s=T.sl[i];if(!s)return;const D=RPPD[s.k],F=T.fx&&T.fx[s.k];
   const live=!!(s.used&&D&&D.kind==='drink'&&F&&F.t<F.d&&rpptAct(R,s.k));x.classList.toggle('live',live);
   let lv=x.querySelector('.rpptlv');if(live&&!lv){lv=document.createElement('i');lv.className='rpptlv';lv.innerHTML='<u></u>';x.appendChild(lv)}
   let lt=x.querySelector('.rpptlt');if(live&&!lt){lt=document.createElement('b');lt.className='rpptlt';x.appendChild(lt)}if(!live&&lt)lt.remove();
   if(live){const left=Math.max(0,F.d-F.t),txt=Math.ceil(left)+'s';if(lt.textContent!==txt)lt.textContent=txt;
    const v=(left/F.d).toFixed(2),u=lv.firstChild;if(u.dataset.v!==v){u.dataset.v=v;u.style.transform=`scaleX(${v})`}}
   })}catch(e){console.error(e)}return r}}
/* the brew button when coins are short: "Need" and the price in red (the old "Not enough coins" pushed the price off the button) */
{const st=document.createElement('style');st.textContent=`.rpptx .rpptbrew.no b{color:#ff8a96}`;document.head.appendChild(st)}
