/* ===== WILDCARD: a tiny QR code maker for Wi-Fi invites =====
   Byte mode, error correction level L, versions 1-20 (up to about 850 characters), standard mask scoring.
   wcQR(text) returns an inline <svg>. No network, no library. */
const WCQ_EC=[0,[7,1,19],[10,1,34],[15,1,55],[20,1,80],[26,1,108],[18,2,68],[20,2,78],[24,2,97],[30,2,116],[18,2,68,2,69],[20,4,81],[24,2,92,2,93],[26,4,107],[30,3,115,1,116],[22,5,87,1,88],[24,5,98,1,99],[28,1,107,5,108],[30,5,120,1,121],[28,3,113,4,114],[28,3,107,5,108]];
const WCQ_AL=[0,[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90]];
const WCQ_EXP=[],WCQ_LOG=[];{let x=1;for(let i=0;i<255;i++){WCQ_EXP[i]=x;WCQ_LOG[x]=i;x<<=1;if(x&256)x^=0x11d}for(let i=255;i<512;i++)WCQ_EXP[i]=WCQ_EXP[i-255]}
const wcqMul=(a,b)=>a&&b?WCQ_EXP[WCQ_LOG[a]+WCQ_LOG[b]]:0;
function wcqRS(data,n){let g=[1];for(let i=0;i<n;i++){const ng=new Array(g.length+1).fill(0);for(let j=0;j<g.length;j++){ng[j]^=g[j];ng[j+1]^=wcqMul(g[j],WCQ_EXP[i])}g=ng}
 const r=new Array(n).fill(0);for(const d of data){const f=d^r[0];r.shift();r.push(0);if(f)for(let j=0;j<n;j++)r[j]^=wcqMul(g[j+1],f)}return r}
function wcqBCH(v,poly,bits){let x=v<<bits;const deg=Math.floor(Math.log2(poly));while(x&&Math.floor(Math.log2(x))>=deg)x^=poly<<(Math.floor(Math.log2(x))-deg);return(v<<bits)|x}
function wcQR(text){const bytes=Array.from(new TextEncoder().encode(text));let ver=0,E;
 for(let v=1;v<=20;v++){E=WCQ_EC[v];const cap=E[1]*E[2]+(E[3]||0)*(E[4]||0),cc=v<10?8:16;if(4+cc+bytes.length*8<=cap*8){ver=v;break}}if(!ver)throw new Error('too long');
 E=WCQ_EC[ver];const cap=E[1]*E[2]+(E[3]||0)*(E[4]||0),bits=[];const put=(v,n)=>{for(let i=n-1;i>=0;i--)bits.push((v>>>i)&1)};
 put(4,4);put(bytes.length,ver<10?8:16);for(const b of bytes)put(b,8);put(0,Math.min(4,cap*8-bits.length));while(bits.length%8)bits.push(0);
 const data=[];for(let i=0;i<bits.length;i+=8)data.push(parseInt(bits.slice(i,i+8).join(''),2));for(let p=0;data.length<cap;p++)data.push(p%2?0x11:0xEC);
 const blocks=[];let o=0;for(const [nb,len] of [[E[1],E[2]],[E[3]||0,E[4]||0]])for(let k=0;k<nb;k++){const d=data.slice(o,o+len);o+=len;blocks.push({d,e:wcqRS(d,E[0])})}
 const cw=[];const mx=Math.max(...blocks.map(b=>b.d.length));for(let i=0;i<mx;i++)for(const b of blocks)if(i<b.d.length)cw.push(b.d[i]);for(let i=0;i<E[0];i++)for(const b of blocks)cw.push(b.e[i]);
 const N=17+ver*4,M=[],F=[];for(let i=0;i<N;i++){M.push(new Array(N).fill(0));F.push(new Array(N).fill(0))}
 const set=(r,c,v)=>{M[r][c]=v?1:0;F[r][c]=1};
 const finder=(r,c)=>{for(let i=-1;i<=7;i++)for(let j=-1;j<=7;j++){const y=r+i,x=c+j;if(y<0||x<0||y>=N||x>=N)continue;const on=i>=0&&i<=6&&j>=0&&j<=6&&(i===0||i===6||j===0||j===6||(i>=2&&i<=4&&j>=2&&j<=4));set(y,x,on)}};
 finder(0,0);finder(0,N-7);finder(N-7,0);for(let i=8;i<N-8;i++){set(6,i,i%2===0);set(i,6,i%2===0)}
 const al=WCQ_AL[ver],last=al.length-1;al.forEach((r,ii)=>al.forEach((c,jj)=>{if((ii===0&&jj===0)||(ii===0&&jj===last)||(ii===last&&jj===0))return;for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++)set(r+i,c+j,Math.max(Math.abs(i),Math.abs(j))!==1)}));
 set(N-8,8,1);for(let i=0;i<9;i++){F[8][i]=1;F[i][8]=1}for(let i=0;i<8;i++){F[8][N-1-i]=1;F[N-1-i][8]=1}
 if(ver>=7)for(let i=0;i<6;i++)for(let j=0;j<3;j++){F[i][N-11+j]=1;F[N-11+j][i]=1}
 const all=[];for(const b of cw)for(let i=7;i>=0;i--)all.push((b>>i)&1);let bi=0;
 for(let c=N-1,up=true;c>0;c-=2,up=!up){if(c===6)c--;for(let k=0;k<N;k++){const r=up?N-1-k:k;for(const x of[c,c-1])if(!F[r][x]){M[r][x]=all[bi++]||0}}}
 const MK=[(r,c)=>(r+c)%2===0,(r)=>r%2===0,(r,c)=>c%3===0,(r,c)=>(r+c)%3===0,(r,c)=>(Math.floor(r/2)+Math.floor(c/3))%2===0,(r,c)=>r*c%2+r*c%3===0,(r,c)=>(r*c%2+r*c%3)%2===0,(r,c)=>((r+c)%2+r*c%3)%2===0];
 const build=m=>{const Q=M.map(r=>r.slice());for(let r=0;r<N;r++)for(let c=0;c<N;c++)if(!F[r][c]&&MK[m](r,c))Q[r][c]^=1;
  const fmt=wcqBCH((1<<3)|m,0x537,10)^0x5412,fb=i=>(fmt>>i)&1;
  for(let i=0;i<=5;i++)Q[i][8]=fb(i);Q[7][8]=fb(6);Q[8][8]=fb(7);Q[8][7]=fb(8);for(let i=9;i<15;i++)Q[8][14-i]=fb(i);
  for(let i=0;i<8;i++)Q[8][N-1-i]=fb(i);for(let i=8;i<15;i++)Q[N-15+i][8]=fb(i);Q[N-8][8]=1;
  if(ver>=7){const vi=wcqBCH(ver,0x1F25,12);for(let i=0;i<18;i++){const b=(vi>>i)&1,a=Math.floor(i/3),c2=i%3;Q[a][N-11+c2]=b;Q[N-11+c2][a]=b}}return Q};
 const score=Q=>{let s=0;for(let r=0;r<N;r++){let run=1;for(let c=1;c<N;c++){if(Q[r][c]===Q[r][c-1]){run++;if(run===5)s+=3;else if(run>5)s++}else run=1}}
  for(let c=0;c<N;c++){let run=1;for(let r=1;r<N;r++){if(Q[r][c]===Q[r-1][c]){run++;if(run===5)s+=3;else if(run>5)s++}else run=1}}
  for(let r=0;r<N-1;r++)for(let c=0;c<N-1;c++){const v=Q[r][c];if(v===Q[r][c+1]&&v===Q[r+1][c]&&v===Q[r+1][c+1])s+=3}
  let dark=0;for(const row of Q)for(const v of row)dark+=v;s+=Math.floor(Math.abs(dark*100/(N*N)-50)/5)*10;return s};
 let best=null,bs=1e9;for(let m=0;m<8;m++){const Q=build(m),sc=score(Q);if(sc<bs){bs=sc;best=Q}}
 let p='';for(let r=0;r<N;r++)for(let c=0;c<N;c++)if(best[r][c])p+=`M${c+4} ${r+4}h1v1h-1z`;
 return `<svg viewBox="0 0 ${N+8} ${N+8}" shape-rendering="crispEdges" aria-label="QR code for the invite"><rect width="${N+8}" height="${N+8}" fill="#fff"/><path d="${p}" fill="#12081f"/></svg>`}
