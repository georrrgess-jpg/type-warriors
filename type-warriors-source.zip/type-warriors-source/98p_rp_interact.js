/* ===== RUNESTONE TOWER DEFENSE 10.1: tower and monster interactions (98p, last; overrides only, prefix rpia) =====
   An audit of every tower against every tower and every monster ability, on the old and the new maps (t_ia101.py). Fixes:
   1. Armor: the Alchemist's Still melts armor by lowering e.armor, but 98b rewrites e.armor from e.arm0 for its abilities, so a soak was
      wiped at once on a Barnacle Brute (shedding shell, every step), dropped a Shellback's +12 while it hid in its shell (and its melt
      when it came out), and was lost on a Titan's plate shed. Now armor is one formula every step and on every soak / dry:
      ability armor (base, shell bonus, shed by health) minus the melt while soaked (rpiaArmor).
   2. Hidden monsters (a diving Leviathan, a leaping Springjack, a glimmering Jellyglide: e.hide) are out of play for every tower, the
      same rule rpTarget, the Hive and the Engine already used: during each tower's fire routine they are veiled from all targeting
      (Prism beams, Dragon breath and dive, Mortar, Still and Tidecaller aims, Bell chains, Frost pulses, Starfall picks), a Still flask or
      Mortar shell landing on one neither soaks, slows, stuns nor turns it to gold, a falling star neither hurts, marks nor finishes it,
      a Tidecaller wave does not shove it, and nothing executes it (rpKillFoe refuses a hidden monster that still has health).
   3. Fog (Shipwreck Cove): the towers with their own aim (Prism, Mortar, Still, Tidecaller, Dragon, Starfall) now follow the rule the
      others follow: a monster inside a fog bank can only be picked by a tower within map.fogNear px of it.
   4. Glowcaps (Kraken's Maw): +15% range now reaches the Frost Spire, Prism, Dragon, Mortar, Still and Tidecaller too (before only
      the Ballista, Brazier, Bell, Hive and Engine), and the selected tower's range ring shows it.
   5. Jams: a jammed Prism drops its beams (they stayed drawn on their target), a jammed tower's charge glow fades (a Dragon's breath
      dies out: its fire glow stayed lit), a Dragon jammed during its wing dive finishes the dive instead of hanging in mid-air, and
      Overcharge's "busiest tower" pick skips jammed towers while another tower is free.
   6. A venting Steam Golem is slow-immune to the Slow Field ability too (it already shrugged off every tower's slow).
   7. Split children (Ooze -> Oozelets) never start behind the road's start (they were placed up to 22 px back into the cave).
   8. A Leviathan stays up at least RPIA.surf s between two dives (damage taken before a dive could chain two or three dives back to
      back: up to 7.5 s out of reach at 1.6x speed).
   9. Monster abilities follow the monster: the World 2/3 casts keep their abilities if they appear on a World 1 map (DEV, tests).
  10. How to Play named the Singularity Engine's old price (650; it costs 600).
  11. A Tidecaller sweep that fatigue (95q) has shrunk below RPIA.minKnock px no longer shoves: in a gravity well it only made the
      monster stutter (a stun frame and a twitch back every wave). It still hurts, soaks and tires it.
  12. Rising Tide (Coral Shallows): the flood drains between waves (it stayed up through the whole build phase), see below.
   RPIA.off = 1 switches the per-tower wrapper off (the test's frame-cost baseline). Test: t_ia101.py. */
const RPIA={surf:1.2,minKnock:10,glowT:{frost:1,prism:1,dragon:1,mortar:1,still:1,tide:1},fogT:{prism:1,mortar:1,still:1,tide:1,dragon:1,star:1}};
/* ---------- 1. armor: ability armor minus the Still's melt ---------- */
function rpiaArmor(e){if(!e||e.dead||e.arm0==null)return;const F=RP_FOE[e.id]||{};let a=e.arm0;
 if(F.shed)a=Math.round(e.arm0*Math.max(0,e.hp/e.mx));else if(F.shellT&&e.shIn>0)a=e.arm0+F.shellA;
 if(e.acid>0&&e.melt>0)a-=e.melt;e.armor=Math.max(0,a)}
const rpiaArmK=F=>!!F&&!!(F.shed||F.shellT||F.shedAt||F.puffAt);
{const s0=rplSoak;rplSoak=function(e){const r=s0.apply(this,arguments);if(e&&!e.dead&&!e.air)rpiaArmor(e);return r}}
{const d0=rplDry;rplDry=function(e){const r=d0.apply(this,arguments);if(e&&rpiaArmK(RP_FOE[e.id]))rpiaArmor(e);return r}}
/* ---------- 9 + 8 + 1 + 2 + 6: around the core's ability step (98b rpwPre) ---------- */
const RPIA_AB=(()=>{const o={};for(const id in RP_FOE){const F=RP_FOE[id];if(F&&(F.scut||F.shellT||F.puffAt||F.glimT||F.shed||F.songT||F.inkAt||F.dive||F.guardR||F.ventAt||F.hasteR||F.leapT||F.empR||F.stompT))o[id]=1}return o})();
{const p0=rpwPre;rpwPre=function(R,dt){const run=R.wst==='run',T=R.tide,tk=T?T.k:0;
 /* 12: Rising Tide. 98b recomputes the flood level from the cycle clock every step and takes dt off it between waves, so the water
    stayed up (k ~ 0.97) through the whole build phase and the next wave began mid-flood. Between waves it now drains for real, and a
    wave that starts while the cycle is flooded starts at the ebb: the clock goes back to the start of that rise (the water rises
    smoothly again) or, if it was already falling, on to its end. The cycle length is unchanged. */
 if(T&&R.map.tide&&run&&R._iaRun===false){const m=R.map,c=T.t%m.tideT,hi=m.tideHi,rp=RPWK.tideRamp,f=c<rp?c/rp:c<hi?1:c<hi+rp?1-(c-hi)/rp:0;
  if(f>T.k+.05)T.t+=c<hi?-c:hi+rp-c}R._iaRun=run;
 /* 8: a surfaced Leviathan cannot dive again for RPIA.surf s */
 const held=[];for(const e of R.foes){if(e.dead||!e.dvI&&e.dvI!==0)continue;if(e._iaSf>0){e._iaSf-=dt;if(!(e.dive>0)){held.push([e,e.dvI]);e.dvI=1e9}}e._iaDv=e.dive>0}
 const r=p0.apply(this,arguments);
 for(const [e,i] of held)if(e.dvI===1e9)e.dvI=i;
 for(const e of R.foes)if(e._iaDv&&!(e.dive>0)){e._iaDv=false;e._iaSf=RPIA.surf}
 const H=[],sk=1-RPT.AB.slow.k;
 for(const e of R.foes){if(e.dead)continue;if(e.hide&&e.s>=0)H.push(e);
  /* 1 */ if(e.acid>0||rpiaArmK(RP_FOE[e.id]))rpiaArmor(e);
  /* 6: the Slow Field would set the venting golem's pace to (1 - k) in the engine: make up for it */
  let f=1;if(e.vent>0&&!e.air&&R.fields.length&&!(e.stun>0)){const p=rpPos(R,e);if(R.fields.some(z=>rpD2(p.x,p.y,z.x,z.y)<z.r*z.r))f=1/sk}
  const o=e._iaV||1;if(o!==f){e.sp=e.sp/o*f;e._iaV=f}}
 if(T&&!run){T.k=Math.max(0,tk-dt);T.high=T.k>.5}
 R._iaH=H;return r}}
{const s0=rpStep;rpStep=function(R,dt){if(R&&R.map&&!(R.map.world>1)&&R.foes&&R.foes.some(e=>!e.dead&&RPIA_AB[e.id])){R.inks=R.inks||[];R.emps=R.emps||[];R.bolts=R.bolts||[];try{rpwPre(R,dt)}catch(e){console.error(e)}}
 return s0.apply(this,arguments)}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){const r=b0.apply(this,arguments);if(R&&R.map&&!(R.map.world>1)&&(R.inks&&R.inks.length||R.emps&&R.emps.length))try{rpwFx(c,R)}catch(e){}return r}}
/* ---------- 2 + 3: the veil (hidden monsters, and fogged ones out of a tower's sight, read as not on the road: s < 0) ---------- */
function rpiaVeil(R,tw,fog,fn){let L=null;const H=R._iaH;
 if(H&&H.length)for(const e of H)if(!e.dead&&e.hide&&e.s>=0)(L||(L=[])).push(e);
 const fn2=fog&&tw&&R.fog&&R.map&&R.map.fogNear;
 if(fn2)for(const e of R.foes){if(e.dead||e.s<0||!e.fogd||e.hide)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)>fn2*fn2)(L||(L=[])).push(e)}
 if(!L)return fn();for(const e of L){e._iaS=e.s;e.s=-1}try{return fn()}finally{for(const e of L)e.s=e._iaS}}
{const f0=rpFire;rpFire=function(R,tw,dt){const t=this,a=arguments;if(RPIA.off)return f0.apply(t,a);/* RPIA.off: the tests' frame-cost baseline */
 /* 5: a jammed tower: no beams, the charge fades */
 if(tw.jam>0){if(tw.beams&&tw.beams.length)tw.beams=[];if(tw.charge>0)tw.charge=Math.max(0,tw.charge-dt*3);
  /* a Dragon's breath (or its wind-up) dies out instead of glowing on through the jam */
  if(tw.type==='dragon'&&(tw.st==='breath'||tw.st==='wind')){tw.st='idle';tw.br=0;tw.streams=null;tw.sa=tw.sa2=null;tw.fire=0;tw.cd=Math.max(tw.cd||0,.4)}
  /* a Dragon already out on its wing dive finishes it (it froze in mid-air for the whole jam) */
  if(tw.type==='dragon'&&tw.dive)try{rpiaVeil(R,tw,false,()=>rpDragonDive(R,tw,RP_TW.dragon,tw.tier-1,dt))}catch(e){console.error(e)}
  return f0.apply(t,a)}
 /* 4: the Glowcap range for the towers that read their range straight from RP_TW */
 const T=RP_TW[tw.type],gi=tw.tier-1,gk=tw.glowK>1&&RPIA.glowT[tw.type]&&T&&T.range?tw.glowK:0,g0=gk?T.range[gi]:0;
 if(gk)T.range[gi]=g0*gk;
 try{return rpiaVeil(R,tw,!!RPIA.fogT[tw.type],()=>f0.apply(t,a))}finally{if(gk)T.range[gi]=g0}}}
/* landings, puddles and craters skip hidden monsters (no soak, slow, stun or gold); stars do not hurt, mark or finish them */
{const s0=rplStep;rplStep=function(R,dt){const t=this,a=arguments;return rpiaVeil(R,null,false,()=>s0.apply(t,a))}}
{const s0=rpqStep;rpqStep=function(R,dt){const t=this,a=arguments;return rpiaVeil(R,null,false,()=>s0.apply(t,a))}}
{const s0=rpsfStrike;rpsfStrike=function(R,e){if(e&&!e.dead&&e.hide)return false;return s0.apply(this,arguments)}}
{const k0=rptKnock;rptKnock=function(e,d){if(e&&e.hide)return;
 /* 11: a sweep tired down to a few px (95q fatigue) only made the monster stutter (a stun frame and a twitch back): it still tires it */
 if(e&&!e.dead&&d<RPIA.minKnock&&!(e.kb>0)){e.tdF=(e.tdF||0)+1;return}return k0.apply(this,arguments)}}
{const k0=rpKillFoe;rpKillFoe=function(e,src){if(e&&!e.dead&&e.hide&&e.hp>0&&!e.leak)return;
 /* 7: split children start on the road, never back in the cave */
 const R=RPX,n0=R&&R.foes?R.foes.length:0;const r=k0.apply(this,arguments);
 try{if(R&&R.foes.length>n0&&RP_FOE[e.id]&&RP_FOE[e.id].split)for(let j=n0;j<R.foes.length;j++){const c=R.foes[j];if(c.id===RP_FOE[e.id].split&&c.s<0&&e.s>=0){c.s=0;c._s=-1}}}catch(x){}
 return r}}
/* ---------- 5: Overcharge's busiest-tower pick skips jammed towers when another one is free ---------- */
{const b0=rpBusiest;rpBusiest=function(){const R=RPX;const tw=b0.apply(this,arguments);if(!tw||!(tw.jam>0)||!R)return tw;
 const J=R.pads.map(p=>p.tw).filter(t=>t&&t.build>=1&&t.jam>0);if(J.length>=R.pads.filter(p=>p.tw&&p.tw.build>=1).length)return tw;
 for(const t of J)t.build=.999;try{return b0.apply(this,arguments)||tw}finally{for(const t of J)t.build=1}}}
/* ---------- 4: the selected tower's range ring includes its Glowcap bonus ---------- */
{const d0=rpDraw;rpDraw=function(){const R=RPX,s=R&&R.sel;if(!s||!(s.glowK>1)||!RP_TW[s.type]||!RP_TW[s.type].range)return d0.apply(this,arguments);
 const T=RP_TW[s.type],i=s.tier-1,r0=T.range[i],k=s.glowK;T.range[i]=r0*k;s.glowK=1;try{return d0.apply(this,arguments)}finally{T.range[i]=r0;s.glowK=k}}}
/* ---------- 10: How to Play ---------- */
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{for(const p of ov.querySelectorAll('#rpmod .rphw p'))if(/Singularity Engine\./.test(p.textContent)&&p.innerHTML.includes('(650 supply'))p.innerHTML=p.innerHTML.replace('(650 supply','(600 supply')}catch(e){}return r}}
