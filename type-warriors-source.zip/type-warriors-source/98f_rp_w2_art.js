/* ===== RUNESTONE TOWER DEFENSE 10.0: World 2 art - Tidebreak Isles (98f; 98f2 holds the other two maps and the world painting) =====
   The three maps of World 2 fill the art registries of 98a (RPW.bake / amb / ambTop / twist / castleHit / icon / world; wired at the end
   of 98f2):
   - coral Coral Shallows (here): a tropical beach island. Grass and palms inland, a beach along a turquoise reef sea (coral seen through
     the water, foam lines), a sand road with shell curbs, tide pools, starfish, shells, a lighthouse on the rocky point, a hammock, a sea
     cave where the road starts and the Seashell Palace (conch spires, a scallop crest, pearls). Wet tide flats where map.tide floods.
     Live: waves rolling onto every shore, glints, a sea turtle and fish, gull shadows, the lighthouse beam; RPW.twist: the flood water
     spreading over the tide flats with R.tide.k; RPW.ambTop: the gulls.
   - wreck Shipwreck Cove and abyss Kraken's Maw: 98f2.
   How it is built: the ground is painted once per pixel from a water field (rpw2aField: about a signed distance in px, > 0 in the water,
   cut back from the roads and the pads), then the props, the road (it follows rpGeo(map).paths sample for sample, like rpBake), the caves
   and the castle are drawn on top; pads are never baked and props keep out of every pad's tower box (rpw2aPadHit). The castles
   (rpw2aCastle: coral, wreck, abyss) are 300 x 520 like 95h's and reuse its wall, drum, window, banner and gate painters with their own
   roofs; rpw2aCastleLive / rpw2aCastleHit are their live layer and flinch. The live layers only blit cached sprites and draw short batched
   paths, and draw less when R.lite or R.rm. No shadowBlur, no ctx.filter, no screen / soft-light blends. */
const RPW2A={c:{},s:{}};/* caches: castles and the world painting (c), sprites (s) */
const rpw2aR=i=>{const x=Math.sin(i*91.373+17.31)*43758.5453;return x-Math.floor(x)};
const rpw2aH=(i,j)=>{const x=Math.sin(i*127.1+j*311.7)*43758.5453;return x-Math.floor(x)};
const rpw2aIH=(x,y)=>{let h=Math.imul(x,374761393)+Math.imul(y,668265263)|0;h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967296};/* a cheap integer hash for per-pixel grain */
function rpw2aCv(w,h){const c=document.createElement('canvas');c.width=Math.max(1,Math.ceil(w));c.height=Math.max(1,Math.ceil(h));return c}
/* value noise and a three-octave fbm (0..1) */
function rpw2aVN(x,y){const i=Math.floor(x),j=Math.floor(y),u=x-i,v=y-j,su=u*u*(3-2*u),sv=v*v*(3-2*v),a=rpw2aH(i,j),b=rpw2aH(i+1,j),c=rpw2aH(i,j+1),d=rpw2aH(i+1,j+1);return a+(b-a)*su+(c-a)*sv+(a-b-c+d)*su*sv}
const rpw2aFbm=(x,y,s)=>rpw2aVN(x/110+s,y/110)*.55+rpw2aVN(x/44,y/44+s)*.3+rpw2aVN(x/17+s*2,y/17)*.15;
/* smooth min / max (k = blend width in px) */
const rpw2aSmin=(a,b,k)=>{const h=Math.max(0,Math.min(1,.5+.5*(b-a)/k));return b*(1-h)+a*h-k*h*(1-h)};
const rpw2aSmax=(a,b,k)=>-rpw2aSmin(-a,-b,k);
const rpw2aEll=(x,y,cx,cy,rx,ry)=>(1-Math.hypot((x-cx)/rx,(y-cy)/ry))*Math.min(rx,ry);/* ~ signed distance, > 0 inside */
const rpw2aCol=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];
const rpw2aSS=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)};
/* a value on an 8 px grid over the stage, read back with bilinear filtering */
function rpw2aGrid(fn){const st=8,W=202,H=115,a=new Float32Array(W*H);for(let j=0;j<H;j++)for(let i=0;i<W;i++)a[j*W+i]=fn(i*st,j*st);
 return{a,W,H,at(x,y){const fx=Math.max(0,Math.min(W-1.001,x/st)),fy=Math.max(0,Math.min(H-1.001,y/st)),i=fx|0,j=fy|0,u=fx-i,v=fy-j,k=j*W+i;return a[k]*(1-u)*(1-v)+a[k+1]*u*(1-v)+a[k+W]*(1-u)*v+a[k+W+1]*u*v}}}
/* the distance to the nearest road on the 8 px grid, stamped from the road samples (capped at 240 px) */
function rpw2aRoadGrid(G){if(G._w2aD)return G._w2aD;const D=rpw2aGrid(()=>240),a=D.a,W=D.W,H=D.H,R=30;
 for(const P of G.paths)for(let s=0;s<P.S.length;s+=2){const q=P.S[s],ci=Math.round(q.x/8),cj=Math.round(q.y/8);
  for(let j=Math.max(0,cj-R);j<=Math.min(H-1,cj+R);j++){const dy=j*8-q.y,dy2=dy*dy;for(let i=Math.max(0,ci-R);i<=Math.min(W-1,ci+R);i++){const dx=i*8-q.x,d=dx*dx+dy2,k=j*W+i;if(d<a[k]*a[k])a[k]=Math.sqrt(d)}}}
 return G._w2aD=D}
/* the water field of a map: sea(x,y) is the designed sea (> 0 inside), cut back from the roads (clear) and the pads (padR) */
function rpw2aField(map,G,sea,o){o=o||{};const clr=o.clear||64,pr=o.padR||74,k=o.k||22,pads=G.pads;
 const D=rpw2aRoadGrid(G);
 const F=rpw2aGrid((x,y)=>{let f=sea(x,y);const cl=typeof clr==='function'?clr(x,y):clr;f=rpw2aSmin(f,D.at(x,y)-cl,k);
  let pd=1e9;for(const p of pads){const d=Math.hypot(p.x-x,(p.y+6-y)*1.25);if(d<pd)pd=d}f=rpw2aSmin(f,pd-pr,k);if(o.extra)f=o.extra(x,y,f);return f});
 return{D,F}}
/* the shore line: points on f = 0 every ~step px with the normal pointing into the water */
function rpw2aShore(F,step,keep){const P=[],st=8;for(let j=1;j<F.H-1;j++)for(let i=1;i<F.W-1;i++){const k=j*F.W+i,a=F.a[k],b=F.a[k+1],c=F.a[k+F.W];
  for(const [v,dx,dy] of[[b,1,0],[c,0,1]]){if((a>0)===(v>0))continue;const u=a/(a-v),x=(i+dx*u)*st,y=(j+dy*u)*st;if(keep&&!keep(x,y))continue;
   if(P.some(p=>Math.abs(p.x-x)<step&&Math.abs(p.y-y)<step))continue;const gx=F.at(x+4,y)-F.at(x-4,y),gy=F.at(x,y+4)-F.at(x,y-4),m=Math.hypot(gx,gy)||1;P.push({x,y,nx:gx/m,ny:gy/m,i:P.length})}}
 return P}
/* paint the ground once per pixel: px(f, n, m, x, y, o, w) writes the land / sea-floor colour into o[0..2] and, for water, a surface
   colour with alpha into w[0..3]; f, n, m are read from the grids F, N, M (bilinear). Returns {base, surf, mask} (surf and mask only when
   water: true). rpw2aM3 mixes colours into an array without allocating. */
const rpw2aM3=(o,a,b,t)=>{o[0]=a[0]+(b[0]-a[0])*t;o[1]=a[1]+(b[1]-a[1])*t;o[2]=a[2]+(b[2]-a[2])*t;return o};
function rpw2aPaint(F,N,M,px,water){const W=1600,H=900,cb=rpw2aCv(W,H),gb=cb.getContext('2d'),ib=gb.createImageData(W,H),db=ib.data,o=[0,0,0],w=[0,0,0,0];
 let cs,cm,is,imk,ds,dm;if(water){cs=rpw2aCv(W,H);cm=rpw2aCv(W,H);is=cs.getContext('2d').createImageData(W,H);imk=cm.getContext('2d').createImageData(W,H);ds=is.data;dm=imk.data}
 const GW=F.W,fa=F.a,na=N.a,ma=M?M.a:null;
 for(let y=0;y<H;y++){const fy=y/8,j=fy|0,v=fy-j,r0=j*GW,r1=r0+GW;
  for(let x=0;x<W;x++){const fx=x/8,i=fx|0,u=fx-i,k0=r0+i,k1=r1+i,a=(1-u)*(1-v),b=u*(1-v),c=(1-u)*v,d=u*v;
   const f=fa[k0]*a+fa[k0+1]*b+fa[k1]*c+fa[k1+1]*d,n=na[k0]*a+na[k0+1]*b+na[k1]*c+na[k1+1]*d,m=ma?ma[k0]*a+ma[k0+1]*b+ma[k1]*c+ma[k1+1]*d:0,p=(y*W+x)*4;w[3]=0;px(f,n,m,x,y,o,w);
   db[p]=o[0];db[p+1]=o[1];db[p+2]=o[2];db[p+3]=255;if(water){if(w[3]>0){ds[p]=w[0];ds[p+1]=w[1];ds[p+2]=w[2];ds[p+3]=w[3]}if(f>-1)dm[p+3]=f>1?255:(f+1)*127.5}}}
 gb.putImageData(ib,0,0);if(water){cs.getContext('2d').putImageData(is,0,0);cm.getContext('2d').putImageData(imk,0,0)}return{base:cb,surf:cs,mask:cm}}
/* draw fn on a scratch layer and keep only the part inside (or outside) the mask, then put it on g */
function rpw2aMasked(g,mask,fn,out){const c=rpw2aCv(1600,900),h=c.getContext('2d');h.lineJoin='round';h.lineCap='round';fn(h);h.globalCompositeOperation=out?'destination-out':'destination-in';h.drawImage(mask,0,0);g.drawImage(c,0,0)}
const rpw2aOut=(g,w)=>{g.strokeStyle=RPO;g.lineWidth=w||2.4;g.stroke()};
const rpw2aBlob=(g,x,y,rx,ry,col,a)=>{g.globalAlpha=a==null?1:a;g.fillStyle=col;g.beginPath();g.ellipse(x,y,rx,ry,0,0,TAU);g.fill();g.globalAlpha=1};
/* the roads, sample for sample like rpBake: shadow, edge, curb and fill strokes for every road first, then texture, curb stones and
   chevrons. o: {edge, curb, fill, fill2, tex(g,P,i,p), stone(g,x,y,a,i,sd), chev, chevW, w (fill width, default 60)} */
function rpw2aRoad(g,G,o){const each=f=>{for(const P of G.paths)f(P)},w=o.w||60;
 const stroke=(P,lw,col)=>{const S=P.S;g.beginPath();g.moveTo(S[0].x,S[0].y);for(let i=1;i<S.length;i++)g.lineTo(S[i].x,S[i].y);g.lineWidth=lw;g.strokeStyle=col;g.stroke()};
 each(P=>stroke(P,w+28,'rgba(0,0,0,.25)'));each(P=>stroke(P,w+18,o.edge));each(P=>stroke(P,w+12,o.curb));each(P=>stroke(P,w,o.fill));
 if(o.fill2)each(P=>stroke(P,w*.62,o.fill2));
 if(o.tex)each(P=>{const S=P.S;for(let i=0;i<S.length;i+=o.texStep||3)if(P.own[i])o.tex(g,P,i,S[i])});
 if(o.stone)each(P=>{const S=P.S;for(let i=0;i<S.length;i+=o.stStep||5){if(!P.own[i])continue;for(const sd of[-1,1]){const p=S[i],x=p.x-Math.sin(p.a)*(w/2+5)*sd,y=p.y+Math.cos(p.a)*(w/2+5)*sd;if(G.dRoad(x,y)<w/2)continue;o.stone(g,x,y,p.a,i,sd)}}});
 if(o.chev){g.strokeStyle=o.chev;g.lineWidth=o.chevW||4;each(P=>{const S=P.S;for(let i=40;i<S.length-30;i+=34){if(!P.own[i])continue;const p=S[i];g.save();g.translate(p.x,p.y);g.rotate(p.a);g.beginPath();g.moveTo(-6,-9);g.lineTo(4,0);g.lineTo(-6,9);g.stroke();g.restore()}})}}
/* a cached soft glow sprite (rgb string, radius) drawn with 'lighter' */
const rpw2aGl=(rgb,r)=>rpwGlow(rgb,r);
/* a sprite baked once: key, size, painter(g) */
function rpw2aSpr(key,w,h,fn){let s=RPW2A.s[key];if(s)return s;s=rpw2aCv(w,h);const g=s.getContext('2d');g.lineJoin='round';g.lineCap='round';fn(g,w,h);return RPW2A.s[key]=s}
/* placement helper: a free spot for a prop away from roads, pads, the castle box, the caves and a list of taken discs. o.w / o.h: the
   prop's box (x +- w/2, y - h .. y) must also stay clear of every pad's tower box (pad x +- 48, y - 116 .. y + 28) */
const rpw2aPadHit=(G,x0,y0,x1,y1)=>G.pads.some(p=>x1>p.x-48&&x0<p.x+48&&y1>p.y-116&&y0<p.y+28);
function rpw2aFree(G,B,x,y,o){if(rpw2aRoadGrid(G).at(x,y)<(o.road||66))return false;if(G.pads.some(p=>Math.hypot(p.x-x,(p.y-y)*1.3)<(o.pad||84)))return false;
 if(o.h&&rpw2aPadHit(G,x-(o.w||o.h)/2,y-o.h,x+(o.w||o.h)/2,y+4))return false;
 const c=B.cast;if(c&&x>c.x-(o.cast||20)&&y>c.y+40&&y<c.y+c.h+30)return false;if(G.ent.some(e=>Math.hypot(e.x-x,e.y-y)<(o.ent||120)))return false;
 if(o.taken&&o.taken.some(t=>Math.hypot(t[0]-x,t[1]-y)<t[2]))return false;return true}
/* ---------- beach and reef props (x, y = the foot of the prop) ---------- */
/* a palm: a curved ringed trunk leaning by lean, a crown of jagged fronds and coconuts */
function rpw2aPalm(g,x,y,h,i,o){o=o||{};const lean=o.lean!=null?o.lean:(rpw2aR(i)-.5)*.9,C=o.cols||['#3fae4a','#2e8a3e','#58c452'],hi=o.hi||'#9cf07a',tr=o.trunk||['#b8844e','#8a5a32'];
 g.save();g.translate(x,y);rpw2aBlob(g,h*.16,3,h*.42,h*.12,'#000',.22);
 const tx=lean*h*.55,ty=-h,c1x=lean*h*.05,c1y=-h*.55;
 const tp=u=>({x:2*(1-u)*u*c1x+u*u*tx,y:2*(1-u)*u*c1y+u*u*ty});
 /* trunk: a tapering band */
 const L=[],Rr=[];for(let k=0;k<=12;k++){const u=k/12,p=tp(u),q=tp(Math.min(1,u+.02)),a=Math.atan2(q.y-p.y,q.x-p.x),w=h*(.075-.03*u);L.push([p.x+Math.sin(a)*w,p.y-Math.cos(a)*w]);Rr.push([p.x-Math.sin(a)*w,p.y+Math.cos(a)*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let k=Rr.length-1;k>=0;k--)g.lineTo(Rr[k][0],Rr[k][1]);g.closePath();
 let q=g.createLinearGradient(-h*.08,0,h*.08,0);q.addColorStop(0,tr[0]);q.addColorStop(1,tr[1]);g.fillStyle=q;g.fill();rpw2aOut(g,2.4);
 g.strokeStyle='rgba(60,30,10,.55)';g.lineWidth=1.4;g.beginPath();for(let k=1;k<12;k++){const a=L[k],b=Rr[k];g.moveTo(a[0],a[1]);g.quadraticCurveTo((a[0]+b[0])/2,(a[1]+b[1])/2+3,b[0],b[1])}g.stroke();
 g.strokeStyle='rgba(255,230,180,.35)';g.lineWidth=1.6;g.beginPath();for(let k=1;k<12;k++){const a=L[k];g.moveTo(a[0]+1,a[1]+1.5);g.lineTo(a[0]+(Rr[k][0]-a[0])*.35,a[1]+(Rr[k][1]-a[1])*.35+2)}g.stroke();
 /* fronds */
 const cx=tx,cy=ty,n=o.n||7,F=[];for(let k=0;k<n;k++){const a=-Math.PI/2+(k/(n-1)-.5)*Math.PI*1.9+(rpw2aR(i*7+k)-.5)*.3,len=h*(.5+rpw2aR(i*3+k)*.18);F.push([a,len,k])}
 F.sort((A,B)=>Math.sin(A[0])-Math.sin(B[0]));
 for(const [a,len,k] of F){const dx=Math.cos(a),dy=Math.sin(a)*.62,droop=len*(.35+.25*Math.abs(dx)),pts=[],m=10;
  const P=u=>({x:cx+dx*len*u,y:cy+dy*len*u-len*.18*Math.sin(u*Math.PI*.9)+droop*u*u});
  const le=[],ri=[];for(let j=0;j<=m;j++){const u=j/m,p=P(u),p2=P(Math.min(1,u+.05)),an=Math.atan2(p2.y-p.y,p2.x-p.x),w=len*.15*Math.sin(Math.PI*Math.min(1,u*1.15))*(1-u*.35),z=j%2?1:.55;
   le.push([p.x+Math.sin(an)*w*z,p.y-Math.cos(an)*w*z]);ri.push([p.x-Math.sin(an)*w*z,p.y+Math.cos(an)*w*z]);pts.push(p)}
  g.beginPath();g.moveTo(cx,cy);for(const p of le)g.lineTo(p[0],p[1]);for(let j=ri.length-1;j>=0;j--)g.lineTo(ri[j][0],ri[j][1]);g.closePath();
  g.fillStyle=C[k%3];g.fill();g.lineWidth=2.2;g.strokeStyle=RPO;g.stroke();
  g.save();g.clip();g.fillStyle='rgba(10,40,20,.28)';g.beginPath();g.moveTo(cx,cy);for(const p of ri)g.lineTo(p[0],p[1]);for(let j=pts.length-1;j>=0;j--)g.lineTo(pts[j].x,pts[j].y);g.closePath();g.fill();g.restore();
  g.strokeStyle=hi;g.globalAlpha=.75;g.lineWidth=1.6;g.beginPath();g.moveTo(cx,cy);for(const p of pts)g.lineTo(p.x,p.y-1);g.stroke();g.globalAlpha=1}
 /* coconuts */
 for(const [dx,dy] of[[-5,6],[5,7],[0,10]]){g.fillStyle='#6a4022';g.beginPath();g.arc(cx+dx,cy+dy,h*.045+1.5,0,TAU);g.fill();rpw2aOut(g,1.6);g.fillStyle='rgba(255,220,160,.4)';g.beginPath();g.arc(cx+dx-1.2,cy+dy-1.2,1.4,0,TAU);g.fill()}
 g.restore()}
/* a tropical bush with broad leaves and hibiscus flowers */
function rpw2aBush(g,x,y,s,i,o){o=o||{};const C=o.cols||['#2f9a48','#3cb854','#237a3a'],fl=o.fl||['#ff5a7a','#ffd24a','#ff8ad0'];g.save();g.translate(x,y);rpw2aBlob(g,s*.1,2,s*.62,s*.2,'#000',.22);
 const L=[];for(let k=0;k<9;k++){const a=-Math.PI+.25+k/8*(Math.PI-.5)+(rpw2aR(i+k)-.5)*.3,r=s*(.55+rpw2aR(i*3+k)*.35);L.push([a,r,k])}
 for(const [a,r,k] of L){const ex=Math.cos(a)*r,ey=Math.sin(a)*r*.75-s*.12,nx=-Math.sin(a),ny=Math.cos(a)*.75,w=r*.32;
  g.beginPath();g.moveTo(0,-s*.05);g.quadraticCurveTo(ex*.5+nx*w,ey*.5+ny*w,ex,ey);g.quadraticCurveTo(ex*.5-nx*w,ey*.5-ny*w,0,-s*.05);g.closePath();g.fillStyle=C[k%3];g.fill();rpw2aOut(g,2);
  g.strokeStyle='rgba(200,255,170,.45)';g.lineWidth=1.2;g.beginPath();g.moveTo(0,-s*.05);g.lineTo(ex*.85,ey*.85);g.stroke()}
 if(!o.nofl)for(let k=0;k<3;k++){const fx=(rpw2aR(i*5+k)-.5)*s*1.1,fy=-s*.25-rpw2aR(i*9+k)*s*.4,c=fl[(i+k)%fl.length],r=s*.13+2;g.fillStyle=c;
  for(let j=0;j<5;j++){const a=j/5*TAU+i;g.beginPath();g.ellipse(fx+Math.cos(a)*r*.7,fy+Math.sin(a)*r*.6,r*.6,r*.42,a,0,TAU);g.fill()}
  g.strokeStyle=RPO;g.lineWidth=1.2;g.beginPath();g.arc(fx,fy,r*1.05,0,TAU);g.globalAlpha=.5;g.stroke();g.globalAlpha=1;g.fillStyle='#fff3a0';g.beginPath();g.arc(fx,fy,r*.28,0,TAU);g.fill()}
 g.restore()}
/* a smooth rounded beach / sea rock */
function rpw2aStone(g,x,y,s,i,C){C=C||['#b8a48c','#e6d6bc','#7a6650'];g.save();g.translate(x,y);rpw2aBlob(g,s*.12,s*.08,s*.62,s*.2,'#000',.25);
 const pts=[];for(let k=0;k<9;k++){const a=Math.PI+k/8*Math.PI,r=s*(.5+rpw2aR(i*5+k)*.18);pts.push([Math.cos(a)*r*1.1,Math.sin(a)*r*.95])}
 g.beginPath();g.moveTo(-s*.58,s*.1);for(const p of pts)g.lineTo(p[0],p[1]);g.lineTo(s*.58,s*.1);g.quadraticCurveTo(0,s*.24,-s*.58,s*.1);g.closePath();
 g.fillStyle=C[0];g.fill();g.save();g.clip();g.fillStyle=C[2];g.globalAlpha=.55;g.beginPath();g.ellipse(s*.3,s*.05,s*.5,s*.5,0,0,TAU);g.fill();g.globalAlpha=.8;g.fillStyle=C[1];g.beginPath();g.ellipse(-s*.2,-s*.32,s*.28,s*.14,-.3,0,TAU);g.fill();g.restore();
 rpw2aOut(g,2.2);g.restore()}
/* a jagged dark rock (cliffs, sea stacks) */
function rpw2aCrag(g,x,y,w,h,i,C){C=C||['#6a7480','#9aa6b2','#3e4650'];g.save();g.translate(x,y);rpw2aBlob(g,w*.1,2,w*.6,w*.16,'#000',.28);
 const J=k=>.82+rpw2aR(i*7+k)*.36,P=[[-w*.5,0],[-w*.48,-h*.42*J(1)],[-w*.3,-h*.82*J(2)],[-w*.06,-h],[w*.2,-h*.86*J(3)],[w*.42,-h*.5*J(4)],[w*.5,0]];
 const poly=a=>{g.beginPath();g.moveTo(a[0][0],a[0][1]);for(let k=1;k<a.length;k++)g.lineTo(a[k][0],a[k][1]);g.closePath()};
 poly(P);g.fillStyle=C[0];g.fill();g.fillStyle=C[1];poly([P[1],P[2],P[3],[-w*.08,-h*.5],[-w*.32,-h*.3]]);g.fill();g.fillStyle=C[2];poly([[w*.02,-h*.45],P[4],P[5],P[6],[w*.06,0]]);g.fill();
 g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=1.2;g.beginPath();g.moveTo(P[3][0],P[3][1]);g.lineTo(-w*.08,-h*.5);g.lineTo(w*.06,0);g.moveTo(-w*.08,-h*.5);g.lineTo(-w*.32,-h*.3);g.stroke();poly(P);rpw2aOut(g,2.4);g.restore()}
/* a five-armed starfish */
function rpw2aStar(g,x,y,r,a,col){g.save();g.translate(x,y);g.rotate(a);g.beginPath();for(let k=0;k<10;k++){const b=-Math.PI/2+k*Math.PI/5,rr=k%2?r*.42:r;const px=Math.cos(b)*rr,py=Math.sin(b)*rr*.8;k?g.lineTo(px,py):g.moveTo(px,py)}g.closePath();
 g.fillStyle=col||'#ff7a4a';g.fill();rpw2aOut(g,1.6);g.fillStyle='rgba(255,240,200,.75)';for(let k=0;k<5;k++){const b=-Math.PI/2+k*TAU/5;for(const u of[.35,.62]){g.beginPath();g.arc(Math.cos(b)*r*u,Math.sin(b)*r*u*.8,r*.07+.4,0,TAU);g.fill()}}g.restore()}
/* a scallop / spiral shell */
function rpw2aShell(g,x,y,s,a,k){g.save();g.translate(x,y);g.rotate(a);const C=[['#ffe2d0','#ffb89a'],['#fff0f4','#f4a8c8'],['#fff6d8','#f0c87a']][k%3];
 if(k%2===0){g.beginPath();g.moveTo(0,s*.5);for(let j=0;j<=8;j++){const b=Math.PI+j/8*Math.PI;g.lineTo(Math.cos(b)*s*.6,Math.sin(b)*s*.6+s*.05)}g.closePath();g.fillStyle=C[0];g.fill();rpw2aOut(g,1.4);
  g.strokeStyle=C[1];g.lineWidth=1.1;g.beginPath();for(let j=1;j<8;j++){const b=Math.PI+j/8*Math.PI;g.moveTo(0,s*.45);g.lineTo(Math.cos(b)*s*.55,Math.sin(b)*s*.55+s*.05)}g.stroke();
  g.fillStyle=C[1];g.fillRect(-s*.18,s*.38,s*.36,s*.14)}
 else{g.beginPath();g.ellipse(0,0,s*.55,s*.36,0,0,TAU);g.fillStyle=C[0];g.fill();rpw2aOut(g,1.4);g.strokeStyle=C[1];g.lineWidth=1.2;g.beginPath();g.arc(s*.08,0,s*.24,0,Math.PI*1.6);g.arc(s*.12,-s*.02,s*.1,Math.PI*1.6,Math.PI*3);g.stroke()}
 g.restore()}
/* coral: 0 branching (staghorn), 1 brain, 2 fan, 3 tube cluster. c = [main, light, dark] */
function rpw2aCoral(g,x,y,s,k,c,i){g.save();g.translate(x,y);i=i||0;
 if(k===0){const br=(px,py,a,l,d)=>{const ex=px+Math.cos(a)*l,ey=py+Math.sin(a)*l;g.moveTo(px,py);g.lineTo(ex,ey);if(d>0){br(ex,ey,a-.45-rpw2aR(i+d)*.2,l*.72,d-1);br(ex,ey,a+.42+rpw2aR(i+d*3)*.2,l*.7,d-1)}};
  g.beginPath();br(0,0,-Math.PI/2+(rpw2aR(i)-.5)*.3,s*.42,3);g.lineWidth=s*.16+3;g.strokeStyle=RPO;g.stroke();g.lineWidth=s*.16;g.strokeStyle=c[0];g.stroke();g.lineWidth=s*.05;g.strokeStyle=c[1];g.globalAlpha=.7;g.stroke();g.globalAlpha=1}
 else if(k===1){g.beginPath();g.ellipse(0,-s*.22,s*.5,s*.32,0,0,TAU);g.fillStyle=c[0];g.fill();rpw2aOut(g,2);g.save();g.clip();g.strokeStyle=c[2];g.lineWidth=1.6;g.beginPath();
  for(let j=0;j<6;j++){const yy=-s*.45+j*s*.1;g.moveTo(-s*.5,yy);for(let xx=-s*.5;xx<=s*.5;xx+=s*.1)g.lineTo(xx,yy+Math.sin(xx*.4+j*2)*s*.04)}g.stroke();g.fillStyle=c[1];g.globalAlpha=.5;g.beginPath();g.ellipse(-s*.18,-s*.36,s*.22,s*.1,-.3,0,TAU);g.fill();g.restore()}
 else if(k===2){g.beginPath();g.moveTo(0,0);for(let j=0;j<=10;j++){const a=-Math.PI*.92+j/10*Math.PI*.84,r=s*(.62+.08*Math.sin(j*2.1+i));g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle=c[0];g.fill();rpw2aOut(g,2);
  g.strokeStyle=c[2];g.lineWidth=1.1;g.beginPath();for(let j=0;j<12;j++){const a=-Math.PI*.9+j/11*Math.PI*.8;g.moveTo(0,0);g.lineTo(Math.cos(a)*s*.58,Math.sin(a)*s*.58)}for(const r of[.25,.4,.52]){g.moveTo(Math.cos(-Math.PI*.9)*s*r,Math.sin(-Math.PI*.9)*s*r);g.arc(0,0,s*r,-Math.PI*.9,-Math.PI*.1)}g.stroke()}
 else{for(let j=0;j<5;j++){const tx=(j-2)*s*.17,th=s*(.35+rpw2aR(i+j)*.4),tw=s*.08;g.beginPath();g.roundRect(tx-tw,-th,tw*2,th,[tw,tw,1,1]);g.fillStyle=c[j%2?0:2];g.fill();rpw2aOut(g,1.6);
  g.fillStyle=c[1];g.beginPath();g.ellipse(tx,-th+1,tw*.8,tw*.45,0,0,TAU);g.fill()}}
 g.restore()}
/* a tide pool: a ring of stones round a little pool with a starfish and weed */
function rpw2aPool(g,x,y,r,i){g.save();g.translate(x,y);rpw2aBlob(g,2,3,r*1.25,r*.62,'#000',.18);
 g.fillStyle='#c8a878';g.beginPath();g.ellipse(0,0,r*1.12,r*.6,0,0,TAU);g.fill();
 const q=g.createRadialGradient(-r*.3,-r*.2,2,0,0,r);q.addColorStop(0,'#bff8f2');q.addColorStop(.6,'#4ad4d8');q.addColorStop(1,'#1a8aa8');g.fillStyle=q;g.beginPath();g.ellipse(0,0,r,r*.5,0,0,TAU);g.fill();rpw2aOut(g,2);
 g.save();g.beginPath();g.ellipse(0,0,r,r*.5,0,0,TAU);g.clip();rpw2aStar(g,r*.25,r*.1,r*.28,i,'#ff8a5a');g.strokeStyle='#2a9a5a';g.lineWidth=2;g.beginPath();g.moveTo(-r*.5,r*.3);g.quadraticCurveTo(-r*.45,0,-r*.6,-r*.2);g.moveTo(-r*.4,r*.3);g.quadraticCurveTo(-r*.3,0,-r*.35,-r*.25);g.stroke();
 g.fillStyle='rgba(0,60,90,.3)';g.fillRect(-r,-r*.5,2*r,r*.2);g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1.4;g.beginPath();g.ellipse(-r*.3,-r*.18,r*.3,r*.08,-.2,0,TAU);g.stroke();g.restore();
 for(let k=0;k<9;k++){const a=k/9*TAU+i,sx=Math.cos(a)*r*1.05,sy=Math.sin(a)*r*.55;if(sy<-r*.2&&k%2)continue;rpw2aStone(g,sx,sy+3,r*.28+rpw2aR(i+k)*r*.18,i*9+k,['#a89480','#d8c8b0','#6a5a4a'])}
 g.restore()}
/* driftwood */
function rpw2aDrift(g,x,y,l,a){g.save();g.translate(x,y);g.rotate(a);rpw2aBlob(g,2,4,l*.55,5,'#000',.2);g.beginPath();g.moveTo(-l/2,-3);g.quadraticCurveTo(0,-7,l/2,-4);g.lineTo(l/2+4,-8);g.lineTo(l/2+2,2);g.quadraticCurveTo(0,5,-l/2,3);g.closePath();
 g.fillStyle='#c8b090';g.fill();rpw2aOut(g,2);g.strokeStyle='rgba(90,70,50,.6)';g.lineWidth=1.2;g.beginPath();g.moveTo(-l*.4,-1);g.lineTo(l*.3,-2);g.moveTo(-l*.2,1.5);g.lineTo(l*.4,.5);g.stroke();g.restore()}
/* dune / sea grass tuft */
function rpw2aTuft(g,x,y,h,col,n){g.strokeStyle=col;g.lineWidth=1.8;g.beginPath();n=n||5;for(let k=0;k<n;k++){const a=(k/(n-1)-.5)*1.3;g.moveTo(x+a*3,y);g.quadraticCurveTo(x+a*h*.35,y-h*.6,x+a*h*.75,y-h*(.9+.2*Math.cos(a*2)))}g.stroke()}
/* a striped lighthouse on its rocks; returns the lamp position */
function rpw2aLighthouse(g,x,y,h){g.save();g.translate(x,y);
 for(const [dx,dy,s,i] of[[-34,8,30,1],[30,10,34,2],[-6,14,40,3],[44,0,22,4],[-46,-2,22,5]])rpw2aCrag(g,dx,dy,s*1.3,s*.8,i,['#8a8070','#c8bca8','#5a5048']);
 const w0=26,w1=17,top=-h,bands=5;
 const body=()=>{g.beginPath();g.moveTo(-w0,0);g.lineTo(-w1,top+26);g.lineTo(w1,top+26);g.lineTo(w0,0);g.quadraticCurveTo(0,7,-w0,0);g.closePath()};
 body();let q=g.createLinearGradient(-w0,0,w0,0);q.addColorStop(0,'#f2f2ff');q.addColorStop(.35,'#ffffff');q.addColorStop(1,'#a8a8c8');g.fillStyle=q;g.fill();
 g.save();body();g.clip();for(let k=0;k<bands;k++){if(k%2)continue;const y0=-(k+1)*(h-26)/bands,y1=-k*(h-26)/bands;q=g.createLinearGradient(-w0,0,w0,0);q.addColorStop(0,'#ff6a6a');q.addColorStop(.35,'#ff4a4a');q.addColorStop(1,'#a81a3a');g.fillStyle=q;
  g.beginPath();g.moveTo(-40,y1+3);g.quadraticCurveTo(0,y1+8,40,y1+3);g.lineTo(40,y0+3);g.quadraticCurveTo(0,y0+8,-40,y0+3);g.closePath();g.fill()}
 g.fillStyle='rgba(18,8,31,.18)';g.fillRect(w1*.4,top,w0,h);g.restore();body();rpw2aOut(g,2.6);
 /* door and windows */
 g.fillStyle='#5a3a22';g.beginPath();g.roundRect(-7,-24,14,24,[7,7,0,0]);g.fill();rpw2aOut(g,2);g.fillStyle='#ffd27a';g.beginPath();g.arc(4,-11,1.4,0,TAU);g.fill();
 for(const wy of[-h*.42,-h*.66]){g.fillStyle='#2a3a5a';g.beginPath();g.roundRect(-4,wy,8,12,[4,4,1,1]);g.fill();rpw2aOut(g,1.6);g.fillStyle='#ffe08a';g.globalAlpha=.8;g.fillRect(-2.5,wy+5,5,6);g.globalAlpha=1}
 /* gallery, lamp room, dome */
 const gy=top+26;g.fillStyle='#3a3a5a';g.beginPath();g.ellipse(0,gy,w1+9,5,0,0,TAU);g.fill();rpw2aOut(g,2.2);
 g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();for(let k=-3;k<=3;k++){const xx=k*(w1+7)/3;g.moveTo(xx,gy);g.lineTo(xx,gy-9)}g.moveTo(-w1-8,gy-9);g.lineTo(w1+8,gy-9);g.stroke();
 g.fillStyle='#3a3a5a';g.fillRect(-12,gy-26,24,4);g.strokeRect(-12,gy-26,24,4);
 q=g.createLinearGradient(0,gy-22,0,gy-2);q.addColorStop(0,'#fff8c0');q.addColorStop(1,'#ffc23a');g.fillStyle=q;g.fillRect(-10,gy-22,20,18);g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(-10,gy-22,20,18);
 g.lineWidth=1.4;g.beginPath();g.moveTo(-3,gy-22);g.lineTo(-3,gy-4);g.moveTo(4,gy-22);g.lineTo(4,gy-4);g.stroke();
 g.fillStyle='#e8343a';g.beginPath();g.moveTo(-15,gy-26);g.quadraticCurveTo(-13,gy-44,0,gy-46);g.quadraticCurveTo(13,gy-44,15,gy-26);g.closePath();g.fill();rpw2aOut(g,2.2);
 g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-6,gy-36,3,6,-.4,0,TAU);g.fill();
 g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(0,gy-46);g.lineTo(0,gy-56);g.stroke();g.fillStyle='#ffd45a';g.beginPath();g.arc(0,gy-50,3,0,TAU);g.fill();rpw2aOut(g,1.4);
 g.restore();return{x,y:y+gy-13}}
/* a little wooden jetty from (x0,y0) to (x1,y1) */
function rpw2aJetty(g,x0,y0,x1,y1,w){const a=Math.atan2(y1-y0,x1-x0),L=Math.hypot(x1-x0,y1-y0);g.save();g.translate(x0,y0);g.rotate(a);
 for(let u=14;u<L;u+=34)for(const s of[-1,1]){g.fillStyle='#5a3a22';g.fillRect(u-3,s*w/2-3,6,14);g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(u-3,s*w/2-3,6,14)}
 g.fillStyle='rgba(0,0,0,.25)';g.fillRect(0,-w/2+6,L,w);
 for(let u=0;u<L;u+=9){g.fillStyle=(u/9)%2?'#b88a56':'#a87a48';g.beginPath();g.rect(u,-w/2,8.4,w);g.fill();g.strokeStyle='rgba(18,8,31,.7)';g.lineWidth=1.2;g.stroke()}
 g.strokeStyle=RPO;g.lineWidth=2.2;g.strokeRect(0,-w/2,L,w);g.restore()}
/* a rowboat (a = heading) */
function rpw2aBoat(g,x,y,l,a,col){g.save();g.translate(x,y);g.rotate(a);rpw2aBlob(g,0,4,l*.55,l*.2,'#000',.18);
 const hull=()=>{g.beginPath();g.moveTo(-l/2,0);g.quadraticCurveTo(-l*.3,-l*.24,l*.15,-l*.2);g.quadraticCurveTo(l*.45,-l*.15,l/2,0);g.quadraticCurveTo(l*.45,l*.15,l*.15,l*.2);g.quadraticCurveTo(-l*.3,l*.24,-l/2,0);g.closePath()};
 hull();g.fillStyle=col||'#c8503a';g.fill();rpw2aOut(g,2.4);g.save();g.scale(.8,.72);hull();g.restore();g.fillStyle='#a87a48';g.fill();g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=1.4;g.stroke();
 g.fillStyle='#8a5a32';for(const u of[-.15,.18]){g.fillRect(l*u-2.5,-l*.15,5,l*.3);g.strokeStyle=RPO;g.lineWidth=1.2;g.strokeRect(l*u-2.5,-l*.15,5,l*.3)}
 g.strokeStyle='#d8b07a';g.lineWidth=2.4;g.beginPath();g.moveTo(-l*.05,-l*.06);g.lineTo(l*.35,-l*.3);g.stroke();g.restore()}
/* a sandcastle with a little flag */
function rpw2aSandcastle(g,x,y,s){g.save();g.translate(x,y);rpw2aBlob(g,2,2,s*.7,s*.18,'#000',.2);const C='#f0cc84',D='#c8a060';
 const blk=(bx,by,w,h)=>{g.fillStyle=C;g.fillRect(bx,by,w,h);g.fillStyle=D;g.fillRect(bx+w*.65,by,w*.35,h);g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(bx,by,w,h);for(let k=0;k<3;k++){g.fillStyle=C;g.fillRect(bx+k*w/3+1,by-4,w/3-3,4);g.strokeRect(bx+k*w/3+1,by-4,w/3-3,4)}};
 blk(-s*.55,-s*.35,s*.32,s*.35);blk(s*.22,-s*.35,s*.32,s*.35);blk(-s*.22,-s*.6,s*.44,s*.6);g.fillStyle='#5a3a22';g.beginPath();g.roundRect(-s*.07,-s*.2,s*.14,s*.2,[3,3,0,0]);g.fill();
 g.strokeStyle=RPO;g.lineWidth=1.4;g.beginPath();g.moveTo(0,-s*.64);g.lineTo(0,-s*.95);g.stroke();g.fillStyle='#ff4a6a';g.beginPath();g.moveTo(0,-s*.95);g.lineTo(s*.22,-s*.88);g.lineTo(0,-s*.8);g.closePath();g.fill();rpw2aOut(g,1.2);
 rpw2aShell(g,-s*.38,-s*.15,6,0,1);g.restore()}
/* a hammock between two palms (x0..x1 at the crowns' height h) */
function rpw2aHammock(g,x0,y0,x1,y1){g.strokeStyle='#8a6a40';g.lineWidth=1.4;g.beginPath();g.moveTo(x0,y0);g.lineTo(x0+12,y0+6);g.moveTo(x1,y1);g.lineTo(x1-12,y1+6);g.stroke();
 const mx=(x0+x1)/2,my=(y0+y1)/2+22;g.beginPath();g.moveTo(x0+12,y0+6);g.quadraticCurveTo(mx,my+10,x1-12,y1+6);g.quadraticCurveTo(mx,my-2,x0+12,y0+6);g.closePath();g.fillStyle='#ff8a5a';g.fill();rpw2aOut(g,2);
 g.save();g.clip();g.strokeStyle='#ffe08a';g.lineWidth=3;for(let k=-3;k<=3;k++){g.beginPath();g.moveTo(mx+k*12-6,my-14);g.lineTo(mx+k*12+6,my+14);g.stroke()}g.restore()}
/* a half-buried treasure chest */
function rpw2aChest(g,x,y,s){g.save();g.translate(x,y);rpw2aBlob(g,0,2,s*.75,s*.2,'#000',.2);g.fillStyle='#8a5028';g.beginPath();g.rect(-s*.5,-s*.42,s,s*.42);g.fill();rpw2aOut(g,2);
 g.fillStyle='#a8683a';g.beginPath();g.moveTo(-s*.5,-s*.42);g.quadraticCurveTo(0,-s*.78,s*.5,-s*.42);g.closePath();g.fill();rpw2aOut(g,2);g.fillStyle='#ffd45a';g.fillRect(-s*.5,-s*.46,s,s*.08);g.fillRect(-s*.07,-s*.5,s*.14,s*.2);g.strokeStyle=RPO;g.lineWidth=1.2;g.strokeRect(-s*.07,-s*.5,s*.14,s*.2);
 for(const [dx,dy] of[[-.2,-.5],[.15,-.56],[0,-.6]]){g.fillStyle='#ffd45a';g.beginPath();g.arc(dx*s,dy*s,s*.08,0,TAU);g.fill();rpw2aOut(g,1)}
 g.fillStyle='#f0d49a';g.beginPath();g.moveTo(-s*.62,0);g.quadraticCurveTo(-s*.4,-s*.14,-s*.1,-s*.06);g.quadraticCurveTo(s*.3,-s*.16,s*.62,0);g.closePath();g.fill();g.restore()}
/* ---------- Coral Shallows ---------- */
const RPW2A_CO={sand:rpw2aCol('#f7dfa6'),sand2:rpw2aCol('#ffefc6'),wet:rpw2aCol('#d8b47c'),grass:rpw2aCol('#3fae46'),grass2:rpw2aCol('#7ad456'),gEdge:rpw2aCol('#2c8a3a'),floor:rpw2aCol('#f4e2b0'),floorD:rpw2aCol('#7ac0c0'),
 w0:rpw2aCol('#9ef6e6'),w1:rpw2aCol('#38d6d6'),w2:rpw2aCol('#1aa2d6'),w3:rpw2aCol('#1a6cc0'),rim:rpw2aCol('#1e5e6e')};
const RPW2A_CORAL=[['#ff6a8a','#ffc6d2','#c03a5e'],['#ff9a4a','#ffdcae','#c45a1a'],['#b67aff','#e4ccff','#6e3ac4'],['#ffd84a','#fff6b4','#c49a1a'],['#4ae0c8','#c4fff2','#1a9a8a'],['#ff5ac0','#ffc4ec','#b02a8a']];
/* the designed sea: the left coast with the lighthouse point, the reef along the bottom with three lagoons, the top-right corner */
function rpw2aCoralSea(x,y){const nz=(rpw2aVN(x/80,y/80+3)-.5)*30+Math.sin(x*.029+y*.013)*6;
 let f=y-(790+16*Math.sin(x*.008+1)+10*Math.sin(x*.023));
 f=rpw2aSmax(f,(92+22*Math.sin(y*.012+.4))-x,40);
 f=rpw2aSmax(f,rpw2aEll(x,y,1640,-40,360,200),40);
 f=rpw2aSmax(f,rpw2aEll(x,y,-40,-40,230,140),40);
 f=rpw2aSmax(f,rpw2aEll(x,y,470,770,160,190),50);
 f=rpw2aSmax(f,rpw2aEll(x,y,830,830,150,120),50);
 f=rpw2aSmax(f,rpw2aEll(x,y,1170,800,150,170),50);
 f=rpw2aSmin(f,-rpw2aEll(x,y,110,322,100,78),30);/* the lighthouse point */
 return f+nz}
function rpw2aCoralBake(map){const G=rpGeo(map),pal=RP_PAL.coral,A=rpw2aCastle('coral'),gt=G.gate;
 const cast={x:Math.round(gt.x-A.gx),y:Math.round(gt.y-A.gy),w:A.w,h:A.h},B={pal,G,cast,trees:[],id:'coral'};
 const tide=map.tide||[],tideK=(x,y)=>{let m=0;for(const t of tide){const d=Math.hypot(x-t[0],(y-t[1])*1.2)/t[2];if(1-d>m)m=1-d}return m};
 const {D,F}=rpw2aField(map,G,rpw2aCoralSea,{clear:(x,y)=>62-24*Math.min(1,tideK(x,y)*1.6),padR:74,
  extra:(x,y,f)=>{const d=Math.hypot(x-gt.x-20,y-gt.y);return rpw2aSmin(f,d-110,30)}});
 const DR=rpw2aRoadGrid(G);
 const N=rpw2aGrid((x,y)=>rpw2aFbm(x,y,1.7)),C=RPW2A_CO;B.F=F;
 const M=rpw2aGrid((x,y)=>rpw2aVN(x/14,y/14)),c2=[0,0,0],c3=[0,0,0],WH=[255,255,255],WH2=[255,250,220],DK=[60,40,0],CL=[230,255,255];
 const RY=new Float32Array(900),CY=new Float32Array(900),CX=new Float32Array(1600);for(let y=0;y<900;y++){RY[y]=Math.sin(y*.05)*2.4+y*.02;CY[y]=Math.sin(y*.06)*2.2}for(let x=0;x<1600;x++)CX[x]=Math.sin(x*.045)*2.5;
 const P=rpw2aPaint(F,N,M,(f,n,m,x,y,o,w)=>{
  if(f<=0){/* land: grass inland, a beach along the water with a crisp drawn edge */
   const e=f+(n-.5)*80+92,b=rpw2aSS(-1.5,1.5,e);rpw2aM3(c2,C.grass,C.grass2,rpw2aSS(.3,.78,n));rpw2aM3(c3,C.sand,C.sand2,rpw2aSS(.25,.8,n));rpw2aM3(o,c2,c3,b);
   if(e<0&&e>-5)rpw2aM3(o,o,C.gEdge,.7*(1-rpw2aSS(-5,-2,e)));else if(e>0&&e<9)rpw2aM3(o,o,WH2,.35*(1-e/9));
   if(f>-18)rpw2aM3(o,o,C.wet,rpw2aSS(-19,-16,f)*.9);
   const gr=rpw2aIH(x,y);if(gr>.94)rpw2aM3(o,o,WH,b>.5?.22:.08);else if(gr<.05)rpw2aM3(o,o,DK,.1);
   if(f>-2.4){w[0]=C.rim[0];w[1]=C.rim[1];w[2]=C.rim[2];w[3]=255*rpw2aSS(-2.4,-1.2,f)}return}
  rpw2aM3(o,C.floor,C.floorD,rpw2aSS(20,170,f));const rip=Math.sin(x*.07+RY[y])*7;o[0]+=rip;o[1]+=rip;o[2]+=rip*.7;
  /* the water in three cartoon depth bands with light contour lines */
  const fb=f+(n-.5)*26;let a;
  if(fb<30){rpw2aM3(w,C.w0,C.w1,fb/30*.5);a=.42}else if(fb<95){rpw2aM3(w,C.w1,C.w2,(fb-30)/65*.55);a=.6}else{rpw2aM3(w,C.w2,C.w3,Math.min(1,(fb-95)/110));a=.86}
  const d1=Math.min(Math.abs(fb-30),Math.abs(fb-95));if(d1<2.2){rpw2aM3(w,w,CL,.55*(1-d1/2.2));a=Math.max(a,.7)}
  if(fb<95){const ca=Math.sin(x*.085+CY[y])+Math.sin(y*.1+CX[x]);if(ca>1.5){rpw2aM3(w,w,WH,.55*(ca-1.5));a=Math.min(1,a+.12)}}
  if(f<1.3){w[0]=C.rim[0];w[1]=C.rim[1];w[2]=C.rim[2];a=1}else if(f<6&&n>.3){const k=1-rpw2aSS(4,6,f);rpw2aM3(w,w,WH,k);a=Math.max(a,k*.95)}else if(f>10.5&&f<13&&m>.42){rpw2aM3(w,w,WH,.5);a=Math.max(a,.62)}
  w[3]=255*a},1);
 const c=rpw2aCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.drawImage(P.base,0,0);B.c=c;
 /* the reef under the water: coral patches, sea grass, starfish and rocks */
 rpw2aMasked(g,P.mask,h=>{const L=[];for(let k=0;k<190;k++){const x=rpw2aR(k*3+5)*1600,y=rpw2aR(k*3+6)*900,f=F.at(x,y);if(f<16||f>130)continue;
   const n=5+(k%4)*2;for(let j=0;j<n;j++){const a=rpw2aR(k*31+j)*TAU,d=rpw2aR(k*17+j)*34,px=x+Math.cos(a)*d,py=y+Math.sin(a)*d*.6;if(F.at(px,py)<12)continue;L.push([px,py,10+rpw2aR(k+j*7)*16,(k+j)%4,RPW2A_CORAL[(k*3+j)%6],k*9+j])}}
  for(let k=0;k<160;k++){const x=rpw2aR(k*5+400)*1600,y=rpw2aR(k*5+401)*900,f=F.at(x,y);if(f<12||f>160)continue;L.push([x,y,12+rpw2aR(k)*10,-1,null,k])}
  L.sort((a,b)=>a[1]-b[1]);for(const [x,y,s,k,cc,i] of L){if(k<0){rpw2aTuft(h,x,y,s*1.3,i%2?'#1e8a6a':'#2aa070',6);continue}rpw2aCoral(h,x,y,s,k,cc,i)}
  for(let k=0;k<30;k++){const x=rpw2aR(k*5+900)*1600,y=rpw2aR(k*5+901)*900,f=F.at(x,y);if(f<10||f>90)continue;rpw2aStar(h,x,y,7+rpw2aR(k)*4,k,['#ff5a3a','#ffb43a','#ff7ad0'][k%3])}
  for(let k=0;k<36;k++){const x=rpw2aR(k*5+700)*1600,y=rpw2aR(k*5+701)*900,f=F.at(x,y);if(f<26)continue;rpw2aStone(h,x,y,16+rpw2aR(k)*24,k,['#8aa8a0','#c8e0d8','#4a6a70'])}});
 g.drawImage(P.surf,0,0);
 /* inland: grass patches, grass strokes and flowers */
 for(let i=0;i<80;i++){const x=rpw2aR(i+300)*1600,y=rpw2aR(i+330)*900,f=F.at(x,y);if(f>-130||DR.at(x,y)<74)continue;rpw2aBlob(g,x,y,40+rpw2aR(i)*60,16+rpw2aR(i+1)*20,i%2?'#33a040':'#74cc54',.38)}
 for(let i=0;i<1100;i++){const x=rpw2aR(i*2+90)*1600,y=rpw2aR(i*2+91)*900,f=F.at(x,y);if(f>-24||DR.at(x,y)<42)continue;const b=f+(N.at(x,y)-.5)*80+92>0;
  g.strokeStyle=b?'#c4a456':(i%3?'#2a8a38':'#5cbc4a');g.lineWidth=1.6;g.beginPath();g.moveTo(x,y);g.lineTo(x-2,y-6-rpw2aR(i)*5);g.moveTo(x+3,y);g.lineTo(x+4,y-5-rpw2aR(i+3)*5);g.stroke()}
 for(let i=0;i<420;i++){const x=rpw2aR(i+1000)*1600,y=rpw2aR(i+1300)*900,f=F.at(x,y);if(f+(N.at(x,y)-.5)*80+92>-6||DR.at(x,y)<46)continue;const col=['#ffffff','#ffe46a','#ff8ad0','#ff6a6a'][i%4];
  for(let k=0;k<5;k++){const a=k/5*TAU+i;g.fillStyle=col;g.beginPath();g.arc(x+Math.cos(a)*2.4,y+Math.sin(a)*1.8,1.6,0,TAU);g.fill()}g.fillStyle='#ffb02a';g.beginPath();g.arc(x,y,1.2,0,TAU);g.fill()}
 /* the road: packed pale sand with ripples and bits of shell, shell-white curb stones */
 rpw2aRoad(g,G,{edge:'#8a6438',curb:'#fff4dc',fill:'#f4dca6',fill2:'rgba(255,244,214,.45)',
  tex:(g,P,i,p)=>{const r=rpw2aR(i*3+1);if(r<.5){const off=(rpw2aR(i)-.5)*36,x=p.x-Math.sin(p.a)*off,y=p.y+Math.cos(p.a)*off;g.strokeStyle='rgba(170,130,70,.35)';g.lineWidth=1.6;g.beginPath();
    g.moveTo(x-Math.sin(p.a)*8-Math.cos(p.a)*2,y+Math.cos(p.a)*8-Math.sin(p.a)*2);g.quadraticCurveTo(x+Math.cos(p.a)*3,y+Math.sin(p.a)*3,x+Math.sin(p.a)*8-Math.cos(p.a)*2,y-Math.cos(p.a)*8-Math.sin(p.a)*2);g.stroke()}
   else if(r<.6){const off=(rpw2aR(i+7)-.5)*44;rpw2aShell(g,p.x-Math.sin(p.a)*off,p.y+Math.cos(p.a)*off,5+rpw2aR(i)*3,rpw2aR(i+2)*6,i)}
   else if(r<.8){const off=(rpw2aR(i+5)-.5)*46,x=p.x-Math.sin(p.a)*off,y=p.y+Math.cos(p.a)*off;g.fillStyle=['#e8c890','#fff0d0','#d8b080'][i%3];g.beginPath();g.ellipse(x,y,2.6,1.8,p.a,0,TAU);g.fill()}},
  stone:(g,x,y,a,i,sd)=>{const k=i%7;if(k===3){rpw2aShell(g,x,y,9,a+(sd>0?Math.PI:0),i);return}g.fillStyle=k%2?'#fff8ea':'#ffe4d8';g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,6.5,4.6,a,0,TAU);g.fill();g.stroke();
   g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.ellipse(x-1,y-1.5,3.4,1.4,a,0,TAU);g.fill()},chev:'rgba(140,90,40,.32)'});
 /* the tide flats: dark wet sand with a drawn edge, ripple marks, puddles and weed where the tide floods */
 for(const [tx,ty,r] of tide){g.save();const sh=()=>{g.beginPath();for(let k=0;k<=28;k++){const a=k/28*TAU,rr=r*(1+.1*Math.sin(a*3+tx)+.07*Math.sin(a*5+ty));k?g.lineTo(tx+Math.cos(a)*rr,ty+Math.sin(a)*rr*.72):g.moveTo(tx+Math.cos(a)*rr,ty+Math.sin(a)*rr*.72)}g.closePath()};
  sh();g.fillStyle='rgba(176,132,76,.42)';g.fill();g.strokeStyle='rgba(120,84,40,.5)';g.lineWidth=2;g.setLineDash([7,6]);g.stroke();g.setLineDash([]);g.clip();
  g.strokeStyle='rgba(110,78,40,.42)';g.lineWidth=1.6;for(let k=0;k<10;k++){const y0=ty-r*.66+k*r*.15;g.beginPath();for(let xx=tx-r;xx<=tx+r;xx+=6){const yy=y0+Math.sin(xx*.17+k)*2.6;xx===tx-r?g.moveTo(xx,yy):g.lineTo(xx,yy)}g.stroke()}
  for(let k=0;k<7;k++){const a=rpw2aR(k+tx)*TAU,d=rpw2aR(k+ty)*r*.62,px=tx+Math.cos(a)*d,py=ty+Math.sin(a)*d*.6,pr=6+rpw2aR(k*3+tx)*10;g.fillStyle='rgba(90,210,215,.62)';g.beginPath();g.ellipse(px,py,pr,pr*.45,0,0,TAU);g.fill();
   g.strokeStyle='rgba(60,120,120,.5)';g.lineWidth=1.2;g.stroke();g.strokeStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(px-pr*.2,py-pr*.12,pr*.4,pr*.1,0,0,TAU);g.stroke()}
  g.strokeStyle='#3a9a5a';g.lineWidth=2;for(let k=0;k<4;k++){const px=tx+(rpw2aR(k*5+tx)-.5)*r*1.3,py=ty+(rpw2aR(k*7+ty)-.5)*r*.7;g.beginPath();g.moveTo(px-6,py);g.quadraticCurveTo(px,py-5,px+7,py+1);g.stroke()}g.restore()}
 /* the lighthouse on its point, a jetty with a rowboat, then props by depth */
 const taken=[],items=[],free=(x,y,o)=>rpw2aFree(G,B,x,y,Object.assign({taken},o||{}));
 B.light=rpw2aLighthouse(g,104,338,200);taken.push([104,320,80]);
 items.push({k:'boat',x:54,y:556,i:3});taken.push([54,556,40]);
 const near=(x0,y0,w,h,beach)=>{for(let k=0;k<200;k++){const a=k*2.4,d=k*4,x=x0+Math.cos(a)*d,y=y0+Math.sin(a)*d*.7;if(x<30||x>1570||y<40||y>880)continue;const f=F.at(x,y);if(f>-16||(beach&&f+(N.at(x,y)-.5)*80+92<4))continue;if(free(x,y,{road:72,w,h}))return[x,y]}return null};
 for(const [x0,y0,k,s] of[[560,560,'castle',34],[1220,690,'chest',26],[1180,120,'castle',30],[90,700,'chest',22]]){const p=near(x0,y0,s*1.5,s*1.2,1);if(!p)continue;items.push({k,x:p[0],y:p[1],i:x0,s});taken.push([p[0],p[1],50])}
 {const p=near(640,100,150,110);if(p){items.push({k:'hammock',x:p[0],y:p[1],i:7});taken.push([p[0],p[1],90])}}
 for(let i=0;i<3200&&items.length<250;i++){const x=rpw2aR(i*4+11)*1640-20,y=rpw2aR(i*4+12)*940-20,f=F.at(x,y);if(f>-14||!free(x,y,{road:68}))continue;
  const d=DR.at(x,y),beach=f+(N.at(x,y)-.5)*80+92>0,r=rpw2aR(i*4+13);if(rpw2aR(i+5)<(d>170?.12:.5))continue;
  let k;if(beach)k=r<.2?'palm':r<.38?'shell':r<.52?'star':r<.64?'stone':r<.72?'drift':r<.8?'pool':'tuft';else k=r<.3?'palm':r<.56?'bush':r<.66?'fern':r<.74?'stone':r<.8?'pool':'tuft';
  const h=78+rpw2aR(i*4+14)*44;
  if(k==='pool'){if(!free(x,y,{road:90,pad:110,w:70,h:34}))continue;taken.push([x,y,70])}
  else if(k==='palm'){if(!free(x,y,{road:74,w:h*1.15,h:h*1.05}))continue;taken.push([x,y,26])}
  else if(k==='bush'){if(!free(x,y,{w:60,h:44}))continue}
  items.push({k,x,y,i,h})}
 items.sort((a,b)=>a.y-b.y);
 for(const it of items){const {x,y,i,h}=it;switch(it.k){
  case'palm':rpw2aPalm(g,x,y,h,i);break;case'bush':rpw2aBush(g,x,y,26+rpw2aR(i)*14,i);break;case'stone':rpw2aStone(g,x,y,14+rpw2aR(i)*14,i);break;
  case'shell':rpw2aShell(g,x,y,8+rpw2aR(i)*5,rpw2aR(i+1)*6,i);break;case'star':rpw2aStar(g,x,y,8+rpw2aR(i)*4,rpw2aR(i)*6,['#ff7a4a','#ff5a8a','#ffb43a'][i%3]);break;
  case'fern':rpw2aBush(g,x,y,18+rpw2aR(i)*8,i,{nofl:1,cols:['#58c452','#3fae4a','#2e8a3e']});break;
  case'drift':rpw2aDrift(g,x,y,40+rpw2aR(i)*30,(rpw2aR(i)-.5)*.8);break;case'pool':rpw2aPool(g,x,y,20+rpw2aR(i)*8,i);break;
  case'boat':rpw2aBoat(g,x,y,60,1.9,'#e85a4a');break;case'hammock':rpw2aPalm(g,x-48,y-4,96,3,{lean:-.25});rpw2aPalm(g,x+48,y,92,8,{lean:.25});rpw2aHammock(g,x-38,y-62,x+38,y-60);break;case'castle':rpw2aSandcastle(g,x,y,it.s);break;case'chest':rpw2aChest(g,x,y,it.s);break;
  default:rpw2aTuft(g,x,y,16+rpw2aR(i)*8,F.at(x,y)>-80?'#8aa048':'#2e8a3a',6)}}
 B.trees=items;
 /* the sea cave where the road starts, then the castle */
 for(const e of G.ent)rpw2aSeaCave(g,Math.max(30,e.x-14),e.y,'coral');
 g.drawImage(A.c,cast.x,cast.y,A.w,A.h);
 /* shore points for the live waves (not under the castle), water spots for sparkles */
 B.shore=rpw2aShore(F,15,(x,y)=>!(x>cast.x+10&&y>cast.y));
 B.sea=[];for(let i=0;i<600&&B.sea.length<60;i++){const x=rpw2aR(i*7+50)*1600,y=rpw2aR(i*7+51)*900;if(F.at(x,y)>24&&!(x>cast.x&&y>cast.y))B.sea.push([x,y,F.at(x,y)])}
 return B}
/* ---------- sea caves (the road comes out of them); kind: coral sandstone, wreck dark basalt, abyss glowing deep rock ---------- */
const RPW2A_CAVE={coral:{r:['#c8a070','#f0d0a0','#8a6440'],in:'#1a2a3a',gl:'80,220,230',weed:'#2e9a5a'},wreck:{r:['#5a6470','#8a96a4','#343c48'],in:'#0a0e16',gl:'255,190,90',weed:'#3a6a3a'},
 abyss:{r:['#24345a','#4a6496','#121c36'],in:'#02040e',gl:'120,90,255',weed:'#1a6a6a'}};
function rpw2aSeaCave(g,x,y,kind){const K=RPW2A_CAVE[kind],R=K.r;g.save();g.translate(x,y);
 rpw2aBlob(g,6,50,84,20,'#000',.3);
 const out=()=>{g.beginPath();g.moveTo(-74,58);g.lineTo(-66,-20);g.quadraticCurveTo(-60,-70,-26,-90);g.quadraticCurveTo(10,-104,42,-84);g.quadraticCurveTo(72,-62,72,-8);g.lineTo(78,58);g.closePath()};
 out();let q=g.createLinearGradient(-70,0,76,0);q.addColorStop(0,R[1]);q.addColorStop(.45,R[0]);q.addColorStop(1,R[2]);g.fillStyle=q;g.fill();rpw2aOut(g,3);
 g.save();out();g.clip();g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1.6;g.beginPath();for(let k=0;k<7;k++){const yy=-74+k*18;g.moveTo(-70,yy+rpw2aR(k)*8);g.quadraticCurveTo(0,yy-6,74,yy+rpw2aR(k+3)*10)}g.stroke();
 g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.moveTo(-62,-18);g.quadraticCurveTo(-54,-66,-24,-84);g.lineTo(-30,-66);g.quadraticCurveTo(-48,-44,-50,0);g.closePath();g.fill();g.restore();
 /* the mouth */
 const mo=()=>{g.beginPath();g.moveTo(-44,58);g.lineTo(-40,-6);g.quadraticCurveTo(-30,-54,6,-58);g.quadraticCurveTo(44,-54,46,-4);g.lineTo(48,58);g.closePath()};
 mo();q=g.createLinearGradient(0,-58,0,58);q.addColorStop(0,K.in);q.addColorStop(1,'#000');g.fillStyle=q;g.fill();rpw2aOut(g,2.6);
 g.save();mo();g.clip();g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpw2aGl(K.gl,60),-56,-10,112,90);g.globalCompositeOperation='source-over';g.globalAlpha=1;
 /* water inside the cave */
 g.fillStyle=kind==='coral'?'#1aa6c0':kind==='wreck'?'#1e4a56':'#1a2a7a';g.beginPath();g.moveTo(-50,40);g.quadraticCurveTo(0,30,50,40);g.lineTo(50,60);g.lineTo(-50,60);g.closePath();g.fill();
 g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.6;g.beginPath();g.moveTo(-34,42);g.quadraticCurveTo(-20,38,-6,42);g.moveTo(8,40);g.quadraticCurveTo(22,36,34,41);g.stroke();
 /* stalactites */
 g.fillStyle=R[2];for(let k=0;k<6;k++){const sx=-30+k*12,sy=-46+Math.abs(k-2.5)*5;g.beginPath();g.moveTo(sx-5,sy-12);g.lineTo(sx,sy+8+(k%3)*5);g.lineTo(sx+5,sy-12);g.closePath();g.fill();rpw2aOut(g,1.6)}g.restore();
 /* rim details per kind */
 if(kind==='coral'){for(const [cx,cy,s,k,c] of[[-60,40,20,0,['#ff6a8a','#ffc0cc','#b83a5a']],[60,44,18,2,['#ff9a4a','#ffd8a8','#c05a1a']],[-50,-46,14,1,['#b07aff','#e0c8ff','#6a3ac0']],[50,-58,14,3,['#ffd84a','#fff4b0','#c09a1a']]])rpw2aCoral(g,cx,cy,s,k,c,cx);
  rpw2aStar(g,24,-76,9,.4,'#ff7a4a');rpw2aShell(g,-20,-86,9,-.2,0)}
 else if(kind==='wreck'){/* a lantern on a hook and a skull mark */g.strokeStyle=RPO;g.lineWidth=2.4;g.beginPath();g.moveTo(52,-60);g.lineTo(66,-60);g.lineTo(66,-44);g.stroke();
  g.fillStyle='#3a2a1a';g.fillRect(60,-44,12,16);g.strokeRect(60,-44,12,16);g.fillStyle='#ffd27a';g.fillRect(62.5,-41,7,10);
  g.fillStyle='#e8e0cc';g.beginPath();g.arc(2,-74,9,0,TAU);g.fill();rpw2aOut(g,1.8);g.fillStyle=RPO;g.beginPath();g.arc(-1.5,-75,2.2,0,TAU);g.arc(5.5,-75,2.2,0,TAU);g.fill();g.fillRect(-1,-68,6,2)}
 else{g.globalCompositeOperation='lighter';for(const [cx,cy,c] of[[-58,30,'90,240,255'],[58,20,'255,90,220'],[-40,-70,'120,255,200']]){g.globalAlpha=.6;g.drawImage(rpw2aGl(c,18),cx-18,cy-18)}g.globalCompositeOperation='source-over';g.globalAlpha=1;
  for(const [cx,cy,c] of[[-58,30,'#6af0ff'],[58,20,'#ff7ae8'],[-40,-70,'#7affc8']]){g.fillStyle=c;g.beginPath();g.arc(cx,cy,4,0,TAU);g.fill();rpw2aOut(g,1.4)}}
 /* hanging weed */
 g.strokeStyle=K.weed;g.lineWidth=2.6;for(const vx of[-36,-14,10,30]){g.beginPath();g.moveTo(vx,-50+Math.abs(vx)*.1);g.quadraticCurveTo(vx+5,-30,vx-2,-14+(vx%3)*4);g.stroke()}
 g.restore()}
/* ---------- the three castles: 300 x 520, painted at 2x like 95h's; the gate point (gx, gy) sits on the road's end ----------
   They reuse 95h's wall, drum, window, banner and gate painters with their own palettes, plus their own roofs: conch spires and a
   scallop crest (coral), plank roofs, a crow's nest and cannons (wreck), domes and a pearl (abyss). */
const RPW2A_CP={
 coral:{st:'#f6dcd4',sl:'#fff6f0',sd:'#dca8a8',sk:'#a8707e',roof:'#ffb89a',rl:'#fff0e0',rd:'#d8706a',ban:'#1ec0c8',ban2:'#fff6e0',win:'#c4fbff',winG:'140,240,255',rock:'#c8a070',rockL:'#f0d0a0',rockD:'#8a6440',wood:'#a8784a',iron:'#4a6070'},
 wreck:{st:'#8a8478',sl:'#b8b2a4',sd:'#5e584e',sk:'#3a3630',roof:'#7a4a2a',rl:'#a8723e',rd:'#4a2a16',ban:'#1a1420',ban2:'#f0e8d8',win:'#ffc46a',winG:'255,180,80',rock:'#4e5864',rockL:'#7e8a98',rockD:'#2a323c',wood:'#6a4426',iron:'#2e2a30'},
 abyss:{st:'#5aa0b8',sl:'#a8e8f0',sd:'#2e6a88',sk:'#1a3a5a',roof:'#2ab0a0',rl:'#8af0d8',rd:'#14606a',ban:'#7a3ad0',ban2:'#8affff',win:'#8affff',winG:'90,240,255',rock:'#24345a',rockL:'#4a6496',rockD:'#121c36',wood:'#3a4a6a',iron:'#1a2a40'}};
const RPW2A_CW=300,RPW2A_CH=520,RPW2A_GX=140,RPW2A_GY=440;
/* a spiral conch spire: a bulging cone wrapped by a spiral with knobs, a pearl on the tip */
function rpw2aConch(g,P,cx,by,R,h,A,flag){const E=R*.3,ay=by-h;
 const path=()=>{g.beginPath();g.moveTo(cx-R,by);g.bezierCurveTo(cx-R*1.05,by-h*.4,cx-R*.3,by-h*.75,cx,ay);g.bezierCurveTo(cx+R*.3,by-h*.75,cx+R*1.05,by-h*.4,cx+R,by);g.ellipse(cx,by,R,E,0,0,Math.PI);g.closePath()};
 g.save();path();let q=g.createLinearGradient(cx-R,0,cx+R,0);q.addColorStop(0,P.roof);q.addColorStop(.28,P.rl);q.addColorStop(.6,P.roof);q.addColorStop(1,P.rd);g.fillStyle=q;g.fill();g.clip();
 const n=Math.max(3,Math.round(h/16));for(let k=0;k<n;k++){const y0=by-h*(k/n),y1=by-h*((k+1)/n),w0=R*Math.pow(1-k/n,.8);
  g.strokeStyle='rgba(120,40,40,.42)';g.lineWidth=2;g.beginPath();g.moveTo(cx-w0*1.1,y0+E*.6);g.quadraticCurveTo(cx,y0-h/n*.2,cx+w0*1.1,y1+E*.2);g.stroke();
  g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=1.4;g.beginPath();g.moveTo(cx-w0,y0+E*.6-3);g.quadraticCurveTo(cx-w0*.2,y0-h/n*.25-2,cx+w0*.4,y1+E*.4);g.stroke()}
 g.fillStyle='rgba(255,255,255,.25)';g.beginPath();g.moveTo(cx-R*.7,by);g.bezierCurveTo(cx-R*.8,by-h*.4,cx-R*.25,by-h*.7,cx,ay+4);g.bezierCurveTo(cx-R*.4,by-h*.6,cx-R*.45,by-h*.3,cx-R*.4,by);g.closePath();g.fill();
 g.restore();path();rpw2aOut(g,2.6);
 /* knobs along the silhouette */
 for(let k=1;k<n;k++){const v=k/n,y=by-h*v,w=R*Math.pow(1-v,.8)*1.02;for(const s of[-1,1]){g.fillStyle=s<0?P.rl:P.roof;g.beginPath();g.ellipse(cx+s*w,y,2.6,3.4,0,0,TAU);g.fill();rpw2aOut(g,1.4)}}
 g.strokeStyle=P.rd;g.lineWidth=3;g.beginPath();g.ellipse(cx,by,R-1,E-1,0,.15,Math.PI-.15);g.stroke();
 g.fillStyle='#fff8f4';g.beginPath();g.arc(cx,ay-3,4.2,0,TAU);g.fill();rpw2aOut(g,1.6);g.fillStyle='#ffffff';g.beginPath();g.arc(cx-1.4,ay-4.4,1.4,0,TAU);g.fill();A.spark.push([cx,ay-3]);
 if(flag){g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(cx,ay-7);g.lineTo(cx,ay-20);g.stroke();A.flags.push({x:cx,y:ay-20,len:flag,col:P.ban,c2:P.ban2})}}
/* a scallop shell fan (crest, gate arch): centre bottom at (x, y), radius r */
function rpw2aScallop(g,x,y,r,C,a0,a1){a0=a0==null?Math.PI*1.04:a0;a1=a1==null?Math.PI*1.96:a1;const n=11;
 const path=()=>{g.beginPath();g.moveTo(x,y);for(let k=0;k<n;k++){const u0=a0+(a1-a0)*k/n,u1=a0+(a1-a0)*(k+1)/n,um=(u0+u1)/2;g.lineTo(x+Math.cos(u0)*r,y+Math.sin(u0)*r);g.quadraticCurveTo(x+Math.cos(um)*r*1.1,y+Math.sin(um)*r*1.1,x+Math.cos(u1)*r,y+Math.sin(u1)*r)}g.closePath()};
 path();const q=g.createRadialGradient(x,y,r*.1,x,y,r*1.05);q.addColorStop(0,C[0]);q.addColorStop(.6,C[1]);q.addColorStop(1,C[2]);g.fillStyle=q;g.fill();
 g.save();path();g.clip();for(let k=0;k<n;k++){const u0=a0+(a1-a0)*k/n,u1=a0+(a1-a0)*(k+1)/n;g.fillStyle=k%2?'rgba(255,255,255,.22)':'rgba(140,40,60,.12)';g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(u0)*r*1.2,y+Math.sin(u0)*r*1.2);g.lineTo(x+Math.cos(u1)*r*1.2,y+Math.sin(u1)*r*1.2);g.closePath();g.fill()}
 g.strokeStyle='rgba(140,50,60,.35)';g.lineWidth=1.4;for(const f of[.35,.6,.82]){g.beginPath();g.arc(x,y,r*f,a0,a1);g.stroke()}g.restore();path();rpw2aOut(g,2.4);
 g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=1.3;g.beginPath();for(let k=1;k<n;k++){const u=a0+(a1-a0)*k/n;g.moveTo(x+Math.cos(u)*r*.18,y+Math.sin(u)*r*.18);g.lineTo(x+Math.cos(u)*r*.97,y+Math.sin(u)*r*.97)}g.stroke()}
/* rounded merlons with a pearl on each (coral) */
function rpw2aCrenR(g,P,x,y,w,mw,pearl){mw=mw||9;const gap=mw*.6,n=Math.max(1,Math.floor((w+gap)/(mw+gap))),sp=n>1?(w-n*mw)/(n-1):0;
 for(let i=0;i<n;i++){const xx=x+i*(mw+sp);g.beginPath();g.moveTo(xx,y+1);g.lineTo(xx,y-mw*.5);g.arc(xx+mw/2,y-mw*.5,mw/2,Math.PI,0);g.lineTo(xx+mw,y+1);g.closePath();g.fillStyle=P.st;g.fill();rpw2aOut(g,2);
  g.fillStyle='rgba(255,255,255,.6)';g.fillRect(xx+1.5,y-mw*.5,mw*.24,mw*.5);if(pearl){g.fillStyle=pearl;g.beginPath();g.arc(xx+mw/2,y-mw-1.5,2.2,0,TAU);g.fill();rpw2aOut(g,1.1)}}}
function rpw2aPaintCoral(g,A){const P=RPW2A_CP.coral,id='moss';A.P=P;
 g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.ellipse(196,508,116,16,0,0,TAU);g.fill();
 /* the giant scallop crest behind the keep */
 g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.45;g.drawImage(rpw2aGl('255,200,230',110),50,40,240,220);g.restore();
 rpw2aScallop(g,170,236,136,['#fff8f4','#ffd0c8','#f0909a']);
 /* reef rocks behind the right side with a turquoise waterfall from a shell spout */
 rpwRocks(g,P,'coral',[[280,320,40,56],[286,390,36,70],[282,460,44,80],[288,520,40,90]],40);
 {const fall=()=>{g.beginPath();g.moveTo(266,300);g.quadraticCurveTo(286,306,290,336);g.lineTo(296,490);g.quadraticCurveTo(300,506,292,514);g.lineTo(262,514);g.quadraticCurveTo(254,500,268,486);g.lineTo(274,336);g.quadraticCurveTo(274,312,266,300);g.closePath()};
  fall();const q=g.createLinearGradient(262,0,298,0);q.addColorStop(0,'#c4fff6');q.addColorStop(.5,'#52e0e0');q.addColorStop(1,'#1a9ac8');g.fillStyle=q;g.fill();
  g.save();fall();g.clip();g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.4;g.beginPath();for(const x of[279,285,290]){g.moveTo(x,314);g.lineTo(x+1,500)}g.stroke();g.restore();fall();rpw2aOut(g,2.4);A.rain=[262,300,34,214];
  rpw2aShell(g,268,300,26,-.5,1)}
 /* the keep: a conch tower in two tiers */
 {const cx=168,t1=rpwDrum(g,P,cx,226,52,104,11);rpw2aCrenR(g,P,cx-26,t1+2,52,8,'#fff8f4');const t2=rpwDrum(g,P,cx,t1-4,36,30,12);rpw2aConch(g,P,cx,t2,22,92,A,30);
  rpwWin(g,P,id,A,cx-6,t1+24,12,22);rpwWin(g,P,id,A,cx-4,t2+8,8,14)}
 /* the main hall with a rose shell window */
 rpwWall(g,P,112,182,114,160,31,10);rpw2aCrenR(g,P,112,182,114,10,'#fff8f4');
 {const x=169,y=238;rpw2aScallop(g,x,y+16,30,['#c4fbff','#52e0e0','#1a8aa8']);A.wins.push([x,y,34]);A.rose=[x,y]}
 for(const [x,y] of[[124,206],[204,206],[126,276],[202,276]])rpwWin(g,P,id,A,x,y,11,20);
 for(const cx of[112,226]){const t=rpwDrum(g,P,cx,306,30,150,cx);rpw2aConch(g,P,cx,t,17,66,A,cx===226?22:0);rpwWin(g,P,id,A,cx-4,t+30,8,15)}
 /* curtain walls */
 rpwWall(g,P,56,268,64,92,51,9);rpw2aCrenR(g,P,56,268,64,9);rpwWall(g,P,184,306,40,170,61,9);rpw2aCrenR(g,P,184,306,40,9);
 /* left tower */
 {const t=rpwDrum(g,P,46,366,46,174,71);rpw2aConch(g,P,46,t,27,96,A,26);rpwWin(g,P,id,A,40,t+34,11,20);rpwWin(g,P,id,A,40,t+96,11,20);
  for(let k=0;k<7;k++){g.fillStyle='#fff8f4';g.beginPath();g.arc(46+Math.cos(Math.PI*(.1+k*.13))*23,t+60+Math.sin(Math.PI*(.1+k*.13))*7,2,0,TAU);g.fill();rpw2aOut(g,.9)}}
 rpwRocks(g,P,'coral',[[18,388,40,30],[52,394,58,34],[88,388,40,24],[30,376,30,20]],7);
 rpw2aCoral(g,14,392,22,0,RPW2A_CORAL[0],3);rpw2aCoral(g,34,394,16,2,RPW2A_CORAL[2],5);rpw2aCoral(g,84,388,14,3,RPW2A_CORAL[3],7);
 /* right great tower */
 {const cx=246,t=rpwDrum(g,P,cx,494,70,234,81);rpw2aCrenR(g,P,cx-35,t+2,70,9,'#fff8f4');const t2=rpwDrum(g,P,cx,t-4,50,30,82);rpw2aConch(g,P,cx,t2,32,120,A,34);
  rpwWin(g,P,id,A,cx-6,t+40,12,22);rpwWin(g,P,id,A,cx-16,t+108,11,20);rpwWin(g,P,id,A,cx+8,t+156,10,18);rpwBanner(g,P,'wonder',cx-10,t+62,20,44);
  rpw2aStar(g,cx+18,t+130,9,.3,'#ff8a5a');rpw2aStar(g,cx-22,t+190,7,-.4,'#ffb43a')}
 /* the gatehouse with a scallop arch */
 rpwWall(g,P,96,330,88,146,91,9);rpw2aCrenR(g,P,96,330,88,9,'#fff8f4');g.fillStyle=P.sl;g.fillRect(90,470,100,7);g.strokeStyle=RPO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,'coral',A,RPW2A_GX,470,48,82);rpw2aScallop(g,RPW2A_GX,372,34,['#fff6f0','#ffc0b8','#f08a90'],Math.PI*1.06,Math.PI*1.94);
 g.fillStyle='#fff8f4';g.beginPath();g.arc(RPW2A_GX,346,5,0,TAU);g.fill();rpw2aOut(g,1.6);A.spark.push([RPW2A_GX,346]);
 rpwBanner(g,P,'wonder',101,346,15,40);rpwBanner(g,P,'wonder',164,346,15,40);rpwTorch(g,A,108,406);rpwTorch(g,A,172,406);
 for(const cx of[96,184]){g.fillStyle=P.sd;g.beginPath();g.moveTo(cx-12,364);g.lineTo(cx,386);g.lineTo(cx+12,364);g.closePath();g.fill();rpw2aOut(g,2.2);
  const t=rpwDrum(g,P,cx,366,24,48,cx+3);rpw2aConch(g,P,cx,t,14,40,A,0)}
 /* a sand ramp instead of a drawbridge, coral and shells at the foot */
 g.fillStyle='#f0d49a';g.beginPath();g.moveTo(112,476);g.lineTo(168,476);g.lineTo(178,500);g.lineTo(102,500);g.closePath();g.fill();rpw2aOut(g,2.2);
 g.strokeStyle='rgba(170,130,70,.5)';g.lineWidth=1.4;g.beginPath();for(const y of[484,492]){g.moveTo(110,y);g.lineTo(172,y)}g.stroke();
 rpwRocks(g,P,'coral',[[206,510,56,30],[248,518,70,34],[288,516,40,26],[196,496,26,16]],27);
 for(const [x,y,s,k,c] of[[200,504,20,0,0],[226,510,16,3,3],[266,514,22,2,5],[290,508,14,1,1],[182,500,12,0,4]])rpw2aCoral(g,x,y,s,k,RPW2A_CORAL[c],x);
 rpw2aStar(g,240,500,8,.2,'#ff7a4a');rpw2aShell(g,214,516,10,.2,0);rpw2aShell(g,62,398,9,-.3,1);
 A.spark.push([169,238],[22,360],[214,470],[276,320],[246,160])}
function rpw2aCastle(id){if(RPW2A.c['cs_'+id])return RPW2A.c['cs_'+id];
 const A={id,w:RPW2A_CW,h:RPW2A_CH,gx:RPW2A_GX,gy:RPW2A_GY,flags:[],wins:[],torch:[],spark:[],ember:[],lant:[],bub:[],lava:null,fire:null,gem:null,rain:null,rose:null};
 const c2=rpw2aCv(RPW2A_CW*2,RPW2A_CH*2),g=c2.getContext('2d');g.lineJoin='round';g.lineCap='round';g.scale(2,2);
 (id==='wreck'&&typeof rpw2aPaintWreck==='function'?rpw2aPaintWreck:id==='abyss'&&typeof rpw2aPaintAbyss==='function'?rpw2aPaintAbyss:rpw2aPaintCoral)(g,A);
 const c=rpw2aCv(RPW2A_CW,RPW2A_CH),h=c.getContext('2d');h.imageSmoothingQuality='high';h.drawImage(c2,0,0,RPW2A_CW,RPW2A_CH);A.c=c;A.c2=c2;return RPW2A.c['cs_'+id]=A}
/* the castle's live layer at its top-left (x, y): pennants, window and torch light, waterfall, lanterns, bubbles, sparkles */
function rpw2aCastleLive(g,A,x,y,t,lite){const P=A.P;g.save();g.translate(x,y);
 for(let i=0;i<A.flags.length;i++){const f=A.flags[i],L=f.len,n=6;g.beginPath();g.moveTo(f.x,f.y);
  for(let k=1;k<=n;k++){const u=k/n;g.lineTo(f.x+L*u,f.y+Math.sin(t*5+i*1.7-u*3)*3*u+u*2)}for(let k=n;k>=0;k--){const u=k/n;g.lineTo(f.x+L*u,f.y+9*(1-u*.85)+Math.sin(t*5+i*1.7-u*3)*3*u+u*2)}
  g.closePath();g.fillStyle=f.col;g.fill();g.strokeStyle=RPO;g.lineWidth=1.6;g.stroke();g.fillStyle=f.c2;g.fillRect(f.x,f.y+3,L*.35,1.8)}
 g.globalCompositeOperation='lighter';const gw=rpw2aGl(P.winG,24);
 for(let i=lite?1:0;i<A.wins.length;i+=lite?5:2){const w=A.wins[i],a=.24+.12*Math.sin(t*3.1+i*2.3)+.05*Math.sin(t*11+i);g.globalAlpha=a;g.drawImage(gw,w[0]-w[2],w[1]-w[2],w[2]*2,w[2]*2)}
 const tg=rpw2aGl(A.id==='abyss'?'120,255,240':'255,170,70',24);for(let i=0;i<A.torch.length;i++){const p=A.torch[i],f=.85+.15*Math.sin(t*13+i*3)+.08*Math.sin(t*29+i);g.globalAlpha=.55;g.drawImage(tg,p[0]-22*f,p[1]-26*f,44*f,44*f);
  g.globalAlpha=1;g.fillStyle=A.id==='abyss'?'#5af0e0':'#ff8a2a';g.beginPath();g.ellipse(p[0],p[1]-5*f,3.6,7*f,0,0,TAU);g.fill();g.fillStyle=A.id==='abyss'?'#e0fffa':'#ffe27a';g.beginPath();g.ellipse(p[0],p[1]-3.5*f,1.8,3.8*f,0,0,TAU);g.fill()}
 if(A.lant.length){const lg=rpw2aGl('255,180,80',30);for(let i=0;i<A.lant.length;i++){const p=A.lant[i],f=.8+.2*Math.sin(t*4+i*2)+.06*Math.sin(t*17+i);g.globalAlpha=.5*f;g.drawImage(lg,p[0]-30*f,p[1]-30*f,60*f,60*f)}}
 if(A.rain){const L=A.rain;g.globalAlpha=.6;g.fillStyle='#ffffff';g.beginPath();for(let i=0;i<6;i++){const u=(t*.6+i/6)%1;g.rect(L[0]+10+(i%3)*7,L[1]+12+u*(L[3]-24),2,10)}g.fill();g.globalAlpha=.3+.15*Math.sin(t*2);g.drawImage(rpw2aGl('140,255,250',30),L[0]-16,L[1]+L[3]-36,66,60)}
 if(A.rose&&!lite){g.globalAlpha=.3+.2*Math.sin(t*1.6);g.drawImage(rpw2aGl(P.winG,30),A.rose[0]-30,A.rose[1]-30)}
 if(A.gem){g.globalAlpha=.4+.3*Math.sin(t*2.2);g.drawImage(rpw2aGl('200,250,255',36),A.gem[0]-36,A.gem[1]-36)}
 if(A.fire){const f=A.fire,k=.5+.25*Math.sin(t*7)+.12*Math.sin(t*17);g.globalAlpha=k;g.drawImage(rpw2aGl('255,140,40',40),f[0]-44,f[1]-40,88,70);
  g.globalAlpha=.75;g.fillStyle='#ffd45a';g.beginPath();for(let i=0;i<3;i++){const u=(t*.8+i/3)%1,x=f[0]-8+i*8+Math.sin(t*3+i)*3,y=f[1]-6-u*30,r=2*(1-u)+.6;g.moveTo(x+r,y);g.arc(x,y,r,0,TAU)}g.fill()}
 g.globalCompositeOperation='source-over';g.globalAlpha=1;
 if(A.jolly)g.drawImage(rpw2aFlagSpr(lite?0:((t*8)|0)%6),A.jolly[0]-2,A.jolly[1]-4);
 if(A.bub.length&&!lite){g.globalAlpha=.75;g.strokeStyle='#c8ffff';g.lineWidth=1.2;g.beginPath();for(let i=0;i<A.bub.length*3;i++){const b=A.bub[i%A.bub.length],u=(t*.35+i*.37)%1,bx=b[0]+Math.sin(t*2+i)*4,by=b[1]-u*90,r=1.5+u*2.5;g.moveTo(bx+r,by);g.arc(bx,by,r,0,TAU)}g.stroke()}
 if(A.spark.length&&!lite){g.fillStyle='#ffffff';g.globalAlpha=.9;g.beginPath();for(let i=0;i<A.spark.length;i++){const p=A.spark[i],u=(t*.6+i*.37)%1,a=Math.max(0,Math.sin(u*Math.PI));if(a<.15)continue;const s=a*4.5;
   g.moveTo(p[0],p[1]-s*1.6);g.lineTo(p[0]+s*.35,p[1]-s*.35);g.lineTo(p[0]+s*1.6,p[1]);g.lineTo(p[0]+s*.35,p[1]+s*.35);g.lineTo(p[0],p[1]+s*1.6);g.lineTo(p[0]-s*.35,p[1]+s*.35);g.lineTo(p[0]-s*1.6,p[1]);g.lineTo(p[0]-s*.35,p[1]-s*.35);g.closePath()}g.fill()}
 g.restore()}
/* the hit flinch: a red flash over the castle, a little shake and flying bits (k 0..1) */
function rpw2aCastleHit(g,A,x,y,k){if(k<0||k>=1)return;
 if(!A.red){const c=rpw2aCv(A.w,A.h),h=c.getContext('2d');h.drawImage(A.c,0,0);h.globalCompositeOperation='source-in';h.fillStyle='#ff2a3a';h.fillRect(0,0,A.w,A.h);A.red=c}
 const e=1-k,dx=Math.sin(k*46)*5*e,dy=Math.cos(k*39)*2*e;g.save();g.globalAlpha=.55*e;g.drawImage(A.red,x+dx,y+dy);g.globalAlpha=Math.min(1,e*1.4);
 const cols=A.id==='coral'?['#fff6f0','#ffb89a','#ff6a8a']:A.id==='wreck'?['#8a8478','#6a4426','#3a3630']:['#5aa0b8','#8affff','#2e6a88'];
 for(let i=0;i<8;i++){const a=-Math.PI*(.15+rpw2aR(i+3)*.7),v=40+rpw2aR(i+9)*70,px=x+A.gx+30+rpw2aR(i)*80+Math.cos(a)*v*k,py=y+A.gy-60-rpw2aR(i+5)*120+Math.sin(a)*v*k+160*k*k;
  g.fillStyle=cols[i%3];g.beginPath();if(A.id==='coral'&&i%2){g.arc(px,py,3.2,0,TAU)}else g.rect(px-3,py-3,6,5);g.fill();g.strokeStyle=RPO;g.lineWidth=1.4;g.stroke()}g.restore()}
/* ---------- live layers shared by the maps ---------- */
/* shore waves: foam arcs that roll in toward every shore point and fade (3 alpha buckets, one path each) */
function rpw2aWaves(c,S,t,lite,col,amp,push){if(!S||!S.length)return;const st=lite?2:1,B=[[],[],[]];amp=amp||16;push=push||0;
 for(let i=0;i<S.length;i+=st){const p=S[i],u=(t*.32+p.i*.137)%1,a=Math.sin(u*Math.PI);if(a<.2)continue;B[a>.75?2:a>.45?1:0].push([p,amp*(1-u)+3-push])}
 c.lineWidth=2.4;c.strokeStyle=col||'#ffffff';for(let b=0;b<3;b++){if(!B[b].length)continue;c.globalAlpha=[.3,.55,.8][b];c.beginPath();
  for(const [p,o] of B[b]){const x=p.x+p.nx*o,y=p.y+p.ny*o,tx=-p.ny*9,ty=p.nx*9;c.moveTo(x-tx,y-ty);c.quadraticCurveTo(x-p.nx*3.5,y-p.ny*3.5,x+tx,y+ty)}c.stroke()}c.globalAlpha=1}
/* twinkles: 4-point stars at fixed spots */
function rpw2aTwinkle(c,L,t,sz,col,rate){c.fillStyle=col||'#ffffff';c.beginPath();for(let i=0;i<L.length;i++){const p=L[i],u=(t*(rate||.5)+i*.371)%1;if(u>.4)continue;const s=Math.sin(u/.4*Math.PI)*(sz||4);
 c.moveTo(p[0],p[1]-s*1.6);c.lineTo(p[0]+s*.3,p[1]-s*.3);c.lineTo(p[0]+s*1.6,p[1]);c.lineTo(p[0]+s*.3,p[1]+s*.3);c.lineTo(p[0],p[1]+s*1.6);c.lineTo(p[0]-s*.3,p[1]+s*.3);c.lineTo(p[0]-s*1.6,p[1]);c.lineTo(p[0]-s*.3,p[1]-s*.3);c.closePath()}c.fill()}
/* a gull seen from above: wings flap with ph; shadow=1 draws its ground shadow */
function rpw2aGull(c,x,y,s,a,ph,shadow){const f=Math.sin(ph);c.save();c.translate(x,y);c.rotate(a);c.scale(s,s);
 if(shadow){c.fillStyle='rgba(20,40,40,.22)';c.beginPath();c.moveTo(-14,-2-f*4);c.quadraticCurveTo(-6,-6,0,0);c.quadraticCurveTo(6,-6,14,-2-f*4);c.quadraticCurveTo(6,-1,0,3);c.quadraticCurveTo(-6,-1,-14,-2-f*4);c.fill();c.restore();return}
 c.fillStyle='#ffffff';c.strokeStyle=RPO;c.lineWidth=1.6/s;c.beginPath();c.moveTo(-15,-3-f*6);c.quadraticCurveTo(-7,-8,0,-1);c.quadraticCurveTo(7,-8,15,-3-f*6);c.quadraticCurveTo(7,-2,0,4);c.quadraticCurveTo(-7,-2,-15,-3-f*6);c.closePath();c.fill();c.stroke();
 c.fillStyle='#3a3a4a';c.beginPath();c.moveTo(-15,-3-f*6);c.lineTo(-11,-4.5-f*4.5);c.lineTo(-12,-1.5-f*4);c.closePath();c.fill();c.beginPath();c.moveTo(15,-3-f*6);c.lineTo(11,-4.5-f*4.5);c.lineTo(12,-1.5-f*4);c.closePath();c.fill();
 c.fillStyle='#ffb43a';c.beginPath();c.moveTo(0,-4.5);c.lineTo(1.6,-7);c.lineTo(-1.6,-7);c.closePath();c.fill();c.restore()}
/* the fish (three colours, 40 x 24 each) and the sea turtle (four flipper frames, 80 x 70 each) in one atlas, pointing right */
function rpw2aSeaAtlas(){return rpw2aSpr('seaatlas',320,94,g=>{for(let k=0;k<3;k++){const C=[['#ffb43a','#ff6a2a'],['#5af0ff','#1a8ad8'],['#ff7ad0','#c03aa0']][k];g.save();g.translate(20+k*40,12);
  g.beginPath();g.moveTo(-14,0);g.lineTo(-19,-6);g.lineTo(-18,6);g.closePath();g.fillStyle=C[1];g.fill();g.strokeStyle=RPO;g.lineWidth=1.4;g.stroke();
  g.beginPath();g.ellipse(0,0,13,6.5,0,0,TAU);g.fillStyle=C[0];g.fill();g.stroke();g.fillStyle='#ffffff';g.fillRect(-4,-6,3,12);g.fillStyle=RPO;g.beginPath();g.arc(7,-1.5,1.6,0,TAU);g.fill();g.restore()}
 for(let f=0;f<4;f++){g.save();g.translate(40+f*80,24+35);const fl=Math.sin(f/4*TAU)*.5;g.lineWidth=2;g.strokeStyle=RPO;
  for(const [sx,sy,ln] of[[1,1,1],[1,-1,1],[-1,1,.6],[-1,-1,.6]]){g.save();g.translate(sx*10,sy*10);g.rotate(sy*(sx>0?.5+fl:.9-fl*.5));g.fillStyle='#5ab888';g.beginPath();g.ellipse(sx*ln*9,0,ln*12,5,0,0,TAU);g.fill();g.stroke();g.restore()}
  g.fillStyle='#5ab888';g.beginPath();g.ellipse(22,0,8,6.5,0,0,TAU);g.fill();g.stroke();g.fillStyle=RPO;g.beginPath();g.arc(25,-3,1.4,0,TAU);g.arc(25,3,1.4,0,TAU);g.fill();
  g.beginPath();g.ellipse(0,0,19,15,0,0,TAU);const q=g.createRadialGradient(-4,-4,2,0,0,19);q.addColorStop(0,'#c8a060');q.addColorStop(1,'#7a5a2a');g.fillStyle=q;g.fill();g.stroke();
  g.strokeStyle='rgba(40,25,10,.6)';g.lineWidth=1.3;g.beginPath();for(let k=0;k<6;k++){const a=k/6*TAU;g.moveTo(Math.cos(a)*7,Math.sin(a)*6);g.lineTo(Math.cos(a)*17,Math.sin(a)*13)}g.moveTo(7,0);g.ellipse(0,0,7,6,0,0,TAU);g.stroke();g.restore()}})}
/* the flood water of a tide stretch (baked once per stretch): sea water with a turquoise shallow rim, caustic glints, ripples and a
   foam edge */
function rpw2aFloodSpr(r,s){return rpw2aSpr('fl'+r+'_'+s,r*2.6,r*2,g=>{const cx=r*1.3,cy=r,sh=(k)=>{g.beginPath();for(let j=0;j<=40;j++){const a=j/40*TAU,rr=r*k*(1.08+.09*Math.sin(a*4+s)+.06*Math.sin(a*7+s*2));
   j?g.lineTo(cx+Math.cos(a)*rr*1.1,cy+Math.sin(a)*rr*.74):g.moveTo(cx+Math.cos(a)*rr*1.1,cy+Math.sin(a)*rr*.74)}g.closePath()};
 sh(1);g.fillStyle='rgba(120,240,230,.62)';g.fill();sh(.84);let q=g.createRadialGradient(cx,cy,r*.1,cx,cy,r);q.addColorStop(0,'rgba(24,170,206,.86)');q.addColorStop(1,'rgba(48,206,218,.78)');g.fillStyle=q;g.fill();
 g.save();sh(1);g.clip();g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=1.8;for(let k=0;k<12;k++){const a=rpw2aR(k+s)*TAU,d=rpw2aR(k*3+s)*r*.75,x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d*.6,l=6+rpw2aR(k+9)*9;g.beginPath();g.moveTo(x-l,y);g.quadraticCurveTo(x,y-3,x+l,y);g.stroke()}
 g.lineWidth=8;g.strokeStyle='rgba(255,255,255,.3)';sh(1);g.stroke();g.lineWidth=2;g.strokeStyle='rgba(230,255,255,.75)';sh(.86);g.stroke();g.restore();
 g.lineWidth=3.2;g.strokeStyle='#ffffff';sh(1);g.stroke();g.lineWidth=1.6;g.strokeStyle='rgba(20,90,100,.7)';g.save();g.translate(0,2.4);sh(1.01);g.stroke();g.restore()})}
/* ---------- Coral Shallows: live ---------- */
function rpw2aCoralAmb(c,R){const B=R.bake,t=R.t,lite=R.lite,rm=R.rm,tk=R.tide?R.tide.k||0:0;c.save();
 /* light shimmer streaks and sparkles on the sea */
 if(!rm){c.globalCompositeOperation='lighter';c.strokeStyle='rgba(255,255,255,.5)';c.lineWidth=2;c.beginPath();const S=B.sea,n=lite?12:26;
  for(let i=0;i<n&&i<S.length;i++){const p=S[i],u=(t*.05+i*.13)%1,x=p[0]+u*40-20,y=p[1]+Math.sin(t+i)*2;c.globalAlpha=1;c.moveTo(x-9*Math.sin(u*Math.PI),y);c.lineTo(x+9*Math.sin(u*Math.PI),y)}c.stroke();
  c.globalCompositeOperation='source-over';c.globalAlpha=.9;rpw2aTwinkle(c,B.sea,t,4,'#ffffff',.45);c.globalAlpha=1}
 /* fish and a sea turtle under the water */
 if(!rm&&!lite){c.globalAlpha=.75;const AT=rpw2aSeaAtlas(),T=[[470,700,110,40,.11,0],[1170,740,90,36,-.09,2]];for(const [x0,y0,rx,ry,w,ph] of T){const a=t*w+ph,x=x0+Math.cos(a)*rx,y=y0+Math.sin(a)*ry,h=Math.atan2(Math.cos(a)*ry*w,-Math.sin(a)*rx*w);
   c.save();c.translate(x,y);c.rotate(h);c.drawImage(AT,(((t*5)|0)%4)*80,24,80,70,-40,-35,80,70);c.restore()}
  for(let s=0;s<2;s++){const cx=s?830:300,cy=s?812:830,a=t*(s?.22:-.18)+s*2;for(let i=0;i<5;i++){const b=a-i*.09,x=cx+Math.cos(b)*(70+i%2*8),y=cy+Math.sin(b)*26+Math.sin(t*3+i)*2,h=Math.atan2(Math.cos(b)*26,-Math.sin(b)*70)+(s?0:Math.PI);
    c.save();c.translate(x,y);c.rotate(h);c.drawImage(AT,((i+s)%3)*40,0,40,24,-14,-8.4,28,16.8);c.restore()}}c.globalAlpha=1}
 /* waves rolling onto the shore (pushed a little inland while the tide is high) */
 if(!rm)rpw2aWaves(c,B.shore,t,lite,'#ffffff',16,tk*6);
 /* gull shadows */
 if(!rm)for(let i=0;i<3;i++){const a=t*(.13+i*.03)+i*2.1,x=800+Math.cos(a)*(520-i*90)+60,y=430+Math.sin(a)*(260-i*40)+70;c.save();c.globalAlpha=1;rpw2aGull(c,x,y,1,a+Math.PI,t*7+i,1);c.restore()}
 /* the lighthouse: a slowly sweeping beam and the lamp */
 if(B.light){const L=B.light;c.globalCompositeOperation='lighter';c.globalAlpha=.5+.2*Math.sin(t*3);c.drawImage(rpw2aGl('255,240,170',34),L.x-34,L.y-34);
  if(!rm){const a=t*.8,dx=Math.cos(a),dy=Math.sin(a)*.45,l=Math.hypot(dx,dy);c.globalAlpha=.1+.1*Math.max(0,Math.sin(a));c.save();c.translate(L.x,L.y);c.rotate(Math.atan2(dy,dx));c.drawImage(rpw2aBeam(),0,-24,300*l,48);c.restore()}c.globalCompositeOperation='source-over';c.globalAlpha=1}
 c.restore();
 try{rpw2aCastleLive(c,rpw2aCastle('coral'),B.cast.x,B.cast.y,t,lite)}catch(e){}}
function rpw2aBeam(){return rpw2aSpr('beam',256,64,g=>{const q=g.createLinearGradient(0,0,256,0);q.addColorStop(0,'rgba(255,245,190,1)');q.addColorStop(1,'rgba(255,245,190,0)');g.fillStyle=q;g.beginPath();g.moveTo(0,28);g.lineTo(256,0);g.lineTo(256,64);g.lineTo(0,36);g.closePath();g.fill()})}
/* the rising tide: flood water spreads over the low stretches as R.tide.k goes 0..1 */
function rpw2aCoralTwist(c,R){const T=R.tide,tide=R.map.tide;if(!T||!tide)return;const k=Math.max(0,Math.min(1,T.k||0)),t=R.t;if(k<=.01)return;c.save();
 for(let i=0;i<tide.length;i++){const [x,y,r]=tide[i],s=.35+.65*k,sp=rpw2aFloodSpr(r,i),w=sp.width*s,h=sp.height*s,wb=R.rm?0:Math.sin(t*2.2+i)*.03;
  c.globalAlpha=Math.min(1,k*1.8)*.95;c.drawImage(sp,x-w/2*(1+wb),y-h/2*(1-wb),w*(1+wb),h*(1-wb));
  if(!R.rm){c.strokeStyle='#ffffff';c.lineWidth=2;for(let j=0;j<2;j++){const u=(t*.45+j*.5+i*.3)%1;c.globalAlpha=(1-u)*.55*k;c.beginPath();c.ellipse(x+Math.sin(i*3+j)*r*.25,y+Math.cos(i+j)*r*.15,r*.25*(.3+u),r*.25*(.3+u)*.6,0,0,TAU);c.stroke()}
   c.globalAlpha=.85*k;rpw2aTwinkle(c,[[x-r*.4,y-r*.2],[x+r*.35,y+r*.1],[x,y-r*.35]],t+i,3.4,'#ffffff',.7)}}
 c.restore()}
function rpw2aCoralTop(c,R){if(R.rm)return;const t=R.t;for(let i=0;i<3;i++){const a=t*(.13+i*.03)+i*2.1,x=800+Math.cos(a)*(520-i*90),y=430+Math.sin(a)*(260-i*40);rpw2aGull(c,x,y,.9+i*.08,a+Math.PI,t*7+i,0)}}
