/* ===== PERFORMANCE MODE LEAVES THE CASINO ALONE =====
   Balanced and Performance still lighten the rest of the game, but every Casino screen (the lobby, each game and all of Wildcard,
   i.e. any #ov screen with the casbg class) runs exactly as in Quality: full resolution, full-rate menu canvases, canvas glow,
   looping CSS animations, backdrop blur and Wildcard's full-length deal and effects. PFM() in 88k returns 'high' while pfCas() is true;
   pfCasSync() re-applies the mode the moment you step in or out. */
function pfCas(){try{return /\bcasbg\b/.test(ov.className)}catch(e){return false}}
const PFC={last:false};
function pfCasSync(){try{const c=pfCas();if(c===PFC.last)return;PFC.last=c;if(PFSET()==='high')return;PFBG.ok=false;applyLayout()}catch(e){}}
{const s0=show;show=function(){const r=s0.apply(this,arguments);pfCasSync();return r}}
{const h0=hide;hide=function(){const r=h0.apply(this,arguments);pfCasSync();return r}}
/* a cheap per-frame check catches any other way the overlay changes */
{const l0=loop;loop=function(ts){pfCasSync();return l0(ts)}}
/* Performance mode changes nothing in the Casino, so the "Running slowly?" offer waits until you are outside it */
{const o0=pfOffer;pfOffer=function(){if(pfCas())return;return o0.apply(this,arguments)}}
/* Every Casino screen (#ov.casbg) has an opaque background over the whole stage, so the game canvas under it is never seen.
   It still redrew the title backdrop (sky, stars, menu art) every frame behind the lobby and the games. Skip that while a
   Casino screen covers it, as Wildcard already did (89f). The canvas keeps its last picture, so nothing changes on leaving. */
{const d0=draw;draw=function(){if(S.mode==='title'&&pfCas()&&!ov.classList.contains('hide')&&!ov.classList.contains('clear'))return;return d0.apply(this,arguments)}}
/* the corner Casino button's light sweep moved its stripe with `left`, which re-ran layout and paint every frame on every
   screen; the same sweep as a transform (500% of the stripe's own 38% width = the old 190% of the button) runs on the
   compositor and looks the same */
{const st=document.createElement('style');st.textContent='@media (prefers-reduced-motion:no-preference){#cz::after{animation-name:czshine2}}@keyframes czshine2{0%,55%{transform:translateX(0) skewX(-18deg)}85%,100%{transform:translateX(500%) skewX(-18deg)}}';document.head.appendChild(st)}
