/* ===== CASINO 9.8c: Penalty Kings, the animation rigs (96zt, after 96zs) =====
   Jointed characters instead of the one-piece figures of 96zr. A pose is {hip, th (torso angle, 0 = upright, + = leaning to
   screen right), feet[2], hands[2], kb/eb (knee and elbow bend sides), look, mood, ha (head tilt)}; knees and elbows are solved
   with two-bone IK (pkIK), so feet stay planted and gloves reach exactly where the pose puts them. Poses blend (pkPoseLerp).
   Keeper (front view): ready (knee bounce, side shuffle, leaning toward his tell), crouch (anticipation), dive (push-off, a flight
   arc that stretches the body flat with both gloves reaching past the head, then a landing slide on his side), jump (centre, top),
   block (centre, low: legs spread, gloves down), celebrate (jumping, arms in a V), down (on the ground, thumping the turf),
   headhands (stands with gloves on his head).
   Kicker (back view, name and number on the shirt): idle, run (alternating strides, arm swing, bob), kick (plant the left foot,
   heel-up back-swing, strike through the ball at k = .42, high follow-through, arms out for balance), celebrate, headhands.
   Effects: pkFx particles (dust, sparks, turf), camera flashes in the crowd (pkFlashes). No shadowBlur, no ctx.filter. */
const PKR={th:38,sh:38,ua:33,fa:31,to:70,hw:14,sw:23,hd:.7};
const pkCl=u=>u<0?0:u>1?1:u,pkSm=u=>{u=pkCl(u);return u*u*(3-2*u)},pkEo=u=>1-Math.pow(1-pkCl(u),3);
const pkL=(h,th,lx,ly)=>({x:h.x+lx*Math.cos(th)-ly*Math.sin(th),y:h.y+lx*Math.sin(th)+ly*Math.cos(th)});
const pkLp=(a,b,k)=>({x:a.x+(b.x-a.x)*k,y:a.y+(b.y-a.y)*k});
/* two-bone IK: joint and end for a limb from p toward tg (lengths a, b), bending to side bend (+1 / -1) */
function pkIK(p,tg,a,b,bend){let dx=tg.x-p.x,dy=tg.y-p.y,d=Math.hypot(dx,dy);const md=a+b-.5;let ex=tg.x,ey=tg.y;if(d>md){ex=p.x+dx/d*md;ey=p.y+dy/d*md;d=md}if(d<1)d=1;
 const ang=Math.atan2(ey-p.y,ex-p.x),c=Math.max(-1,Math.min(1,(a*a+d*d-b*b)/(2*a*d))),k=ang+bend*Math.acos(c);return{j:{x:p.x+Math.cos(k)*a,y:p.y+Math.sin(k)*a},e:{x:ex,y:ey}}}
function pkLimb(g,pts,w,col){g.beginPath();g.moveTo(pts[0].x,pts[0].y);for(let i=1;i<pts.length;i++)g.lineTo(pts[i].x,pts[i].y);g.lineCap='round';g.lineJoin='round';g.lineWidth=w+6;g.strokeStyle=PKO;g.stroke();g.lineWidth=w;g.strokeStyle=col;g.stroke()}
function pkPoseLerp(A,B,k){const L=(a,b)=>pkLp(a,b,k);return{hip:L(A.hip,B.hip),th:A.th+(B.th-A.th)*k,feet:[L(A.feet[0],B.feet[0]),L(A.feet[1],B.feet[1])],hands:[L(A.hands[0],B.hands[0]),L(A.hands[1],B.hands[1])],
 kb:k<.5?A.kb:B.kb,eb:k<.5?A.eb:B.eb,look:k<.5?A.look:B.look,mood:k<.5?A.mood:B.mood,ha:(A.ha||0)+((B.ha||0)-(A.ha||0))*k}}
/* ---------- keeper poses (front view; x0 = goal centre, gy = goal line) ---------- */
function pkKeeperPose(x0,gy,P,t){if(P.blend)return pkPoseLerp(pkKeeperPose(x0,gy,P.blend[0],t),pkKeeperPose(x0,gy,P.blend[1],t),P.blend[2]);
 const st=P.st||'ready',R={th:0,look:P.look||0,mood:P.mood||0,kb:[1,-1],eb:[1,-1],ha:0};
 if(st==='ready'){const c=P.crouch||0,ln=P.lean||0,sw=Math.sin(t*1.4)*9+ln*18,bo=Math.sin(t*6.2)*2.4*(1-c*.6),x=x0+sw+(P.x||0);
  R.hip={x,y:gy-72+18*c+bo};R.th=ln*.1+Math.sin(t*1.4)*.025;R.feet=[{x:x-30-10*c,y:gy},{x:x+30+10*c,y:gy}];
  const hy=R.hip.y-34+10*c,fl=Math.sin(t*5)*3;R.hands=[{x:R.hip.x-56-8*c,y:hy+fl},{x:R.hip.x+56+8*c,y:hy-fl}];R.eb=[-1,1];return R}
 if(st==='dive'){const s=P.s,p=P.p,lift=P.lift||0,amt=P.amt||1,a=pkEo(p/.2),f=pkCl((p-.1)/.6),fe=pkEo(f),l=pkSm((p-.68)/.32);
  const Rr=150*amt,hx=x0+s*(16*a+(Rr-16)*fe),arc=(34+78*lift)*Math.sin(Math.PI*Math.min(1,f*1.1));
  let hy=gy-72+16*a*(1-fe)+((gy-26)-(gy-72))*fe-arc;hy+=(gy-22-hy)*l;
  const fl=1.2+.22*(1-lift),th=s*(.16*a*(1-fe)+fl*fe+(1.52-fl)*l);R.hip={x:hx,y:hy};R.th=th;
  const shc=pkL(R.hip,th,0,-PKR.to+8),ext=th-s*.12*lift+s*.08*(1-lift),ha=pkL(shc,ext,0,-68);R.hands=[pkL(ha,ext,-11,0),pkL(ha,ext,11,0)];
  const tr=th+Math.PI,ft=pkL(R.hip,tr,0,-70),tf=[pkL(ft,tr,-17,0),pkL(ft,tr,17,0)],k=pkSm((p-.06)/.36),st0=[{x:x0-30,y:gy},{x:x0+30,y:gy}];
  R.feet=[0,1].map(i=>pkLp(st0[i],tf[i],k));R.kb=[-s,-s];R.eb=[s,s];R.mood=1;R.ha=th*.8;return R}
 if(st==='jump'){const j=Math.sin(Math.PI*pkCl(P.p/.85));R.hip={x:x0,y:gy-72-84*j};R.feet=[{x:x0-18,y:Math.min(gy,R.hip.y+64)},{x:x0+18,y:Math.min(gy,R.hip.y+64)}];R.kb=[-1,1];
  const shc=pkL(R.hip,0,0,-PKR.to);R.hands=[{x:shc.x-22,y:shc.y-66},{x:shc.x+22,y:shc.y-66}];R.eb=[1,-1];R.mood=1;return R}
 if(st==='block'){const k=pkEo(P.p/.28);R.hip={x:x0,y:gy-72+28*k};R.feet=[{x:x0-30-48*k,y:gy},{x:x0+30+48*k,y:gy}];R.hands=[{x:x0-46-30*k,y:gy-34-18*(1-k)},{x:x0+46+30*k,y:gy-34-18*(1-k)}];R.eb=[-1,1];R.mood=1;return R}
 if(st==='celebrate'){const j=Math.abs(Math.sin(t*7.5)),x=x0+(P.x||0);R.hip={x,y:gy-72-24*j};R.feet=[{x:x-24,y:Math.min(gy,R.hip.y+74)},{x:x+24,y:Math.min(gy,R.hip.y+74)}];
  const shc=pkL(R.hip,0,0,-PKR.to),w=Math.sin(t*15)*6;R.hands=[{x:shc.x-50,y:shc.y-54+w},{x:shc.x+50,y:shc.y-54-w}];R.eb=[1,-1];R.mood=2;return R}
 if(st==='down'){const D=pkKeeperPose(x0,gy,{st:'dive',s:P.s,p:1,lift:0,amt:P.amt},t),pd=Math.abs(Math.sin(t*9));D.hands[1]={x:D.hands[1].x,y:D.hands[1].y-22*pd};D.mood=1;return D}
 if(st==='headhands'){const D=pkKeeperPose(x0,gy,{st:'ready',x:P.x},t),sc=pkL(D.hip,0,0,-PKR.to-26);D.hands=[{x:sc.x-24,y:sc.y-8},{x:sc.x+24,y:sc.y-8}];D.eb=[1,-1];D.mood=1;return D}
 return pkKeeperPose(x0,gy,{st:'ready'},t)}
/* ---------- kicker poses (back view; X,Y = where the feet stand) ---------- */
function pkKickerPose(X,Y,P,t){if(P.blend)return pkPoseLerp(pkKickerPose(X,Y,P.blend[0],t),pkKickerPose(X,Y,P.blend[1],t),P.blend[2]);
 const st=P.st||'idle',R={th:0,look:0,mood:0,kb:[1,-1],eb:[1,-1],ha:0};
 if(st==='idle'){const bo=Math.sin(t*3)*1.6;R.hip={x:X,y:Y-74+bo};R.feet=[{x:X-21,y:Y},{x:X+21,y:Y}];R.hands=[{x:X-38,y:R.hip.y-8},{x:X+38,y:R.hip.y-8}];return R}
 if(st==='run'){const f=P.f,up=Math.abs(Math.sin(f))*7,lL=Math.max(0,Math.sin(f))*26,lR=Math.max(0,-Math.sin(f))*26;R.hip={x:X,y:Y-76-up};R.th=Math.sin(f)*.05;
  R.feet=[{x:X-16,y:Y-lL},{x:X+16,y:Y-lR}];R.hands=[{x:X-36,y:R.hip.y-12-lR*.8},{x:X+36,y:R.hip.y-12-lL*.8}];return R}
 if(st==='kick'){const k=P.k,K=[[0,{x:20,y:0}],[.3,{x:28,y:-60}],[.42,{x:64,y:-46}],[.7,{x:42,y:-118}],[1,{x:30,y:-4}]];let fo=K[0][1];
  for(let i=1;i<K.length;i++){if(k<=K[i][0]){const u=pkSm((k-K[i-1][0])/(K[i][0]-K[i-1][0]));fo=pkLp(K[i-1][1],K[i][1],u);break}fo=K[i][1]}
  const bal=pkSm((k-.15)/.25)*(1-pkSm((k-.85)/.15));R.hip={x:X+8*pkSm(k/.42),y:Y-74+7*Math.sin(Math.PI*pkCl(k))};R.th=k<.42?-.12*pkSm(k/.42):-.12+.32*pkSm((k-.42)/.35);
  R.feet=[{x:X-14,y:Y},{x:X+fo.x,y:Y+fo.y}];R.kb=[1,k<.36?1:-1];R.hands=[{x:X-38-40*bal,y:R.hip.y-8-34*bal},{x:X+38+10*bal,y:R.hip.y-8+14*bal}];return R}
 if(st==='celebrate'){const j=Math.abs(Math.sin(t*7.5));R.hip={x:X,y:Y-74-22*j};R.feet=[{x:X-22,y:Math.min(Y,R.hip.y+74)},{x:X+22,y:Math.min(Y,R.hip.y+74)}];
  const shc=pkL(R.hip,0,0,-PKR.to),w=Math.sin(t*15)*6;R.hands=[{x:shc.x-48,y:shc.y-56+w},{x:shc.x+48,y:shc.y-56-w}];R.eb=[1,-1];return R}
 if(st==='headhands'){const D=pkKickerPose(X,Y,{st:'idle'},t),sc=pkL(D.hip,0,0,-PKR.to-26);D.hip.y+=4;D.hands=[{x:sc.x-24,y:sc.y-4},{x:sc.x+24,y:sc.y-4}];D.th=Math.sin(t*2)*.04;return D}
 return pkKickerPose(X,Y,{st:'idle'},t)}
/* ---------- drawing a rigged character ---------- */
function pkBackHead(g,id,t){
 if(id==='moss'){g.fillStyle='#6aae3e';g.beginPath();g.ellipse(0,0,42,40,0,0,TAU);g.fill();pkOut(g,3.4);g.fillStyle='#3a8a2a';g.beginPath();g.moveTo(-6,-40);for(let i=0;i<5;i++){g.lineTo(-4,-30+i*12);g.lineTo(8,-26+i*12)}g.lineTo(6,-40);g.closePath();g.fill();pkOut(g,2);
  for(const k of [-1,1]){g.fillStyle='#5a9a34';g.beginPath();g.moveTo(k*36,-4);g.lineTo(k*58,-16);g.lineTo(k*40,12);g.closePath();g.fill();pkOut(g,3)}}
 else if(id==='gloop'){const w=Math.sin(t*3)*2;g.fillStyle='rgba(90,216,160,.96)';g.beginPath();g.moveTo(-44,30);g.quadraticCurveTo(-50,-30+w,0,-48);g.quadraticCurveTo(50,-30-w,44,30);g.quadraticCurveTo(0,38,-44,30);g.fill();pkOut(g,3.4);g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(20,-24,8,14,.5,0,TAU);g.fill()}
 else if(id==='grim'){g.fillStyle='#7a7298';g.beginPath();g.moveTo(-42,-40);g.lineTo(40,-44);g.lineTo(46,30);g.lineTo(-44,34);g.closePath();g.fill();pkOut(g,3.4);g.fillStyle=`rgba(140,220,255,${.6+.4*Math.sin(t*4)})`;g.font='bold 18px serif';g.textAlign='center';g.fillText('ᛉ',0,6)}
 else{g.fillStyle='#c8ccdf';g.beginPath();g.ellipse(0,0,40,42,0,0,TAU);g.fill();pkOut(g,3.4);g.fillStyle='#a8aec8';g.beginPath();g.ellipse(-10,6,20,30,0,0,TAU);g.fill();g.fillStyle='#ffd45a';g.beginPath();g.moveTo(-4,-40);g.quadraticCurveTo(26,-66,40,-30);g.quadraticCurveTo(22,-44,4,-34);g.closePath();g.fill();pkOut(g,2.4)}}
function pkRigDraw(g,R,o,t,back,sc){g.save();if(sc&&sc!==1){const p=R.feet[0].y>R.feet[1].y?R.feet[0]:R.feet[1];g.translate(R.hip.x,p.y);g.scale(sc,sc);g.translate(-R.hip.x,-p.y)}
 const th=R.th,hip=R.hip,hL=pkL(hip,th,-PKR.hw,0),hR=pkL(hip,th,PKR.hw,0),sL=pkL(hip,th,-PKR.sw,-PKR.to+12),sR=pkL(hip,th,PKR.sw,-PKR.to+12);
 const lg=[pkIK(hL,R.feet[0],PKR.th,PKR.sh,R.kb[0]),pkIK(hR,R.feet[1],PKR.th,PKR.sh,R.kb[1])],ar=[pkIK(sL,R.hands[0],PKR.ua,PKR.fa,R.eb[0]),pkIK(sR,R.hands[1],PKR.ua,PKR.fa,R.eb[1])];
 const kit=o.kit,kit2=o.kit2,skin=o.skin||o.col||'#c8ccdf';
 /* ground shadow */g.fillStyle='rgba(0,0,0,.26)';g.beginPath();g.ellipse(hip.x,Math.max(R.feet[0].y,R.feet[1].y)+3,46+Math.abs(Math.sin(th))*40,9,0,0,TAU);g.fill();
 /* legs: tights, socks, boots */
 [[hL,lg[0]],[hR,lg[1]]].forEach(([h,l])=>{pkLimb(g,[h,l.j,l.e],17,'#221c4a');const m=pkLp(l.j,l.e,.3);pkLimb(g,[m,l.e],16,kit);g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=3;g.beginPath();const m2=pkLp(l.j,l.e,.42),m3=pkLp(l.j,l.e,.47);g.moveTo(m2.x,m2.y);g.lineTo(m3.x,m3.y);g.stroke();
  const a=Math.atan2(l.e.y-l.j.y,l.e.x-l.j.x);g.save();g.translate(l.e.x,l.e.y);g.rotate(a-Math.PI/2);g.fillStyle='#14102a';g.beginPath();g.ellipse(0,5,11,12,0,0,TAU);g.fill();pkOut(g,2.4);g.fillStyle='#ffd45a';g.fillRect(-7,1,14,3);g.restore()});
 /* shorts and shirt (rotated with the torso) */
 g.save();g.translate(hip.x,hip.y);g.rotate(th);
 g.fillStyle='#2a2460';g.beginPath();g.roundRect(-25,-12,50,26,9);g.fill();pkOut(g,3);g.fillStyle=kit2;g.fillRect(-25,-1,6,13);g.fillRect(19,-1,6,13);
 g.beginPath();g.moveTo(-23,-8);g.quadraticCurveTo(-30,-PKR.to*.55,-29,-PKR.to+4);g.quadraticCurveTo(0,-PKR.to-6,29,-PKR.to+4);g.quadraticCurveTo(30,-PKR.to*.55,23,-8);g.quadraticCurveTo(0,-3,-23,-8);g.closePath();
 const q=g.createLinearGradient(-30,0,30,0);q.addColorStop(0,pkMix(kit,'#ffffff',.18));q.addColorStop(.6,kit);q.addColorStop(1,pkMix(kit,'#12081f',.25));g.fillStyle=q;g.fill();pkOut(g,3.2);
 g.save();g.clip();g.fillStyle=kit2;g.fillRect(-32,-PKR.to,9,PKR.to);g.fillRect(23,-PKR.to,9,PKR.to);g.fillRect(-32,-PKR.to-2,64,7);g.restore();
 g.textAlign='center';g.textBaseline='middle';g.lineJoin='round';
 if(back){g.font='800 10px Poppins,sans-serif';g.fillStyle='#fff8e0';g.fillText(o.n.toUpperCase(),0,-PKR.to+16);g.font="400 32px 'Pirata One',Georgia,serif";g.lineWidth=5;g.strokeStyle=PKO;g.strokeText(String(o.num),0,-PKR.to*.42);g.fillText(String(o.num),0,-PKR.to*.42)}
 else{g.font="400 30px 'Pirata One',Georgia,serif";g.lineWidth=5;g.strokeStyle=PKO;g.strokeText(String(o.num),0,-PKR.to*.45);g.fillStyle='#fff8e0';g.fillText(String(o.num),0,-PKR.to*.45);
  g.fillStyle='#ffd45a';g.beginPath();g.arc(-13,-PKR.to+18,4,0,TAU);g.fill();pkOut(g,1.6)}
 g.restore();
 /* head */
 const hp=pkL(hip,th,0,-PKR.to-20);g.save();g.translate(hp.x,hp.y);g.rotate(R.ha||th*.5);g.scale(PKR.hd,PKR.hd);if(back)pkBackHead(g,o.id,t);else pkHead(g,o.id,R.look||0,R.mood||0,t);g.restore();
 /* arms (in front of the body), gloves or fists */
 [[sL,ar[0]],[sR,ar[1]]].forEach(([s,a])=>{pkLimb(g,[s,a.j,a.e],15,kit);const cf=pkLp(a.j,a.e,.78);pkLimb(g,[cf,a.e],15,kit2);const ang=Math.atan2(a.e.y-a.j.y,a.e.x-a.j.x);
  if(back){g.fillStyle=skin;g.beginPath();g.arc(a.e.x,a.e.y,9,0,TAU);g.fill();pkOut(g,2.6)}else{g.save();g.translate(a.e.x,a.e.y);g.rotate(ang+Math.PI/2);pkGlove(g,0,-6,.78,'#ffd45a');g.restore()}});
 g.restore()}
/* ---------- particles and crowd flashes ---------- */
function pkFxAdd(L,x,y,kind,n){for(let i=0;i<n;i++){const a=kind==='dust'?-Math.PI*(.1+.8*Math.random()):Math.random()*TAU,v=kind==='spark'?160+Math.random()*220:kind==='turf'?90+Math.random()*140:30+Math.random()*60;
  L.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-(kind==='turf'?120:0),l:1,d:kind==='dust'?.9+Math.random()*.5:kind==='spark'?.35+Math.random()*.25:.7,s:kind==='dust'?8+Math.random()*10:kind==='turf'?3+Math.random()*3:2,k:kind})}if(L.length>160)L.splice(0,L.length-160)}
function pkFxStep(L,dt){for(const p of L){p.l-=dt/p.d;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.k==='turf')p.vy+=520*dt;else if(p.k==='dust'){p.vx*=.96;p.vy*=.96;p.s+=dt*14}else p.vy+=200*dt}for(let i=L.length-1;i>=0;i--)if(L[i].l<=0)L.splice(i,1)}
function pkFxDraw(g,L){for(const p of L){const a=Math.max(0,p.l);if(p.k==='dust'){g.fillStyle=`rgba(214,196,160,${(a*.45).toFixed(3)})`;g.beginPath();g.arc(p.x,p.y,p.s,0,TAU);g.fill()}
  else if(p.k==='turf'){g.fillStyle=`rgba(70,160,70,${a.toFixed(3)})`;g.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s*1.6)}
  else{g.strokeStyle=`rgba(255,236,150,${a.toFixed(3)})`;g.lineWidth=2.6;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(p.x-p.vx*.04,p.y-p.vy*.04);g.stroke()}}}
function pkFlashes(g,t,cheer){const n=cheer>0?14:5;for(let i=0;i<40;i++){const r=pkRnd(i+400),ph=(t*(.35+r*.4)+r*7)%1;if(i>=n*3)break;if(ph>.05)continue;const x=40+pkRnd(i+500)*1000,y=120+pkRnd(i+600)*170;
  g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(x,y,0,x,y,16);q.addColorStop(0,'rgba(255,255,255,.95)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(x-16,y-16,32,32);g.restore()}}
/* ---------- 9.8c styles: the shoot-out scoreboard, keeper cards, ladder values ---------- */
{const st=document.createElement('style');st.textContent=`
.pksb{position:absolute;left:50%;top:12px;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:5px;padding:7px 16px 8px;border-radius:16px;background:linear-gradient(180deg,#1e1650f2,#0c0824f4);border:2px solid #ffd45a;box-shadow:0 0 0 2px #12081f,0 8px 18px #000a;pointer-events:none}
.pksb small{font:800 10px var(--ui);letter-spacing:.32em;color:#ffd45a}
.pksbd{display:flex;gap:5px}.pksbd i{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;font:900 12px var(--ui);font-style:normal;color:#fff;border:2px solid #12081f;background:#3a3070;transition:transform .25s cubic-bezier(.34,1.56,.64,1)}
.pksbd i.sh{background:#40368a}.pksbd i.sv{background:#24407a}.pksbd i.bt{background:#7a5a10;color:#ffd45a}
.pksbd i.w{background:#2fb860}.pksbd i.l{background:#d0304a}.pksbd i.cur{background:#ffd45a;color:#3a1a04;transform:scale(1.22);box-shadow:0 0 0 3px #ffd45a55}
.pksb b{font:800 13px var(--ui);letter-spacing:.12em;text-transform:uppercase;color:#fff8e8}
.pksb b.save{color:#9fe8ff}.pksb b.boot{color:#ffd45a}.pksb b.pop{animation:pkpop .45s cubic-bezier(.34,1.56,.64,1)}
.pktell{max-width:270px}.pkhint{top:96px}
.pkcap{margin:-4px 0 2px;text-align:center;font:600 12px var(--ui);color:#a99be0}.pkcap b{color:#ffd45a}
.pkr{gap:6px}.pkr span{flex:1;font:600 11.5px var(--ui)}.pkr b{font:800 15px var(--ui)}.pkr u{text-decoration:none;min-width:62px;text-align:right;font:700 11.5px var(--ui);color:#c4badf}.pkr u.mx{color:#ffd45a}
.pkr.next u{color:#5a3a04}.pkr.done u{color:#9affb8}
.pkleft h4{margin:0 0 2px 4px;font:800 11px var(--ui);letter-spacing:.24em;text-transform:uppercase;color:#a99be0}
.pkop{flex-direction:row;align-items:center;text-align:left;gap:6px;padding:6px 10px 6px 4px}
.pkop canvas{width:84px;height:84px;flex:none}.pkop span{display:flex;flex-direction:column;gap:1px;min-width:0}
.pkop b{font-size:22px}.pkop small{font-size:11px}.pkop em{font-size:11.5px}.pkdf{font-style:normal;color:#ffd45a;font-size:12px;letter-spacing:.1em}
.pkop.on{box-shadow:0 0 0 2px #ffd45a55,0 8px 18px #0008}`;document.head.appendChild(st)}
