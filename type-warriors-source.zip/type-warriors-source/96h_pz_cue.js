/* ===== 9.4 THE CROOKED CUE: cues, hands, chalk and the aim guide (96h) =====
   Cue sprites are baked once per skin (pointing right, tip at x = 0 of the sprite's right end). Everything is drawn with transforms. */
const PZ_CUE={L:470,cache:{}};
function pzCueSprite(id){if(PZ_CUE.cache[id])return PZ_CUE.cache[id];const sk=PZ_CUES.find(c=>c.id===id)||PZ_CUES[0],L=PZ_CUE.L,S=2,W=(L+22)*S,H=30*S,c=pzCv(W,H),g=c.getContext('2d');
 g.scale(S,S);g.translate(L+10,15);/* tip of the cue at x=10 -> after this, tip is at x=0 of the drawing space, butt at -L */g.lineJoin='round';g.lineCap='round';
 const wd=x=>{/* half-thickness at distance x behind the tip (taper) */return x<-L*.58?(3.0+(-x-L*.58)/(L*.42)*4.6):(2.5+(-x)/(L*.58)*.7)};
 const body=(x0,x1,fill)=>{g.fillStyle=fill;g.beginPath();g.moveTo(x0,-wd(x0));g.lineTo(x1,-wd(x1));g.lineTo(x1,wd(x1));g.lineTo(x0,wd(x0));g.closePath();g.fill()};
 /* shadow underneath */
 g.fillStyle='rgba(0,0,0,.22)';g.beginPath();g.moveTo(0,-1);g.lineTo(-L,-6);g.lineTo(-L,9);g.lineTo(0,5);g.fill();
 /* shaft (maple, tip colour to shaft colour) */
 body(-26,-L*.58,pzLin(g,-26,0,-L*.58,0,[[0,sk.a],[1,sk.b]]));
 for(let i=0;i<7;i++){g.strokeStyle='rgba(90,50,10,.16)';g.lineWidth=.6;g.beginPath();const y=(i-3)*.9;g.moveTo(-28,y*.9);g.lineTo(-L*.58,y*1.05);g.stroke()}
 /* ferrule and tip */
 g.fillStyle='#f8f4e8';g.beginPath();g.roundRect(-26,-2.6,18,5.2,1.6);g.fill();g.fillStyle='rgba(0,0,0,.14)';g.fillRect(-26,.6,18,2);
 g.fillStyle='#3a86e8';g.beginPath();g.roundRect(-8.5,-2.5,8.5,5,2.2);g.fill();g.fillStyle='rgba(255,255,255,.55)';g.fillRect(-7,-1.8,5,1.1);
 /* the joint ring */
 g.fillStyle='#d8a03a';g.fillRect(-L*.58-3,-wd(-L*.58)-.4,6,wd(-L*.58)*2+.8);g.fillStyle='rgba(255,248,210,.7)';g.fillRect(-L*.58-3,-wd(-L*.58)-.4,6,1.2);
 /* wrap */
 const w0=-L*.58-3,w1=-L*.58-116;body(w0,w1,sk.wrap);for(let i=0;i<24;i++){const x=w0-i*4.7;g.strokeStyle='rgba(255,255,255,.10)';g.lineWidth=.8;g.beginPath();g.moveTo(x,-wd(x));g.lineTo(x-3.5,wd(x));g.stroke();g.strokeStyle='rgba(0,0,0,.25)';g.beginPath();g.moveTo(x-2,-wd(x));g.lineTo(x-5.5,wd(x));g.stroke()}
 /* butt */
 const b0=w1,b1=-L+6;body(b0,b1,pzLin(g,0,-8,0,8,[[0,sk.d],[.4,sk.c],[1,sk.c]]));
 g.fillStyle=pzLin(g,0,-8,0,8,[[0,'rgba(255,255,255,.28)'],[.5,'rgba(255,255,255,0)'],[1,'rgba(0,0,0,.3)']]);g.beginPath();g.moveTo(b0,-wd(b0));g.lineTo(b1,-wd(b1));g.lineTo(b1,wd(b1));g.lineTo(b0,wd(b0));g.closePath();g.fill();
 for(let k=0;k<4;k++){const x=b0-26-k*52;g.fillStyle=sk.d;g.strokeStyle='rgba(0,0,0,.5)';g.lineWidth=.8;g.beginPath();g.moveTo(x,0);g.lineTo(x-10,-wd(x)*.55);g.lineTo(x-20,0);g.lineTo(x-10,wd(x)*.55);g.closePath();g.fill();g.stroke()}
 g.fillStyle='#d8a03a';g.fillRect(b0-2,-wd(b0)-.4,4,wd(b0)*2+.8);g.fillRect(b1+10,-wd(b1+10)-.4,3,wd(b1+10)*2+.8);
 /* bumper */
 g.fillStyle='#14101a';g.beginPath();g.roundRect(-L,-wd(-L+6)-.8,8,(wd(-L+6)+.8)*2,3);g.fill();
 /* outline and top highlight */
 g.strokeStyle=PZ_O;g.lineWidth=1.5;g.beginPath();g.moveTo(-8.5,-2.5);g.lineTo(-26,-2.6);g.lineTo(-L*.58,-wd(-L*.58));g.lineTo(-L*.58-116,-wd(-L*.58-116));g.lineTo(-L+6,-wd(-L+6));g.lineTo(-L,-wd(-L+6));g.lineTo(-L,wd(-L+6));g.lineTo(-L+6,wd(-L+6));g.lineTo(-L*.58-116,wd(-L*.58-116));g.lineTo(-L*.58,wd(-L*.58));g.lineTo(-26,2.6);g.lineTo(-8.5,2.5);g.stroke();
 g.strokeStyle='rgba(255,255,255,.34)';g.lineWidth=.9;g.beginPath();g.moveTo(-28,-1.9);g.lineTo(-L*.58,-wd(-L*.58)+.7);g.stroke();
 return PZ_CUE.cache[id]={c,W,H,L,sk}}
/* draw the cue with its tip at the origin, then back by `gap`; ang = direction the cue points */
function pzDrawCue(g,x,y,ang,gap,skinId,alpha){const s=pzCueSprite(skinId);g.save();g.translate(x,y);g.rotate(ang);g.translate(-gap,0);if(alpha!=null&&alpha<1)g.globalAlpha=alpha;
 g.drawImage(s.c,-(s.L+10),-15,s.W/2,s.H/2);g.restore()}
/* the butt-end position of the cue (for the gripping hand) */
const pzCueButt=(x,y,ang,gap,L)=>({x:x-Math.cos(ang)*(gap+(L||PZ_CUE.L)*.9),y:y-Math.sin(ang)*(gap+(L||PZ_CUE.L)*.9)});
/* a stylised hand: kind 'bridge' (fingers fanned on the cloth around the shaft) or 'grip' (a fist round the butt with a cuff). local +x = cue direction */
function pzHand(g,x,y,ang,skin,kind,cuff){g.save();g.translate(x,y);g.rotate(ang);g.lineJoin='round';
 const sh=pzMix(skin,'#000000',.28),hi=pzMix(skin,'#ffffff',.3),ln=(rx,ry,cx,cy,rot,f)=>{g.fillStyle=f||skin;g.beginPath();g.ellipse(cx,cy,rx,ry,rot||0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.5;g.stroke()};
 if(kind==='bridge'){g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.ellipse(-4,7,22,13,0,0,TAU);g.fill();
  ln(15,10.5,-9,1,0,sh);ln(14,9,-8,-1,0,skin);
  ln(11,3.8,4,-10,-.55);ln(12,3.8,9,-4,-.18);ln(12,3.8,9,5,.18);ln(11,3.8,4,11,.55);
  /* the thumb arches over the shaft */
  g.fillStyle=skin;g.beginPath();g.ellipse(3,-1,10.5,4.4,-.12,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.5;g.stroke();g.fillStyle=hi;g.beginPath();g.ellipse(2,-2.4,6,1.5,-.12,0,TAU);g.fill()}
 else{/* the cuff, then the fist */
  if(cuff){/* a forearm in the sleeve colour that fades away behind the hand, as if it reaches in from outside the table */
   const fa=g.createLinearGradient(-30,0,-170,0);fa.addColorStop(0,cuff);fa.addColorStop(.55,cuff);fa.addColorStop(1,'rgba(0,0,0,0)');
   g.save();g.globalAlpha=Math.max(0,g.globalAlpha);g.fillStyle=fa;g.beginPath();g.moveTo(-28,-12);g.lineTo(-170,-19);g.lineTo(-170,19);g.lineTo(-28,12);g.closePath();g.fill();
   const fo=g.createLinearGradient(-30,0,-170,0);fo.addColorStop(0,'rgba(18,8,31,1)');fo.addColorStop(1,'rgba(18,8,31,0)');g.strokeStyle=fo;g.lineWidth=2;g.beginPath();g.moveTo(-28,-12);g.lineTo(-170,-19);g.moveTo(-28,12);g.lineTo(-170,19);g.stroke();g.restore();
   g.fillStyle=cuff;g.beginPath();g.roundRect(-34,-14,24,28,5);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();g.fillStyle='rgba(255,255,255,.16)';g.fillRect(-32,-11,3,22);g.fillStyle='#d8a03a';g.fillRect(-14,-14,4,28)}
  ln(14,12,-4,0,0,sh);g.fillStyle=skin;g.beginPath();g.roundRect(-16,-11,30,22,9);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.6;g.stroke();
  for(let i=0;i<4;i++){g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=1.2;g.beginPath();g.moveTo(2,-8+i*5.3);g.lineTo(11,-8+i*5.3);g.stroke()}
  g.fillStyle=hi;g.beginPath();g.ellipse(-3,-8,9,2.2,0,0,TAU);g.fill();ln(7,3.6,-1,-12,.1)}
 g.restore()}
/* chalk cube: a little blue cube with a worn corner, drawn upright at (x,y) with a twist */
function pzChalk(g,x,y,rot,s){g.save();g.translate(x,y);g.rotate(rot||0);g.scale(s||1,s||1);g.fillStyle='#2c64c8';g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.roundRect(-10,-10,20,20,4);g.fill();g.stroke();g.fillStyle='#5a9aff';g.beginPath();g.roundRect(-10,-10,20,8,4);g.fill();g.fillStyle='#e8f0ff';g.beginPath();g.ellipse(0,5,6,3,0,0,TAU);g.fill();g.restore()}
/* ---- aim geometry (pure, in table px) ---- */
/* first thing a cue ball hits when it travels from (x,y) along (dx,dy): a ball, or a cushion line */
function pzRay(B,x,y,dx,dy,skipId){const R=PZ_PHY.R,PW=PZ_PHY.W,PH=PZ_PHY.H;let best=null;
 for(const b of B){if(!b.on||b.id===skipId)continue;const fx=b.x-x,fy=b.y-y,t=fx*dx+fy*dy;if(t<=0)continue;const d2=fx*fx+fy*fy-t*t,r2=4*R*R;if(d2>=r2)continue;const th=t-Math.sqrt(r2-d2);if(th>0&&(!best||th<best.t))best={type:'ball',id:b.id,t:th,gx:x+dx*th,gy:y+dy*th,b}}
 let tr=1e9,nx=0,ny=0;if(dx>1e-6){const t=(PW-R-x)/dx;if(t<tr){tr=t;nx=-1;ny=0}}if(dx<-1e-6){const t=(R-x)/dx;if(t<tr){tr=t;nx=1;ny=0}}
 if(dy>1e-6){const t=(PH-R-y)/dy;if(t<tr){tr=t;nx=0;ny=-1}}if(dy<-1e-6){const t=(R-y)/dy;if(t<tr){tr=t;nx=0;ny=1}}
 if(tr>0&&(!best||tr<best.t))best={type:'rail',t:tr,gx:x+dx*tr,gy:y+dy*tr,nx,ny};return best}
/* which pocket does an object ball heading along (dx,dy) from b point at? returns the pocket index with the smallest angle, or -1 */
function pzPocketToward(bx,by,dx,dy){let bi=-1,ba=.5;const P=PZ_PHY;for(let k=0;k<6;k++){const [ax,ay]=PZ_AIM[k],vx=ax-bx,vy=ay-by,l=Math.hypot(vx,vy)||1,c=(vx*dx+vy*dy)/l;if(c<=0)continue;const a=Math.acos(Math.min(1,c));if(a<ba){ba=a;bi=k}}return bi}
/* draw the guide. mode 'full' | 'short' | 'pro'. returns {hit,pocket} for the HUD and the 8-ball auto-call */
function pzDrawGuide(g,B,ang,mode,t,spinB){const cue=B[0],R=PZ_PHY.R,G=PZ_G,dx=Math.cos(ang),dy=Math.sin(ang),h=pzRay(B,cue.x,cue.y,dx,dy,0),out={hit:h,pocket:-1};if(!h)return out;
 g.save();g.translate(G.x,G.y);g.lineCap='round';
 const dash=(x0,y0,x1,y1,col,lw,gap)=>{g.strokeStyle=col;g.lineWidth=lw;g.setLineDash(gap?[9,9]:[]);g.lineDashOffset=-(t*26%18);g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.setLineDash([])};
 /* the aim line from the cue ball to the ghost ball (or the cushion) */
 const sx=cue.x+dx*(R+3),sy=cue.y+dy*(R+3);dash(sx,sy,h.gx,h.gy,'rgba(0,0,0,.3)',3.6,true);dash(sx,sy,h.gx,h.gy,'rgba(255,255,255,.82)',2,true);
 if(h.type==='ball'){const ob=h.b;
  /* ghost ball */
  g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=2;g.beginPath();g.arc(h.gx,h.gy,R,0,TAU);g.stroke();g.fillStyle='rgba(255,255,255,.1)';g.beginPath();g.arc(h.gx,h.gy,R,0,TAU);g.fill();
  const ux=ob.x-h.gx,uy=ob.y-h.gy,ul=Math.hypot(ux,uy)||1,ox=ux/ul,oy=uy/ul;
  out.pocket=pzPocketToward(ob.x,ob.y,ox,oy);
  if(mode!=='pro'){const len=mode==='full'?190:70;
   /* the object ball's path (gold), reflecting once off a cushion in full mode */
   const r2=pzRay(B,ob.x,ob.y,ox,oy,ob.id);let L1=len,ex=ob.x+ox*len,ey=oy*len+ob.y;
   if(r2&&r2.t<len){ex=r2.gx;ey=r2.gy;L1=r2.t}
   dash(ob.x+ox*R,ob.y+oy*R,ex,ey,'rgba(255,212,90,.95)',2.6,false);g.fillStyle='rgba(255,212,90,.95)';g.beginPath();g.arc(ex,ey,2.8,0,TAU);g.fill();
   if(mode==='full'&&r2&&r2.type==='rail'&&r2.t<len){const dd=ox*r2.nx+oy*r2.ny,rx=ox-2*dd*r2.nx,ry=oy-2*dd*r2.ny,rem=len-r2.t;dash(r2.gx,r2.gy,r2.gx+rx*rem,r2.gy+ry*rem,'rgba(255,212,90,.5)',2,true)}
   /* the cue ball's path after contact: the tangent line, bent forward (follow) or back (draw) by the spin */
   if(mode==='full'){const tx=-oy,ty=ox,side=(dx*tx+dy*ty)>=0?1:-1,cut=Math.abs(dx*ox+dy*oy);let ax=tx*side,ay=ty*side;const bend=(spinB||0)*.55*cut;ax=ax*(1-Math.abs(bend)*.4)+dx*bend;ay=ay*(1-Math.abs(bend)*.4)+dy*bend;const al=Math.hypot(ax,ay)||1;ax/=al;ay/=al;
    const ln=Math.max(18,92*(1-cut*.85));dash(h.gx+ax*R,h.gy+ay*R,h.gx+ax*(R+ln),h.gy+ay*(R+ln),'rgba(159,232,255,.85)',2.2,true)}}}
 else{/* a cushion first: show the rebound */
  g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.arc(h.gx,h.gy,3,0,TAU);g.fill();
  if(mode!=='pro'){const dd=dx*h.nx+dy*h.ny,rx=dx-2*dd*h.nx,ry=dy-2*dd*h.ny,rem=mode==='full'?150:60;dash(h.gx,h.gy,h.gx+rx*rem,h.gy+ry*rem,'rgba(255,255,255,.42)',2,true)}}
 g.restore();return out}
