/* ===== 9.6: Mines max bet 2,500 (was 5,000; the 15,000 payout cap stays) (96zf). casCap is a const in 65, so the cap is set after gameOpen ===== */
{const g0=gameOpen;gameOpen=function(id){const r=g0.apply(this,arguments);if(id==='mi'){CAS.cap=2500;if(CAS.bet>2500)CAS.bet=2500;const sm=ov.querySelector('.bv small');if(sm)sm.textContent='max '+cmn(2500);try{betRefresh()}catch(e){}}return r}}
